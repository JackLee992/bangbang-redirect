# 阿里云家人服务：回环部署与数据迁移

这套代码承载家人请求、配对、推送 outbox 与现有诊断；画面/操作由独立的 [原生中继服务](../../docs/ALIYUN_RELAY.md) 处理。目标是已购买的北京 ECS：Ubuntu 20.04、x86_64、2核2GB、40GB盘、固定3Mbps。大 APK 直接从 Gitee Release 下载，不经过 API，也不新增 OSS。

审核入口：[服务端产品需求](../../docs/PRD-bangbang-server.md) · [服务端技术方案](../../docs/TECHNICAL_DESIGN-bangbang-server.md)。两稿区分当前启用、已部署未启用和后续建设，不把回环部署当作正式迁移完成。

本目录代码由真实 SQLite、HTTP 回环和独立 Node 子进程验证。迁移 v3 加入数据库停写栅栏、冻结编号和原配置摘要验证，实际部署结果见 [本轮验真](../../docs/ALIYUN_VALIDATION_20261004.md)。默认只监听 `127.0.0.1:8789`，未完成当前权威全量迁移之前保持 `BANGBANG_FAMILY_API_ENABLED=false` 和诊断上传关闭。

## 运行输入与建库

推荐 Node 24 官方 Linux x64 包，按确切补丁版本下载并核对官方 `SHASUMS256.txt` 的 SHA-256。`install-node.sh 24.x.y` 提供同样的验证流程，安装到 `/opt/bangbang-node/current`，不替换系统其他 Node。SQLite API 使用 Node 22.13 已有的同步接口；22.12 需要实验标志，不宣称已在该版本运行验收。[Node 22.13 SQLite 文档](https://nodejs.org/download/release/v22.13.0/docs/api/sqlite.html)

无需 npm、Docker 或完整 Rust/Flutter 仓库。`runtime-manifest.mjs` 列出 17 个运行文件以及 systemd/环境示例的精确字节数和 SHA-256；部署时保留 `backend/` 与 `site/` 相对目录。没有静态网站、APK、测试夹具、签名材料或真实 env 文件。

```sh
node backend/aliyun/runtime-manifest.mjs
```

在独立服务用户 `bangbang` 下显式建新库。已有文件拒绝重新初始化，正常启动也不会自动创建缺失数据库。

```sh
sudo -u bangbang /opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs init --db /var/lib/bangbang/family.sqlite
```

数据库目录 700、文件 600；WAL、`synchronous=FULL`、busy timeout 5 秒。仅一个 ECS 持久化卷是权威数据源；SQLite 错误直接返回 503，不自动连接 D1/Blobs，也不在空库重新登记原用户。

将 `family.env.example` 的实际副本保存到 `/etc/bangbang/family.env`，root 所有、权限 600，填真实路径/域名、仍保留 API 和诊断关闭。实际秘密不能放入源码、命令参数、聊天或访问日志；推送缺少配置时保持未配置状态。

## systemd（无 Docker）

`bangbang-family.service` 使用 `/opt/bangbang` 指向的只读发行代码与 `/var/lib/bangbang` 私有卷，以 `bangbang` 用户运行。Node heap 上限 384MiB，服务总内存上限 768MiB；保留空间给系统和数据库。这些限制不是 1000 台同时前台的容量保证。

主入口有 URL/启动路径一致性检查；原子发行符号链接需要 `--preserve-symlinks-main`，unit 已包含它。通过 `/opt/bangbang` 别名调用 CLI 时也须使用该参数，或改用实际发行路径。命令的成功 JSON 和独立读回必须一起核对，不能只看进程退出码。

部署者先准备用户/目录与 env，再将 unit 安装到 `/etc/systemd/system/bangbang-family.service` 并执行 daemon-reload/start。示例 unit 提供自动重启、只读系统目录和去掉 Linux capabilities；没有设置会破坏 V8 JIT 的 `MemoryDenyWriteExecute`。

未设置代理秘密时，本机只读健康验证：

```sh
curl --fail --silent http://127.0.0.1:8789/api/health
```

预期包含 `ok=true`、`authority=ecs-sqlite`、`familyApiEnabled=false`。这会实际读取 SQLite 表。开启 API 前的登记/配对/日志上传仍返回 503，不公开下载或数据库文件。若配置了代理秘密，健康请求也需由可信代理注入秘密；不要把它粘到 shell 命令中。

## 当前 D1 权威迁移

先按 [完整操作单](../../docs/ALIYUN_DATA_CUTOVER.md) 完成加密演练及合法可达的目标 HTTPS。本轮真实数据的私有演练已通过，正式 HTTPS 和停写后的切换尚未完成，生产仍由 Sites D1 服务。管理工具的截断 JSON 不能作为全量快照，现有旧家人导入接口也不能导出三表。

1. 安装已验证的固定 14 项栅栏 DDL（控制表及 13 个触发器），暂停**当前 Sites**的全部业务写入口和推送调度，排空 provider 调用及旧后台任务。独立状态请求可读到真实 `pendingDispatch`；实际原子冻结提交也要求发送中记录为零。部署环境或改变本机参数不能代替数据库冻结。
2. 经受控临时授权提交冻结，取得不可通过 HTTP 修改的源 epoch。三张业务表的旧连接、旧 prepared statement 和旧 Worker 都受数据库触发器约束；其他 scope 不受影响。随后在原 Worker 中对 `production` 做完整主库分页导出，正式 v3 包必须通过前后同一栅栏及零发送中记录检查；未冻结、缺少 DDL 或 v2 演练包均不能正式激活。
3. 经独立的认证 HEAD 请求记录 digest、epoch、counts 与配置指纹，再 GET 加密包。保存私有 600 明文及密文副本，保持原诊断 HMAC 和原推送配置。冻结证据属于格式及状态校验，并不是不可伪造签名；可信摘要和 epoch 必须来自源服务，不能取待导入文件自己的字段。原 `updated_at`、`expiresAt`、撤销、永久 claims、push ownership 和已散列诊断/预算完整保留，transport etag 重建。**旧 Netlify 21 条备份不等于当前 D1**，不能用它切换新的权威。
4. ECS 停写时将这份当前快照导入。传入第二次独立源读取确认的 digest，CLI 只输出数量/摘要，不输出记录或推送 token。

   ```sh
   sudo /opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs import --db /var/lib/bangbang/family.sqlite --scope production --snapshot /私有目录/current-authority.json --expected-digest 独立核对的64位摘要 --expected-source-epoch 独立取得的源编号 --env-file /etc/bangbang/family.env --paused
   ```

   `--paused` 是部署者对实际停写状态的声明，不会替你停旧服务。示例以 root 读取 0600 配置/快照；恢复低权限服务前须核对并恢复数据目录、DB/WAL/SHM 的 bangbang 所有权及私有权限。家人每批最多32条/1MiB，诊断每批128条，都是 SQLite `BEGIN IMMEDIATE` 的真实原子事务。仅新插入，同数据幂等；不同已有状态拒绝，不提供 `force` 或覆盖。部分批次完成后失败也保持未核验，不启用 API。

5. 导入后重新完整读取 ECS 三表，核对 scope、配置指纹、总数和规范摘要，禁止目标有额外或缺失记录。仅 v3 `purpose:"cutover"` 的完整迁移可写入激活标记；v2 演练快照、v1 快照、旧标记或错误诊断散列密钥不能启用 API。再运行 CLI verify，使用同一独立可信 digest 和 epoch，保持原私有配置，另行安排轮换。源栅栏不能通过 HTTP 解冻；恢复来源必须按操作单的回退界限处理。
6. 经过独立控制流程验收才启用 ECS，移除临时迁移授权。用 `site/scripts/prepare-service-site.mjs --authority ecs` 生成并发布永久 `ecs-only` 入口：保留同一路径代理到 ECS，**不导入或写 D1**，不执行旧推送；代理或 ECS 配置全部缺失也返回失败。迁移后旧 D1 只作为不可继续写的快照参考，不能当即时数据回滚库，不发布旧 D1 构建产物来回滚。

CLI `verify` 可再次核对快照，`export` 仅用于未来已实际暂停的 ECS 权威，输出私有文件不覆盖旧备份。每份快照限制128MiB、每表100000行，超过直接拒绝，必须另审迁移方案。诊断时间按源绝对值保留，正常7日清理不更新原记录时钟。

## 代理集成约定

复用路径 `/.netlify/functions/family`、`/v1/attempts`、`/v1/summary`、`/v1/diagnostics/cleanup`、`/api/admin/family-migration`、`/api/push/dispatch`、`/api/health`。没有产品账号登录。

Sites/Caddy 经过 HTTPS 转发时配置独立 `BANGBANG_ECS_PROXY_SECRET`（32+随机字节的规范base64url），注入 `x-bangbang-proxy-secret`；原安装 `Authorization` 保留。只在此独立服务器凭据验真后接受 `x-bangbang-client-ip`，必须为单个合法 IP。来自客户端的 CF、Forwarded、X-Forwarded、X-Real-IP 一律丢弃，代理秘密和地址头不会流入核心。

`BANGBANG_PUBLIC_ORIGIN` 是核心验证浏览器 Origin 的来源。使用 `site/worker/ecs-proxy.mjs` 时，ECS 配置为与 `BANGBANG_ECS_API_ORIGIN` 一致的正式 HTTPS origin；Sites 先确认浏览器 Origin 是自身同源，才改写为 ECS origin，回应中的合法同源标头再映回 Sites。浏览器诊断上传仍被拒绝，管理员密钥保持独立。没有真实 DNS/TLS/ICP备案核验前不开放公网监听或切客户端域名。

HTTPS 反向代理配置见 [Caddy 接入准备](tls/README.md)。独立代理秘密、真实 TCP 来源及 Sites 核验地址的边界已通过真实 Caddy 和 HTTP 适配器验证。完整用例在实际 ECS 启动独立 Caddy 和目标数据库，证明迁移后的原家人身份、呼叫和诊断可经代理继续使用，并验证上游中断不会写回旧权威。测试将固定 HTTPS 目标映到回环 HTTP，未建立公网 DNS/TLS 或真实 Sites→ECS 链路。正式 Caddy 仍仅服务回环静态页，未开放 80/443 或申请公网证书。

每共享出口6000次/分钟、每完整规范设备Bearer摘要180次/分钟；伪造 secret 不占真实设备桶。诊断另保留每安装/服务分钟与每天预算。服务器每15秒运行去重推送 sweep、有界清理；维护模式两者都暂停。APNs 使用现有 Node 原生 HTTP/2 provider，真正通知送达仍需凭据与真机验收。

## 本地验真

```sh
node --test backend/aliyun/*.test.mjs
```

包含真实 SQLite 多连接 CAS、WAL 重开、事务回滚、完整 HTTP 求助/接听/原生 lease/结束/取消、请求重放拒绝、原鉴权诊断、可信代理/伪造 IP、chunked 大正文拒绝、当前全量三表迁移与冲突、独立进程 CLI、关闭/未核验库不能启用。尚未完成真实 ECS 负载、正式 Sites→ECS 代理、真机或跨网远控验收。
