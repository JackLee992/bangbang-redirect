import { constants, openSync, fstatSync, closeSync, readFileSync, writeFileSync } from "node:fs";
import { createHash, createPrivateKey, createPublicKey, webcrypto } from "node:crypto";
import { pathToFileURL } from "node:url";
import { authorityConfigurationFingerprint, authoritySnapshotDigest } from "../snapshot.mjs";
import { validFreezeEvidence } from "../../../site/worker/authority-fence.mjs";

const AAD = Buffer.from("bangbang-authority-export:BBAE1", "utf8");
const keys = ["BANGBANG_FAMILY_STORE_SCOPE", "BANGBANG_DIAGNOSTICS_HASH_SECRET",
  "BANGBANG_DIAGNOSTICS_ADMIN_SECRET", "BANGBANG_BACKUP_ADMIN_SECRET"];
function privateRead(path, max) {
  const fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || (stat.mode & 0o077) || stat.size < 1 || stat.size > max) throw new Error("invalid_transfer");
    return readFileSync(fd);
  } finally { closeSync(fd); }
}
function decode(text, min, max) {
  if (typeof text !== "string" || !/^[A-Za-z0-9_-]+$/.test(text)) throw new Error("invalid_transfer");
  const data = Buffer.from(text, "base64url");
  if (data.length < min || data.length > max || data.toString("base64url") !== text) throw new Error("invalid_transfer");
  return data;
}
export async function decryptAuthorityTransfer(envelope, privatePem, { purpose = "rehearsal" } = {}) {
  if (!["rehearsal", "cutover"].includes(purpose)) throw new Error("invalid_transfer");
  if (!envelope || Object.keys(envelope).sort().join() !== "ciphertext,format,iv,keyFingerprint,v,wrappedKey" ||
      envelope.v !== 1 || envelope.format !== "BBAE1") throw new Error("invalid_transfer");
  const privateKey = createPrivateKey(privatePem);
  if (privateKey.asymmetricKeyType !== "rsa" || privateKey.asymmetricKeyDetails.modulusLength !== 4096) throw new Error("invalid_transfer");
  const spki = createPublicKey(privateKey).export({ type: "spki", format: "der" });
  if (createHash("sha256").update(spki).digest("hex") !== envelope.keyFingerprint) throw new Error("invalid_transfer");
  const rsa = await webcrypto.subtle.importKey("pkcs8", privateKey.export({ type: "pkcs8", format: "der" }),
    { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
  const rawKey = await webcrypto.subtle.decrypt("RSA-OAEP", rsa, decode(envelope.wrappedKey, 512, 512));
  if (rawKey.byteLength !== 32) throw new Error("invalid_transfer");
  const aes = await webcrypto.subtle.importKey("raw", rawKey, "AES-GCM", false, ["decrypt"]);
  const plaintext = await webcrypto.subtle.decrypt({ name: "AES-GCM", iv: decode(envelope.iv, 12, 12), additionalData: AAD },
    aes, decode(envelope.ciphertext, 16, 8_388_608 + 16));
  const payload = JSON.parse(new TextDecoder("utf8", { fatal: true }).decode(plaintext));
  const version = purpose === "cutover" ? 3 : 2;
  if (payload?.v !== version || Object.keys(payload).sort().join() !== "configuration,snapshot,v" ||
      !payload.snapshot || payload.snapshot.v !== version ||
      payload.snapshot.purpose !== purpose || payload.snapshot.scope !== "production" ||
      !payload.configuration || typeof payload.configuration !== "object" || Array.isArray(payload.configuration) ||
      Object.keys(payload.configuration).some(key => !keys.includes(key)) ||
      payload.configuration.BANGBANG_FAMILY_STORE_SCOPE !== "production" ||
      typeof payload.configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET !== "string") throw new Error("invalid_transfer");
  for (const value of Object.values(payload.configuration)) {
    if (typeof value !== "string" || !/^[A-Za-z0-9_-]{1,512}$/.test(value)) throw new Error("invalid_transfer");
  }
  if (authorityConfigurationFingerprint(payload.configuration) !== payload.snapshot.configFingerprint ||
      authoritySnapshotDigest(payload.snapshot) !== payload.snapshot.digest ||
      purpose === "cutover" && !validFreezeEvidence(payload.snapshot.freezeEvidence, "production", { createdAt: payload.snapshot.createdAt })) {
    throw new Error("invalid_transfer");
  }
  return payload;
}
export async function saveAuthorityTransfer({ envelopePath, privateKeyPath, snapshotPath, configurationPath, purpose = "rehearsal" }) {
  const envelope = JSON.parse(privateRead(envelopePath, 12_000_000));
  const payload = await decryptAuthorityTransfer(envelope, privateRead(privateKeyPath, 16_384), { purpose });
  const configuration = { ...payload.configuration, BANGBANG_FAMILY_API_ENABLED: "false", BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "false" };
  // Exclusive creation: a rerun cannot replace the original snapshot or secret.
  writeFileSync(snapshotPath, JSON.stringify(payload.snapshot), { flag: "wx", mode: 0o600 });
  writeFileSync(configurationPath, Object.entries(configuration).map(([key, value]) => `${key}=${value}\n`).join(""),
    { flag: "wx", mode: 0o600 });
  return { ok: true, purpose, activationEligible: purpose === "cutover",
    ...(purpose === "cutover" ? { freezeEvidence: payload.snapshot.freezeEvidence } : {}),
    digest: payload.snapshot.digest, counts: payload.snapshot.counts, configFingerprint: payload.snapshot.configFingerprint };
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.umask(0o077);
  try {
    const args = process.argv.slice(2); let purpose = "rehearsal";
    if (args[0] === "--purpose") {
      args.shift(); purpose = args.shift();
      if (!["rehearsal", "cutover"].includes(purpose)) throw new Error("invalid_transfer");
    }
    const [envelopePath, privateKeyPath, snapshotPath, configurationPath, ...extra] = args;
    if (extra.length || [envelopePath, privateKeyPath, snapshotPath, configurationPath].some(path => !path?.startsWith("/"))) throw new Error("invalid_transfer");
    process.stdout.write(`${JSON.stringify(await saveAuthorityTransfer({ envelopePath, privateKeyPath, snapshotPath, configurationPath, purpose }))}\n`);
  } catch { process.stderr.write("authority_transfer_failed\n"); process.exitCode = 1; }
}
