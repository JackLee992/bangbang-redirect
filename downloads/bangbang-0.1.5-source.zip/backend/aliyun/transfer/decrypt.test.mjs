import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync, randomBytes, createHash, webcrypto } from "node:crypto";
import { mkdtempSync, rmSync, writeFileSync, readFileSync, statSync, chmodSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { SQLiteFamilyDatabase } from "../sqlite.mjs";
import { authoritySnapshotDigest, exportAuthoritySnapshot } from "../snapshot.mjs";
import { installAuthorityFence, freezeAuthority } from "../../../site/worker/authority-fence.mjs";
import { decryptAuthorityTransfer, saveAuthorityTransfer } from "./decrypt.mjs";

const rsa = generateKeyPairSync("rsa", { modulusLength: 4096 });
const privatePem = rsa.privateKey.export({ format: "pem", type: "pkcs8" });
const spki = rsa.publicKey.export({ format: "der", type: "spki" });
const random = bytes => randomBytes(bytes).toString("base64url");
const clock = 1_800_000_000_000;
const configuration = { BANGBANG_FAMILY_STORE_SCOPE: "production", BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32),
  BANGBANG_DIAGNOSTICS_ADMIN_SECRET: random(32) };
const closed = { ...configuration, BANGBANG_FAMILY_API_ENABLED: "false", BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "false" };

async function payload(t, purpose) {
  const source = new SQLiteFamilyDatabase(":memory:", { initialize: true }); t.after(() => source.close());
  await source.prepare("INSERT INTO bangbang_family_records VALUES (?, ?, ?, ?, ?)")
    .bind("production", `devices/${random(16)}`, JSON.stringify({ revision: 1, private: random(16) }), "source", 123).run();
  if (purpose === "cutover") {
    await installAuthorityFence(source); await freezeAuthority(source, { scope: "production", now: () => clock });
  }
  const snapshot = await exportAuthoritySnapshot(source, { purpose, scope: "production", apiEnabled: "false", configuration: closed, now: () => clock });
  return { v: snapshot.v, snapshot, configuration };
}
async function encrypt(payload, keyBytes = 32) {
  const rsaKey = await webcrypto.subtle.importKey("spki", spki, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
  const rawKey = randomBytes(keyBytes), aes = await webcrypto.subtle.importKey("raw", rawKey, "AES-GCM", false, ["encrypt"]);
  const iv = randomBytes(12), ciphertext = await webcrypto.subtle.encrypt({ name: "AES-GCM", iv,
    additionalData: Buffer.from("bangbang-authority-export:BBAE1") }, aes, Buffer.from(JSON.stringify(payload)));
  const wrapped = await webcrypto.subtle.encrypt("RSA-OAEP", rsaKey, rawKey);
  return { v: 1, format: "BBAE1", keyFingerprint: createHash("sha256").update(spki).digest("hex"),
    wrappedKey: Buffer.from(wrapped).toString("base64url"), iv: iv.toString("base64url"), ciphertext: Buffer.from(ciphertext).toString("base64url") };
}
function files(t, envelope) {
  const folder = mkdtempSync(join(tmpdir(), "bangbang-authority-transfer-"));
  t.after(() => rmSync(folder, { force: true, recursive: true }));
  const paths = { envelopePath: join(folder, "source.bbae.json"), privateKeyPath: join(folder, "private.pem"),
    snapshotPath: join(folder, "snapshot.json"), configurationPath: join(folder, "target.env") };
  writeFileSync(paths.envelopePath, JSON.stringify(envelope), { mode: 0o600 });
  writeFileSync(paths.privateKeyPath, privatePem, { mode: 0o600 });
  return { folder, paths };
}

test("decryption defaults to rehearsal and formal v3 proof requires explicit cutover review", async t => {
  const rehearsal = await payload(t, "rehearsal"), formal = await payload(t, "cutover");
  const rehearsalEnvelope = await encrypt(rehearsal), formalEnvelope = await encrypt(formal);
  assert.deepEqual(await decryptAuthorityTransfer(rehearsalEnvelope, privatePem), rehearsal);
  await assert.rejects(decryptAuthorityTransfer(rehearsalEnvelope, privatePem, { purpose: "cutover" }), /invalid_transfer/);
  await assert.rejects(decryptAuthorityTransfer(formalEnvelope, privatePem), /invalid_transfer/);
  assert.deepEqual(await decryptAuthorityTransfer(formalEnvelope, privatePem, { purpose: "cutover" }), formal);
});

test("legacy v2 cutover and edited rehearsal labels cannot authorize formal migration", async t => {
  const original = await payload(t, "rehearsal");
  const legacy = structuredClone(original); legacy.snapshot.purpose = "cutover";
  legacy.snapshot.digest = authoritySnapshotDigest(legacy.snapshot);
  await assert.rejects(decryptAuthorityTransfer(await encrypt(legacy), privatePem, { purpose: "cutover" }), /invalid_transfer/);
  const promoted = structuredClone(original); promoted.v = 3; promoted.snapshot.v = 3; promoted.snapshot.purpose = "cutover";
  await assert.rejects(decryptAuthorityTransfer(await encrypt(promoted), privatePem, { purpose: "cutover" }));
});

test("freeze evidence, content digest and original HMAC configuration are bound and cannot be changed independently", async t => {
  const original = await payload(t, "cutover");
  for (const mutate of [
    value => { value.snapshot.freezeEvidence.pendingDispatch = 1; },
    value => { value.snapshot.freezeEvidence.schemaDigest = "0".repeat(64); },
    value => { value.snapshot.freezeEvidence.frozenAt = clock + 1; },
    value => { value.snapshot.freezeEvidence.scope = "other"; },
    value => { value.snapshot.freezeEvidence.epoch = "A".repeat(23); },
    value => { value.snapshot.freezeEvidence.extra = true; },
    value => { value.snapshot.freezeEvidence.epoch = random(16); },
    value => { value.configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET = random(32); },
  ]) {
    const changed = structuredClone(original); mutate(changed);
    await assert.rejects(decryptAuthorityTransfer(await encrypt(changed), privatePem, { purpose: "cutover" }), /invalid_transfer/);
  }
  const badProof = structuredClone(original); badProof.snapshot.freezeEvidence.pendingDispatch = 1;
  badProof.snapshot.digest = authoritySnapshotDigest(badProof.snapshot);
  await assert.rejects(decryptAuthorityTransfer(await encrypt(badProof), privatePem, { purpose: "cutover" }), /invalid_transfer/,
    "even a recomputed content digest does not make unresolved dispatch safe");
});

test("encrypted transfer rejects ciphertext tampering, noncanonical framing and AES keys outside the 256-bit contract", async t => {
  const original = await payload(t, "cutover"), envelope = await encrypt(original);
  for (const changed of [
    { ...envelope, ciphertext: `${envelope.ciphertext[0] === "A" ? "B" : "A"}${envelope.ciphertext.slice(1)}` },
    { ...envelope, iv: envelope.iv + "=" }, { ...envelope, plaintext: original },
    { ...envelope, keyFingerprint: "0".repeat(64) }, await encrypt(original, 16),
  ]) await assert.rejects(decryptAuthorityTransfer(changed, privatePem, { purpose: "cutover" }));
});

test("private saves preserve rehearsal ineligibility and do not overwrite files or print records/secrets", async t => {
  const original = await payload(t, "rehearsal"), f = files(t, await encrypt(original));
  const result = await saveAuthorityTransfer(f.paths);
  assert.equal(result.purpose, "rehearsal"); assert.equal(result.activationEligible, false);
  for (const path of [f.paths.snapshotPath, f.paths.configurationPath]) assert.equal(statSync(path).mode & 0o777, 0o600);
  assert.equal(JSON.parse(readFileSync(f.paths.snapshotPath)).v, 2);
  assert.match(readFileSync(f.paths.configurationPath, "utf8"), /BANGBANG_FAMILY_API_ENABLED=false/);
  const before = readFileSync(f.paths.snapshotPath, "utf8");
  await assert.rejects(saveAuthorityTransfer(f.paths));
  assert.equal(readFileSync(f.paths.snapshotPath, "utf8"), before);
  for (const secret of Object.values(configuration)) {
    if (secret !== "production") assert.equal(JSON.stringify(result).includes(secret), false);
  }
  assert.equal(JSON.stringify(result).includes(original.snapshot.records[0].key), false);
});

test("file reads reject public permissions and symlinks; standalone CLI requires explicit cutover purpose", async t => {
  const original = await payload(t, "cutover"), f = files(t, await encrypt(original));
  chmodSync(f.paths.envelopePath, 0o644); await assert.rejects(saveAuthorityTransfer({ ...f.paths, purpose: "cutover" }), /invalid_transfer/);
  chmodSync(f.paths.envelopePath, 0o600);
  const link = join(f.folder, "linked.bbae.json"); symlinkSync(f.paths.envelopePath, link);
  await assert.rejects(saveAuthorityTransfer({ ...f.paths, envelopePath: link, purpose: "cutover" }));
  const cli = fileURLToPath(new URL("./decrypt.mjs", import.meta.url));
  const args = [f.paths.envelopePath, f.paths.privateKeyPath, f.paths.snapshotPath, f.paths.configurationPath];
  const run = extra => spawnSync(process.execPath, [cli, ...extra, ...args], { encoding: "utf8", timeout: 10000 });
  const denied = run([]); assert.equal(denied.status, 1); assert.equal(denied.stdout, "");
  assert.equal(denied.stderr, "authority_transfer_failed\n");
  const result = run(["--purpose", "cutover"]); assert.equal(result.status, 0, result.stderr);
  const audit = JSON.parse(result.stdout); assert.equal(audit.activationEligible, true);
  assert.deepEqual(audit.freezeEvidence, original.snapshot.freezeEvidence);
  for (const value of [configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET, original.snapshot.records[0].key, privatePem]) {
    assert.equal(`${result.stdout}${result.stderr}`.includes(value), false);
  }
});
