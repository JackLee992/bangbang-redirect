import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createServer } from "node:net";
import { SQLiteFamilyDatabase } from "../sqlite.mjs";
import { createAliyunFamilyApplication } from "../service.mjs";
import { createAliyunHTTPServer } from "../http.mjs";
import { exportAuthoritySnapshot, importAuthoritySnapshot } from "../snapshot.mjs";
import worker from "../../../site/worker/index.mjs";
import { handleECSProxyRequest } from "../../../site/worker/ecs-proxy.mjs";
import { installAuthorityFence, freezeAuthority } from "../../../site/worker/authority-fence.mjs";
import { caddyfile } from "./start.mjs";

const binary = process.env.BANGBANG_TEST_CADDY_BIN ?? "/usr/bin/caddy";
const random = bytes => randomBytes(bytes).toString("base64url");
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const origin = "https://api.bangbang.yilin.fun";

async function unusedPort() {
  const probe = createServer();
  await new Promise((resolve, reject) => { probe.once("error", reject); probe.listen(0, "127.0.0.1", resolve); });
  const port = probe.address().port;
  await new Promise(resolve => probe.close(resolve));
  return port;
}

test("frozen source migration retains a family across Sites proxy, real Caddy and ECS SQLite",
  { skip: !existsSync(binary) }, async t => {
    const folder = mkdtempSync(join(tmpdir(), "bangbang-migrated-proxy-"));
    const scope = "controlled-proxy-migration";
    const sourceFile = join(folder, "source.sqlite");
    const source = new SQLiteFamilyDatabase(sourceFile, { initialize: true });
    const target = new SQLiteFamilyDatabase(join(folder, "target.sqlite"), { initialize: true });
    let backend, child, closed;
    let logs = "";
    t.after(async () => {
      try {
        if (backend) {
          backend.closeAllConnections();
          if (backend.listening) await new Promise(resolve => backend.close(resolve));
        }
        if (child) {
          if (child.exitCode === null && child.signalCode === null) child.kill("SIGTERM");
          await Promise.race([closed, pause(2000)]);
          if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
          await closed;
        }
      } finally {
        source.close(); target.close(); rmSync(folder, { recursive: true, force: true });
      }
    });
    let timestamp = Date.now();
    const now = () => timestamp;
    t.mock.method(Date, "now", now);
    const env = { BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_API_ENABLED: "true",
      BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "true", BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32),
      BANGBANG_DIAGNOSTICS_ADMIN_SECRET: random(32), BANGBANG_PUBLIC_ORIGIN: origin };
    const sourceEnv = { ...env, DB: source };
    const elder = { id: random(16), secret: random(32), peerId: "123456789" };
    const helper = { id: random(16), secret: random(32), peerId: "987654321" };
    const pair = { pairId: random(16), capability: random(32), nonce: random(16),
      elderInstallationId: elder.id, helperInstallationId: helper.id,
      elderPeerId: elder.peerId, helperPeerId: helper.peerId, serverScope: "public-v1" };
    const familyRequest = (who, op, fields = {}) => new Request(
      "https://source.controlled.test/.netlify/functions/family", {
        method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${who.id}.${who.secret}` },
        body: JSON.stringify({ v: 1, op, ...fields }),
      });
    const oldSend = async (who, op, fields = {}) => {
      const response = await worker.fetch(familyRequest(who, op, fields), sourceEnv);
      assert.equal(response.status, 200, "controlled source family operation");
      return response.json();
    };
    for (const who of [elder, helper]) await oldSend(who, "register", { peerId: who.peerId, serverScope: pair.serverScope });
    await oldSend(helper, "pair.offer", pair);
    await oldSend(elder, "pair.confirm", { pairId: pair.pairId, capability: pair.capability, nonce: pair.nonce });
    const first = { pairId: pair.pairId, capability: pair.capability, requestId: random(16) };
    await oldSend(elder, "request.create", first);
    await oldSend(helper, "request.respond", { ...first, decision: "accept" });
    await oldSend(helper, "request.progress", { ...first, leaseMode: "native-v1" });
    await oldSend(elder, "request.end", { ...first, reason: "ended" });

    await installAuthorityFence(source);
    await freezeAuthority(source, { scope, now });
    assert.equal((await worker.fetch(familyRequest(elder, "register", {
      peerId: elder.peerId, serverScope: pair.serverScope,
    }), sourceEnv)).status, 503, "old source bindings cannot write after the persistent fence");
    const paused = { ...env, BANGBANG_FAMILY_API_ENABLED: "false", BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "false" };
    const options = { scope, configuration: paused, apiEnabled: "false", purpose: "cutover", now };
    const snapshot = await exportAuthoritySnapshot(source, options);
    assert.equal(snapshot.v, 3);
    assert.equal(snapshot.freezeEvidence.pendingDispatch, 0);
    const independentSource = await exportAuthoritySnapshot(source, options);
    assert.equal(independentSource.digest, snapshot.digest);
    const imported = await importAuthoritySnapshot(target, snapshot, { ...options,
      expectedDigest: independentSource.digest, expectedSourceEpoch: independentSource.freezeEvidence.epoch });
    assert.equal(imported.activationEligible, true);

    const proxySecret = random(32);
    const targetEnv = { ...env, BANGBANG_ECS_PROXY_SECRET: proxySecret };
    backend = createAliyunHTTPServer({
      application: createAliyunFamilyApplication({ db: target, env: targetEnv, now }), env: targetEnv,
    });
    const listen = async () => { backend.listen(0, "127.0.0.1"); await once(backend, "listening"); };
    await listen();
    const backendPort = backend.address().port;
    const local = `http://127.0.0.1:${await unusedPort()}`;
    const config = join(folder, "Caddyfile");
    writeFileSync(config, readFileSync(caddyfile, "utf8").replace(origin, local)
      .replace("127.0.0.1:8789", `127.0.0.1:${backendPort}`), { mode: 0o600 });
    child = spawn(binary, ["run", "--config", config, "--adapter", "caddyfile"], {
      env: { BANGBANG_ECS_PROXY_SECRET: proxySecret, BANGBANG_TLS_DEPLOYMENT_READY: "true",
        XDG_DATA_HOME: folder, XDG_CONFIG_HOME: folder }, stdio: ["ignore", "pipe", "pipe"],
    });
    for (const stream of [child.stdout, child.stderr]) stream.on("data", chunk => {
      if (logs.length < 1_048_576) logs += chunk.toString();
    });
    closed = new Promise(resolve => child.once("close", resolve));
    t.after(() => {
      for (const secret of [proxySecret, elder.secret, helper.secret, pair.capability]) assert.equal(logs.includes(secret), false);
    });
    let ready = false;
    for (let attempt = 0; attempt < 50; attempt++) {
      try {
        ready = (await fetch(local + "/api/health", { signal: AbortSignal.timeout(1000) })).status === 200;
        if (ready) break;
      } catch { /* Only the task-local listener is starting. */ }
      if (child.exitCode !== null || child.signalCode !== null) break;
      await pause(80);
    }
    assert.equal(ready, true, "actual task-local Caddy must start");
    const gatewayEnv = { ...env, BANGBANG_ECS_API_ORIGIN: origin, BANGBANG_ECS_PROXY_SECRET: proxySecret };
    const proxy = async request => handleECSProxyRequest(request, gatewayEnv, { required: true,
      fetchImpl: async (url, init) => {
        assert.equal(new URL(url).origin, origin);
        const response = await fetch(local + new URL(url).pathname, init);
        // Test-only transport maps the fixed HTTPS origin to loopback HTTP;
        // it does not establish public DNS, TLS or actual Sites-to-ECS reachability.
        return new Response(response.body, { status: response.status, headers: response.headers });
      },
    });
    const send = async (who, op, fields = {}) => {
      const response = await proxy(familyRequest(who, op, fields));
      return { status: response.status, body: await response.json() };
    };
    assert.equal((await send(helper, "identity.verify")).body.identity.pairs.length, 1,
      "the same install credential and saved family survive migration");
    assert.equal((await send(elder, "request.create", first)).body.request.status, "ended",
      "retrying the latest terminal request cannot restart its call");
    timestamp += 15_001;
    const second = { ...first, requestId: random(16) };
    assert.equal((await send(elder, "request.create", second)).body.request.status, "queued");
    assert.equal((await send(helper, "poll")).body.requests[0].status, "observed");
    assert.equal((await send(helper, "request.respond", { ...second, decision: "accept" })).body.request.status, "accepted");
    assert.equal((await send(helper, "request.progress", { ...second, leaseMode: "native-v1" })).body.request.status, "active");
    assert.equal((await send(elder, "request.end", { ...second, reason: "ended" })).body.request.status, "ended");
    assert.equal((await send(elder, "request.create", first)).body.error, "request_replayed",
      "a historical permanent request claim is retained after migration");
    assert.equal((await send({ ...helper, secret: random(32) }, "poll")).status, 401);
    const diagnostic = new Request("https://source.controlled.test/v1/attempts", {
      method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${helper.id}.${helper.secret}` },
      body: JSON.stringify({ v: 1, attemptId: random(16), callId: random(16), role: "helper", kind: "connection", platform: "ios",
        appVersion: "0.1.3", build: "18", startedAt: Date.now(), elapsedMs: 950, phase: "firstFrame",
        outcome: "success", error: "none", path: "relay", revision: 2 }),
    });
    assert.equal((await proxy(diagnostic)).status, 202);
    const summary = await proxy(new Request("https://source.controlled.test/v1/summary", {
      headers: { authorization: `Bearer ${env.BANGBANG_DIAGNOSTICS_ADMIN_SECRET}` },
    }));
    assert.equal(summary.status, 200);
    assert.equal((await summary.json()).success, 1);
    assert.equal((await exportAuthoritySnapshot(source, options)).digest, snapshot.digest,
      "all gateway operations left the old authority unchanged");
    backend.closeAllConnections();
    await new Promise(resolve => backend.close(resolve));
    const unavailable = await send(helper, "poll");
    assert.deepEqual(unavailable, { status: 503, body: { v: 1, ok: false, error: "service_unavailable" } },
      "an ECS outage does not retry the previous authority");
  });
