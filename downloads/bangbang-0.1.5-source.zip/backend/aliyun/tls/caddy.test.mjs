import test from "node:test";
import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { createServer } from "node:net";
import { fileURLToPath } from "node:url";
import { createAliyunHTTPServer } from "../http.mjs";
import { caddyfile, startupConfiguration } from "./start.mjs";

const binary = process.env.BANGBANG_TEST_CADDY_BIN ?? "/usr/bin/caddy";
const hasCaddy = existsSync(binary);
const secret = () => randomBytes(32).toString("base64url");
const script = fileURLToPath(new URL("./start.mjs", import.meta.url));
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const envFor = (scratch, key, extra = {}) => ({
  BANGBANG_ECS_PROXY_SECRET: key, BANGBANG_TLS_DEPLOYMENT_READY: "true",
  XDG_DATA_HOME: scratch, XDG_CONFIG_HOME: scratch, ...extra,
});
async function unusedPort() {
  const probe = createServer();
  await new Promise((resolve, reject) => { probe.once("error", reject); probe.listen(0, "127.0.0.1", resolve); });
  const port = probe.address().port;
  await new Promise(resolve => probe.close(resolve));
  return port;
}

test("startup needs explicit readiness and a canonical independent secret", () => {
  for (const key of ["", "short", secret() + "=", "A".repeat(42) + "B", "é".repeat(64)]) {
    assert.throws(() => startupConfiguration(envFor(".", key)), /not_ready/);
  }
  for (const flag of [undefined, "", "false", "TRUE", "1"]) {
    assert.throws(() => startupConfiguration(envFor(".", secret(), {
      BANGBANG_TLS_DEPLOYMENT_READY: flag,
    })), /not_ready/);
  }
  assert.deepEqual(startupConfiguration(envFor(".", secret())), { binary: "/usr/bin/caddy" });
  assert.throws(() => startupConfiguration(envFor(".", secret(), { BANGBANG_CADDY_BIN: "caddy" })), /invalid/);
});

test("unready startup and an unexpected child signal fail without echoing secrets", () => {
  const scratch = mkdtempSync(join(tmpdir(), "bangbang-caddy-lifecycle-"));
  try {
    const fake = join(scratch, "caddy-fixture");
    writeFileSync(fake, "#!/bin/sh\nkill -TERM $$\n", { mode: 0o700 });
    const key = secret();
    const denied = spawnSync(process.execPath, [script], {
      env: envFor(scratch, key, { BANGBANG_CADDY_BIN: fake, BANGBANG_TLS_DEPLOYMENT_READY: "false" }),
      encoding: "utf8", timeout: 3000,
    });
    assert.equal(denied.status, 78);
    assert.equal(denied.stderr, "tls_configuration_not_ready\n");
    const terminated = spawnSync(process.execPath, [script], {
      env: envFor(scratch, key, { BANGBANG_CADDY_BIN: fake }),
      encoding: "utf8", timeout: 3000,
    });
    assert.equal(terminated.status, 1);
    assert.equal((terminated.stdout + terminated.stderr).includes(key), false);
  } finally { rmSync(scratch, { recursive: true, force: true }); }
});

test("production template validates; admin, config persistence and credential logs are off",
  { skip: !hasCaddy }, () => {
    const scratch = mkdtempSync(join(tmpdir(), "bangbang-caddy-adapt-"));
    try {
      const key = secret();
      const options = { env: envFor(scratch, key), encoding: "utf8", timeout: 15_000 };
      const validated = spawnSync(binary, ["validate", "--config", caddyfile, "--adapter", "caddyfile"], options);
      assert.equal(validated.status, 0, "production template must pass real Caddy validate");
      const adapted = spawnSync(binary, ["adapt", "--config", caddyfile, "--adapter", "caddyfile"], options);
      assert.equal(adapted.status, 0);
      assert.equal(adapted.stdout.includes(key), false, "runtime secret must not be rendered into JSON");
      const config = JSON.parse(adapted.stdout);
      assert.equal(config.admin.disabled, true);
      assert.equal(config.admin.config.persist, false);
      assert.equal(config.logging.logs.default.writer.output, "discard");
      for (const server of Object.values(config.apps.http.servers)) {
        assert.equal(server.trusted_proxies, undefined);
      }
      const unit = readFileSync(new URL("./bangbang-caddy.service", import.meta.url), "utf8");
      assert.ok(unit.includes("ExecStart=/opt/bangbang-node/current/bin/node "));
      assert.ok(!unit.includes("ExecReload="));
    } finally { rmSync(scratch, { recursive: true, force: true }); }
  });

async function fixture(t, extra = {}) {
  const scratch = mkdtempSync(join(tmpdir(), "bangbang-caddy-http-"));
  const key = secret(), received = [], ingress = [];
  const backend = createAliyunHTTPServer({
    env: { BANGBANG_PUBLIC_ORIGIN: "https://api.bangbang.yilin.fun", BANGBANG_ECS_PROXY_SECRET: key },
    application: { fetch: async request => {
      received.push(request);
      return Response.json({ v: 1, ok: true });
    } },
  });
  backend.on("request", incoming => ingress.push({ ...incoming.headers }));
  await new Promise((resolve, reject) => { backend.once("error", reject); backend.listen(0, "127.0.0.1", resolve); });
  const port = await unusedPort();
  const base = "http://127.0.0.1:" + port;
  const localFile = join(scratch, "Caddyfile");
  const source = readFileSync(caddyfile, "utf8");
  writeFileSync(localFile, source.replace("https://api.bangbang.yilin.fun", base)
    .replace("127.0.0.1:8789", "127.0.0.1:" + backend.address().port), { mode: 0o600 });
  const child = spawn(binary, ["run", "--config", localFile, "--adapter", "caddyfile"], {
    env: envFor(scratch, key, extra), stdio: ["ignore", "pipe", "pipe"],
  });
  let logs = "";
  for (const stream of [child.stdout, child.stderr]) stream.on("data", chunk => {
    if (logs.length < 1_048_576) logs += chunk.toString();
  });
  const closed = new Promise(resolve => child.once("close", resolve));
  t.after(async () => {
    if (child.exitCode === null && child.signalCode === null) child.kill("SIGTERM");
    await Promise.race([closed, pause(2000)]);
    if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    await closed;
    backend.closeAllConnections();
    if (backend.listening) await new Promise(resolve => backend.close(resolve));
    rmSync(scratch, { recursive: true, force: true });
    assert.equal(logs.includes(key), false, "request/error logs must not contain the proxy secret");
    assert.equal(logs.includes("Bearer "), false, "request/error logs must not contain device credentials");
  });
  const request = (path, options = {}) => fetch(base + path, {
    ...options, redirect: "error", signal: AbortSignal.timeout(2000),
  });
  let ready = false;
  for (let attempt = 0; attempt < 50; attempt++) {
    try {
      const response = await request("/api/health");
      if ((await response.json()).v === 1) { ready = true; break; }
    } catch { /* Local listener is starting; never contact an external address. */ }
    if (child.exitCode !== null || child.signalCode !== null) break;
    await pause(100);
  }
  assert.equal(ready, true, "controlled local Caddy listener must start");
  received.length = 0; ingress.length = 0;
  return { request, key, received, ingress, backend };
}

test("real loopback Caddy and ECS adapter enforce the complete header boundary",
  { skip: !hasCaddy }, async t => {
    const f = await fixture(t);
    const auth = "Bearer " + randomBytes(16).toString("base64url") + "." + secret();
    const spoof = {
      authorization: auth, forwarded: "for=192.0.2.30",
      "cf-connecting-ip": "192.0.2.31", "cf-ray": "fixture",
      "x-forwarded-for": "192.0.2.32", "x-forwarded-host": "evil.test",
      "x-forwarded-proto": "https", "x-real-ip": "192.0.2.33",
      "x-client-ip": "192.0.2.34", "true-client-ip": "192.0.2.35",
      "x-bangbang-client-ip": "192.0.2.36", cookie: "private=fixture",
      "proxy-authorization": "Basic fixture",
    };
    await t.test("direct mobile retains Authorization and uses its actual TCP peer", async () => {
      const response = await f.request("/.netlify/functions/family", {
        method: "POST", body: "{}", headers: { ...spoof, "content-type": "application/json",
          "x-bangbang-timestamp": "1", "x-bangbang-signature": "a".repeat(64) },
      });
      assert.equal(response.status, 200);
      const raw = f.ingress.at(-1), core = f.received.at(-1);
      assert.equal(raw.authorization, auth);
      assert.equal(raw["x-bangbang-proxy-secret"], f.key);
      assert.equal(raw["x-bangbang-client-ip"], "127.0.0.1");
      assert.equal(core.headers.get("authorization"), auth);
      assert.equal(core.headers.get("cf-connecting-ip"), "127.0.0.1");
      assert.equal(core.headers.get("x-bangbang-signature"), "a".repeat(64));
      for (const name of Object.keys(spoof).filter(name => name !== "authorization" && name !== "x-bangbang-client-ip")) {
        assert.equal(raw[name], undefined, "Caddy must remove " + name);
      }
      assert.equal(core.headers.has("x-bangbang-proxy-secret"), false);
    });
    await t.test("wrong or empty proxy credentials never reach ECS", async () => {
      const before = f.ingress.length;
      for (const supplied of ["wrong", ""]) {
        assert.equal((await f.request("/api/health", {
          headers: { "x-bangbang-proxy-secret": supplied, "x-bangbang-client-ip": "192.0.2.10" },
        })).status, 401);
      }
      assert.equal(f.ingress.length, before);
    });
    await t.test("authenticated Sites retains only its verified single client IP", async () => {
      for (const ip of ["192.0.2.10", "2001:db8::10"]) {
        assert.equal((await f.request("/api/health", {
          headers: { ...spoof, "x-bangbang-proxy-secret": f.key, "x-bangbang-client-ip": ip },
        })).status, 200);
        assert.equal(f.ingress.at(-1)["x-bangbang-client-ip"], ip);
        assert.equal(f.received.at(-1).headers.get("cf-connecting-ip"), ip);
        assert.equal(f.received.at(-1).headers.get("authorization"), auth);
      }
    });
    await t.test("Sites with no verified IP uses the TCP peer; malformed IPs fail before core", async () => {
      assert.equal((await f.request("/api/health", {
        headers: { "x-bangbang-proxy-secret": f.key },
      })).status, 200);
      assert.equal(f.received.at(-1).headers.get("cf-connecting-ip"), "127.0.0.1");
      const before = f.received.length;
      for (const ip of ["192.0.2.1,192.0.2.2", "2001:db8::1%en0", "[2001:db8::1]", "not-an-ip"]) {
        assert.equal((await f.request("/api/health", {
          headers: { "x-bangbang-proxy-secret": f.key, "x-bangbang-client-ip": ip },
        })).status, 400);
      }
      assert.equal(f.received.length, before);
    });
    await t.test("unknown paths, downloads, query parameters and methods are never proxied", async () => {
      const before = f.ingress.length;
      for (const path of ["/", "/downloads/app.apk", "/api/admin/backups/migration-20261003.bgbak",
        "/api/health/", "/api/health?token=fixture"]) {
        assert.equal((await f.request(path)).status, 404);
      }
      assert.equal((await f.request("/api%2fhealth")).status, 400);
      assert.equal((await f.request("/api/health", { method: "POST", body: "{}" })).status, 404);
      assert.equal(f.ingress.length, before);
    });
    await t.test("the fixed seven JSON APIs work and oversized bodies are denied", async () => {
      const routes = [
        ["/api/health", "GET"], ["/v1/summary", "GET"],
        ["/.netlify/functions/family", "POST"], ["/v1/attempts", "POST"],
        ["/v1/diagnostics/cleanup", "POST"], ["/api/admin/family-migration", "POST"],
        ["/api/push/dispatch", "POST"],
      ];
      for (const [path, method] of routes) {
        assert.equal((await f.request(path, { method, ...(method === "POST" ? { body: "{}" } : {}) })).status, 200);
      }
      assert.equal((await f.request("/v1/attempts", { method: "POST", body: "x".repeat(16_385) })).status, 413);
      assert.equal((await f.request("/api/admin/family-migration", {
        method: "POST", body: "x".repeat(1_048_577),
      })).status, 413);
    });
    await t.test("upstream failure produces a fixed error, without credential request logs", async () => {
      f.backend.closeAllConnections();
      await new Promise(resolve => f.backend.close(resolve));
      const response = await f.request("/api/health", { headers: { authorization: auth } });
      assert.equal(response.status, 503);
      assert.deepEqual(await response.json(), { v: 1, ok: false, error: "service_unavailable" });
    });
  });

test("manual Caddy execution is also fail closed while readiness is unset",
  { skip: !hasCaddy }, async t => {
    const f = await fixture(t, { BANGBANG_TLS_DEPLOYMENT_READY: "false" });
    const response = await f.request("/api/health");
    assert.equal(response.status, 503);
    assert.equal(f.ingress.length, 0);
  });
