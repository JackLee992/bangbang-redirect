import { spawn } from "node:child_process";
import { isAbsolute } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

export const caddyfile = fileURLToPath(new URL("./Caddyfile", import.meta.url));

/** Requires verified DNS/ICP/certificate-issuance prerequisites. Never prints
 * the runtime secret, renders it into a file, or places it in a command argument.
 */
export function startupConfiguration(env) {
  const secret = env.BANGBANG_ECS_PROXY_SECRET ?? "";
  const bytes = Buffer.from(secret, "base64url");
  if (env.BANGBANG_TLS_DEPLOYMENT_READY !== "true" ||
      !/^[A-Za-z0-9_-]{43,171}$/.test(secret) || bytes.length < 32 || bytes.length > 128 ||
      bytes.toString("base64url") !== secret) {
    throw new Error("tls_configuration_not_ready");
  }
  const binary = env.BANGBANG_CADDY_BIN ?? "/usr/bin/caddy";
  if (!isAbsolute(binary) || /[\r\n\0]/.test(binary)) {
    throw new Error("invalid_caddy_binary");
  }
  return { binary };
}

export function startCaddy({ env = process.env } = {}) {
  const { binary } = startupConfiguration(env);
  const runtimeEnv = {
    BANGBANG_ECS_PROXY_SECRET: env.BANGBANG_ECS_PROXY_SECRET,
    BANGBANG_TLS_DEPLOYMENT_READY: "true",
  };
  for (const key of ["PATH", "TMPDIR", "XDG_DATA_HOME", "XDG_CONFIG_HOME"]) {
    if (env[key]) runtimeEnv[key] = env[key];
  }
  const child = spawn(binary, ["run", "--config", caddyfile, "--adapter", "caddyfile"],
    { env: runtimeEnv, stdio: ["ignore", "inherit", "inherit"] });
  let stopping = false;
  const stop = () => {
    stopping = true;
    child.kill("SIGTERM");
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  const cleanup = () => {
    process.off("SIGINT", stop);
    process.off("SIGTERM", stop);
  };
  child.once("error", () => {
    cleanup();
    process.stderr.write("caddy_start_failed\n");
    process.exitCode = 1;
  });
  child.once("exit", code => {
    cleanup();
    process.exitCode = code ?? (stopping ? 0 : 1);
  });
  return child;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { startCaddy(); }
  catch { process.stderr.write("tls_configuration_not_ready\n"); process.exitCode = 78; }
}
