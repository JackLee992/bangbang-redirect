import { execFileSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { mkdtempSync, rmSync } from "node:fs";
import { isAbsolute, join } from "node:path";
import { tmpdir } from "node:os";
import { caddyfile } from "./start.mjs";

// Syntax/provisioning check only. Does not start a server, request a public
// certificate, connect to ECS, or read an operator's production credentials.
const binary = process.argv[2];
if (!binary || !isAbsolute(binary) || /[\r\n\0]/.test(binary)) {
  process.stderr.write("usage: node check.mjs /absolute/path/to/caddy\n");
  process.exitCode = 64;
} else {
  const scratch = mkdtempSync(join(tmpdir(), "bangbang-caddy-validate-"));
  try {
    execFileSync(binary, ["validate", "--config", caddyfile, "--adapter", "caddyfile"], {
      env: {
        BANGBANG_ECS_PROXY_SECRET: randomBytes(32).toString("base64url"),
        BANGBANG_TLS_DEPLOYMENT_READY: "false",
        XDG_DATA_HOME: scratch, XDG_CONFIG_HOME: scratch,
      },
      stdio: "pipe", timeout: 15_000,
    });
    process.stdout.write("caddy_template_validated; public_tls_unverified\n");
  } catch {
    process.stderr.write("caddy_template_validation_failed\n");
    process.exitCode = 1;
  } finally { rmSync(scratch, { recursive: true, force: true }); }
}
