# 帮帮 API HTTPS 入口准备

本目录只准备 `api.bangbang.yilin.fun → Caddy HTTPS → 127.0.0.1:8789`，不修改 DNS、购买资源或部署云端。家人 API 的数据库迁移、维护开关和 Sites 代理切换仍按主部署方案执行；宣发站 `bangbang.yilin.fun` 的 Cloudflare 403 不会因这份 ECS 模板自动解决。

| 文件 | 用途 |
| --- | --- |
| `Caddyfile` | 固定域名、固定本机上游、七个小型 JSON API、请求头信任边界 |
| `start.mjs` | 就绪检查、规范服务器密钥校验、运行 Caddy、信号退出处理 |
| `check.mjs` | 使用临时测试密钥执行真实 `caddy validate`，不启动服务器 |
| `bangbang-caddy.service` | ECS systemd 模板，使用已有 `/opt/bangbang-node/current/bin/node` |
| `caddy.env.example` | 运行环境示例，默认未就绪，包含空密钥槽位 |
| `caddy.test.mjs` | 配置、启动生命周期、真实本机 Caddy→ECS HTTP 适配器边界测试 |

## 运行前提与启用顺序

`BANGBANG_TLS_DEPLOYMENT_READY=false` 是技术就绪状态；现有部署授权不需要再次确认。正式启动器在状态未就绪或密钥无效时以 78 退出，systemd 不会重复启动。模板本身也会在未就绪时返回固定 503，阻止请求进入 API。

先核对域名和适用的备案前提、DNS 指向、80/443 可达、端口占用与持久证书目录。Caddy 的自动 HTTPS 会签发并续期证书，通常通过 HTTP 80 或 TLS-ALPN 443 验证域名；仅通过配置校验不代表拿到了有效证书。[Caddy 自动 HTTPS 文档](https://caddyserver.com/docs/automatic-https)

证书验收阶段可以由部署负责人安排**维护实例**：使用同一模板且 `BANGBANG_TLS_DEPLOYMENT_READY=false`，仅验收公开 HTTPS/证书，此时所有应用 API 返回 503。维护实例不是本目录正式启动器的运行模式，也不在本轮自动启动。确认正确域名、可信证书和无证书错误的 HTTPS 后，再把私有运行环境的就绪标志设为 `true`，使用正式 unit。核心 `BANGBANG_FAMILY_API_ENABLED` 仍须遵守完整数据迁移和核验顺序；不能用 TLS 就绪替代迁移完成。

正式部署准备事项：

- Caddy 二进制装在 `/usr/bin/caddy`，或者通过私有运行环境的绝对路径 `BANGBANG_CADDY_BIN` 指定。生产 Linux 架构与本轮 macOS 验证二进制不同，分别核对官方发行资产。
- 代码安装在 `/opt/bangbang`，ECS 应用只监听 `127.0.0.1:8789`，该端口不公开。先建立 `caddy` 用户/组并核对 unit 的运行路径。
- 私有 `/etc/bangbang/caddy.env` 使用 root 所有、0600 权限，由 systemd 加载运行变量。真实密钥不写入仓库、Caddyfile、启动参数或日志。
- TLS 证书状态使用 unit 的 `/var/lib/caddy` 持久目录，0700 权限。保留此目录支持重启和续期，不把证书私钥放进公开源码或下载桶。
- `admin off` 禁用管理 API；`persist_config off` 禁用配置自动存盘。没有 `ExecReload`，更新用受控重启。[Caddy 全局配置文档](https://caddyserver.com/docs/caddyfile/options)
- 没有访问日志；运行日志输出也关闭，避免自定义代理密钥或请求内容进入错误日志。健康、退出状态及既有脱敏诊断 API 用于运行观察；当前模板不会保留 Caddy/ACME 详细故障日志。

## 请求头信任边界

`BANGBANG_ECS_PROXY_SECRET` 是 32–128 个随机字节的规范 base64url，必须与 ECS `family.env` 和 Sites 私有运行环境一致，与设备 Bearer、后台密钥及推送签名密钥独立。

直连手机不持有这个服务器密钥。Caddy 保留安装身份 `Authorization` 和服务验证所需的签名头，清除来访者的 `Forwarded`、`CF-*`、`X-Forwarded-*`、`X-Real-IP` 等地址别名以及 Cookie，并把真实 TCP 来源写成 `X-Bangbang-Client-IP`。它不信任代理 IP 段、不接受 PROXY protocol；不能在它前面直接加一个 CDN 并继续声称 TCP 来源等于最终用户。

只有入站 `X-Bangbang-Proxy-Secret` 与运行密钥匹配，Caddy 才保留 Sites 的 `X-Bangbang-Client-IP`。Sites 必须先用平台覆盖的 `CF-Connecting-IP` 核验来源，不能转发用户正文或任意自报地址。Caddy 拒绝空值、列表、区域标记和括号，ECS HTTP 适配器继续用 `isIP` 校验单个 IPv4/IPv6。Sites 没有提供地址时使用其 TCP 来源；错误或空代理密钥返回 401，不进入 ECS。

Caddy 重新注入本机上游的代理密钥，但不会把它替换成手机的 `Authorization`。ECS 在服务器鉴权后移除内部头，手机安装身份仍由家人服务验证。配置使用运行时 `{env.BANGBANG_ECS_PROXY_SECRET}` 占位符，受控 `adapt` 检查确认 JSON 不含测试密钥。[Caddy 占位符文档](https://caddyserver.com/docs/extending-caddy/placeholders)、[代理请求头文档](https://caddyserver.com/docs/caddyfile/directives/reverse_proxy)

## 只代理小型 API

| 路径 | 方法 | ECS 请求体上限 |
| --- | --- | --- |
| `/api/health`、`/v1/summary` | GET | 0 |
| `/.netlify/functions/family` | POST | 8 KiB |
| `/v1/attempts` | POST | 16 KiB |
| `/v1/diagnostics/cleanup` | POST | 128 B |
| `/api/push/dispatch` | POST | 256 B |
| `/api/admin/family-migration` | POST | 1 MiB |

其余路径、方法、查询参数和编码路径都不代理。Caddy 总请求体限制 1 MiB，ECS 保留更小的逐路径限制。连接上游限时 2 秒，等待回应头 10 秒，上游读写 15 秒；故障返回固定错误 JSON，不输出异常或来访内容。APK、源码压缩包、加密备份与视频/远控内容不经过这条入口，避免占用 ECS 3 Mbps 出口。[Caddy 请求体限制文档](https://caddyserver.com/docs/caddyfile/directives/request_body)

## 本地验证

从仓库根目录执行，参数只有测试二进制路径，没有真实服务器密钥：

```sh
node backend/aliyun/tls/check.mjs /absolute/path/to/caddy
BANGBANG_TEST_CADDY_BIN=/absolute/path/to/caddy node --test backend/aliyun/tls/caddy.test.mjs
```

2026-10-03 本轮实际使用官方 [Caddy v2.11.6](https://github.com/caddyserver/caddy/releases/tag/v2.11.6) macOS arm64 二进制，下载包 SHA-256 已与官方发行资产核对：`4ad5a757d4ebb880e0a2bb333410a0089f09348d9e74693bcf13be0669675f6e`。Node 为 24.17.0，真实生产模板 `validate` 成功，12 项测试全部通过、无跳过。

HTTP 测试只把监听地址和上游端口替换成临时本机地址；请求头、路由、日志和错误处理使用生产模板。它验证了直连地址伪造、Sites 鉴权、IPv4/IPv6、非法地址、原设备 Bearer、HMAC 头保留、错误方法/路径、大包拒绝、上游失败及子进程非预期信号退出。应用使用受控响应桩，测试不证明真实手机身份/配对、数据库迁移、Linux systemd 启动、公网 DNS/ICP备案、ACME 证书签发或跨网可达。
