#!/bin/sh
# Explicit Node 24 patch version; installation never uses an unverified "latest".
set -eu
version=${1:?Usage: install-node.sh 24.x.y [installation-prefix]}
prefix=${2:-/opt/bangbang-node}
case "$version" in 24.[0-9]*.[0-9]*) ;; *) echo 'node_version_required' >&2; exit 1 ;; esac
case "$version" in *[!0-9.]*|*..*) echo 'node_version_invalid' >&2; exit 1 ;; esac
case "$prefix" in /*) ;; *) echo 'node_prefix_invalid' >&2; exit 1 ;; esac
[ "$(uname -s)" = Linux ] && [ "$(uname -m)" = x86_64 ] || { echo 'node_platform_unsupported' >&2; exit 1; }
archive="node-v${version}-linux-x64.tar.xz"
directory="node-v${version}-linux-x64"
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM
curl --fail --location --proto '=https' --tlsv1.2 --silent --show-error \
  "https://nodejs.org/dist/v${version}/SHASUMS256.txt" --output "$temporary/SHASUMS256.txt"
curl --fail --location --proto '=https' --tlsv1.2 --silent --show-error \
  "https://nodejs.org/dist/v${version}/${archive}" --output "$temporary/$archive"
awk -v file="$archive" '$2 == file { print $0; found++ } END { if (found != 1) exit 1 }' \
  "$temporary/SHASUMS256.txt" > "$temporary/checksum.txt"
(cd "$temporary" && sha256sum --check checksum.txt)
# Extract only after the official HTTPS manifest's exact filename/hash matches.
tar -xJf "$temporary/$archive" -C "$temporary"
"$temporary/$directory/bin/node" --version | awk -v expected="v$version" '$0 != expected { exit 1 }'
mkdir -p "$prefix"
test ! -e "$prefix/$directory" || { echo 'node_version_already_installed' >&2; exit 1; }
mv "$temporary/$directory" "$prefix/$directory"
ln -sfn "$directory" "$prefix/current"
echo 'node_install_verified'
