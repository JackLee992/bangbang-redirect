import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, statSync, existsSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { SQLiteFamilyDatabase } from "./sqlite.mjs";
import { createSitesFamilyStore } from "../../site/server/sites_family_store.mjs";

function directory(t) {
  const path = mkdtempSync(join(tmpdir(), "bangbang-aliyun-sqlite-"));
  t.after(() => rmSync(path, { recursive: true, force: true }));
  return path;
}
test("SQLite initialization is explicit, private, WAL-backed and refuses replacement or symlinks", async t => {
  const path = directory(t), file = join(path, "family.sqlite");
  assert.throws(() => new SQLiteFamilyDatabase(file));
  assert.equal(existsSync(file), false);
  assert.throws(() => new SQLiteFamilyDatabase("relative.sqlite", { initialize: true }));
  const db = new SQLiteFamilyDatabase(file, { initialize: true });
  assert.equal(statSync(file).mode & 0o777, 0o600);
  assert.equal((await db.prepare("PRAGMA journal_mode").first()).journal_mode, "wal");
  assert.equal((await db.prepare("PRAGMA synchronous").first()).synchronous, 2);
  assert.equal((await db.prepare("PRAGMA busy_timeout").first()).timeout, 5000);
  assert.throws(() => new SQLiteFamilyDatabase(file, { initialize: true }));
  const link = join(path, "alias.sqlite"); symlinkSync(file, link);
  assert.throws(() => new SQLiteFamilyDatabase(link), /storage_unavailable/);
  assert.throws(() => db.prepare("CREATE TABLE unexpected (secret TEXT)"), /storage_unavailable/);
  db.close();
  const restored = new SQLiteFamilyDatabase(file, { readOnly: true });
  assert.equal(await restored.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first().then(row => row.n), 0);
  restored.close();
});

test("two real SQLite connections keep original CAS and strong revocation reads through reopen", async t => {
  const file = join(directory(t), "family.sqlite");
  const one = new SQLiteFamilyDatabase(file, { initialize: true });
  const two = new SQLiteFamilyDatabase(file);
  const a = createSitesFamilyStore({ db: one, scope: "controlled-test" });
  const b = createSitesFamilyStore({ db: two, scope: "controlled-test" });
  const key = "devices/controlled";
  const read = store => store.getWithMetadata(key, { type: "json", consistency: "strong" });
  assert.equal((await a.setJSON(key, { revision: 1 }, { onlyIfNew: true })).modified, true);
  const old = await read(b);
  const results = await Promise.all([
    a.setJSON(key, { revision: 2, revokedAt: 123 }, { onlyIfMatch: old.etag }),
    b.setJSON(key, { revision: 2, revokedAt: 456 }, { onlyIfMatch: old.etag }),
  ]);
  assert.equal(results.filter(result => result.modified).length, 1);
  assert.equal((await read(b)).data.revokedAt, 123);
  one.close(); two.close();
  const reopened = new SQLiteFamilyDatabase(file);
  assert.equal((await createSitesFamilyStore({ db: reopened, scope: "controlled-test" }).getWithMetadata(
    key, { type: "json", consistency: "strong" })).data.revokedAt, 123);
  reopened.close();
});

test("SQLite batch fully rolls back and cannot execute statements owned by another database", async () => {
  const one = new SQLiteFamilyDatabase(":memory:", { initialize: true });
  const two = new SQLiteFamilyDatabase(":memory:", { initialize: true });
  const insert = (db, key, json) => db.prepare("INSERT INTO bangbang_family_records VALUES (?, ?, ?, ?, ?)")
    .bind("controlled-test", key, json, "test-etag", 123);
  await assert.rejects(one.batch([insert(one, "one", "{}"), insert(one, "two", null)]));
  assert.equal((await one.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 0);
  await assert.rejects(one.batch([insert(two, "outside", "{}")]), /storage_unavailable/);
  assert.equal((await two.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 0);
  one.close(); two.close();
});
