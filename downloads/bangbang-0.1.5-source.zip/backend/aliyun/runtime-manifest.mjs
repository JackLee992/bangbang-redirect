import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";

export const RUNTIME_FILES = Object.freeze([
  "backend/aliyun/cli.mjs", "backend/aliyun/http.mjs", "backend/aliyun/service.mjs",
  "backend/aliyun/snapshot.mjs", "backend/aliyun/sqlite.mjs", "backend/diagnostics/worker.mjs",
  "site/server/family-service.mjs", "site/server/push-delivery.mjs", "site/server/push-dispatcher.mjs",
  "site/server/push-providers.mjs", "site/server/sites_diagnostics_store.mjs", "site/server/sites_family_service.mjs",
  "site/server/sites_family_store.mjs", "site/server/sites_push_providers.mjs",
  "site/worker/diagnostics.mjs", "site/worker/family-migration.mjs", "site/worker/authority-fence.mjs",
]);
export function runtimeManifest() {
  const root = new URL("../../", import.meta.url);
  const files = [...RUNTIME_FILES, "backend/aliyun/bangbang-family.service", "backend/aliyun/family.env.example"].map(path => {
    const bytes = readFileSync(fileURLToPath(new URL(path, root)));
    return { path, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") };
  });
  return { v: 1, runtime: "node24", dependencyInstallRequired: false, files };
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.stdout.write(`${JSON.stringify(runtimeManifest(), null, 2)}\n`);
}
