import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes, createHash } from "node:crypto";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { SQLiteFamilyDatabase } from "./sqlite.mjs";
import { createAliyunFamilyApplication } from "./service.mjs";
import { exportAuthoritySnapshot as exportSnapshot, importAuthoritySnapshot, verifyAuthoritySnapshot, authoritySnapshotDigest, authorityConfigurationFingerprint } from "./snapshot.mjs";
import { createSitesFamilyStore } from "../../site/server/sites_family_store.mjs";
import { createSitesDiagnosticStore } from "../../site/server/sites_diagnostics_store.mjs";

import { installAuthorityFence, freezeAuthority } from "../../site/worker/authority-fence.mjs";

async function exportAuthoritySnapshot(db, options) {
  if ((options?.purpose ?? "cutover") === "cutover" && options?.apiEnabled === "false" &&
      options.configuration?.BANGBANG_FAMILY_API_ENABLED === "false" && options.configuration?.BANGBANG_DIAGNOSTICS_INGEST_ENABLED === "false") {
    await installAuthorityFence(db);
    await freezeAuthority(db, { scope: options.scope, now: options.now });
  }
  return exportSnapshot(db, options);
}

const random = bytes => randomBytes(bytes).toString("base64url");
const scope = "controlled-test";
const configuration = { BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_API_ENABLED: "false",
  BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "false", BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32) };
const fingerprint = authorityConfigurationFingerprint(configuration);
const context = { scope, configuration, apiEnabled: "false", now: () => 1_800_000_000_000 };
const database = t => {
  const db = new SQLiteFamilyDatabase(":memory:", { initialize: true });
  t.after(() => db.close()); return db;
};
const familyInsert = (db, key, data) => db.prepare("INSERT INTO bangbang_family_records VALUES (?, ?, ?, ?, ?)")
  .bind(scope, key, JSON.stringify(data), "source-etag", 123).run();
const importSnapshot = (db, snapshot) => importAuthoritySnapshot(db, snapshot, { ...context, expectedDigest: snapshot.digest });

test("full current-authority snapshot preserves family claims, revoked state, original TTL, diagnostics and budgets", async t => {
  const source = database(t), target = database(t), id = random(16), pair = random(16), request = random(16);
  await familyInsert(source, `devices/${id}`, { revision: 8, authHash: "a".repeat(64), revokedAt: 321, pairs: [pair] });
  await familyInsert(source, `pairs/${pair}`, { capabilityHash: "b".repeat(64), revokedAt: 321,
    request: { requestId: request, status: "cancelled", createdAt: 100, expiresAt: 120100 } });
  await familyInsert(source, `claims/${pair}/${request}`, { revision: 1, createdAt: 100 });
  await familyInsert(source, `push-tokens/${"c".repeat(64)}`, { installationId: id, registrationId: "generation", previousRegistrationId: "prior" });
  await source.prepare("INSERT INTO bangbang_diagnostic_attempts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
    .bind(scope, "a".repeat(64), "b".repeat(64), "c".repeat(64), "helper", "connection", "ios", "0.1.3", "18",
      1_800_000_000_000, 1300, "firstFrame", "success", "none", "direct", 4, 1_800_000_001_300).run();
  await source.prepare("INSERT INTO bangbang_diagnostic_limits VALUES (?, ?, ?, ?, ?, ?, ?)")
    .bind(scope, "scope_day", "d".repeat(64), 20833, 400, 600, 1_800_000_000_000).run();
  const snapshot = await exportAuthoritySnapshot(source, context);
  assert.deepEqual(snapshot.counts, { family: 4, attempts: 1, limits: 1 });
  const result = await importSnapshot(target, snapshot);
  assert.deepEqual(result.inserted, snapshot.counts);
  assert.equal(result.digest, snapshot.digest);
  assert.equal(target.isAuthorityVerified(scope, fingerprint), true);
  const saved = await target.prepare("SELECT json, updated_at FROM bangbang_family_records WHERE scope = ? AND key = ?")
    .bind(scope, `pairs/${pair}`).first();
  assert.equal(JSON.parse(saved.json).request.expiresAt, 120100);
  assert.equal(saved.updated_at, 123);
  assert.equal(snapshot.v, 3);
  assert.equal(snapshot.freezeEvidence.pendingDispatch, 0);
  assert.equal(snapshot.records[0].updatedAt, 123);
  const retry = await importSnapshot(target, snapshot);
  assert.deepEqual(retry.inserted, { family: 0, attempts: 0, limits: 0 });
  assert.deepEqual(retry.unchanged, snapshot.counts);
  assert.equal(JSON.stringify(result).includes(id), false);
  assert.deepEqual(await verifyAuthoritySnapshot(target, snapshot, { ...context, expectedDigest: snapshot.digest }),
    { digest: snapshot.digest, counts: snapshot.counts, configFingerprint: fingerprint, purpose: "cutover",
      activationEligible: true, freezeEvidence: snapshot.freezeEvidence });
});

test("source export is complete across cursor pages, isolated by scope, and rejects an unfrozen caller", async t => {
  const db = database(t);
  for (let i = 0; i < 140; i++) await familyInsert(db, `devices/${random(16)}`, { revision: i, revokedAt: 123 });
  await db.prepare("INSERT INTO bangbang_family_records VALUES (?, ?, ?, ?, ?)")
    .bind("other-scope", `devices/${random(16)}`, "{}", "other-etag", 123).run();
  const one = await exportAuthoritySnapshot(db, context);
  const two = await exportAuthoritySnapshot(db, { ...context, now: () => context.now() + 1000 });
  assert.equal(one.counts.family, 140); assert.equal(two.digest, one.digest);
  await assert.rejects(exportAuthoritySnapshot(db, { ...context, apiEnabled: "true" }), /authority_must_be_paused/);
  await assert.rejects(exportAuthoritySnapshot(db, { scope }), /authority_must_be_paused/);
});

test("different family or diagnostic state is never overwritten and partial import remains inactive", async t => {
  const source = database(t), target = database(t), id = random(16);
  await familyInsert(source, `devices/${id}`, { revokedAt: 123 });
  await familyInsert(target, `devices/${id}`, { revokedAt: 456 });
  const snapshot = await exportAuthoritySnapshot(source, context);
  await assert.rejects(importSnapshot(target, snapshot), /migration_conflict/);
  assert.equal(target.isAuthorityVerified(scope, fingerprint), false);
  assert.equal(JSON.parse((await target.prepare("SELECT json FROM bangbang_family_records WHERE key = ?").bind(`devices/${id}`).first()).json).revokedAt, 456);
  assert.throws(() => createAliyunFamilyApplication({ db: target, env: { BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_API_ENABLED: "true" } }), /authority_migration_not_verified/);

  const diagnosticSource = database(t), diagnosticTarget = database(t);
  await diagnosticSource.prepare("INSERT INTO bangbang_diagnostic_limits VALUES (?, ?, ?, ?, ?, ?, ?)")
    .bind(scope, "scope_day", "a".repeat(64), 5, 10, 10, 123).run();
  await diagnosticTarget.prepare("INSERT INTO bangbang_diagnostic_limits VALUES (?, ?, ?, ?, ?, ?, ?)")
    .bind(scope, "scope_day", "a".repeat(64), 5, 20, 20, 123).run();
  const diagnosticSnapshot = await exportAuthoritySnapshot(diagnosticSource, context);
  await assert.rejects(importSnapshot(diagnosticTarget, diagnosticSnapshot), /migration_conflict/);
  assert.equal((await diagnosticTarget.prepare("SELECT events FROM bangbang_diagnostic_limits").first()).events, 20);
  assert.equal(diagnosticTarget.isAuthorityVerified(scope, fingerprint), false);
});

test("missing/extra rows, tampered digest and unknown tables/fields cannot gain an activation marker", async t => {
  const source = database(t), target = database(t);
  await familyInsert(source, `devices/${random(16)}`, { revokedAt: 123 });
  const snapshot = await exportAuthoritySnapshot(source, context);
  const modified = structuredClone(snapshot); modified.records[0].data.revokedAt = 999;
  await assert.rejects(importSnapshot(target, modified), /snapshot_invalid/);
  await assert.rejects(importAuthoritySnapshot(target, snapshot, { ...context, expectedDigest: "0".repeat(64) }), /snapshot_invalid/);
  const unknown = structuredClone(snapshot); unknown.records[0].key = "arbitrary/secret";
  unknown.digest = authoritySnapshotDigest(unknown);
  await assert.rejects(importSnapshot(target, unknown), /snapshot_invalid/);
  await assert.rejects(verifyAuthoritySnapshot(target, snapshot, { ...context, expectedDigest: snapshot.digest }), /migration_verification_failed/);
  await familyInsert(target, `devices/${random(16)}`, { revokedAt: 321 });
  await assert.rejects(importSnapshot(target, snapshot), /migration_verification_failed/);
  assert.equal(target.isAuthorityVerified(scope, fingerprint), false);
});

test("rehearsal export can read an active source but can never activate an imported database", async t => {
  const source = database(t), target = database(t);
  await familyInsert(source, `devices/${random(16)}`, { revision: 3 });
  const active = { ...configuration, BANGBANG_FAMILY_API_ENABLED: "true", BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "true" };
  const snapshot = await exportAuthoritySnapshot(source, { ...context, apiEnabled: "true", configuration: active, purpose: "rehearsal" });
  const result = await importSnapshot(target, snapshot);
  assert.equal(result.activationEligible, false); assert.equal(result.purpose, "rehearsal");
  assert.equal((await target.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 1);
  assert.equal(target.isAuthorityVerified(scope, fingerprint), false);
  assert.equal((await target.prepare("SELECT COUNT(*) AS n FROM bangbang_aliyun_authority").first()).n, 0);
  assert.throws(() => createAliyunFamilyApplication({ db: target, env: { ...active } }), /authority_migration_not_verified/);
  await assert.rejects(exportAuthoritySnapshot(source, { ...context, configuration: active }), /authority_must_be_paused/);
  await assert.rejects(exportAuthoritySnapshot(source, { ...context,
    configuration: { ...configuration, BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "true" } }), /authority_must_be_paused/);
});

test("v1 snapshots and mismatched hash namespaces are rejected before any target row is imported", async t => {
  const source = database(t), target = database(t);
  await familyInsert(source, `devices/${random(16)}`, { revision: 1 });
  const snapshot = await exportAuthoritySnapshot(source, context);
  const legacy = structuredClone(snapshot); legacy.v = 1;
  delete legacy.purpose; delete legacy.configFingerprint; delete legacy.records[0].updatedAt;
  await assert.rejects(importSnapshot(target, legacy), /snapshot_invalid/);
  const changed = { ...configuration, BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32) };
  await assert.rejects(importAuthoritySnapshot(target, snapshot,
    { ...context, configuration: changed, expectedDigest: snapshot.digest }), /authority_configuration_mismatch/);
  assert.equal((await target.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 0);
  assert.throws(() => authorityConfigurationFingerprint({ ...configuration, BANGBANG_DIAGNOSTICS_HASH_SECRET: "invalid" }), /authority_configuration_invalid/);
  assert.notEqual(authorityConfigurationFingerprint({ ...configuration, BANGBANG_FAMILY_STORE_SCOPE: "other" }), fingerprint);
  assert.equal(authorityConfigurationFingerprint({ ...configuration, BANGBANG_DIAGNOSTICS_ADMIN_SECRET: random(32) }), fingerprint);
});

test("legacy v2 cutover and missing, altered or unresolved formal proof cannot create a target activation marker", async t => {
  const source = database(t), target = database(t);
  await familyInsert(source, `devices/${random(16)}`, { revision: 1 });
  const snapshot = await exportAuthoritySnapshot(source, context);
  const legacy = structuredClone(snapshot); legacy.v = 2; delete legacy.freezeEvidence;
  legacy.digest = authoritySnapshotDigest(legacy);
  await assert.rejects(importSnapshot(target, legacy), /snapshot_invalid/);
  for (const change of [
    value => { delete value.freezeEvidence; },
    value => { value.freezeEvidence.pendingDispatch = 1; },
    value => { value.freezeEvidence.schemaDigest = "0".repeat(64); },
    value => { value.freezeEvidence.scope = "other-scope"; },
    value => { value.freezeEvidence.frozenAt = value.createdAt + 1; },
  ]) {
    const altered = structuredClone(snapshot); change(altered);
    if (altered.freezeEvidence) altered.digest = authoritySnapshotDigest(altered);
    await assert.rejects(importSnapshot(target, altered), /snapshot_invalid/);
  }
  assert.equal((await target.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 0);
  assert.equal(target.isAuthorityVerified(scope, fingerprint), false);
  const result = await importSnapshot(target, snapshot);
  assert.equal(result.activationEligible, true);
  const marker = await target.prepare("SELECT counts FROM bangbang_aliyun_authority WHERE scope = ?").bind(scope).first();
  assert.deepEqual(JSON.parse(marker.counts).freezeEvidence, snapshot.freezeEvidence);
  await familyInsert(target, `devices/${random(16)}`, { revision: 2 });
  assert.equal((await target.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 2,
    "source proof is retained in the marker; target does not inherit the source write fence");
});

test("original clocks preserve transient expiry and a timestamp-only conflict cannot be overwritten", async t => {
  const source = database(t), target = database(t), key = `rate-limits/1/${"f".repeat(64)}`;
  await familyInsert(source, key, { count: 180 });
  const snapshot = await exportAuthoritySnapshot(source, context);
  await importSnapshot(target, snapshot);
  await verifyAuthoritySnapshot(target, snapshot, { ...context, expectedDigest: snapshot.digest });
  const altered = structuredClone(snapshot); altered.records[0].updatedAt++;
  altered.digest = authoritySnapshotDigest(altered);
  await assert.rejects(importSnapshot(target, altered), /migration_conflict/);
  assert.equal((await target.prepare("SELECT updated_at FROM bangbang_family_records WHERE key = ?").bind(key).first()).updated_at, 123);
  await createSitesFamilyStore({ db: target, scope, now: context.now }).cleanupTransient();
  assert.equal((await target.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 0,
    "migration does not refresh expired ingress counters");
});

test("a competing real SQLite writer makes the whole family batch roll back without granting activation", async t => {
  const source = database(t);
  const directory = mkdtempSync(join(tmpdir(), "bangbang-migration-race-"));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const file = join(directory, "target.sqlite");
  const target = new SQLiteFamilyDatabase(file, { initialize: true }), competitor = new SQLiteFamilyDatabase(file);
  t.after(() => { target.close(); competitor.close(); });
  const a = `devices/${random(16)}`, b = `pairs/${random(16)}`;
  await familyInsert(source, a, { revision: 1 }); await familyInsert(source, b, { revision: 1 });
  const snapshot = await exportAuthoritySnapshot(source, context);
  const batch = target.batch.bind(target); let raced = false;
  t.mock.method(target, "batch", async statements => {
    if (!raced) { raced = true; await familyInsert(competitor, b, { revision: 2, revokedAt: 456 }); }
    return batch(statements);
  });
  await assert.rejects(importSnapshot(target, snapshot), /migration_conflict/);
  assert.equal(await target.prepare("SELECT key FROM bangbang_family_records WHERE key = ?").bind(a).first(), null);
  assert.equal(JSON.parse((await target.prepare("SELECT json FROM bangbang_family_records WHERE key = ?").bind(b).first()).json).revision, 2);
  assert.equal(target.isAuthorityVerified(scope, fingerprint), false);
});

test("all three tables paginate fully and preserve diagnostic revisions, received clocks and day budgets", async t => {
  const source = database(t), target = database(t);
  const hash = value => createHash("sha256").update(value).digest("hex");
  for (let i = 0; i < 140; i++) {
    await familyInsert(source, `claims/${random(16)}/${random(16)}`, { revision: 1, createdAt: i + 1 });
    await source.prepare("INSERT INTO bangbang_diagnostic_attempts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
      .bind(scope, hash(`installation/${i}`), hash(`attempt/${i}`), hash(`call/${i}`), "helper", "connection", "ios", "0.1.3", "18",
        context.now(), 1000, "ringing", "pending", "none", "unknown", 3, context.now() + i).run();
    await source.prepare("INSERT INTO bangbang_diagnostic_limits VALUES (?, ?, ?, ?, ?, ?, ?)")
      .bind(scope, "scope_day", hash("global"), i, i + 1, i + 2, 123 + i).run();
  }
  const snapshot = await exportAuthoritySnapshot(source, context);
  assert.deepEqual(snapshot.counts, { family: 140, attempts: 140, limits: 140 });
  const result = await importSnapshot(target, snapshot); assert.deepEqual(result.inserted, snapshot.counts);
  assert.equal(result.digest, snapshot.digest);
  assert.equal((await target.prepare("SELECT revision FROM bangbang_diagnostic_attempts LIMIT 1").first()).revision, 3);
  assert.equal((await target.prepare("SELECT events FROM bangbang_diagnostic_limits WHERE window = 139").first()).events, 141);
});

test("pending diagnostic attempts keep one hashed identity and original budget after migration and replay", async t => {
  const source = database(t), target = database(t), installation = random(16), attempt = random(16), call = random(16);
  const store = db => createSitesDiagnosticStore({ db, scope, secret: configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET, now: context.now });
  const event = { v: 1, attemptId: attempt, callId: call, role: "helper", kind: "connection", platform: "ios",
    appVersion: "0.1.3", build: "18", startedAt: context.now(), elapsedMs: 1000, phase: "ringing", outcome: "pending",
    error: "none", path: "unknown", revision: 1 };
  await store(source).write(installation, [event]);
  for (let i = 0; i < 60; i++) assert.equal(await store(source).consumeIngestLimit(installation, 1), true);
  const snapshot = await exportAuthoritySnapshot(source, context);
  await importSnapshot(target, snapshot);
  assert.equal(await store(target).consumeIngestLimit(installation, 1), false, "migration does not reset a spent install budget");
  const decided = { ...event, elapsedMs: 1400, phase: "firstFrame", outcome: "success", path: "relay", revision: 2 };
  await store(target).write(installation, [decided]); await store(target).write(installation, [event]);
  const rows = (await target.prepare("SELECT * FROM bangbang_diagnostic_attempts").all()).results;
  assert.equal(rows.length, 1); assert.equal(rows[0].revision, 2); assert.equal(rows[0].outcome, "success");
  assert.equal((await store(target).summary()).success, 1);
  for (const value of [installation, attempt, call, configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET]) {
    assert.equal(JSON.stringify(rows).includes(value), false);
  }
});
