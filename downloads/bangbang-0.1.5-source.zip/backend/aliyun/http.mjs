import { createServer } from "node:http";
import { createHash, timingSafeEqual } from "node:crypto";
import { isIP } from "node:net";
import { pathToFileURL } from "node:url";
import { SQLiteFamilyDatabase } from "./sqlite.mjs";
import { createAliyunFamilyApplication } from "./service.mjs";
import { sitesFamilyResponse, SITES_FAMILY_PATH, SITES_PUSH_DISPATCH_PATH } from "../../site/server/sites_family_service.mjs";

const response = (status, error) => sitesFamilyResponse(status, { ok: false, error });
function configuration(env) {
  let origin;
  try { origin = new URL(env.BANGBANG_PUBLIC_ORIGIN); } catch { throw new Error("invalid_server_configuration"); }
  if (origin.protocol !== "https:" || origin.username || origin.password || origin.pathname !== "/" || origin.search || origin.hash) {
    throw new Error("invalid_server_configuration");
  }
  const secret = env.BANGBANG_ECS_PROXY_SECRET ?? "";
  const decoded = Buffer.from(secret, "base64url");
  if (secret && (decoded.length < 32 || decoded.length > 128 || decoded.toString("base64url") !== secret)) {
    throw new Error("invalid_server_configuration");
  }
  return { origin: origin.origin, secret };
}
function allowedProxy(supplied, secret) {
  return !secret || timingSafeEqual(createHash("sha256").update(supplied ?? "").digest(),
    createHash("sha256").update(secret).digest());
}
function bodyLimit(path) {
  if (path === "/api/admin/family-migration") return 1_048_576;
  if (path === "/v1/attempts") return 16_384;
  if (path === "/v1/diagnostics/cleanup") return 128;
  if (path === SITES_PUSH_DISPATCH_PATH) return 256;
  if (path === "/api/health" || path === "/v1/summary") return 0;
  return 8192;
}
function readBody(incoming, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    const cleanup = () => {
      incoming.off("data", data); incoming.off("end", end);
      incoming.off("error", error); incoming.off("aborted", error);
    };
    const error = () => { cleanup(); reject(new Error("request_unavailable")); };
    const end = () => { cleanup(); resolve({ bytes: Buffer.concat(chunks) }); };
    const data = chunk => {
      size += chunk.length;
      if (size > limit) { cleanup(); incoming.pause(); resolve({ denied: response(413, "body_too_large") }); }
      else chunks.push(chunk);
    };
    incoming.on("data", data); incoming.once("end", end);
    incoming.once("error", error); incoming.once("aborted", error);
  });
}
async function writeResponse(outgoing, result, head = false) {
  if (outgoing.destroyed) return;
  outgoing.writeHead(result.status, Object.fromEntries(result.headers));
  outgoing.end(head ? undefined : Buffer.from(await result.arrayBuffer()));
}

/** TLS terminates at the operator's reverse proxy. Unauthenticated forwarded
 * IPs are discarded. A Sites proxy must supply a separate server-only secret,
 * while forwarding the device Bearer unchanged for actual family authorization.
 */
export function createAliyunHTTPServer({ application, env = process.env }) {
  const { origin, secret } = configuration(env);
  const server = createServer({ maxHeaderSize: 8192 }, async (incoming, outgoing) => {
    const reject = async result => {
      outgoing.setHeader("connection", "close"); incoming.resume();
      await writeResponse(outgoing, result, incoming.method === "HEAD");
    };
    try {
      if (!allowedProxy(incoming.headers["x-bangbang-proxy-secret"], secret)) {
        return await reject(response(401, "unauthorized"));
      }
      if (!incoming.url?.startsWith("/") || incoming.url.startsWith("//")) return await reject(response(400, "invalid_request"));
      const url = new URL(incoming.url, origin);
      if (url.origin !== origin) return await reject(response(400, "invalid_request"));
      const limit = bodyLimit(url.pathname);
      const length = incoming.headers["content-length"];
      if (length && (!/^\d+$/.test(length) || Number(length) > limit)) return await reject(response(413, "body_too_large"));
      const body = await readBody(incoming, limit);
      if (body.denied) return await reject(body.denied);
      const headers = new Headers();
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (value === undefined || /^(?:host|connection|transfer-encoding|forwarded|cf-.+|x-forwarded-.+|x-real-ip|x-bangbang-(?:proxy-secret|client-ip))$/.test(name)) continue;
        headers.set(name, Array.isArray(value) ? value.join(",") : value);
      }
      const suppliedIP = incoming.headers["x-bangbang-client-ip"];
      if (secret && suppliedIP && (typeof suppliedIP !== "string" || !isIP(suppliedIP))) {
        return await reject(response(400, "invalid_request"));
      }
      const address = secret && suppliedIP ? suppliedIP : incoming.socket.remoteAddress?.replace(/^::ffff:/, "");
      if (address && isIP(address)) headers.set("cf-connecting-ip", address);
      const method = incoming.method ?? "GET";
      const result = await application.fetch(new Request(url, { method, headers,
        ...(["GET", "HEAD"].includes(method) ? {} : { body: body.bytes }) }));
      await writeResponse(outgoing, result, method === "HEAD");
    } catch {
      if (!outgoing.headersSent && !outgoing.destroyed) await reject(response(503, "service_unavailable"));
      else outgoing.end();
    }
  });
  server.requestTimeout = 15_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5000;
  server.maxRequestsPerSocket = 1000;
  return server;
}

export function startAliyunServer({ env = process.env } = {}) {
  const host = env.BANGBANG_FAMILY_HOST ?? "127.0.0.1";
  const port = Number(env.BANGBANG_FAMILY_PORT ?? 8789);
  const flag = env.BANGBANG_FAMILY_API_ENABLED ?? "false";
  if (!["127.0.0.1", "::1"].includes(host) || !Number.isInteger(port) || port < 1 || port > 65535 ||
    !["false", "true"].includes(flag)) throw new Error("invalid_server_configuration");
  configuration(env);
  process.umask(0o077);
  const db = new SQLiteFamilyDatabase(env.BANGBANG_FAMILY_DB);
  let application, server;
  try {
    application = createAliyunFamilyApplication({ db, env });
    server = createAliyunHTTPServer({ application, env });
  } catch (error) { db.close(); throw error; }
  let running = false;
  const sweep = async () => {
    if (running) return;
    running = true;
    try { await application.dispatch(); }
    catch { process.stderr.write("family_dispatch_retry\n"); }
    finally { running = false; }
  };
  const timer = setInterval(sweep, 15_000); timer.unref();
  server.once("close", () => { clearInterval(timer); db.close(); });
  server.listen(port, host);
  return { server, db, application };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const { server } = startAliyunServer();
    const stop = () => server.close();
    process.once("SIGINT", stop); process.once("SIGTERM", stop);
    server.once("error", () => { process.stderr.write("family_start_failed\n"); process.exitCode = 1; });
  } catch { process.stderr.write("family_start_failed\n"); process.exitCode = 1; }
}
