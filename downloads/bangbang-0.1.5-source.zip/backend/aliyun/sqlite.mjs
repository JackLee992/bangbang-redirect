import { DatabaseSync } from "node:sqlite";
import { constants, openSync, closeSync, chmodSync, mkdirSync, lstatSync } from "node:fs";
import { dirname, isAbsolute } from "node:path";
import { DIAGNOSTIC_SCHEMA_SQL } from "../../site/server/sites_diagnostics_store.mjs";
import { AUTHORITY_FENCE_SCHEMA_SQL, validFreezeEvidence } from "../../site/worker/authority-fence.mjs";

const APPLICATION_ID = 0x42424641;
const SCHEMA_VERSION = 1;
const unavailable = () => { throw new Error("storage_unavailable"); };
const scopeValid = value => typeof value === "string" && /^[A-Za-z0-9_-]{1,100}$/.test(value);
const runSync = Symbol("sqlite_bound_statement");
const statementOwner = Symbol("sqlite_statement_owner");
const schema = `
CREATE TABLE bangbang_family_records (
  scope TEXT NOT NULL, key TEXT NOT NULL, json TEXT NOT NULL,
  etag TEXT NOT NULL, updated_at INTEGER NOT NULL, PRIMARY KEY (scope, key)
);
${DIAGNOSTIC_SCHEMA_SQL}
CREATE TABLE bangbang_aliyun_authority (
  scope TEXT NOT NULL PRIMARY KEY, digest TEXT NOT NULL,
  counts TEXT NOT NULL, verified_at INTEGER NOT NULL
);
PRAGMA application_id = ${APPLICATION_ID};
PRAGMA user_version = ${SCHEMA_VERSION};
`;

/** A local SQLite volume implements the existing D1 envelope. Each batch is a
 * synchronous transaction: it cannot yield to another request before COMMIT.
 * Initialization is an explicit deploy command, never an HTTP side effect.
 */
export class SQLiteFamilyDatabase {
  #sqlite;
  #closed = false;
  #transaction = false;
  constructor(filename, { initialize = false, readOnly = false } = {}) {
    if (typeof filename !== "string" || (filename !== ":memory:" && !isAbsolute(filename)) ||
      (initialize && readOnly) || (filename === ":memory:" && !initialize)) unavailable();
    if (filename !== ":memory:") {
      if (initialize) {
        mkdirSync(dirname(filename), { recursive: true, mode: 0o700 });
        // An existing volume is never silently initialized or replaced.
        closeSync(openSync(filename, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW, 0o600));
      }
      const info = lstatSync(filename);
      if (!info.isFile() || info.isSymbolicLink()) unavailable();
      if (readOnly && (info.mode & 0o077)) unavailable();
      if (!readOnly) chmodSync(filename, 0o600);
    }
    const sqlite = new DatabaseSync(filename, { readOnly, enableForeignKeyConstraints: true, allowExtension: false });
    this.#sqlite = sqlite;
    try {
      // PRAGMA works on Node 22.13 as well as 24; the timeout constructor option
      // was added later, so it is deliberately not relied on here.
      sqlite.exec("PRAGMA busy_timeout = 5000");
      if (!readOnly) {
        sqlite.exec("PRAGMA journal_mode = WAL");
        sqlite.exec("PRAGMA synchronous = FULL");
      }
      if (initialize) {
        sqlite.exec("BEGIN IMMEDIATE");
        try { sqlite.exec(schema); sqlite.exec("COMMIT"); }
        catch (error) { sqlite.exec("ROLLBACK"); throw error; }
      }
      if (sqlite.prepare("PRAGMA application_id").get().application_id !== APPLICATION_ID ||
        sqlite.prepare("PRAGMA user_version").get().user_version !== SCHEMA_VERSION) unavailable();
      const columns = sqlite.prepare('PRAGMA table_info("bangbang_family_records")').all();
      if (columns.length !== 5 || !columns.some(row => row.name === "scope" && row.pk === 1) ||
        !columns.some(row => row.name === "key" && row.pk === 2) ||
        !columns.some(row => row.name === "json" && row.notnull === 1)) unavailable();
      // Refuse missing diagnostic or verification tables before serving traffic.
      sqlite.prepare("SELECT scope, installation_hash, attempt_hash FROM bangbang_diagnostic_attempts LIMIT 0").all();
      sqlite.prepare("SELECT scope, kind, subject_hash, window FROM bangbang_diagnostic_limits LIMIT 0").all();
      sqlite.prepare("SELECT scope, digest, counts, verified_at FROM bangbang_aliyun_authority LIMIT 0").all();
    } catch {
      sqlite.close(); this.#closed = true; unavailable();
    }
  }
  prepare(sql) {
    if (this.#closed || typeof sql !== "string" || sql.includes(";") || /\b(?:CREATE|ALTER|DROP|ATTACH|DETACH)\b/i.test(sql)) unavailable();
    const statement = this.#sqlite.prepare(sql);
    const bound = values => ({
      bind: (...next) => bound(next),
      first: async () => statement.get(...values) ?? null,
      all: async () => ({ success: true, results: statement.all(...values) }),
      run: async () => execute(values),
      [runSync]: () => execute(values),
      [statementOwner]: this,
    });
    const execute = values => {
      const result = statement.run(...values);
      return { success: true, results: [], meta: { changes: Number(result.changes) } };
    };
    return bound([]);
  }
  async batch(statements) {
    if (this.#closed || this.#transaction || !Array.isArray(statements) || statements.length < 1 ||
      statements.length > 1000 || statements.some(statement => typeof statement?.[runSync] !== "function" || statement[statementOwner] !== this)) unavailable();
    this.#sqlite.exec("BEGIN IMMEDIATE"); this.#transaction = true;
    try {
      const results = statements.map(statement => statement[runSync]());
      this.#sqlite.exec("COMMIT"); return results;
    } catch (error) { this.#sqlite.exec("ROLLBACK"); throw error; }
    finally { this.#transaction = false; }
  }
  // Explicit offline deployment command only. The SQL is a fixed audited
  // schema; prepare() still forbids arbitrary DDL and startup never calls this.
  async installAuthorityFence() {
    if (this.#closed || this.#transaction) unavailable();
    this.#sqlite.exec("BEGIN IMMEDIATE"); this.#transaction = true;
    try { this.#sqlite.exec(AUTHORITY_FENCE_SCHEMA_SQL); this.#sqlite.exec("COMMIT"); }
    catch { this.#sqlite.exec("ROLLBACK"); unavailable(); }
    finally { this.#transaction = false; }
  }
  isAuthorityVerified(scope, configFingerprint) {
    if (!scopeValid(scope) || this.#closed) unavailable();
    if (typeof configFingerprint !== "string" || !/^[a-f0-9]{64}$/.test(configFingerprint)) return false;
    const row = this.#sqlite.prepare("SELECT digest, counts, verified_at FROM bangbang_aliyun_authority WHERE scope = ?").get(scope);
    if (!row || !/^[a-f0-9]{64}$/.test(row.digest) || !Number.isSafeInteger(row.verified_at) || row.verified_at < 1) return false;
    let state;
    try { state = JSON.parse(row.counts); } catch { return false; }
    // The existing schema keeps its private marker payload in counts. Legacy
    // markers without a configuration binding deliberately cannot activate.
    return !!state && Object.keys(state).length === 5 && state.configFingerprint === configFingerprint &&
      validFreezeEvidence(state.freezeEvidence, scope) &&
      [state.family, state.attempts, state.limits].every(value => Number.isSafeInteger(value) && value >= 0);
  }
  async markAuthorityVerified(scope, { digest, counts, configFingerprint, freezeEvidence, verifiedAt = Date.now() }) {
    if (!scopeValid(scope) || !/^[a-f0-9]{64}$/.test(digest) ||
      typeof configFingerprint !== "string" || !/^[a-f0-9]{64}$/.test(configFingerprint) ||
      !validFreezeEvidence(freezeEvidence, scope) ||
      !counts || [counts.family, counts.attempts, counts.limits].some(value => !Number.isSafeInteger(value) || value < 0) ||
      !Number.isSafeInteger(verifiedAt) || verifiedAt < 1) unavailable();
    await this.prepare(`INSERT INTO bangbang_aliyun_authority (scope, digest, counts, verified_at) VALUES (?, ?, ?, ?)
      ON CONFLICT (scope) DO UPDATE SET digest = excluded.digest, counts = excluded.counts, verified_at = excluded.verified_at`)
      .bind(scope, digest, JSON.stringify({ family: counts.family, attempts: counts.attempts, limits: counts.limits,
        configFingerprint, freezeEvidence }), verifiedAt).run();
  }
  async invalidateAuthorityVerification(scope) {
    if (!scopeValid(scope)) unavailable();
    await this.prepare("DELETE FROM bangbang_aliyun_authority WHERE scope = ?").bind(scope).run();
  }
  close() {
    if (!this.#closed) { this.#sqlite.close(); this.#closed = true; }
  }
}
