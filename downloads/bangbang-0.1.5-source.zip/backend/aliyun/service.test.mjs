import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { once } from "node:events";
import { SQLiteFamilyDatabase } from "./sqlite.mjs";
import { createAliyunFamilyApplication } from "./service.mjs";
import { createAliyunHTTPServer } from "./http.mjs";
import { exportAuthoritySnapshot, importAuthoritySnapshot, authorityConfigurationFingerprint } from "./snapshot.mjs";

import { installAuthorityFence, freezeAuthority } from "../../site/worker/authority-fence.mjs";

const random = bytes => randomBytes(bytes).toString("base64url");
const scope = "controlled-test";
async function verifiedDatabase(db, env) {
  const configuration = { ...env, BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_API_ENABLED: "false",
    BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "false" };
  const context = { scope, configuration, apiEnabled: "false" };
  const source = new SQLiteFamilyDatabase(":memory:", { initialize: true });
  try {
    await installAuthorityFence(source); await freezeAuthority(source, { scope });
    const snapshot = await exportAuthoritySnapshot(source, context);
    await importAuthoritySnapshot(db, snapshot, { ...context, expectedDigest: snapshot.digest });
  } finally { source.close(); }
}
async function fixture(t) {
  const folder = mkdtempSync(join(tmpdir(), "bangbang-aliyun-service-"));
  t.after(() => rmSync(folder, { recursive: true, force: true }));
  const filename = join(folder, "family.sqlite");
  let db = new SQLiteFamilyDatabase(filename, { initialize: true });
  let timestamp = 1_800_000_000_000;
  const now = () => timestamp;
  t.mock.method(Date, "now", now);
  const env = { BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_API_ENABLED: "true",
    BANGBANG_PUBLIC_ORIGIN: "https://api.controlled.test", BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "true",
    BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32), BANGBANG_DIAGNOSTICS_ADMIN_SECRET: random(32) };
  await verifiedDatabase(db, env);
  let app = createAliyunFamilyApplication({ db, env, now });
  let server = createAliyunHTTPServer({ application: app, env });
  const listen = async () => { server.listen(0, "127.0.0.1"); await once(server, "listening"); };
  await listen();
  t.after(async () => { if (server.listening) await new Promise(resolve => server.close(resolve)); db.close(); });
  const elder = { id: random(16), secret: random(32), peerId: "123456789" };
  const helper = { id: random(16), secret: random(32), peerId: "987654321" };
  const pair = { pairId: random(16), capability: random(32), nonce: random(16),
    elderInstallationId: elder.id, helperInstallationId: helper.id,
    elderPeerId: elder.peerId, helperPeerId: helper.peerId, serverScope: "public-v1" };
  const send = async (who, op, fields = {}) => {
    const response = await fetch(`http://127.0.0.1:${server.address().port}/.netlify/functions/family`, {
      method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${who.id}.${who.secret}` },
      body: JSON.stringify({ v: 1, op, ...fields }),
    });
    return { status: response.status, body: await response.json() };
  };
  const restart = async () => {
    await new Promise(resolve => server.close(resolve)); db.close();
    db = new SQLiteFamilyDatabase(filename);
    app = createAliyunFamilyApplication({ db, env, now });
    server = createAliyunHTTPServer({ application: app, env });
    await listen();
  };
  const setup = async () => {
    for (const who of [elder, helper]) assert.equal((await send(who, "register", { peerId: who.peerId, serverScope: pair.serverScope })).status, 200);
    assert.equal((await send(helper, "pair.offer", pair)).status, 200);
    assert.equal((await send(elder, "pair.confirm", { pairId: pair.pairId, capability: pair.capability, nonce: pair.nonce })).status, 200);
  };
  return { filename, folder, env, now, elder, helper, pair, send, restart, setup,
    db: () => db, app: () => app, base: () => `http://127.0.0.1:${server.address().port}`,
    advance: ms => { timestamp += ms; } };
}

test("a full local HTTP call flow persists pairing and rejects old request replay after server/database reopen", async t => {
  const f = await fixture(t); await f.setup();
  const first = { pairId: f.pair.pairId, capability: f.pair.capability, requestId: random(16) };
  assert.equal((await f.send(f.elder, "request.create", first)).body.request.status, "queued");
  assert.equal((await f.send(f.helper, "poll")).body.requests[0].status, "observed");
  assert.equal((await f.send(f.helper, "request.respond", { ...first, decision: "accept" })).body.request.status, "accepted");
  assert.equal((await f.send(f.helper, "request.progress", { ...first, leaseMode: "native-v1" })).body.request.status, "active");
  assert.equal((await f.send(f.elder, "request.end", { ...first, reason: "ended" })).body.request.status, "ended");
  f.advance(15_001);
  const second = { ...first, requestId: random(16) };
  await f.send(f.elder, "request.create", second);
  await f.send(f.elder, "request.cancel", second);
  await f.restart();
  assert.equal((await f.send(f.helper, "identity.verify")).body.identity.pairs.length, 1);
  assert.equal((await f.send(f.elder, "request.create", first)).body.error, "request_replayed");
  assert.equal((await f.send(f.helper, "poll")).body.requests[0].status, "cancelled");
  const health = await fetch(`${f.base()}/api/health`).then(response => response.json());
  assert.deepEqual(health, { v: 1, ok: true, service: "bangbang-family", authority: "ecs-sqlite", familyApiEnabled: true });
  const records = JSON.stringify((await f.db().prepare("SELECT json FROM bangbang_family_records WHERE key LIKE 'devices/%' OR key LIKE 'pairs/%'").all()).results);
  for (const value of [f.elder.secret, f.helper.secret, f.pair.capability, f.pair.nonce]) assert.equal(records.includes(value), false);
});

test("ECS diagnostics reuses persisted install verification, private HMAC statistics and original limits", async t => {
  const f = await fixture(t); await f.setup();
  const payload = { v: 1, attemptId: random(16), callId: random(16), role: "helper", kind: "connection", platform: "ios",
    appVersion: "0.1.3", build: "18", startedAt: f.now(), elapsedMs: 1200, phase: "firstFrame", outcome: "success", error: "none", path: "direct", revision: 2 };
  const upload = async authorization => fetch(`${f.base()}/v1/attempts`, { method: "POST", headers: {
    "content-type": "application/json", authorization }, body: JSON.stringify(payload) });
  const auth = `Bearer ${f.helper.id}.${f.helper.secret}`;
  assert.equal((await upload(auth)).status, 202);
  assert.equal((await upload(`Bearer ${f.helper.id}.${random(32)}`)).status, 401);
  assert.equal((await fetch(`${f.base()}/v1/summary`, { headers: { authorization: auth } })).status, 401);
  const summary = await fetch(`${f.base()}/v1/summary`, { headers: { authorization: `Bearer ${f.env.BANGBANG_DIAGNOSTICS_ADMIN_SECRET}` } }).then(response => response.json());
  assert.equal(summary.success, 1); assert.equal(summary.firstFrame.meanMs, 1200);
  const retained = JSON.stringify((await f.db().prepare("SELECT * FROM bangbang_diagnostic_attempts").all()).results);
  for (const value of [f.helper.id, f.helper.secret, payload.attemptId, payload.callId]) assert.equal(retained.includes(value), false);
});

test("maintenance is the default, unverified volumes cannot activate, and fresh migration invalidates prior verification", async t => {
  const db = new SQLiteFamilyDatabase(":memory:", { initialize: true }); t.after(() => db.close());
  const env = { BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_MIGRATION_SECRET: random(32),
    BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32) };
  let app = createAliyunFamilyApplication({ db, env });
  const request = () => new Request("https://service.test/.netlify/functions/family", { method: "POST", body: "{}" });
  assert.equal((await app.fetch(request())).status, 503);
  assert.throws(() => createAliyunFamilyApplication({ db, env: { ...env, BANGBANG_FAMILY_API_ENABLED: "true" } }), /authority_migration_not_verified/);
  const health = await app.fetch(new Request("https://service.test/api/health"));
  assert.equal(health.status, 200);
  await verifiedDatabase(db, env);
  assert.equal(db.isAuthorityVerified(scope, authorityConfigurationFingerprint(env)), true);
  app = createAliyunFamilyApplication({ db, env: { ...env, BANGBANG_FAMILY_API_ENABLED: "false" } });
  const migrated = await app.fetch(new Request("https://service.test/api/admin/family-migration", {
    method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${env.BANGBANG_FAMILY_MIGRATION_SECRET}` },
    body: JSON.stringify({ v: 1, records: [{ key: `devices/${random(16)}`, data: { revision: 1, revokedAt: 123 } }] }),
  }));
  assert.equal(migrated.status, 200); assert.equal(db.isAuthorityVerified(scope, authorityConfigurationFingerprint(env)), false);
  await app.dispatch();
  assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM bangbang_family_records").first()).n, 1);
});

test("closed or failed local storage returns a fixed error and never falls back to another authority", async t => {
  const f = await fixture(t); await f.setup();
  f.db().close();
  const result = await f.send(f.helper, "poll");
  assert.deepEqual(result, { status: 503, body: { v: 1, ok: false, error: "service_unavailable" } });
  assert.equal((await fetch(`${f.base()}/api/health`)).status, 503);
});

test("startup rejects missing or changed diagnostic hash keys and legacy markers while preserving healthy credential rotation", async t => {
  const f = await fixture(t);
  assert.equal(f.db().isAuthorityVerified(scope), false, "marker inspection without a namespace fingerprint cannot activate");
  assert.throws(() => createAliyunFamilyApplication({ db: f.db(), env: { ...f.env, BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32) } }), /authority_migration_not_verified/);
  assert.throws(() => createAliyunFamilyApplication({ db: f.db(), env: { ...f.env, BANGBANG_DIAGNOSTICS_HASH_SECRET: "" } }), /authority_migration_not_verified/);
  assert.doesNotThrow(() => createAliyunFamilyApplication({ db: f.db(), env: { ...f.env, BANGBANG_DIAGNOSTICS_ADMIN_SECRET: random(32) } }));
  await f.db().prepare("UPDATE bangbang_aliyun_authority SET counts = ? WHERE scope = ?")
    .bind(JSON.stringify({ family: 0, attempts: 0, limits: 0, configFingerprint: authorityConfigurationFingerprint(f.env) }), scope).run();
  assert.throws(() => createAliyunFamilyApplication({ db: f.db(), env: f.env }), /authority_migration_not_verified/,
    "an old v2 marker has no verified source-fence evidence");
  await f.db().prepare("UPDATE bangbang_aliyun_authority SET counts = ? WHERE scope = ?")
    .bind(JSON.stringify({ family: 0, attempts: 0, limits: 0 }), scope).run();
  assert.throws(() => createAliyunFamilyApplication({ db: f.db(), env: f.env }), /authority_migration_not_verified/);
});
