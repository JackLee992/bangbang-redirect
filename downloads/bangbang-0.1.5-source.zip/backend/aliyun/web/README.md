# 帮帮宣发站：阿里云静态发布预案

这里只发布网页。网站域名是 `bangbang.yilin.fun`，业务接口继续由现有 Sites 服务提供。APK 和完整源码 ZIP 继续外链到 Sites R2，不经过 ECS 的 3Mbps 带宽。帮助页和 AGPL 许可证保留，首页不增加源码入口。当前公开应用版本为 **0.1.2**。

本目录没有网站登录、服务端密钥、数据库、反向代理或新增 npm 依赖。Node 24 已有运行时足够。代码和文件已可本机审查；**当前未备案，不运行公网 HTTPS、不切 DNS**。

## 生成发布包

先由 `site/scripts/build.mjs --target aliyun` 生成真实静态产物。实际域名、下载服务与家人 API 必须显式传入：

```sh
node site/scripts/build.mjs --target aliyun \
  --site-origin https://bangbang.yilin.fun/ \
  --download-base-url https://bangbang-services.s419505080.chatgpt.site/downloads/ \
  --family-api-base-url https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family
```

生成包的输入/输出都用绝对路径，输出目录必须不存在；真实构建可以通过 `--output-dir` 使用审核过的独立目录。

```sh
node backend/aliyun/web/release.mjs package \
  --input /absolute/path/to/dist-aliyun \
  --output /absolute/path/to/new-package \
  --expected-app-version 0.1.2
```

输出 `manifest.json`、`SHA256SUMS` 和 `bangbang-web-0.1.2-<digest>.tar.gz`。清单按实际文件逐个计算长度与 SHA；当前白名单只有 20 个既有网页/图片/关联文件/小型下载说明。源码、APK、环境文件、数据库、非清单文件、目录链接和私钥不会进入包。唯一隐藏目录例外是 Android 所需的 `.well-known/assetlinks.json`。发布包的 SHA 要通过独立已审查的清单传到服务器，不能临时从未验真的来包里当作可信值读取。

## 先安装文件，不启动公网服务

以后服务器仅需本目录运行文件 `release.mjs`、`start.mjs`、`Caddyfile` 及已有 Node 和单个 Caddy 二进制。将包放在 `/root` 等私有暂存目录；静态部署根目录独立为 `/var/www/bangbang`。部署脚本应由文件所有者（正式部署为 root）执行，Caddy 用户只读。

```sh
/opt/bangbang-node/current/bin/node /opt/bangbang/backend/aliyun/web/release.mjs install \
  --archive /root/bangbang-web-reviewed.tar.gz \
  --expected-sha256 <独立核验的64位SHA256> \
  --root /var/www/bangbang
/opt/bangbang-node/current/bin/node /opt/bangbang/backend/aliyun/web/release.mjs verify \
  --root /var/www/bangbang
```

安装先检查压缩包 SHA、严格 USTAR 普通文件格式及完整清单，在 `releases/.stage-*` 校验全部内容后才创建不可变版本目录。文件为 `0444`、版本目录为 `0555`；`current` 是同文件系统内原子替换的相对链接，`previous` 保存上一份完整版本。重试同包不会覆盖版本或丢掉 previous，失败不会切换 current。`.deploy-lock` 防止同时切换；中断后可人工确认没有部署进程，再删除残留锁。旧版本不会自动清理。

回退同样先校验 previous，再原子切回，文件服务器不需要重载配置：

```sh
/opt/bangbang-node/current/bin/node /opt/bangbang/backend/aliyun/web/release.mjs rollback \
  --root /var/www/bangbang
```

包 SHA 证明静态产物完整；它不证明未提交的构建代码已完成版本冻结，也不能替代手机连接验收。

## HTTPS 与单 Caddy 进程

`web.env.example` 默认 `BANGBANG_WEB_HTTPS_READY=false`。`start.mjs` 必须看到明确的 `true`，且 current 全量校验通过才启动；未就绪退出码 78，systemd 不循环重启。没有自动启用 service 的脚本。

北京 ECS 对公网网站需先完成 ICP 备案批准及接入记录；详情见仓库 `docs/ALIYUN_ICP_FILING.md`。随后实际核对域名解析指向目标 ECS、安全组/防火墙 80 和 443、HTTPS 证书签发及站点归属，完成验收后开放。域名当前仍 CNAME 到 Sites，此目录不修改 DNS。

`bangbang-web.service` 使用非 root 的 `caddy` 用户及只读系统，仅允许绑定低位端口、写 Caddy 证书状态目录。**同一台机器只能有一个 Caddy 进程占用 80/443。** 这份配置适用于目前尚未安装 API Caddy 的单网站阶段。将来上线 API 时，把本网站块和 `backend/aliyun/tls/Caddyfile` 的 API 块合成一份配置，共用一次全局设置和一个服务；不要同时启用 `bangbang-web.service` 与 `bangbang-caddy.service`，也不要通过冲突设置自动停掉已有 API。

网页 Caddy 只开放清单中的固定路径，支持 `/help`、`/legal` 的短路径。`/invite` 内部映射到 `invite.html`，保留完整查询；`invite.html` 原路径也有效。Android 两个关联地址返回 JSON。`/api`、`/.netlify`、`/v1` 一律 404 JSON，其余未知路径 404，不会把业务请求错误地返回首页。配置没有访问日志，邀请口令不会写入请求日志。

## 本机验真

```sh
BANGBANG_TEST_CADDY_BIN=/absolute/path/to/caddy \
  node --test backend/aliyun/web/web.test.mjs
```

测试使用真实 Caddy 的生产模板，将地址仅改成 `http://127.0.0.1:<随机端口>`，验证真实路由、查询保留、文件类型、API 拒绝、原子切换与 previous 回退。没有 Caddy 时这三项明确跳过；不能把跳过当通过。仅本机 HTTP 验证不证明北京公网、备案、TLS、微信跳转或手机深链验收已完成。
