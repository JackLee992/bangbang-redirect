import { createHash, randomBytes } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
import { lstat, mkdir, readFile, readdir, readlink, rename, rm, symlink, writeFile, chmod } from "node:fs/promises";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

export const WEB_ORIGIN = "https://bangbang.yilin.fun/";
export const WEB_FILES = Object.freeze([
  ".well-known/assetlinks.json", "404.html", "app.js", "assets/app-welcome.png", "assets/brand.png", "assets/brand.svg",
  "assetlinks.json", "deployment.json", "downloads/AGPL-3.0.txt", "downloads/SHA256SUMS", "downloads/build-info.json",
  "help.html", "index.html", "invite-utils.js", "invite.html", "invite.js", "privacy.html", "release.json", "site-share.js", "styles.css",
].sort());
const allowed = new Set(WEB_FILES);
const MAX_FILE_BYTES = 8 * 1024 * 1024;
const MAX_PACKAGE_BYTES = 32 * 1024 * 1024;
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const fail = () => { throw new Error("web_release_invalid"); };
const privateText = /-----BEGIN (?:[A-Z ]* )?PRIVATE KEY-----|\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,}/;
const exactKeys = (value, keys) => value && typeof value === "object" && !Array.isArray(value) &&
  Object.keys(value).sort().join() === [...keys].sort().join();
const pathRequired = path => { if (typeof path !== "string" || !isAbsolute(path) || /[\r\n\0]/.test(path)) fail(); return resolve(path); };
async function physical(path, directory) {
  const info = await lstat(path);
  if (info.isSymbolicLink() || (directory ? !info.isDirectory() : !info.isFile())) fail();
  return info;
}
async function paths(root, prefix = "") {
  await physical(root, true);
  const result = [];
  for (const name of (await readdir(root)).sort()) {
    const path = join(root, name), info = await lstat(path), relative = prefix + name;
    if (info.isSymbolicLink()) fail();
    if (info.isDirectory()) {
      if (!["assets", "downloads", ".well-known"].includes(relative)) fail();
      result.push(...await paths(path, relative + "/"));
    } else if (info.isFile() && allowed.has(relative) && info.size <= MAX_FILE_BYTES) result.push(relative);
    else fail();
  }
  if (!prefix && result.sort().join() !== WEB_FILES.join()) fail();
  return result;
}
function parsed(bytes) { try { return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)); } catch { fail(); } }
function checkDistribution(files) {
  const deployment = parsed(files.get("deployment.json")), release = parsed(files.get("release.json"));
  if (deployment.target !== "aliyun" || deployment.websiteUrl !== WEB_ORIGIN ||
      !/^\d+\.\d+\.\d+$/.test(release.version) || deployment.appVersion !== release.version) fail();
  // The public API remains Sites-owned and the narrow ECS uplink does not serve APK/ZIP.
  const downloadBase = "https://bangbang-services.s419505080.chatgpt.site/downloads/";
  const androidOverride = release.android?.downloadUrl;
  const androidUrl = androidOverride === undefined ? downloadBase + release.android?.filename :
    `https://gitee.com/yilin-dev/bangbang-releases/releases/download/v${release.version}/${release.android?.filename}`;
  if (deployment.downloadBaseUrl !== downloadBase ||
      deployment.familyApiBaseUrl !== "https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family" ||
      (androidOverride !== undefined && androidOverride !== androidUrl) || deployment.downloads?.android !== androidUrl ||
      deployment.downloads?.source !== downloadBase + release.source?.filename ||
      !/^[A-Za-z0-9_.-]+\.apk$/.test(release.android?.filename ?? "") ||
      !/^[A-Za-z0-9_.-]+\.zip$/.test(release.source?.filename ?? "")) fail();
  const association = parsed(files.get(".well-known/assetlinks.json"));
  if (!Array.isArray(association) || !association.length ||
      !files.get(".well-known/assetlinks.json").equals(files.get("assetlinks.json")) || association.some(item =>
        !item.relation?.includes("delegate_permission/common.handle_all_urls") || item.target?.namespace !== "android_app" ||
        !/^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+$/.test(item.target.package_name ?? "") ||
        !Array.isArray(item.target.sha256_cert_fingerprints) || !item.target.sha256_cert_fingerprints.length ||
        item.target.sha256_cert_fingerprints.some(value => !/^(?:[A-Fa-f0-9]{2}:){31}[A-Fa-f0-9]{2}$/.test(value)))) fail();
  for (const [name, bytes] of files) {
    if (/\.(html|js|css|json|svg|txt)$/.test(name) && privateText.test(bytes.toString("utf8"))) fail();
    if (/\.html$/.test(name) && /\{\{[A-Z0-9_]+\}\}/.test(bytes.toString("utf8"))) fail();
  }
  if (!files.get("index.html").toString("utf8").includes(deployment.downloads.android)) fail();
  return release.version;
}
function manifestFrom(files) {
  const base = { v: 1, siteOrigin: WEB_ORIGIN, appVersion: checkDistribution(files), files: WEB_FILES.map(path => ({
    path, bytes: files.get(path).length, sha256: sha(files.get(path)),
  })) };
  return { ...base, digest: sha(JSON.stringify(base)) };
}
function checkManifest(manifest, files) {
  if (!exactKeys(manifest, ["v", "siteOrigin", "appVersion", "files", "digest"]) || !Array.isArray(manifest.files) ||
      !/^[a-f0-9]{64}$/.test(manifest.digest ?? "") || JSON.stringify(manifest) !== JSON.stringify(manifestFrom(files))) fail();
  return manifest;
}
async function readPublic(root) {
  const files = new Map(); let size = 0;
  for (const path of await paths(root)) {
    const bytes = await readFile(join(root, path)); size += bytes.length;
    if (bytes.length > MAX_FILE_BYTES || size > MAX_PACKAGE_BYTES) fail();
    files.set(path, bytes);
  }
  return files;
}

// The archive deliberately implements only regular USTAR files produced here.
// No external extractor, directory links, PAX attributes or archive paths are trusted.
function archive(entries) {
  const blocks = [];
  for (const [name, bytes] of entries) {
    const header = Buffer.alloc(512);
    header.write(name, 0, 100, "ascii");
    for (const [offset, length, value] of [[100, 8, 0o444], [108, 8, 0], [116, 8, 0], [124, 12, bytes.length], [136, 12, 0]])
      header.write(value.toString(8).padStart(length - 1, "0") + "\0", offset, length, "ascii");
    header.fill(32, 148, 156); header[156] = 48; header.write("ustar\0", 257, 6, "ascii"); header.write("00", 263);
    header.write([...header].reduce((sum, byte) => sum + byte, 0).toString(8).padStart(6, "0") + "\0 ", 148, 8, "ascii");
    blocks.push(header, bytes, Buffer.alloc((512 - bytes.length % 512) % 512));
  }
  return gzipSync(Buffer.concat([...blocks, Buffer.alloc(1024)]));
}
function unpack(bytes) {
  if (bytes.length > MAX_PACKAGE_BYTES) fail();
  let tar;
  try { tar = gunzipSync(bytes, { maxOutputLength: MAX_PACKAGE_BYTES + 128 * 1024 }); } catch { fail(); }
  const entries = new Map(); let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512); offset += 512;
    if (header.every(byte => byte === 0)) {
      if (tar.length - offset < 512 || tar.subarray(offset).some(byte => byte !== 0)) fail();
      return entries;
    }
    const string = (start, length) => header.subarray(start, start + length).toString("ascii").split("\0")[0];
    const octal = (start, length) => { const value = string(start, length).trim(); if (!/^[0-7]+$/.test(value)) fail(); return parseInt(value, 8); };
    const checksum = [...header].reduce((sum, byte, index) => sum + (index >= 148 && index < 156 ? 32 : byte), 0);
    const name = string(0, 100), size = octal(124, 12);
    if (octal(148, 8) !== checksum || string(257, 6) !== "ustar" || string(345, 155) !== "" || header[156] !== 48 ||
        !Number.isSafeInteger(size) || size > MAX_FILE_BYTES || offset + size > tar.length || entries.has(name) ||
        (name !== "manifest.json" && !(name.startsWith("public/") && allowed.has(name.slice(7))))) fail();
    entries.set(name, tar.subarray(offset, offset + size));
    if (entries.size > WEB_FILES.length + 1) fail();
    offset += size + (512 - size % 512) % 512;
  }
  fail();
}
export async function packageWebsite({ input, output, expectedAppVersion = "0.1.2" }) {
  input = pathRequired(input); output = pathRequired(output);
  const files = await readPublic(input), manifest = manifestFrom(files);
  if (manifest.appVersion !== expectedAppVersion || output === input || output.startsWith(input + "/")) fail();
  await mkdir(output, { mode: 0o700 });
  try {
    const manifestBytes = Buffer.from(JSON.stringify(manifest, null, 2) + "\n");
    const bytes = archive([["manifest.json", manifestBytes], ...WEB_FILES.map(name => [`public/${name}`, files.get(name)])]);
    const filename = `bangbang-web-${manifest.appVersion}-${manifest.digest.slice(0, 12)}.tar.gz`;
    await writeFile(join(output, filename), bytes, { flag: "wx", mode: 0o600 });
    await writeFile(join(output, "manifest.json"), manifestBytes, { flag: "wx", mode: 0o600 });
    await writeFile(join(output, "SHA256SUMS"), `${sha(bytes)}  ${filename}\n`, { flag: "wx", mode: 0o600 });
    return { v: 1, appVersion: manifest.appVersion, files: WEB_FILES.length, bytes: bytes.length, digest: manifest.digest,
      archive: join(output, filename), sha256: sha(bytes) };
  } catch (error) { await rm(output, { recursive: true, force: true }); throw error; }
}
export async function verifyRelease(directory) {
  directory = pathRequired(directory); await physical(directory, true);
  if ((await readdir(directory)).sort().join() !== "manifest.json,public") fail();
  const metadata = await physical(join(directory, "manifest.json"), false);
  if (metadata.size > 32_768) fail();
  return checkManifest(parsed(await readFile(join(directory, "manifest.json"))), await readPublic(join(directory, "public")));
}
async function pointer(root, name) {
  let target;
  try { target = await readlink(join(root, name)); } catch (error) { if (error.code === "ENOENT") return null; throw error; }
  if (!/^releases\/[a-f0-9]{64}$/.test(target)) fail();
  const manifest = await verifyRelease(join(root, target));
  if (target !== `releases/${manifest.digest}`) fail();
  return target;
}
async function replacePointer(root, name, target) {
  const staging = join(root, `.${name}-${randomBytes(8).toString("hex")}`);
  try { await symlink(target, staging); await rename(staging, join(root, name)); }
  finally { await rm(staging, { force: true }); }
}
async function locked(root, operation) {
  root = pathRequired(root); await mkdir(root, { recursive: true, mode: 0o755 }); await physical(root, true);
  await chmod(root, 0o755);
  const lock = join(root, ".deploy-lock"); await mkdir(lock, { mode: 0o700 });
  try { return await operation(root); } finally { await rm(lock, { recursive: true, force: true }); }
}
export async function installWebsite({ archive: filename, expectedSha256, root }) {
  filename = pathRequired(filename);
  const info = await physical(filename, false);
  if (!/^[a-f0-9]{64}$/.test(expectedSha256 ?? "") || info.size > MAX_PACKAGE_BYTES) fail();
  const bytes = await readFile(filename);
  if (sha(bytes) !== expectedSha256) fail();
  const entries = unpack(bytes);
  if (entries.size !== WEB_FILES.length + 1 || !entries.has("manifest.json")) fail();
  const files = new Map(WEB_FILES.map(name => [name, entries.get(`public/${name}`)]));
  if ([...files.values()].some(value => !value)) fail();
  const manifest = checkManifest(parsed(entries.get("manifest.json")), files);
  return await locked(root, async base => {
    const releases = join(base, "releases"); await mkdir(releases, { mode: 0o755 }).catch(error => { if (error.code !== "EEXIST") throw error; });
    await physical(releases, true);
    await chmod(releases, 0o755);
    await pointer(base, "previous");
    const old = await pointer(base, "current"), target = `releases/${manifest.digest}`, destination = join(base, target);
    const stage = join(releases, `.stage-${randomBytes(8).toString("hex")}`); await mkdir(stage, { mode: 0o755 });
    try {
      for (const [name, content] of entries) {
        const path = join(stage, name); await mkdir(dirname(path), { recursive: true, mode: 0o755 });
        await writeFile(path, content, { flag: "wx", mode: 0o444 });
        await chmod(path, 0o444);
      }
      await verifyRelease(stage);
      try { await physical(destination, true); if ((await verifyRelease(destination)).digest !== manifest.digest) fail(); }
      catch (error) {
        if (error.code !== "ENOENT") throw error;
        for (const dir of ["public/assets", "public/downloads", "public/.well-known", "public", ""]) await chmod(join(stage, dir), 0o555);
        await rename(stage, destination);
      }
      if (old !== target) {
        if (old) await replacePointer(base, "previous", old);
        await replacePointer(base, "current", target);
      }
      return { v: 1, digest: manifest.digest, appVersion: manifest.appVersion, alreadyCurrent: old === target };
    } finally { await rm(stage, { recursive: true, force: true }); }
  });
}
export async function verifyCurrent(root) {
  root = pathRequired(root); await physical(root, true);
  const current = await pointer(root, "current"); if (!current) fail();
  return await verifyRelease(join(root, current));
}
export async function rollbackWebsite(root) {
  return await locked(root, async base => {
    const current = await pointer(base, "current"), previous = await pointer(base, "previous");
    if (!current || !previous || current === previous) fail();
    await replacePointer(base, "previous", current); await replacePointer(base, "current", previous);
    return { v: 1, digest: previous.slice("releases/".length), rolledBack: true };
  });
}
function options(argv) {
  const result = {}, names = { "--input": "input", "--output": "output", "--expected-app-version": "expectedAppVersion",
    "--archive": "archive", "--expected-sha256": "expectedSha256", "--root": "root" };
  for (let i = 0; i < argv.length; i += 2) {
    const name = names[argv[i]];
    if (!name || !argv[i + 1] || Object.hasOwn(result, name)) fail();
    result[name] = argv[i + 1];
  }
  return result;
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const [command, ...argv] = process.argv.slice(2), args = options(argv);
    let result;
    if (command === "package" && exactKeys(args, ["input", "output", "expectedAppVersion"])) result = await packageWebsite(args);
    else if (command === "install" && exactKeys(args, ["archive", "expectedSha256", "root"])) result = await installWebsite(args);
    else if (command === "verify" && exactKeys(args, ["root"])) {
      const manifest = await verifyCurrent(args.root); result = { v: 1, digest: manifest.digest, files: manifest.files.length, appVersion: manifest.appVersion };
    } else if (command === "rollback" && exactKeys(args, ["root"])) result = await rollbackWebsite(args.root);
    else fail();
    process.stdout.write(JSON.stringify(result) + "\n");
  } catch { process.stderr.write("web_release_invalid\n"); process.exitCode = 1; }
}
