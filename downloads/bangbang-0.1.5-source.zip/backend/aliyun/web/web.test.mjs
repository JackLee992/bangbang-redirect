import test from "node:test";
import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
import { existsSync } from "node:fs";
import { chmod, cp, lstat, mkdir, mkdtemp, readFile, readdir, readlink, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createServer } from "node:net";
import { fileURLToPath } from "node:url";
import { WEB_FILES, WEB_ORIGIN, packageWebsite, installWebsite, verifyCurrent, rollbackWebsite } from "./release.mjs";
import { caddyfile, startupConfiguration } from "./start.mjs";

const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const cli = fileURLToPath(new URL("./release.mjs", import.meta.url));
const binary = process.env.BANGBANG_TEST_CADDY_BIN ?? "/usr/bin/caddy";
async function writable(path) {
  const info = await lstat(path);
  if (!info.isDirectory() || info.isSymbolicLink()) return;
  await chmod(path, 0o755);
  for (const child of await readdir(path)) await writable(join(path, child));
}
async function inputAt(path, label = "one") {
  const base = "https://bangbang-services.s419505080.chatgpt.site/downloads/";
  const release = { version: "0.1.2", android: { filename: "bangbang-0.1.2-arm.apk" }, source: { filename: "bangbang-0.1.2-source.zip" } };
  const association = [{ relation: ["delegate_permission/common.handle_all_urls"], target: { namespace: "android_app",
    package_name: "com.example.bangbang", sha256_cert_fingerprints: [Array(32).fill("AA").join(":")] } }];
  const deployment = { target: "aliyun", websiteUrl: WEB_ORIGIN, appVersion: release.version, downloadBaseUrl: base,
    familyApiBaseUrl: "https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family",
    downloads: { android: base + release.android.filename, source: base + release.source.filename } };
  for (const name of WEB_FILES) {
    const filename = join(path, name); await mkdir(join(filename, ".."), { recursive: true });
    let content = `controlled-${name}-${label}`;
    if (name.endsWith(".html")) content = `<html><body>${name}-${label}<a href="${deployment.downloads.android}">Android</a></body></html>`;
    if (name === "deployment.json") content = JSON.stringify(deployment);
    else if (name === "release.json") content = JSON.stringify(release);
    else if (name.endsWith("assetlinks.json")) content = JSON.stringify(association);
    else if (name.endsWith("build-info.json")) content = '{"version":"0.1.2"}';
    await writeFile(filename, content);
  }
  return path;
}
async function fixture(t) {
  const folder = await mkdtemp(join(tmpdir(), "bangbang-web-test-"));
  t.after(async () => { await writable(folder); await rm(folder, { recursive: true, force: true }); });
  const input = await inputAt(join(folder, "input")), root = join(folder, "installed");
  const bundle = await packageWebsite({ input, output: join(folder, "package") });
  const install = extra => installWebsite({ archive: bundle.archive, expectedSha256: bundle.sha256, root, ...extra });
  return { folder, input, root, bundle, install };
}
const giteeAndroid = "https://gitee.com/yilin-dev/bangbang-releases/releases/download/v0.1.3/bangbang-0.1.3-arm.apk";
async function useGiteeDistribution(input, downloadUrl = giteeAndroid) {
  const deployment = JSON.parse(await readFile(join(input, "deployment.json")));
  const release = JSON.parse(await readFile(join(input, "release.json")));
  const previousAndroid = deployment.downloads.android;
  release.version = deployment.appVersion = "0.1.3";
  release.android.filename = "bangbang-0.1.3-arm.apk"; release.android.downloadUrl = downloadUrl;
  release.source.filename = "bangbang-0.1.3-source.zip";
  deployment.downloads.android = downloadUrl;
  deployment.downloads.source = deployment.downloadBaseUrl + release.source.filename;
  await writeFile(join(input, "release.json"), JSON.stringify(release));
  await writeFile(join(input, "deployment.json"), JSON.stringify(deployment));
  await writeFile(join(input, "downloads/build-info.json"), '{"version":"0.1.3"}');
  for (const name of WEB_FILES.filter(name => name.endsWith(".html"))) {
    const filename = join(input, name);
    await writeFile(filename, (await readFile(filename, "utf8")).replaceAll(previousAndroid, downloadUrl));
  }
}

test("a real archive verifies all 20 actual files and restores only read-only static content", async t => {
  const f = await fixture(t); const installed = await f.install();
  assert.equal(installed.digest, f.bundle.digest); assert.equal(installed.appVersion, "0.1.2");
  assert.equal(await readlink(join(f.root, "current")), `releases/${f.bundle.digest}`);
  const manifest = await verifyCurrent(f.root);
  assert.deepEqual(manifest.files.map(file => file.path), WEB_FILES);
  for (const file of manifest.files) {
    const filename = join(f.root, "current/public", file.path), bytes = await readFile(filename);
    assert.equal(sha(bytes), file.sha256); assert.equal(bytes.length, file.bytes);
    assert.equal((await lstat(filename)).mode & 0o222, 0);
  }
  assert.equal((await lstat(join(f.root, "current/public"))).mode & 0o222, 0);
  assert.equal((await f.install()).alreadyCurrent, true);
});

test("stage validation precedes atomic current switch; previous survives repeat install and rollback", async t => {
  const f = await fixture(t); await f.install();
  const nextInput = await inputAt(join(f.folder, "next-input"), "two");
  const next = await packageWebsite({ input: nextInput, output: join(f.folder, "next-package") });
  await f.install({ archive: next.archive, expectedSha256: next.sha256 });
  assert.equal(await readlink(join(f.root, "current")), `releases/${next.digest}`);
  assert.equal(await readlink(join(f.root, "previous")), `releases/${f.bundle.digest}`);
  await f.install({ archive: next.archive, expectedSha256: next.sha256 });
  assert.equal(await readlink(join(f.root, "previous")), `releases/${f.bundle.digest}`);
  await rollbackWebsite(f.root);
  assert.equal((await verifyCurrent(f.root)).digest, f.bundle.digest);
  assert.equal(await readlink(join(f.root, "previous")), `releases/${next.digest}`);
  assert.match(await readFile(join(f.root, "current/public/index.html"), "utf8"), /index.html-one/);
});

test("verified Gitee APK overrides upgrade and roll back to legacy Sites downloads without changing API or source", async t => {
  const f = await fixture(t); await f.install();
  const input = await inputAt(join(f.folder, "gitee-input")); await useGiteeDistribution(input);
  const next = await packageWebsite({ input, output: join(f.folder, "gitee-package"), expectedAppVersion: "0.1.3" });
  await f.install({ archive: next.archive, expectedSha256: next.sha256 });
  assert.equal((await verifyCurrent(f.root)).appVersion, "0.1.3");
  const deployment = JSON.parse(await readFile(join(f.root, "current/public/deployment.json")));
  assert.equal(deployment.downloads.android, giteeAndroid);
  assert.equal(deployment.downloads.source, "https://bangbang-services.s419505080.chatgpt.site/downloads/bangbang-0.1.3-source.zip");
  assert.equal(deployment.familyApiBaseUrl, "https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family");
  await rollbackWebsite(f.root);
  assert.equal((await verifyCurrent(f.root)).appVersion, "0.1.2");
  assert.equal(JSON.parse(await readFile(join(f.root, "current/public/deployment.json"))).downloads.android,
    "https://bangbang-services.s419505080.chatgpt.site/downloads/bangbang-0.1.2-arm.apk");
});

test("Gitee APK overrides reject alternate origin, credentials, ports, repo, tag, encoding, query and fragment", async t => {
  const f = await fixture(t);
  const invalid = [giteeAndroid.replace("https:", "http:"), giteeAndroid.replace("gitee.com", "gitee.com:443"),
    giteeAndroid + "?via=share", giteeAndroid + "#fragment", giteeAndroid.replace("yilin-dev/", "another-owner/"),
    giteeAndroid.replace("bangbang-releases/", "another-repo/"), giteeAndroid.replace("/v0.1.3/", "/v0.1.4/"),
    giteeAndroid.replace("/bangbang-0.1.3-arm.apk", "/another.apk"),
    giteeAndroid.replace("/v0.1.3/", "/%760.1.3/"), giteeAndroid.replace("/bangbang-0.1.3-arm.apk", "/%62angbang-0.1.3-arm.apk"),
    giteeAndroid.replace("/v0.1.3/", "/v0.1.3/../v0.1.3/"), giteeAndroid.replace("gitee.com", "other.test"),
    giteeAndroid.replace("gitee.com", "controlled-user@gitee.com"), "", null];
  for (const [i, url] of invalid.entries()) {
    const input = await inputAt(join(f.folder, `bad-gitee-${i}`)); await useGiteeDistribution(input, url);
    await assert.rejects(packageWebsite({ input, output: input + "-package", expectedAppVersion: "0.1.3" }), /web_release_invalid/);
  }
  const undeclared = await inputAt(join(f.folder, "undeclared-gitee")); await useGiteeDistribution(undeclared);
  const release = JSON.parse(await readFile(join(undeclared, "release.json"))); delete release.android.downloadUrl;
  await writeFile(join(undeclared, "release.json"), JSON.stringify(release));
  await assert.rejects(packageWebsite({ input: undeclared, output: undeclared + "-package", expectedAppVersion: "0.1.3" }), /web_release_invalid/);
});

test("hidden files, nonmanifest paths, package binaries, databases, symlinks and private keys never enter a package", async t => {
  const f = await fixture(t);
  for (const extra of [".env", ".git/config", "assets/unlisted.png", "downloads/app.apk", "downloads/source.zip", "site.sqlite", "_headers"]) {
    const input = join(f.folder, `bad-${extra.replaceAll(/[^A-Za-z]/g, "")}`);
    await cp(f.input, input, { recursive: true }); await mkdir(join(input, extra, ".."), { recursive: true });
    await writeFile(join(input, extra), "private-material");
    await assert.rejects(packageWebsite({ input, output: input + "-package" }), /web_release_invalid/);
  }
  await symlink(join(f.input, "app.js"), join(f.input, "extra.js"));
  await assert.rejects(packageWebsite({ input: f.input, output: join(f.folder, "symlink-package") }), /web_release_invalid/);
  await rm(join(f.input, "extra.js"));
  await writeFile(join(f.input, "assets/brand.svg"), "-----BEGIN PRIVATE KEY-----\nprivate\n-----END PRIVATE KEY-----");
  await assert.rejects(packageWebsite({ input: f.input, output: join(f.folder, "key-package") }), /web_release_invalid/);
});

test("Aliyun origin, external downloads, Sites API, app version and Android association are checked before publication", async t => {
  const f = await fixture(t);
  const filename = join(f.input, "deployment.json"), original = JSON.parse(await readFile(filename));
  for (const update of [{ target: "netlify" }, { websiteUrl: "https://other.test/" }, { downloadBaseUrl: "https://bangbang.yilin.fun/downloads/" },
    { familyApiBaseUrl: "https://api.bangbang.yilin.fun/.netlify/functions/family" }, { appVersion: "0.1.3" }]) {
    await writeFile(filename, JSON.stringify({ ...original, ...update }));
    await assert.rejects(packageWebsite({ input: f.input, output: join(f.folder, "invalid-package") }), /web_release_invalid/);
  }
  await writeFile(filename, JSON.stringify(original));
  await assert.rejects(packageWebsite({ input: f.input, output: join(f.folder, "wrong-version"), expectedAppVersion: "0.1.3" }), /web_release_invalid/);
  await writeFile(join(f.input, ".well-known/assetlinks.json"), "{}");
  await assert.rejects(packageWebsite({ input: f.input, output: join(f.folder, "bad-association") }), /web_release_invalid/);
});

test("bad transport SHA, archive traversal and symlink entries cannot alter the current release", async t => {
  const f = await fixture(t); await f.install();
  await assert.rejects(f.install({ expectedSha256: "0".repeat(64) }), /web_release_invalid/);
  const original = gunzipSync(await readFile(f.bundle.archive));
  for (const [name, type] of [["../../escape", "0"], ["public/.env", "0"], ["manifest.json", "2"]]) {
    const tar = Buffer.from(original); tar.fill(0, 0, 100); tar.write(name, 0, 100); tar.write(type, 156, 1);
    tar.fill(32, 148, 156);
    tar.write([...tar.subarray(0, 512)].reduce((sum, value) => sum + value, 0).toString(8).padStart(6, "0") + "\0 ", 148, 8);
    const bytes = gzipSync(tar), archive = join(f.folder, `bad-${type}-${name.replaceAll(/[^A-Za-z]/g, "")}.tar.gz`);
    await writeFile(archive, bytes);
    await assert.rejects(f.install({ archive, expectedSha256: sha(bytes) }), /web_release_invalid/);
    assert.equal((await verifyCurrent(f.root)).digest, f.bundle.digest);
  }
  assert.equal(existsSync(join(f.folder, "escape")), false);
});

test("concurrent deployments are excluded and a foreign current pointer never gets replaced", async t => {
  const f = await fixture(t); await f.install();
  await mkdir(join(f.root, ".deploy-lock"));
  await assert.rejects(f.install(), /EEXIST/); await rm(join(f.root, ".deploy-lock"), { recursive: true });
  await rm(join(f.root, "current")); await symlink(f.input, join(f.root, "current"));
  await assert.rejects(f.install(), /web_release_invalid/);
  assert.equal(await readlink(join(f.root, "current")), f.input);
});

test("tampered contents and a mismatched preexisting immutable release never activate", async t => {
  const f = await fixture(t); await f.install();
  await chmod(join(f.root, "current/public/app.js"), 0o644);
  await writeFile(join(f.root, "current/public/app.js"), "tampered");
  await assert.rejects(verifyCurrent(f.root), /web_release_invalid/);
  await assert.rejects(f.install(), /web_release_invalid/);
});

test("independent CLI installation/verification use no npm and only fixed error output", async t => {
  const f = await fixture(t);
  const installed = spawnSync(process.execPath, [cli, "install", "--archive", f.bundle.archive,
    "--expected-sha256", f.bundle.sha256, "--root", f.root], { encoding: "utf8" });
  assert.equal(installed.status, 0); assert.equal(JSON.parse(installed.stdout).digest, f.bundle.digest);
  const verified = spawnSync(process.execPath, [cli, "verify", "--root", f.root], { encoding: "utf8" });
  assert.equal(verified.status, 0); assert.equal(JSON.parse(verified.stdout).files, 20);
  const failed = spawnSync(process.execPath, [cli, "install", "--archive", f.bundle.archive,
    "--expected-sha256", "invalid-secret-input", "--root", f.root], { encoding: "utf8" });
  assert.equal(failed.status, 1); assert.equal(failed.stdout, ""); assert.equal(failed.stderr, "web_release_invalid\n");
});

test("startup is closed before readiness or complete static validation; unit is nonroot and read-only", async t => {
  const f = await fixture(t); await f.install();
  for (const ready of [undefined, "false", "TRUE", "1"]) {
    await assert.rejects(startupConfiguration({ BANGBANG_WEB_ROOT: f.root, BANGBANG_WEB_HTTPS_READY: ready }), /not_ready/);
  }
  const env = { BANGBANG_WEB_ROOT: f.root, BANGBANG_WEB_HTTPS_READY: "true" };
  assert.deepEqual(await startupConfiguration(env), { binary: "/usr/bin/caddy", publicRoot: join(f.root, "current/public") });
  await assert.rejects(startupConfiguration({ ...env, BANGBANG_CADDY_BIN: "caddy" }), /not_ready/);
  await chmod(join(f.root, "current/public"), 0o755); await writeFile(join(f.root, "current/public/.env"), "private");
  await assert.rejects(startupConfiguration(env), /web_release_invalid/);
  const unit = await readFile(new URL("./bangbang-web.service", import.meta.url), "utf8");
  assert.match(unit, /User=caddy/); assert.match(unit, /ProtectSystem=strict/);
  assert.doesNotMatch(unit, /ExecReload=|Conflicts=/);
});

async function port() {
  const server = createServer(); await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  const value = server.address().port; await new Promise(resolve => server.close(resolve)); return value;
}
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
async function runningCaddy(t, f, ready = "true") {
  const base = `http://127.0.0.1:${await port()}`;
  const filename = join(f.folder, "Caddyfile");
  await writeFile(filename, (await readFile(caddyfile, "utf8")).replace("https://bangbang.yilin.fun", base));
  const child = spawn(binary, ["run", "--config", filename, "--adapter", "caddyfile"], { env: {
    PATH: process.env.PATH, XDG_DATA_HOME: f.folder, XDG_CONFIG_HOME: f.folder,
    BANGBANG_WEB_PUBLIC_ROOT: join(f.root, "current/public"), BANGBANG_WEB_HTTPS_READY: ready,
  }, stdio: ["ignore", "pipe", "pipe"] });
  let logs = ""; for (const stream of [child.stdout, child.stderr]) stream.on("data", bytes => { logs += bytes.toString(); });
  const closed = new Promise(resolve => child.once("close", resolve));
  t.after(async () => { if (child.exitCode === null) child.kill("SIGTERM"); await closed; assert.equal(logs.includes("BB1-test-query"), false); });
  const send = (path, options = {}) => fetch(base + path, { ...options, redirect: "error", cache: "no-store", signal: AbortSignal.timeout(2000) });
  for (let attempt = 0; attempt < 60; attempt++) {
    try { await send("/"); return { send, base }; } catch { if (child.exitCode !== null) assert.fail("controlled Caddy startup failed"); await pause(30); }
  }
  assert.fail("controlled Caddy did not become ready");
}

test("real Caddy accepts production configuration without public start or credential logging", { skip: !existsSync(binary) }, async t => {
  const f = await fixture(t); await f.install();
  const result = spawnSync(binary, ["validate", "--config", caddyfile, "--adapter", "caddyfile"], { encoding: "utf8", timeout: 15000,
    env: { PATH: process.env.PATH, XDG_DATA_HOME: f.folder, XDG_CONFIG_HOME: f.folder,
      BANGBANG_WEB_HTTPS_READY: "true", BANGBANG_WEB_PUBLIC_ROOT: join(f.root, "current/public") } });
  assert.equal(result.status, 0);
  const denied = await runningCaddy(t, f, "false"); assert.equal((await denied.send("/")).status, 503);
});

test("real Caddy serves exact assets/legal/help and both invitations preserve URL query; API never returns homepage", { skip: !existsSync(binary) }, async t => {
  const f = await fixture(t); await f.install(); const { send, base } = await runningCaddy(t, f);
  for (const path of ["/", "/help", "/help.html", "/legal", "/privacy.html", "/assets/brand.png", "/styles.css", "/downloads/AGPL-3.0.txt"]) {
    const response = await send(path); assert.equal(response.status, 200, path); assert.equal(response.redirected, false);
    assert.equal(response.headers.get("x-content-type-options"), "nosniff");
  }
  for (const path of ["/invite?code=BB1-test-query&extra=keep", "/invite.html?code=BB1-test-query"]) {
    const response = await send(path); assert.equal(response.status, 200); assert.equal(response.url, base + path);
    assert.match(await response.text(), /invite.html-one/); assert.equal(response.headers.get("location"), null);
  }
  for (const path of ["/.well-known/assetlinks.json", "/assetlinks.json"]) {
    const response = await send(path); assert.equal(response.status, 200); assert.match(response.headers.get("content-type"), /^application\/json/);
    assert.equal((await response.json())[0].target.namespace, "android_app");
  }
  for (const path of ["/.env", "/manifest.json", "/assets/unlisted.png", "/downloads/app.apk", "/unknown"]) assert.equal((await send(path)).status, 404, path);
  for (const path of ["/.netlify/functions/family", "/api/health", "/v1/attempts"]) {
    for (const method of ["GET", "POST"]) {
      const response = await send(path, { method }); assert.equal(response.status, 404);
      assert.deepEqual(await response.json(), { v: 1, ok: false, error: "not_found" });
    }
  }
  assert.equal((await send("/index.html", { method: "POST" })).status, 405);
});

test("real Caddy observes atomic deployment and rollback without configuration reload", { skip: !existsSync(binary) }, async t => {
  const f = await fixture(t); await f.install(); const { send } = await runningCaddy(t, f);
  assert.match(await (await send("/")).text(), /index.html-one/);
  const input = await inputAt(join(f.folder, "second-input"), "two");
  const bundle = await packageWebsite({ input, output: join(f.folder, "second-package") });
  await f.install({ archive: bundle.archive, expectedSha256: bundle.sha256 });
  assert.match(await (await send("/")).text(), /index.html-two/);
  await rollbackWebsite(f.root);
  assert.match(await (await send("/")).text(), /index.html-one/);
});
