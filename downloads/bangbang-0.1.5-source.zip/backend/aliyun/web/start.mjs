import { spawn } from "node:child_process";
import { isAbsolute, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { verifyCurrent } from "./release.mjs";

export const caddyfile = fileURLToPath(new URL("./Caddyfile", import.meta.url));
export async function startupConfiguration(env) {
  if (env.BANGBANG_WEB_HTTPS_READY !== "true") throw new Error("web_configuration_not_ready");
  const root = env.BANGBANG_WEB_ROOT ?? "/var/www/bangbang", binary = env.BANGBANG_CADDY_BIN ?? "/usr/bin/caddy";
  if (![root, binary].every(value => typeof value === "string" && isAbsolute(value) && !/[\r\n\0]/.test(value))) {
    throw new Error("web_configuration_not_ready");
  }
  await verifyCurrent(root);
  return { binary, publicRoot: join(root, "current/public") };
}
export async function startCaddy({ env = process.env } = {}) {
  const { binary, publicRoot } = await startupConfiguration(env);
  const runtimeEnv = { BANGBANG_WEB_HTTPS_READY: "true", BANGBANG_WEB_PUBLIC_ROOT: publicRoot };
  for (const key of ["PATH", "TMPDIR", "XDG_DATA_HOME", "XDG_CONFIG_HOME"]) if (env[key]) runtimeEnv[key] = env[key];
  const child = spawn(binary, ["run", "--config", caddyfile, "--adapter", "caddyfile"], { env: runtimeEnv, stdio: ["ignore", "inherit", "inherit"] });
  let stopping = false;
  const stop = () => { stopping = true; child.kill("SIGTERM"); };
  process.once("SIGINT", stop); process.once("SIGTERM", stop);
  const cleanup = () => { process.off("SIGINT", stop); process.off("SIGTERM", stop); };
  child.once("error", () => { cleanup(); process.stderr.write("web_start_failed\n"); process.exitCode = 1; });
  child.once("exit", code => { cleanup(); process.exitCode = code ?? (stopping ? 0 : 1); });
  return child;
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { await startCaddy(); }
  catch { process.stderr.write("web_configuration_not_ready\n"); process.exitCode = 78; }
}
