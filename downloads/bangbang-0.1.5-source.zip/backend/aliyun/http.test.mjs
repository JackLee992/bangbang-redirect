import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { request as httpRequest } from "node:http";
import { once } from "node:events";
import { createAliyunHTTPServer, startAliyunServer } from "./http.mjs";

async function fixture(t, extra = {}) {
  const received = [];
  const env = { BANGBANG_PUBLIC_ORIGIN: "https://api.controlled.test", ...extra };
  const server = createAliyunHTTPServer({ env, application: { async fetch(request) {
    received.push(request); return new Response('{"ok":true}', { headers: { "content-type": "application/json" } });
  } } });
  server.listen(0, "127.0.0.1"); await once(server, "listening");
  t.after(() => new Promise(resolve => server.close(resolve)));
  return { server, received, base: `http://127.0.0.1:${server.address().port}` };
}
test("HTTP bridge discards spoofed forwarding headers and keeps actual device Authorization", async t => {
  const f = await fixture(t);
  const auth = `Bearer ${randomBytes(16).toString("base64url")}.${randomBytes(32).toString("base64url")}`;
  const response = await fetch(`${f.base}/.netlify/functions/family`, { method: "POST", body: "{}", headers: {
    "content-type": "application/json", authorization: auth,
    "cf-connecting-ip": "192.0.2.50", "x-forwarded-for": "192.0.2.51", "x-real-ip": "192.0.2.52",
    "x-bangbang-client-ip": "192.0.2.53", "x-bangbang-proxy-secret": "untrusted" } });
  assert.equal(response.status, 200);
  assert.equal(f.received[0].headers.get("authorization"), auth);
  assert.equal(f.received[0].headers.get("cf-connecting-ip"), "127.0.0.1");
  for (const name of ["x-forwarded-for", "x-real-ip", "x-bangbang-client-ip", "x-bangbang-proxy-secret"]) {
    assert.equal(f.received[0].headers.has(name), false);
  }
  assert.equal(new URL(f.received[0].url).origin, "https://api.controlled.test");
});

test("Sites gateway secret is independent, verified before reading body, and is required for trusted client IP", async t => {
  const secret = randomBytes(32).toString("base64url");
  const f = await fixture(t, { BANGBANG_ECS_PROXY_SECRET: secret });
  for (const supplied of ["", "wrong", `Bearer ${secret}`]) {
    const result = await fetch(`${f.base}/api/health`, { headers: { "x-bangbang-proxy-secret": supplied } });
    assert.equal(result.status, 401); assert.equal((await result.text()).includes(secret), false);
  }
  assert.equal(f.received.length, 0);
  const approved = await fetch(`${f.base}/.netlify/functions/family`, { method: "POST", body: "{}", headers: {
    "content-type": "application/json", "x-bangbang-proxy-secret": secret, "x-bangbang-client-ip": "192.0.2.10" } });
  assert.equal(approved.status, 200);
  assert.equal(f.received[0].headers.get("cf-connecting-ip"), "192.0.2.10");
  assert.equal(f.received[0].headers.has("x-bangbang-proxy-secret"), false);
  assert.equal((await fetch(`${f.base}/api/health`, { headers: {
    "x-bangbang-proxy-secret": secret, "x-bangbang-client-ip": "invalid,192.0.2.10" } })).status, 400);
});

test("chunked oversized bodies are bounded and production startup refuses public/plain listeners", async t => {
  const f = await fixture(t);
  const status = await new Promise((resolve, reject) => {
    const request = httpRequest(`${f.base}/.netlify/functions/family`, { method: "POST",
      headers: { "content-type": "application/json", "transfer-encoding": "chunked" } }, response => {
      response.resume(); response.once("end", () => resolve(response.statusCode));
    });
    request.once("error", reject); request.write(Buffer.alloc(9000, 32)); request.end();
  });
  assert.equal(status, 413); assert.equal(f.received.length, 0);
  assert.throws(() => startAliyunServer({ env: { BANGBANG_FAMILY_HOST: "0.0.0.0", BANGBANG_PUBLIC_ORIGIN: "https://api.controlled.test" } }), /invalid_server_configuration/);
  assert.throws(() => createAliyunHTTPServer({ application: {}, env: { BANGBANG_PUBLIC_ORIGIN: "http://api.controlled.test" } }), /invalid_server_configuration/);
  assert.throws(() => createAliyunHTTPServer({ application: {}, env: { BANGBANG_PUBLIC_ORIGIN: "https://api.controlled.test", BANGBANG_ECS_PROXY_SECRET: "too-short" } }), /invalid_server_configuration/);
});
