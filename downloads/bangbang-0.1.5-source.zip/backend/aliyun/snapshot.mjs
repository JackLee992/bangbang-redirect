import { createHash, createHmac, randomUUID } from "node:crypto";
import { diagnosticPhases, diagnosticErrors } from "../diagnostics/worker.mjs";
import { diagnosticSecret } from "../../site/server/sites_diagnostics_store.mjs";
import { validFreezeEvidence, verifiedFreezeEvidence } from "../../site/worker/authority-fence.mjs";

export const MAX_SNAPSHOT_BYTES = 134_217_728;
export const AUTHORITY_SNAPSHOT_VERSION = 3;
const PAGE_SIZE = 128;
const MAX_ROWS = 100_000;
const attempts = { table: "bangbang_diagnostic_attempts", pk: ["installation_hash", "attempt_hash"],
  columns: ["installation_hash", "attempt_hash", "call_hash", "role", "kind", "platform", "app_version", "build",
    "started_at", "elapsed_ms", "phase", "outcome", "error", "path", "revision", "received_at"] };
const limits = { table: "bangbang_diagnostic_limits", pk: ["kind", "subject_hash", "window"],
  columns: ["kind", "subject_hash", "window", "requests", "events", "updated_at"] };
const id = "[A-Za-z0-9_-]{22}";
const familyKeys = [new RegExp(`^(devices|pairs)/${id}$`), new RegExp(`^claims/${id}/${id}$`),
  /^push-tokens\/[a-f0-9]{64}$/, new RegExp(`^push-ready/[0-9]{1,12}/${id}/${id}$`),
  new RegExp(`^dispatch-claims/${id}$`), /^rate-limits\/[0-9]{1,12}\/[a-f0-9]{64}$/];
const fail = (code = "snapshot_invalid") => { throw new Error(code); };
const integer = (value, min = 0, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(value) && value >= min && value <= max;
const exactKeys = (value, keys) => value && !Array.isArray(value) && typeof value === "object" &&
  Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
const hex = value => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);

/** Only the scope and diagnostic HMAC key define the persistent hash namespace.
 * Provider, scheduler and administrator credentials may rotate independently.
 * The domain-separated fingerprint is safe to audit; it cannot recover the key.
 */
export function authorityConfigurationFingerprint(configuration) {
  const scope = configuration?.BANGBANG_FAMILY_STORE_SCOPE;
  const key = diagnosticSecret(configuration?.BANGBANG_DIAGNOSTICS_HASH_SECRET);
  if (typeof scope !== "string" || !/^[A-Za-z0-9_-]{1,100}$/.test(scope) || !key) fail("authority_configuration_invalid");
  return createHmac("sha256", key).update(`bangbang-authority-configuration/v1\n${scope}\n`).digest("hex");
}
function checkedConfiguration(configuration, scope) {
  if (configuration?.BANGBANG_FAMILY_STORE_SCOPE !== scope) fail("authority_configuration_mismatch");
  return authorityConfigurationFingerprint(configuration);
}
function paused(configuration, apiEnabled) {
  if (apiEnabled !== "false" || configuration?.BANGBANG_FAMILY_API_ENABLED !== "false" ||
      configuration?.BANGBANG_DIAGNOSTICS_INGEST_ENABLED !== "false") fail("authority_must_be_paused");
}

function canonical(value, depth = 0) {
  if (depth > 32 || (typeof value === "number" && !Number.isFinite(value))) fail();
  if (Array.isArray(value)) return `[${value.map(item => canonical(item, depth + 1)).join(",")}]`;
  if (value !== null && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonical(value[key], depth + 1)}`).join(",")}}`;
  const result = JSON.stringify(value);
  if (result === undefined) fail();
  return result;
}
function compareRows(columns) {
  return (a, b) => {
    for (const name of columns) {
      if (a[name] < b[name]) return -1;
      if (a[name] > b[name]) return 1;
    }
    return 0;
  };
}
function content(snapshot) {
  return { v: snapshot.v, scope: snapshot.scope, purpose: snapshot.purpose, configFingerprint: snapshot.configFingerprint,
    ...(snapshot.v === 3 ? { freezeEvidence: snapshot.freezeEvidence } : {}),
    records: snapshot.records.slice().sort(compareRows(["key"])),
    diagnostics: { attempts: snapshot.diagnostics.attempts.slice().sort(compareRows(attempts.pk)),
      limits: snapshot.diagnostics.limits.slice().sort(compareRows(limits.pk)) } };
}
export function authoritySnapshotDigest(snapshot) {
  return createHash("sha256").update(canonical(content(snapshot))).digest("hex");
}
function countsFor(snapshot) {
  return { family: snapshot.records.length, attempts: snapshot.diagnostics.attempts.length, limits: snapshot.diagnostics.limits.length };
}
function validAttempt(row) {
  return exactKeys(row, attempts.columns) && [row.installation_hash, row.attempt_hash, row.call_hash].every(hex) &&
    ["elder", "helper"].includes(row.role) && ["connection", "preparation", "call"].includes(row.kind) &&
    ["ios", "android"].includes(row.platform) && typeof row.app_version === "string" && row.app_version.length <= 40 &&
    /^\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.]+)?$/.test(row.app_version) && typeof row.build === "string" && /^\d{1,12}$/.test(row.build) &&
    integer(row.started_at, 1) && integer(row.elapsed_ms, 0, 600_000) && integer(row.received_at, 1) && integer(row.revision, 0, 64) &&
    diagnosticPhases.includes(row.phase) &&
    ["success", "failure", "cancelled", "interrupted", "pending", "ready"].includes(row.outcome) &&
    diagnosticErrors.includes(row.error) &&
    ["unknown", "direct", "relay"].includes(row.path) && (row.outcome !== "success" || row.phase === "firstFrame") &&
    (row.outcome !== "ready" || (row.kind === "preparation" && row.phase === "serviceReady"));
}
function validLimit(row) {
  return exactKeys(row, limits.columns) && ["installation_minute", "scope_minute", "scope_day", "admin_minute", "admin_day"].includes(row.kind) &&
    hex(row.subject_hash) && [row.window, row.requests, row.events].every(value => integer(value)) && integer(row.updated_at, 1);
}
function validate(snapshot, scope, expectedDigest) {
  const version3 = snapshot?.v === 3;
  if (!exactKeys(snapshot, ["v", "scope", "purpose", "configFingerprint", "createdAt", "records", "diagnostics", "counts", "digest",
    ...(version3 ? ["freezeEvidence"] : [])]) ||
    (version3 ? snapshot.purpose !== "cutover" : snapshot.v !== 2 || snapshot.purpose !== "rehearsal") || !hex(snapshot.configFingerprint) ||
    typeof scope !== "string" || !/^[A-Za-z0-9_-]{1,100}$/.test(scope) || snapshot.scope !== scope || !integer(snapshot.createdAt, 1) ||
    !hex(expectedDigest) || snapshot.digest !== expectedDigest || !exactKeys(snapshot.diagnostics, ["attempts", "limits"]) ||
    !exactKeys(snapshot.counts, ["family", "attempts", "limits"])) fail();
  if (version3 && !validFreezeEvidence(snapshot.freezeEvidence, scope, { createdAt: snapshot.createdAt })) fail();
  for (const rows of [snapshot.records, snapshot.diagnostics.attempts, snapshot.diagnostics.limits]) {
    if (!Array.isArray(rows) || rows.length > MAX_ROWS) fail();
  }
  const keys = new Set();
  for (const record of snapshot.records) {
    if (!exactKeys(record, ["key", "data", "updatedAt"]) || typeof record.key !== "string" || !integer(record.updatedAt, 1) ||
      !familyKeys.some(pattern => pattern.test(record.key)) || keys.has(record.key) ||
      !record.data || Array.isArray(record.data) || typeof record.data !== "object" ||
      Buffer.byteLength(canonical(record.data)) > 131_072) fail();
    keys.add(record.key);
  }
  for (const [rows, spec, valid] of [[snapshot.diagnostics.attempts, attempts, validAttempt], [snapshot.diagnostics.limits, limits, validLimit]]) {
    const seen = new Set();
    for (const row of rows) {
      const key = JSON.stringify(spec.pk.map(name => row?.[name]));
      if (!valid(row) || seen.has(key)) fail();
      seen.add(key);
    }
  }
  if (canonical(snapshot.counts) !== canonical(countsFor(snapshot)) || authoritySnapshotDigest(snapshot) !== expectedDigest ||
    Buffer.byteLength(JSON.stringify(snapshot)) > MAX_SNAPSHOT_BYTES) fail();
  return snapshot;
}
async function readPages(db, scope, { table, columns, pk }, budget) {
  let cursor = pk.map(name => name === "window" ? -1 : "");
  const rows = [];
  while (true) {
    const tuple = pk.length === 1 ? pk[0] : `(${pk.join(", ")})`;
    const parameters = pk.length === 1 ? "?" : `(${pk.map(() => "?").join(", ")})`;
    let result;
    try {
      result = await db.prepare(`SELECT ${columns.join(", ")} FROM ${table}
        WHERE scope = ? AND ${tuple} > ${parameters} ORDER BY ${pk.join(", ")} LIMIT ?`)
        .bind(scope, ...cursor, PAGE_SIZE).all();
    } catch { fail("storage_unavailable"); }
    if (result?.success !== true || !Array.isArray(result.results) || result.results.length > PAGE_SIZE) fail("storage_unavailable");
    for (const row of result.results) {
      if (!exactKeys(row, columns) || compareRows(pk)(row, Object.fromEntries(pk.map((name, index) => [name, cursor[index]]))) <= 0) fail("storage_unavailable");
      budget.bytes += Buffer.byteLength(JSON.stringify(row)) + 2;
      if (budget.bytes > MAX_SNAPSHOT_BYTES - 4096) fail("snapshot_too_large");
      cursor = pk.map(name => row[name]); rows.push({ ...row });
      if (rows.length > MAX_ROWS) fail("snapshot_too_large");
    }
    if (result.results.length < PAGE_SIZE) return rows;
  }
}

/** The caller must actually pause source API + scheduler before both exports.
 * This generic raw-primary D1 interface neither reads cloud secrets nor asserts
 * that setting a local flag has paused a separately deployed source service.
 */
export async function exportAuthoritySnapshot(db, { scope, apiEnabled, configuration, purpose = "cutover", now = Date.now } = {}) {
  if (!["cutover", "rehearsal"].includes(purpose)) fail();
  if (purpose === "cutover") paused(configuration, apiEnabled);
  else if (!["false", "true"].includes(apiEnabled) || configuration?.BANGBANG_FAMILY_API_ENABLED !== apiEnabled) fail("authority_configuration_mismatch");
  const configFingerprint = checkedConfiguration(configuration, scope);
  const freezeEvidence = purpose === "cutover" ? await verifiedFreezeEvidence(db, { scope }) : undefined;
  const snapshot = await readSnapshotTables(db, { scope, configFingerprint, purpose, freezeEvidence, now });
  if (freezeEvidence && canonical(await verifiedFreezeEvidence(db, { scope })) !== canonical(freezeEvidence)) fail("authority_fence_changed");
  return snapshot;
}

async function readSnapshotTables(db, { scope, configFingerprint, purpose, freezeEvidence, now }) {
  const budget = { bytes: 0 };
  const family = await readPages(db, scope, { table: "bangbang_family_records", columns: ["key", "json", "updated_at"], pk: ["key"] }, budget);
  const diagnosticAttempts = await readPages(db, scope, attempts, budget);
  const diagnosticLimits = await readPages(db, scope, limits, budget);
  const records = family.map(row => {
    try { return { key: row.key, data: JSON.parse(row.json), updatedAt: row.updated_at }; }
    catch { fail("snapshot_invalid"); }
  });
  const snapshot = { v: purpose === "cutover" ? AUTHORITY_SNAPSHOT_VERSION : 2, scope, purpose, configFingerprint,
    ...(purpose === "cutover" ? { freezeEvidence } : {}), createdAt: now(), records,
    diagnostics: { attempts: diagnosticAttempts, limits: diagnosticLimits } };
  snapshot.counts = countsFor(snapshot);
  snapshot.digest = authoritySnapshotDigest(snapshot);
  return validate(snapshot, scope, snapshot.digest);
}

export async function verifyAuthoritySnapshot(db, snapshot, { scope, apiEnabled, expectedDigest, expectedSourceEpoch, configuration, now = Date.now } = {}) {
  paused(configuration, apiEnabled);
  validate(snapshot, scope, expectedDigest);
  if (expectedSourceEpoch !== undefined && (snapshot.purpose !== "cutover" || expectedSourceEpoch !== snapshot.freezeEvidence.epoch)) {
    fail("source_epoch_mismatch");
  }
  if (checkedConfiguration(configuration, scope) !== snapshot.configFingerprint) fail("authority_configuration_mismatch");
  // Target verification compares business rows against the authenticated source
  // proof. It must not install the source's fence on the newly writable target.
  const actual = await readSnapshotTables(db, { scope, configFingerprint: snapshot.configFingerprint, purpose: snapshot.purpose,
    freezeEvidence: snapshot.freezeEvidence, now: () => Math.max(now(), snapshot.createdAt) });
  if (actual.digest !== expectedDigest || canonical(actual.counts) !== canonical(snapshot.counts)) fail("migration_verification_failed");
  return { digest: actual.digest, counts: actual.counts, configFingerprint: actual.configFingerprint,
    purpose: actual.purpose, activationEligible: actual.purpose === "cutover",
    ...(actual.purpose === "cutover" ? { freezeEvidence: actual.freezeEvidence } : {}) };
}

async function familyInsert(db, scope, record) {
  const json = canonical(record.data);
  const existing = await db.prepare("SELECT json, updated_at FROM bangbang_family_records WHERE scope = ? AND key = ?")
    .bind(scope, record.key).first();
  let expected = json;
  if (existing !== null) {
    if (!existing || typeof existing.json !== "string") fail("migration_import_failed");
    let current;
    try { current = canonical(JSON.parse(existing.json)); }
    catch { fail("migration_import_failed"); }
    if (current !== json || existing.updated_at !== record.updatedAt) fail("migration_conflict");
    expected = existing.json;
  }
  // NOT NULL is evaluated before the primary-key conflict resolution. A
  // competing importer changing content or its original clock rolls back the
  // whole SQLite batch. ETags are server-local CAS generations and may renew.
  return db.prepare(`INSERT INTO bangbang_family_records (scope, key, json, etag, updated_at)
    SELECT ?, ?, CASE WHEN EXISTS (SELECT 1 FROM bangbang_family_records
      WHERE scope = ? AND key = ? AND NOT (json IS ? AND updated_at IS ?))
      THEN NULL ELSE ? END, ?, ? ON CONFLICT (scope, key) DO NOTHING`)
    .bind(scope, record.key, scope, record.key, expected, record.updatedAt, json, randomUUID(), record.updatedAt);
}

function diagnosticInsert(db, scope, spec, row) {
  const same = spec.columns.map(name => `${name} IS ?`).join(" AND ");
  const where = ["scope", ...spec.pk].map(name => `${name} = ?`).join(" AND ");
  const values = spec.columns.map(name => row[name]);
  // Fail NOT NULL before the primary-key conflict resolution if another
  // importer wrote different state. The SQLite batch rolls back every insert.
  return db.prepare(`INSERT INTO ${spec.table} (scope, ${spec.columns.join(", ")})
    SELECT ?, CASE WHEN EXISTS (SELECT 1 FROM ${spec.table} WHERE ${where} AND NOT (${same}))
    THEN NULL ELSE ? END, ${values.slice(1).map(() => "?").join(", ")}
    ON CONFLICT (scope, ${spec.pk.join(", ")}) DO NOTHING`)
    .bind(scope, scope, ...spec.pk.map(name => row[name]), ...values, ...values);
}
function familyBatches(records) {
  const batches = []; let batch = [];
  for (const record of records) {
    const candidate = [...batch, record];
    if (candidate.length > 32 || Buffer.byteLength(JSON.stringify({ v: 1, records: candidate })) > 1_048_576) {
      batches.push(batch); batch = [record];
    } else batch = candidate;
  }
  if (batch.length) batches.push(batch);
  return batches;
}

/** Offline administrator import: no public export route and no overwrite mode.
 * Family batches keep the original allowlist and insert-only CAS guard. All three
 * tables are checked again before an activation marker is written. A partial
 * failure leaves the authority paused and unverified for an idempotent retry.
 */
export async function importAuthoritySnapshot(db, snapshot, { scope, apiEnabled, expectedDigest, expectedSourceEpoch, configuration, now = Date.now } = {}) {
  paused(configuration, apiEnabled);
  if (typeof db?.invalidateAuthorityVerification !== "function") fail("authority_must_be_paused");
  validate(snapshot, scope, expectedDigest);
  if (expectedSourceEpoch !== undefined && (snapshot.purpose !== "cutover" || expectedSourceEpoch !== snapshot.freezeEvidence.epoch)) {
    fail("source_epoch_mismatch");
  }
  if (checkedConfiguration(configuration, scope) !== snapshot.configFingerprint) fail("authority_configuration_mismatch");
  await db.invalidateAuthorityVerification(scope);
  const inserted = { family: 0, attempts: 0, limits: 0 };
  for (const records of familyBatches(snapshot.records)) {
    let results;
    try { results = await db.batch(await Promise.all(records.map(record => familyInsert(db, scope, record)))); }
    catch (error) {
      const message = String(error?.message ?? "");
      fail(message === "migration_conflict" || message.startsWith("NOT NULL constraint failed: bangbang_family_records.json")
        ? "migration_conflict" : "migration_import_failed");
    }
    if (!Array.isArray(results) || results.length !== records.length ||
        results.some(result => result?.success !== true || ![0, 1].includes(result.meta?.changes))) fail("migration_import_failed");
    inserted.family += results.reduce((total, result) => total + result.meta.changes, 0);
  }
  for (const [name, spec] of [["attempts", attempts], ["limits", limits]]) {
    const rows = snapshot.diagnostics[name];
    for (let i = 0; i < rows.length; i += 128) {
      let results;
      try { results = await db.batch(rows.slice(i, i + 128).map(row => diagnosticInsert(db, scope, spec, row))); }
      catch (error) {
        const message = String(error?.message ?? "");
        fail(message.startsWith("NOT NULL constraint failed: bangbang_diagnostic_") ? "migration_conflict" : "migration_import_failed");
      }
      if (!Array.isArray(results) || results.some(result => result?.success !== true || ![0, 1].includes(result.meta?.changes))) fail("migration_import_failed");
      inserted[name] += results.reduce((total, result) => total + result.meta.changes, 0);
    }
  }
  const verified = await verifyAuthoritySnapshot(db, snapshot, { scope, apiEnabled, expectedDigest, expectedSourceEpoch, configuration, now });
  if (verified.activationEligible) await db.markAuthorityVerified(scope, { ...verified, verifiedAt: now() });
  return { ...verified, inserted,
    unchanged: Object.fromEntries(Object.entries(snapshot.counts).map(([name, count]) => [name, count - inserted[name]])) };
}
