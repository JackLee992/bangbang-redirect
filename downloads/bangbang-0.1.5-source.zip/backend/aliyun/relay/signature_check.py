"""Public signature verification for the diagnostic probe (RFC 8032 section 5.1).

This has no signing operation and is not used by the production client or server.
"""
import hashlib
import os

P = 2 ** 255 - 19
L = 2 ** 252 + 27742317777372353535851937790883648493
D = (-121665 * pow(121666, P - 2, P)) % P
IDENTITY = (0, 1)


def decode_point(encoded):
    if len(encoded) != 32:
        raise ValueError("invalid Ed25519 point length")
    value = int.from_bytes(encoded, "little")
    y, sign = value & (2 ** 255 - 1), value >> 255
    if y >= P:
        raise ValueError("noncanonical Ed25519 point")
    y2 = y * y % P
    x2 = (y2 - 1) * pow(D * y2 + 1, P - 2, P) % P
    x = pow(x2, (P + 3) // 8, P)
    if x * x % P != x2:
        x = x * pow(2, (P - 1) // 4, P) % P
    if x * x % P != x2 or (x == 0 and sign):
        raise ValueError("invalid Ed25519 point")
    if x & 1 != sign:
        x = P - x
    return x, y


def add(left, right):
    x1, y1 = left
    x2, y2 = right
    product = D * x1 * x2 * y1 * y2 % P
    x = (x1 * y2 + y1 * x2) * pow(1 + product, P - 2, P) % P
    y = (y1 * y2 + x1 * x2) * pow(1 - product, P - 2, P) % P
    return x, y


def multiply(point, scalar):
    result = IDENTITY
    while scalar:
        if scalar & 1:
            result = add(result, point)
        point = add(point, point)
        scalar >>= 1
    return result


B = decode_point(bytes.fromhex("58" + "66" * 31))


def ephemeral_public_key():
    scalar = 1 + int.from_bytes(os.urandom(32), "little") % (L - 1)
    x, y = multiply(B, scalar)
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def verify(public_key, message, signature):
    if len(signature) != 64 or len(public_key) != 32:
        return False
    try:
        public = decode_point(public_key)
        commitment = decode_point(signature[:32])
        scalar = int.from_bytes(signature[32:], "little")
        if scalar >= L or multiply(public, 8) == IDENTITY or multiply(commitment, 8) == IDENTITY:
            return False
        challenge = int.from_bytes(hashlib.sha512(signature[:32] + public_key + message).digest(), "little") % L
        return multiply(B, scalar) == add(commitment, multiply(public, challenge))
    except ValueError:
        return False
