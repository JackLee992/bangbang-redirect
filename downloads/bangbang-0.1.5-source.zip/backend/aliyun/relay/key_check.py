#!/usr/bin/env python3
"""Check shared key structure without printing or passing the secret to a process."""
import base64
import os
from pathlib import Path
import stat
import sys


def read_keypair(directory, expected_uid=None):
    directory = Path(directory)
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError("key directory must be a real directory")
    if (directory / ".env").exists():
        raise ValueError("unexpected .env would override managed server options")
    values = []
    for name, length in (("id_ed25519.pub", 32), ("id_ed25519", 64)):
        path = directory / name
        fd = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, "rb") as file:
            info = os.fstat(file.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > 128:
                raise ValueError("key file is not a bounded regular file")
            if stat.S_IMODE(info.st_mode) != 0o600:
                raise ValueError("key permissions must be 0600")
            if expected_uid is not None and info.st_uid != expected_uid:
                raise ValueError("key owner differs from service user")
            raw = file.read().strip()
        try:
            decoded = base64.b64decode(raw, validate=True)
        except ValueError:
            raise ValueError("invalid key encoding") from None
        if len(decoded) != length:
            raise ValueError("invalid key length")
        values.append((raw.decode("ascii"), decoded))
    if values[1][1][32:] != values[0][1]:
        raise ValueError("public and private key do not match")
    return values[0][0]


if __name__ == "__main__":
    try:
        read_keypair(sys.argv[1], os.geteuid())
    except (OSError, ValueError, IndexError):
        print("relay key check failed; inspect file ownership/permissions locally", file=sys.stderr)
        sys.exit(1)
