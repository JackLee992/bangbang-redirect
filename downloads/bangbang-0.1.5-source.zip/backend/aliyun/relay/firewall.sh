#!/bin/sh
# Own relay ports only: reject direct WebSocket and bound per-source native floods.
# This does not accept native traffic or alter SSH / other application ports.
set -eu
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
[ "$(id -u)" = 0 ] || { echo 'WebSocket guard requires root' >&2; exit 1; }
exec 9>/run/lock/bangbang-relay-ws.lock
flock -x 9
for tool in iptables ip6tables; do
    if [ "$tool" = ip6tables ] && [ "$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6 2>/dev/null || echo 1)" = 1 ]; then
        continue
    fi
    command -v "$tool" >/dev/null
    "$tool" -w 5 -S BANGBANG_RD_WS >/dev/null 2>&1 || "$tool" -w 5 -N BANGBANG_RD_WS
    "$tool" -w 5 -C BANGBANG_RD_WS ! -i lo -p tcp -m multiport --dports 21118,21119 \
        -m comment --comment bangbang-relay-ws-guard -j REJECT --reject-with tcp-reset 2>/dev/null || \
        "$tool" -w 5 -A BANGBANG_RD_WS ! -i lo -p tcp -m multiport --dports 21118,21119 \
        -m comment --comment bangbang-relay-ws-guard -j REJECT --reject-with tcp-reset
    "$tool" -w 5 -C BANGBANG_RD_WS ! -i lo -p tcp -m multiport --dports 21115,21116,21117 \
        --tcp-flags SYN,RST,ACK SYN -m hashlimit --hashlimit-above 30/second --hashlimit-burst 60 \
        --hashlimit-mode srcip --hashlimit-name bb_rdtcp --hashlimit-htable-max 8192 \
        -m comment --comment bangbang-relay-syn-rate -j DROP 2>/dev/null || \
        "$tool" -w 5 -A BANGBANG_RD_WS ! -i lo -p tcp -m multiport --dports 21115,21116,21117 \
        --tcp-flags SYN,RST,ACK SYN -m hashlimit --hashlimit-above 30/second --hashlimit-burst 60 \
        --hashlimit-mode srcip --hashlimit-name bb_rdtcp --hashlimit-htable-max 8192 \
        -m comment --comment bangbang-relay-syn-rate -j DROP
    "$tool" -w 5 -C BANGBANG_RD_WS ! -i lo -p udp --dport 21116 \
        -m hashlimit --hashlimit-above 60/second --hashlimit-burst 120 \
        --hashlimit-mode srcip --hashlimit-name bb_rdudp --hashlimit-htable-max 8192 \
        -m comment --comment bangbang-relay-udp-rate -j DROP 2>/dev/null || \
        "$tool" -w 5 -A BANGBANG_RD_WS ! -i lo -p udp --dport 21116 \
        -m hashlimit --hashlimit-above 60/second --hashlimit-burst 120 \
        --hashlimit-mode srcip --hashlimit-name bb_rdudp --hashlimit-htable-max 8192 \
        -m comment --comment bangbang-relay-udp-rate -j DROP
    # Keep our guard before any permissive INPUT rule; never flush other chains.
    while "$tool" -w 5 -C INPUT -m comment --comment bangbang-relay-ws-guard -j BANGBANG_RD_WS 2>/dev/null; do
        "$tool" -w 5 -D INPUT -m comment --comment bangbang-relay-ws-guard -j BANGBANG_RD_WS
    done
    "$tool" -w 5 -I INPUT 1 -m comment --comment bangbang-relay-ws-guard -j BANGBANG_RD_WS
done
