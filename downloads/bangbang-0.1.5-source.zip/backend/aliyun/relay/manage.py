#!/usr/bin/env python3
"""Pinned RustDesk OSS install, idempotent reapply, and transactional rollback (Ubuntu 20.04+)."""
import argparse
import base64
import fcntl
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import platform
import pwd
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request
import uuid
import zipfile

from health import local_checks, local_protocol_host, protocol_checks, verify_release
from key_check import read_keypair

SOURCE = Path(__file__).resolve().parent
BASE = Path("/opt/bangbang-relay")
STATE = Path("/var/lib/bangbang-relay")
CONFIG = Path("/etc/bangbang-relay")
CACHE = Path("/var/cache/bangbang-relay")
UNITS = Path("/etc/systemd/system")
SERVICES = ("bangbang-hbbs.service", "bangbang-hbbr.service")
MARKER = "Managed-by: bangbang-aliyun-relay-v1"
SUPPORT = ("release.json", "manage.py", "health.py", "key_check.py", "signature_check.py", "firewall.sh", "LICENSE.rustdesk-server") + SERVICES
MANAGED_FILES = tuple(UNITS / name for name in SERVICES) + (CONFIG / "relay.env", CONFIG / "client-config.json")


def checked(command, capture=True):
    result = subprocess.run(command, stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, timeout=45, check=False, text=True)
    if result.returncode != 0:
        raise ValueError("command failed: " + Path(command[0]).name)
    return result.stdout if capture else ""


def atomic_write(path, data, mode=0o600):
    path = Path(path)
    if path.is_symlink():
        raise ValueError("refusing symlink: " + str(path))
    fd, temporary = tempfile.mkstemp(prefix=".new-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def switch_current(target):
    link = BASE / (".current-" + uuid.uuid4().hex)
    os.symlink(target, link)
    os.replace(link, BASE / "current")


def valid_host(value):
    try:
        address = ipaddress.ip_address(value)
        if address.version != 4 or not address.is_global:
            raise ValueError("use a public IPv4 address or DNS name")
    except ValueError:
        if not re.fullmatch(r"(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}", value):
            raise ValueError("use a public IPv4 address or DNS name") from None
    return value.lower()


def relay_env(host):
    return ("# " + MARKER + "\nRELAY_HOST=" + valid_host(host) + "\n"
            "TOTAL_BANDWIDTH=2\nSINGLE_BANDWIDTH=1.5\nLIMIT_SPEED=0.75\n"
            "DOWNGRADE_THRESHOLD=0.90\nDOWNGRADE_START_CHECK=30\n").encode()


def pinned():
    return json.loads((SOURCE / "release.json").read_text())


def unpack_verified(archive, destination, manifest=None):
    manifest = manifest or pinned()
    archive = Path(archive)
    if archive.stat().st_size != manifest["asset_bytes"]:
        raise ValueError("release archive size mismatch")
    if hashlib.sha256(archive.read_bytes()).hexdigest() != manifest["asset_sha256"]:
        raise ValueError("release archive SHA-256 mismatch")
    with zipfile.ZipFile(archive) as package:
        allowed = {"amd64/"} | {"amd64/" + name for name in manifest["files"]}
        if len(package.namelist()) != len(set(package.namelist())) or set(package.namelist()) - allowed:
            raise ValueError("unexpected release archive paths")
        for name, expected in manifest["files"].items():
            member = package.getinfo("amd64/" + name)
            if stat.S_IFMT(member.external_attr >> 16) == stat.S_IFLNK or member.file_size != expected["bytes"]:
                raise ValueError("release member type/size mismatch")
            data = package.read(member)
            if hashlib.sha256(data).hexdigest() != expected["sha256"]:
                raise ValueError("binary SHA-256 mismatch: " + name)
            if data[:6] != b"\x7fELF\x02\x01" or data[18:20] != b"\x3e\x00":
                raise ValueError("release binary is not x86_64 ELF")
            atomic_write(Path(destination) / name, data, 0o555)


def archive_path(argument):
    if argument:
        return Path(argument).resolve()
    path = CACHE / ("rustdesk-server-" + pinned()["version"] + "-amd64.zip")
    if path.is_file():
        return path
    request = urllib.request.Request(pinned()["asset_url"], headers={"User-Agent": "bangbang-pinned-relay-installer"})
    with urllib.request.urlopen(request, timeout=45) as response:
        data = response.read(pinned()["asset_bytes"] + 1)
    if len(data) != pinned()["asset_bytes"] or hashlib.sha256(data).hexdigest() != pinned()["asset_sha256"]:
        raise ValueError("downloaded archive size/SHA-256 mismatch")
    atomic_write(path, data)
    return path


def prepare_release(archive):
    stage = Path(tempfile.mkdtemp(prefix=".stage-", dir=str(BASE / "releases")))
    try:
        unpack_verified(archive, stage)
        for name in SUPPORT:
            source = SOURCE / name
            if not source.is_file() or source.is_symlink():
                raise ValueError("missing regular deployment support file: " + name)
            atomic_write(stage / name, source.read_bytes(), 0o555 if name.endswith((".py", ".sh")) else 0o444)
        files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(stage.iterdir())}
        identifier = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()[:16]
        deployment = {"version": pinned()["version"], "identifier": identifier,
                      "archive_sha256": pinned()["asset_sha256"], "source_commit": pinned()["source_commit"], "files": files}
        atomic_write(stage / "deployment.json", (json.dumps(deployment, sort_keys=True, indent=2) + "\n").encode(), 0o444)
        target = BASE / "releases" / (pinned()["version"] + "-" + identifier)
        if target.exists():
            if verify_release(target) != deployment:
                raise ValueError("immutable release directory differs")
        else:
            os.chmod(stage, 0o755)
            os.rename(stage, target)
        # Reject incompatible executables before changing the current service.
        for name in ("hbbs", "hbbr"):
            if pinned()["version"] not in checked([str(target / name), "--version"]):
                raise ValueError("unexpected executable version")
        return target
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def service_state(name):
    return {kind: subprocess.run(["systemctl", "is-" + kind, "--quiet", name],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False).returncode == 0
            for kind in ("enabled", "active")}


def root_preflight():
    if os.geteuid() != 0 or platform.system() != "Linux" or platform.machine() not in ("x86_64", "amd64"):
        raise ValueError("install/rollback requires root on Linux x86_64")
    if not Path("/run/systemd/system").is_dir():
        raise ValueError("a running systemd host is required")
    for command in ("systemctl", "ss", "iptables", "ip6tables", "flock", "runuser", "useradd", "groupadd"):
        if shutil.which(command) is None:
            raise ValueError("required host tool missing: " + command)
    version = checked(["systemctl", "--version"]).splitlines()[0]
    if int(version.split()[1]) < 245:
        raise ValueError("systemd 245+ is required")
    for path in (BASE, STATE, CONFIG, CACHE, UNITS):
        if path.is_symlink():
            raise ValueError("refusing managed directory symlink")
    if BASE.exists() and (not (BASE / "managed-by").is_file() or (BASE / "managed-by").read_text().strip() != MARKER):
        raise ValueError("existing install directory is not managed by this installer")
    for path in MANAGED_FILES:
        if path.is_symlink():
            raise ValueError("refusing managed file symlink")
        if path.exists() and path.name != "client-config.json" and MARKER not in path.read_text():
            raise ValueError("existing unit/config belongs to another deployment")
    current = BASE / "current"
    if current.exists() and not current.is_symlink():
        raise ValueError("current must be a managed release symlink")
    if current.is_symlink() and current.resolve().parent != BASE / "releases":
        raise ValueError("current points outside the release directory")


def check_ports():
    owned = set()
    for name in SERVICES:
        if not (UNITS / name).exists():
            continue
        text = checked(["systemctl", "show", name, "--property=MainPID", "--value"])
        if text.strip().isdigit() and int(text.strip()):
            owned.add(int(text.strip()))
    for line in checked(["ss", "-H", "-lntup"]).splitlines():
        if re.search(r":2111[5-9]\s", line):
            processes = {int(value) for value in re.findall(r"pid=(\d+)", line)}
            if not processes or not processes <= owned:
                raise ValueError("a reserved relay port is owned by another process")


def prepare_directories():
    for path, mode in ((BASE, 0o755), (BASE / "releases", 0o755), (BASE / "snapshots", 0o700),
                       (CONFIG, 0o700), (CACHE, 0o700)):
        if path.is_symlink():
            raise ValueError("refusing symlink in managed installation")
        path.mkdir(mode=mode, parents=True, exist_ok=True)
        os.chmod(path, mode)
    atomic_write(BASE / "managed-by", (MARKER + "\n").encode(), 0o444)
    try:
        account = pwd.getpwnam("bangbang-relay")
    except KeyError:
        checked(["groupadd", "--system", "bangbang-relay"])
        checked(["useradd", "--system", "--gid", "bangbang-relay", "--home-dir", str(STATE),
                 "--shell", "/usr/sbin/nologin", "--no-create-home", "bangbang-relay"])
        account = pwd.getpwnam("bangbang-relay")
    if account.pw_uid == 0 or account.pw_dir != str(STATE) or account.pw_shell not in ("/usr/sbin/nologin", "/bin/false"):
        raise ValueError("existing relay account is not an isolated service account")
    STATE.mkdir(mode=0o700, exist_ok=True)
    os.chmod(STATE, 0o700)
    os.chown(STATE, account.pw_uid, account.pw_gid)
    return account


def ensure_keys(target, account):
    paths = [STATE / "id_ed25519", STATE / "id_ed25519.pub"]
    if any(path.exists() or path.is_symlink() for path in paths):
        # Never repair/regenerate a half-written or inconsistent persistent identity.
        return read_keypair(STATE, account.pw_uid)
    result = checked(["runuser", "-u", "bangbang-relay", "--", str(target / "rustdesk-utils"), "genkeypair"])
    matches = re.fullmatch(r"Public Key:\s+([A-Za-z0-9+/=]+)\s+Secret Key:\s+([A-Za-z0-9+/=]+)\s*", result)
    if not matches:
        raise ValueError("key generation did not return the expected format")
    public, secret = matches.groups()
    if len(base64.b64decode(public, validate=True)) != 32 or len(base64.b64decode(secret, validate=True)) != 64:
        raise ValueError("generated key length mismatch")
    for path, value in ((paths[1], public), (paths[0], secret)):
        atomic_write(path, value.encode())
        os.chown(path, account.pw_uid, account.pw_gid)
    return read_keypair(STATE, account.pw_uid)


def guard_present(tool):
    return subprocess.run([tool, "-w", "5", "-S", "BANGBANG_RD_WS"], stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL, check=False).returncode == 0


def snapshot():
    current = BASE / "current"
    value = {"schema": 1, "previous_target": str(current.resolve()) if current.is_symlink() else None,
             "files": {str(path): base64.b64encode(path.read_bytes()).decode() if path.exists() else None for path in MANAGED_FILES},
             "services": {name: service_state(name) for name in SERVICES},
             "guards": {tool: guard_present(tool) for tool in ("iptables", "ip6tables")}}
    name = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + uuid.uuid4().hex[:8] + ".json"
    atomic_write(BASE / "snapshots" / name, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode())
    return name, value


def remove_new_guard(tool):
    hook = [tool, "-w", "5", "-D", "INPUT", "-m", "comment", "--comment", "bangbang-relay-ws-guard", "-j", "BANGBANG_RD_WS"]
    while subprocess.run(hook, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False).returncode == 0:
        pass
    # A chain created by this installer is private; no unrelated rules are touched.
    if guard_present(tool):
        checked([tool, "-w", "5", "-F", "BANGBANG_RD_WS"])
        checked([tool, "-w", "5", "-X", "BANGBANG_RD_WS"])


def restore(value):
    if value.get("schema") != 1 or set(value["files"]) != {str(path) for path in MANAGED_FILES} or set(value["services"]) != set(SERVICES):
        raise ValueError("invalid rollback snapshot")
    target = value["previous_target"]
    if target:
        if Path(target).parent != BASE / "releases":
            raise ValueError("rollback release points outside managed directory")
        verify_release(target)
    for name in reversed(SERVICES):
        if (UNITS / name).exists():
            checked(["systemctl", "stop", name], capture=False)
            checked(["systemctl", "disable", name], capture=False)
    for path in MANAGED_FILES:
        content = value["files"][str(path)]
        if content is None:
            if path.exists():
                path.unlink()
        else:
            atomic_write(path, base64.b64decode(content, validate=True), 0o644 if path.parent == UNITS or path.name == "client-config.json" else 0o600)
    if target:
        switch_current(target)
    elif (BASE / "current").is_symlink():
        (BASE / "current").unlink()
    checked(["systemctl", "daemon-reload"], capture=False)
    for name in SERVICES:
        if value["services"][name]["enabled"]:
            checked(["systemctl", "enable", name], capture=False)
        if value["services"][name]["active"]:
            checked(["systemctl", "reset-failed", name], capture=False)
            checked(["systemctl", "start", name], capture=False)
    for tool in ("iptables", "ip6tables"):
        if not value["guards"].get(tool, True):
            remove_new_guard(tool)


def wait_healthy():
    end = time.monotonic() + 25
    while True:
        try:
            key, release, services = local_checks()
            checks = protocol_checks(local_protocol_host(), key, 2.0)
            return {"release": release["identifier"], "checks": checks, "services": services}
        except (OSError, ValueError, KeyError, subprocess.SubprocessError):
            if time.monotonic() > end:
                raise ValueError("local service/protocol verification failed") from None
            time.sleep(0.5)


def install(args):
    root_preflight()
    check_ports()
    account = prepare_directories()
    target = prepare_release(archive_path(args.archive))
    key = ensure_keys(target, account)
    config = {"id_server": args.public_host + ":21116", "relay_server": args.public_host + ":21117",
              "key": key, "api_server": "", "allow_websocket": False}
    expected = {UNITS / name: (SOURCE / name).read_bytes() for name in SERVICES}
    expected[CONFIG / "relay.env"] = relay_env(args.public_host)
    expected[CONFIG / "client-config.json"] = (json.dumps(config, sort_keys=True, indent=2) + "\n").encode()
    current = BASE / "current"
    if current.is_symlink() and current.resolve() == target and all(path.exists() and path.read_bytes() == data for path, data in expected.items()):
        try:
            health = wait_healthy()
        except ValueError:
            pass
        else:
            return {"ok": True, "changed": False, "client_config": config, "health": health}
    name, previous = snapshot()
    try:
        for service in reversed(SERVICES):
            if (UNITS / service).exists():
                checked(["systemctl", "stop", service], capture=False)
        switch_current(str(target))
        for path, data in expected.items():
            atomic_write(path, data, 0o644 if path.parent == UNITS or path.name == "client-config.json" else 0o600)
        checked(["systemctl", "daemon-reload"], capture=False)
        for service in SERVICES:
            checked(["systemctl", "enable", service], capture=False)
            checked(["systemctl", "reset-failed", service], capture=False)
            checked(["systemctl", "start", service], capture=False)
        health = wait_healthy()
        atomic_write(BASE / "last-snapshot", (name + "\n").encode())
        return {"ok": True, "changed": True, "snapshot": name, "client_config": config, "health": health}
    except BaseException:
        try:
            restore(previous)
        except BaseException:
            print("automatic rollback failed; use the saved snapshot locally: " + name, file=sys.stderr)
        else:
            print("installation failed; prior service configuration restored; persistent keys/data retained", file=sys.stderr)
        raise


def rollback(args):
    root_preflight()
    name = args.snapshot or (BASE / "last-snapshot").read_text().strip()
    if not re.fullmatch(r"[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}\.json", name):
        raise ValueError("invalid snapshot name")
    path = BASE / "snapshots" / name
    if path.is_symlink():
        raise ValueError("refusing snapshot symlink")
    value = json.loads(path.read_text())
    restore(value)
    active = all(item["active"] and item["enabled"] for item in value["services"].values())
    return {"ok": True, "snapshot": name, "persistent_keys_and_database": "retained",
            "health": wait_healthy() if active else "prior service state restored"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    apply = sub.add_parser("install")
    apply.add_argument("--public-host", type=valid_host, default="123.57.57.202")
    apply.add_argument("--archive", help="optional pre-downloaded official ZIP; size and all SHA-256 values are still checked")
    undo = sub.add_parser("rollback")
    undo.add_argument("--snapshot", help="snapshot filename; default is the last successful changed install")
    sub.add_parser("stop", help="stop/disable only these two services; keep keys/data and WebSocket guard")
    sub.add_parser("plan", help="print fixed package/port/capacity plan, without host mutation")
    args = parser.parse_args()
    if args.command == "plan":
        print(json.dumps({"release": pinned(), "tcp_public": [21115, 21116, 21117], "udp_public": [21116],
                          "closed_public": [21114, 21118, 21119], "total_bits_per_second": 2097152,
                          "single_bits_per_second": 1572864, "tcp_registration": "UNSUPPORTED", "wss_mobile": "NOT_ENABLED"}, indent=2))
        return
    root_preflight()
    # Serialize install and rollback independently of the service firewall lock.
    with open("/run/lock/bangbang-relay-install.lock", "a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if args.command == "install":
            output = install(args)
        elif args.command == "rollback":
            output = rollback(args)
        else:
            for service in reversed(SERVICES):
                checked(["systemctl", "disable", "--now", service], capture=False)
            output = {"ok": True, "services": "stopped and disabled", "persistent_keys_and_database": "retained"}
        print(json.dumps(output, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, subprocess.SubprocessError, zipfile.BadZipFile):
        # Key generator stdout and persistent identity bytes must never reach errors.
        print("relay management failed; inspect prerequisites or run health.py locally", file=sys.stderr)
        sys.exit(1)
