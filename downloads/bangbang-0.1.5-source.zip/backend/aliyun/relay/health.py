#!/usr/bin/env python3
"""Service/protocol checks using synthetic bytes; --register adds one nonce peer record."""
import argparse
import base64
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import pwd
import socket
import stat
import subprocess
import sys
import time
import uuid

from key_check import read_keypair
from signature_check import ephemeral_public_key, verify as verify_signature

BASE = Path("/opt/bangbang-relay")
STATE = Path("/var/lib/bangbang-relay")
SERVICES = ("bangbang-hbbs.service", "bangbang-hbbr.service")


def local_protocol_host():
    # hbbs treats loopback TCP 21115 as its plaintext management port, not
    # TestNatRequest. Select the local routed IPv4 without sending any packet.
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
        route.connect(("192.0.2.1", 9))
        host = route.getsockname()[0]
    address = ipaddress.ip_address(host)
    if address.is_loopback or address.is_unspecified or not address.is_private:
        raise ValueError("local private IPv4 route required for NAT protocol check")
    return host


def varint(value):
    if value < 0:
        raise ValueError("negative protobuf value")
    out = bytearray()
    while value > 127:
        out.append((value & 127) | 128)
        value >>= 7
    return bytes(out) + bytes([value])


def blob(number, value):
    if isinstance(value, str):
        value = value.encode("utf-8")
    return varint(number * 8 + 2) + varint(len(value)) + value


def fields(data):
    result = {}
    offset = 0

    def integer():
        nonlocal offset
        value = 0
        for shift in range(0, 70, 7):
            if offset >= len(data):
                raise ValueError("truncated protobuf")
            item = data[offset]
            offset += 1
            value |= (item & 127) << shift
            if item < 128:
                return value
        raise ValueError("oversize protobuf varint")

    while offset < len(data):
        tag = integer()
        number, wire = tag >> 3, tag & 7
        if number == 0:
            raise ValueError("invalid protobuf field")
        if wire == 0:
            value = integer()
        elif wire in (1, 2, 5):
            size = integer() if wire == 2 else (8 if wire == 1 else 4)
            if offset + size > len(data):
                raise ValueError("truncated protobuf field")
            value = data[offset:offset + size]
            offset += size
        else:
            raise ValueError("unsupported protobuf wire type")
        result[number] = value
    return result


def framed(data):
    # RustDesk BytesCodec uses a little-endian length shifted left by two bits.
    for width in range(1, 5):
        if len(data) <= (1 << (8 * width - 2)) - 1:
            return ((len(data) << 2) | (width - 1)).to_bytes(width, "little") + data
    raise ValueError("frame too large")


def receive_exact(connection, size):
    result = bytearray()
    while len(result) < size:
        chunk = connection.recv(size - len(result))
        if not chunk:
            raise ValueError("unexpected EOF")
        result.extend(chunk)
    return bytes(result)


def receive_frame(connection):
    header = receive_exact(connection, 1)
    width = (header[0] & 3) + 1
    header += receive_exact(connection, width - 1)
    size = int.from_bytes(header, "little") >> 2
    if size > 65536:
        raise ValueError("oversize server response")
    return receive_exact(connection, size)


def tcp_message(host, port, message, timeout):
    with socket.create_connection((host, port), timeout) as connection:
        connection.settimeout(timeout)
        connection.sendall(framed(message))
        return receive_frame(connection)


def nat_probe(host, port, timeout):
    response = fields(tcp_message(host, port, blob(20, b""), timeout))
    nested = fields(response[21])
    if not 0 < nested.get(1, 0) < 65536:
        raise ValueError("invalid NAT test response")


def udp_probe(host, timeout):
    # An ID shorter than six bytes returns UUID_MISMATCH before touching peers/DB.
    message = blob(15, blob(1, "?") + blob(2, b"probe") + blob(3, b"probe"))
    address = socket.getaddrinfo(host, 21116, type=socket.SOCK_DGRAM)[0]
    with socket.socket(address[0], socket.SOCK_DGRAM) as connection:
        connection.settimeout(timeout)
        connection.connect(address[4])
        connection.send(message)
        response = fields(connection.recv(4096))
    if fields(response[16]).get(1) != 2:
        raise ValueError("unexpected UDP registration error response")


def rendezvous_key_probe(host, key, timeout):
    target = "health-" + uuid.uuid4().hex
    request = blob(1, target)
    no_key = fields(tcp_message(host, 21116, blob(8, request), timeout))
    if fields(no_key[11]).get(3) != 3:
        raise ValueError("hbbs accepted a client without the pinned key")
    valid = fields(tcp_message(host, 21116, blob(8, request + blob(3, key)), timeout))
    if fields(valid[11]).get(3, 0) not in (0, 2):
        raise ValueError("hbbs rejected the configured public key")


def relay_probe(host, key, timeout):
    with socket.create_connection((host, 21117), timeout) as denied:
        denied.settimeout(timeout)
        denied.sendall(framed(blob(18, blob(2, "health-denied-" + uuid.uuid4().hex))))
        if denied.recv(1):
            raise ValueError("hbbr did not reject a client without the pinned key")
    request = blob(18, blob(2, "health-pair-" + uuid.uuid4().hex) + blob(6, key))
    with socket.create_connection((host, 21117), timeout) as left:
        left.settimeout(timeout)
        left.sendall(framed(request))
        with socket.create_connection((host, 21117), timeout) as right:
            right.settimeout(timeout)
            right.sendall(framed(request))
            # Allow the two small handshake messages to switch the pair to raw mode.
            time.sleep(0.1)
            challenge = os.urandom(64)
            left.sendall(challenge)
            if receive_exact(right, len(challenge)) != challenge:
                raise ValueError("relay forward payload mismatch")
            reply = os.urandom(64)
            right.sendall(reply)
            if receive_exact(left, len(reply)) != reply:
                raise ValueError("relay return payload mismatch")


def registration_probe(host, key, timeout):
    """One real nonce registration; retains one synthetic peer row, never user IDs."""
    peer_id = "health-" + uuid.uuid4().hex
    device_uuid = uuid.uuid4().bytes
    device_key = ephemeral_public_key()
    address = socket.getaddrinfo(host, 21116, type=socket.SOCK_DGRAM)[0]
    with socket.socket(address[0], socket.SOCK_DGRAM) as device:
        device.settimeout(timeout)
        device.connect(address[4])
        register = blob(6, blob(1, peer_id))
        device.send(register)
        initial = fields(device.recv(4096))
        if fields(initial[7]).get(2) != 1:
            raise ValueError("new nonce peer did not request its public key")
        device.send(blob(15, blob(1, peer_id) + blob(2, device_uuid) + blob(3, device_key)))
        response = fields(device.recv(4096))
        if fields(response[16]).get(1, 0) != 0:
            raise ValueError("nonce public key registration was rejected")
        device.send(register)
        if fields(fields(device.recv(4096))[7]).get(2, 0) != 0:
            raise ValueError("nonce registration heartbeat was not accepted")
        with socket.create_connection((host, 21116), timeout) as helper:
            helper.settimeout(timeout)
            request = blob(1, peer_id) + varint(2 * 8) + varint(2) + blob(3, key) + blob(6, "1.4.9")
            helper.sendall(framed(blob(8, request)))
            instruction = fields(device.recv(4096))
            if 12 in instruction:  # Same public IP / LAN: FetchLocalAddr -> LocalAddr.
                route = fields(instruction[12])
                reply = blob(1, route[1]) + blob(2, route[1]) + blob(3, route.get(2, b"")) + blob(4, peer_id) + blob(5, "1.4.9")
                reply_message = blob(13, reply)
            elif 9 in instruction:  # Different networks: PunchHole -> PunchHoleSent.
                route = fields(instruction[9])
                reply = blob(1, route[1]) + blob(2, peer_id) + blob(3, route.get(2, b"")) + blob(5, "1.4.9")
                reply_message = blob(10, reply)
            else:
                raise ValueError("nonce peer did not receive a supported connection instruction")
            # Registration is UDP, but the native client answers the connection
            # instruction over TCP. A UDP answer sends UDP to the helper's TCP
            # port and cannot complete this signature proof. The echoed local
            # address is a synthetic protocol fixture, never a remote session.
            with socket.create_connection((host, 21116), timeout) as answer:
                answer.settimeout(timeout)
                answer.sendall(framed(reply_message))
                response = fields(fields(receive_frame(helper))[11])
            signed = response.get(2, b"")
            if len(signed) < 65 or not verify_signature(base64.b64decode(key, validate=True), signed[64:], signed[:64]):
                raise ValueError("hbbs public key signature verification failed")
            identity = fields(signed[64:])
            if identity.get(1) != peer_id.encode() or identity.get(2) != device_key:
                raise ValueError("hbbs signed a different nonce device identity")
    return {"ok": True, "udp_registered": True, "server_signature_valid": True,
            "synthetic_peer_rows_added": 1, "remote_desktop_encryption": "NOT_TESTED"}


def run(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            text=True, timeout=10, check=False)
    if result.returncode != 0:
        raise ValueError("local service check failed: " + command[0])
    return result.stdout


def verify_release(directory):
    directory = Path(directory)
    manifest = json.loads((directory / "deployment.json").read_text())
    for name, digest in manifest["files"].items():
        if Path(name).name != name:
            raise ValueError("invalid deployment file path")
        path = directory / name
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o222:
            raise ValueError("release file is mutable or not regular")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError("release file digest mismatch: " + name)
    return manifest


def local_checks():
    uid = pwd.getpwnam("bangbang-relay").pw_uid
    state_info = STATE.lstat()
    if not stat.S_ISDIR(state_info.st_mode) or state_info.st_uid != uid or stat.S_IMODE(state_info.st_mode) != 0o700:
        raise ValueError("persistent directory owner/permissions differ")
    key = read_keypair(STATE, uid)
    release = verify_release(BASE / "current")
    service_info = {}
    for name in SERVICES:
        unit_path = Path("/etc/systemd/system") / name
        if unit_path.is_symlink() or unit_path.read_bytes() != (BASE / "current" / name).read_bytes():
            raise ValueError("installed unit differs from the immutable release")
        run(["systemctl", "is-active", "--quiet", name])
        run(["systemctl", "is-enabled", "--quiet", name])
        details = run(["systemctl", "show", name, "--property=MainPID,User,Group,NRestarts,MemoryCurrent,CPUUsageNSec"])
        service_info[name] = dict(line.split("=", 1) for line in details.splitlines() if "=" in line)
        if service_info[name].get("User") != "bangbang-relay" or int(service_info[name].get("MainPID", "0")) == 0:
            raise ValueError("unexpected service identity")
    listeners = run(["ss", "-H", "-lntup"])
    for protocol, port in (("tcp", 21115), ("tcp", 21116), ("tcp", 21117), ("udp", 21116)):
        if not any(line.startswith(protocol + " ") and (":" + str(port) + " ") in line for line in listeners.splitlines()):
            raise ValueError("required listener missing")
    for tool in ("iptables", "ip6tables"):
        if tool == "ip6tables" and Path("/proc/sys/net/ipv6/conf/all/disable_ipv6").read_text().strip() == "1":
            continue
        lines = run([tool, "-w", "5", "-S", "INPUT"]).splitlines()
        rules = [line for line in lines if line.startswith("-A ")]
        if not rules or "bangbang-relay-ws-guard" not in rules[0] or "-j BANGBANG_RD_WS" not in rules[0]:
            raise ValueError("WebSocket guard must be the first INPUT rule")
        run([tool, "-w", "5", "-C", "BANGBANG_RD_WS", "!", "-i", "lo", "-p", "tcp", "-m", "multiport",
             "--dports", "21118,21119", "-m", "comment", "--comment", "bangbang-relay-ws-guard",
             "-j", "REJECT", "--reject-with", "tcp-reset"])
        rules = run([tool, "-w", "5", "-S", "BANGBANG_RD_WS"])
        if "bangbang-relay-syn-rate" not in rules or "bangbang-relay-udp-rate" not in rules:
            raise ValueError("native flood guards are missing")
    return key, release, service_info


def protocol_checks(host, key, timeout=3.0, closed_ws=False):
    results = {}
    for name, operation in (
        ("tcp_nat_21115", lambda: nat_probe(host, 21115, timeout)),
        ("tcp_nat_21116", lambda: nat_probe(host, 21116, timeout)),
        ("udp_21116_stateless_response", lambda: udp_probe(host, timeout)),
        ("hbbs_requires_key", lambda: rendezvous_key_probe(host, key, timeout)),
        ("hbbr_requires_key_and_forwards_both_directions", lambda: relay_probe(host, key, timeout)),
    ):
        start = time.monotonic()
        operation()
        results[name] = {"ok": True, "elapsed_ms": round((time.monotonic() - start) * 1000)}
    if closed_ws:
        for port in (21114, 21118, 21119):
            try:
                with socket.create_connection((host, port), timeout):
                    pass
            except OSError:
                results["tcp_" + str(port) + "_closed"] = {"ok": True}
            else:
                raise ValueError("unexpected public port: " + str(port))
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--local", action="store_true", help="run on ECS as root, inspect units/files/guard")
    parser.add_argument("--host", default="123.57.57.202")
    parser.add_argument("--key-file", type=Path, help="public id_ed25519.pub only; never supply the private key")
    parser.add_argument("--timeout", type=float, default=3.0)
    parser.add_argument("--register", action="store_true", help="also register one nonce peer and verify the hbbs signed device key; adds one synthetic DB row")
    args = parser.parse_args()
    if not 0.1 <= args.timeout <= 10:
        parser.error("timeout must be 0.1..10 seconds")
    if args.local:
        key, release, services = local_checks()
        host = local_protocol_host()
    else:
        if args.key_file is None:
            parser.error("external check requires --key-file with the public key")
        key = args.key_file.read_text().strip()
        if len(base64.b64decode(key, validate=True)) != 32:
            parser.error("key file must contain a 32-byte public key")
        release, services, host = {}, {}, args.host
    checks = protocol_checks(host, key, args.timeout, closed_ws=not args.local)
    if args.register:
        checks["nonce_udp_registration_and_signed_device_key"] = registration_probe(host, key, args.timeout)
    print(json.dumps({"ok": True, "scope": "local-service-protocol" if args.local else "external-protocol",
                      "host": host, "version": release.get("version"), "checks": checks,
                      "services": services, "client_remote_desktop": "NOT_TESTED",
                      "tcp_device_registration": "UNSUPPORTED_BY_OSS_1.1.16"}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
        # Do not echo key files, wire data, logs, user IDs or exception arguments.
        print(json.dumps({"ok": False, "error": "relay health/protocol check failed"}), file=sys.stderr)
        sys.exit(1)
