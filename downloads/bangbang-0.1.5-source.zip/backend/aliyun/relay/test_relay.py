"""Safety/rollback/protocol-parser checks that run without root, network or Linux binaries."""
import base64
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import health
import key_check
import manage
import signature_check


class RelayTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="bangbang-relay-test-")
        self.base = Path(self.temporary.name).resolve()

    def tearDown(self):
        self.temporary.cleanup()

    def keys(self, directory=None):
        directory = directory or self.base
        public = os.urandom(32)
        secret = os.urandom(32) + public
        for name, value in (("id_ed25519.pub", public), ("id_ed25519", secret)):
            path = directory / name
            path.write_bytes(base64.b64encode(value))
            path.chmod(0o600)
        return base64.b64encode(public).decode()

    def archive(self, extra=None, duplicate=False):
        archive = self.base / "fake.zip"
        data = b"\x7fELF\x02\x01" + bytes(12) + b"\x3e\x00" + b"fixture"
        with zipfile.ZipFile(archive, "w") as package:
            package.writestr("amd64/hbbs", data)
            if extra:
                package.writestr(extra, b"unsafe")
            if duplicate:
                import warnings
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    package.writestr("amd64/hbbs", data)
        manifest = {"asset_bytes": archive.stat().st_size, "asset_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                    "files": {"hbbs": {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}}}
        return archive, manifest

    def test_verified_archive_writes_only_readonly_binary(self):
        archive, manifest = self.archive()
        out = self.base / "out"
        out.mkdir()
        manage.unpack_verified(archive, out, manifest)
        self.assertEqual((out / "hbbs").stat().st_mode & 0o777, 0o555)
        self.assertEqual(sorted(path.name for path in out.iterdir()), ["hbbs"])

    def test_archive_tamper_is_rejected_before_writing(self):
        archive, manifest = self.archive()
        archive.write_bytes(archive.read_bytes()[:-1] + b"!")
        with self.assertRaisesRegex(ValueError, "SHA-256"):
            manage.unpack_verified(archive, self.base, manifest)
        self.assertFalse((self.base / "hbbs").exists())

    def test_archive_path_traversal_is_rejected(self):
        archive, manifest = self.archive("../../outside")
        with self.assertRaisesRegex(ValueError, "paths"):
            manage.unpack_verified(archive, self.base, manifest)
        self.assertFalse((self.base / "hbbs").exists())

    def test_archive_duplicate_is_rejected(self):
        archive, manifest = self.archive(duplicate=True)
        with self.assertRaisesRegex(ValueError, "paths"):
            manage.unpack_verified(archive, self.base, manifest)

    def test_mismatched_binary_digest_is_rejected(self):
        archive, manifest = self.archive()
        manifest["files"]["hbbs"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "binary SHA"):
            manage.unpack_verified(archive, self.base, manifest)

    def test_keypair_only_returns_public_key(self):
        expected = self.keys()
        self.assertEqual(key_check.read_keypair(self.base, os.getuid()), expected)

    def test_half_keypair_is_rejected_without_regeneration(self):
        self.keys()
        original = (self.base / "id_ed25519").read_bytes()
        (self.base / "id_ed25519.pub").unlink()
        with self.assertRaises(OSError):
            key_check.read_keypair(self.base)
        self.assertEqual((self.base / "id_ed25519").read_bytes(), original)

    def test_private_key_wrong_permissions_rejected(self):
        self.keys()
        (self.base / "id_ed25519").chmod(0o644)
        with self.assertRaisesRegex(ValueError, "permissions"):
            key_check.read_keypair(self.base)

    def test_key_symlink_rejected(self):
        self.keys()
        target = self.base / "id_ed25519"
        target.rename(self.base / "outside")
        target.symlink_to(self.base / "outside")
        with self.assertRaises(OSError):
            key_check.read_keypair(self.base)

    def test_env_override_rejected(self):
        self.keys()
        (self.base / ".env").write_text("KEY=\n")
        with self.assertRaisesRegex(ValueError, "override"):
            key_check.read_keypair(self.base)

    def test_public_private_mismatch_rejected_without_output(self):
        self.keys()
        (self.base / "id_ed25519.pub").write_bytes(base64.b64encode(os.urandom(32)))
        output = io.StringIO()
        with contextlib.redirect_stdout(output), self.assertRaisesRegex(ValueError, "match"):
            key_check.read_keypair(self.base)
        self.assertEqual(output.getvalue(), "")

    def test_host_injection_private_ip_and_urls_rejected(self):
        for value in ("123.57.57.202\nKEY=", "127.0.0.1", "192.168.1.1", "https://relay.example.com", "relay.example.com;id", "relay.example.com:21117"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                manage.valid_host(value)
        self.assertEqual(manage.valid_host("123.57.57.202"), "123.57.57.202")
        self.assertEqual(manage.valid_host("relay.EXAMPLE.com"), "relay.example.com")

    def test_frame_roundtrip_and_partial_receive(self):
        for length in (0, 1, 63, 64, 16383, 16384, 65536):
            message = bytes([42]) * length
            encoded = health.framed(message)
            class PartialSocket:
                data = encoded
                def recv(self, size):
                    value, self.data = self.data[:min(size, 3)], self.data[min(size, 3):]
                    return value
            self.assertEqual(health.receive_frame(PartialSocket()), message)

    def test_oversize_and_eof_responses_rejected(self):
        class FakeSocket:
            def __init__(self, data):
                self.data = data
            def recv(self, size):
                value, self.data = self.data[:size], self.data[size:]
                return value
        for data in (health.framed(b"a")[:-1], health.framed(bytes(65537))):
            with self.assertRaises(ValueError):
                health.receive_frame(FakeSocket(data))

    def test_truncated_protobuf_rejected(self):
        for value in (b"\x80", b"\x00", b"\x0a\x05x", b"\x0b"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                health.fields(value)
        self.assertEqual(health.fields(health.blob(21, b"\x08\x2a")), {21: b"\x08\x2a"})

    def test_rendezvous_does_not_accept_wrong_key_reply(self):
        with patch.object(health, "tcp_message", return_value=health.blob(11, b"")):
            with self.assertRaisesRegex(ValueError, "without"):
                health.rendezvous_key_probe("127.0.0.1", "public", 1)

    def test_rfc8032_signature_and_tamper(self):
        public = bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
        signature = bytes.fromhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
                                  "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
        self.assertTrue(signature_check.verify(public, b"", signature))
        self.assertFalse(signature_check.verify(public, b"tampered", signature))
        self.assertFalse(signature_check.verify(public, b"", signature[:-1]))
        self.assertFalse(signature_check.verify(bytes(32), b"", signature))

    def test_rollback_restores_units_and_config_without_touching_identity(self):
        root = self.base / "install"
        units = self.base / "units"
        config = self.base / "config"
        state = self.base / "state"
        for directory in (root / "releases" / "old", units, config, state):
            directory.mkdir(parents=True)
        original_key = self.keys(state)
        original_secret = (state / "id_ed25519").read_bytes()
        database = state / "db_v2.sqlite3"
        database.write_bytes(b"retain-existing-database-fixture")
        previous_target = root / "releases" / "old"
        current_target = root / "releases" / "new"
        current_target.mkdir()
        (root / "current").symlink_to(current_target)
        paths = tuple(units / name for name in manage.SERVICES) + (config / "relay.env", config / "client-config.json")
        for path in paths:
            path.write_text("new configuration")
        snapshot = {"schema": 1, "previous_target": str(previous_target),
                    "files": {str(path): base64.b64encode(b"old configuration").decode() for path in paths},
                    "services": {manage.SERVICES[0]: {"enabled": True, "active": True},
                                 manage.SERVICES[1]: {"enabled": False, "active": False}},
                    "guards": {"iptables": True, "ip6tables": True}}
        commands = []
        with patch.object(manage, "BASE", root), patch.object(manage, "UNITS", units), patch.object(manage, "MANAGED_FILES", paths), \
                patch.object(manage, "verify_release", return_value={}), patch.object(manage, "checked", side_effect=lambda command, capture=True: commands.append(command)):
            manage.restore(snapshot)
        self.assertEqual((root / "current").resolve(), previous_target)
        self.assertTrue(all(path.read_bytes() == b"old configuration" for path in paths))
        self.assertEqual(key_check.read_keypair(state), original_key)
        self.assertEqual((state / "id_ed25519").read_bytes(), original_secret)
        self.assertEqual(database.read_bytes(), b"retain-existing-database-fixture")
        self.assertIn(["systemctl", "start", manage.SERVICES[0]], commands)
        self.assertNotIn(["systemctl", "start", manage.SERVICES[1]], commands)

    def test_rollback_refuses_path_outside_managed_release(self):
        value = {"schema": 1, "previous_target": "/unrelated/directory",
                 "files": {str(path): None for path in manage.MANAGED_FILES},
                 "services": {name: {"enabled": False, "active": False} for name in manage.SERVICES}}
        with patch.object(manage, "checked") as command:
            with self.assertRaisesRegex(ValueError, "outside"):
                manage.restore(value)
        command.assert_not_called()


if __name__ == "__main__":
    unittest.main()
