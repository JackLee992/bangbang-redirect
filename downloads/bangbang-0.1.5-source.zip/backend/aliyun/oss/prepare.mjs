import { execFile } from 'node:child_process';
import { mkdir, readFile, rm } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { auditText, BACKUP_KEY, boundedFile, httpsOrigin, IMMUTABLE_CACHE, MAX_BACKUP_BYTES,
  newPrivateDirectory, ossConfig, parseOptions, privateWrite, sha256, uploadArguments } from './common.mjs';

const execFileAsync = promisify(execFile);
const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const VERSION = /^(?:0|[1-9]\d{0,3})\.(?:0|[1-9]\d{0,3})\.(?:0|[1-9]\d{0,3})$/;
const SHA = /^[a-f0-9]{64}$/;

function validateRelease(raw) {
  if (!raw || !VERSION.test(raw.version) || !/^[a-f0-9]{40}$/.test(raw.sourceCommit) || !SHA.test(raw.buildInfoSha256))
    throw new Error('release_manifest_invalid');
  const release = { version: raw.version, sourceCommit: raw.sourceCommit, buildInfoSha256: raw.buildInfoSha256 };
  for (const [kind, suffix, max] of [['android', 'arm.apk', 128 * 1024 * 1024], ['source', 'source.zip', 64 * 1024 * 1024]]) {
    const asset = raw[kind];
    if (!asset || asset.filename !== `bangbang-${raw.version}-${suffix}` || !SHA.test(asset.sha256) ||
        !Number.isSafeInteger(asset.bytes) || asset.bytes < 4 || asset.bytes > max)
      throw new Error('release_asset_invalid');
    release[kind] = { filename: asset.filename, bytes: asset.bytes, sha256: asset.sha256 };
  }
  return release; // Unknown manifest fields never enter public output or CLI arguments.
}

export async function auditSourceZip(filename) {
  try {
    const { stdout } = await execFileAsync('python3', [join(dirname(fileURLToPath(import.meta.url)), 'audit-source.py'), filename],
      { timeout: 30000, maxBuffer: 2048, env: { PATH: process.env.PATH, PYTHONIOENCODING: 'utf-8' } });
    const result = JSON.parse(stdout);
    if (result.v !== 1 || result.ok !== true) throw new Error('invalid_audit');
    return result;
  } catch { throw new Error('source_zip_audit_failed'); }
}

function objectInfo(config, version, filename, bytes, contentType) {
  const key = `releases/${version}/${filename}`;
  return { filename, key, bytes: bytes.length, sha256: sha256(bytes), contentType,
    acl: config.downloadAccess === 'public-objects' ? 'public-read' : 'private',
    cacheControl: IMMUTABLE_CACHE, url: new URL(key, `${config.publicOrigin}/`).href };
}

export async function prepareRelease({ releaseFile = join(root, 'site/release.json'), assetsDir, licenseFile = join(root, 'LICENCE'), outputDir, env = process.env, localOnly = false }) {
  if (!assetsDir || !outputDir) throw new Error('assets_and_new_output_required');
  const config = localOnly ? { publicOrigin: httpsOrigin(env.BANGBANG_OSS_PUBLIC_ORIGIN) } : ossConfig(env);
  const releaseBytes = await boundedFile(releaseFile, 16384);
  auditText(releaseBytes);
  let release;
  try { release = validateRelease(JSON.parse(releaseBytes.toString('utf8'))); }
  catch { throw new Error('release_manifest_invalid'); }
  const contents = new Map();
  for (const [kind, max] of [['android', 128 * 1024 * 1024], ['source', 64 * 1024 * 1024]]) {
    const asset = release[kind];
    const bytes = await boundedFile(join(assetsDir, asset.filename), max, asset);
    if (!bytes.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04]))) throw new Error('release_zip_signature_invalid');
    contents.set(asset.filename, bytes);
  }
  const buildInfo = await boundedFile(join(assetsDir, 'build-info.json'), 64 * 1024);
  if (sha256(buildInfo) !== release.buildInfoSha256) throw new Error('build_info_checksum_invalid');
  auditText(buildInfo);
  let metadata;
  try { metadata = JSON.parse(buildInfo.toString('utf8')); } catch { throw new Error('build_info_invalid'); }
  if (metadata.version !== release.version || metadata.release_commit !== release.sourceCommit)
    throw new Error('build_info_release_mismatch');
  contents.set('build-info.json', buildInfo);
  const license = await boundedFile(licenseFile, 256 * 1024);
  auditText(license);
  if (!license.toString('utf8').includes('GNU AFFERO GENERAL PUBLIC LICENSE')) throw new Error('license_invalid');
  contents.set('AGPL-3.0.txt', license);
  const types = new Map([[release.android.filename, 'application/vnd.android.package-archive'],
    [release.source.filename, 'application/zip'], ['build-info.json', 'application/json'], ['AGPL-3.0.txt', 'text/plain; charset=utf-8']]);
  const assets = [...contents].map(([filename, bytes]) => objectInfo(config, release.version, filename, bytes, types.get(filename)));
  const sums = Buffer.from(assets.map(asset => `${asset.sha256}  ${asset.filename}\n`).join(''));
  contents.set('SHA256SUMS', sums);
  assets.push(objectInfo(config, release.version, 'SHA256SUMS', sums, 'text/plain; charset=utf-8'));
  const manifest = { v: 1, version: release.version, sourceCommit: release.sourceCommit,
    assets: assets.map(({ filename, bytes, sha256, url }) => ({ filename, bytes, sha256, url })) };
  const manifestBytes = Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`);
  contents.set('manifest.json', manifestBytes);
  assets.push(objectInfo(config, release.version, 'manifest.json', manifestBytes, 'application/json'));
  const out = await newPrivateDirectory(outputDir);
  try {
    const prefix = `releases/${release.version}/`;
    await mkdir(join(out, 'public', 'releases', release.version), { recursive: true, mode: 0o700 });
    for (const [name, bytes] of contents) await privateWrite(join(out, 'public', prefix, name), bytes);
    // Audit exactly the verified bytes that will be uploaded, not a mutable input path.
    await auditSourceZip(join(out, 'public', prefix, release.source.filename));
    if (localOnly) {
      const review = { v: 1, kind: 'release-assets', execute: false, cloudVerified: false,
        version: release.version, sourceCommit: release.sourceCommit, proposedPublicOrigin: config.publicOrigin,
        preconditions: ['confirm_actual_bucket_region_acl_and_never_versioned', 'choose_download_access',
          'prepare_upload_plan_with_actual_bucket', 'complete_public_https_sha_head_range_cors_and_backup_checks'],
        objects: assets.map(({ acl, ...asset }) => ({ ...asset, localFile: join(out, 'public', asset.key) })) };
      await privateWrite(join(out, 'asset-review.json'), `${JSON.stringify(review, null, 2)}\n`);
      return review; // No bucket, ACL or upload command can be inferred from a local asset review.
    }
    const plan = { v: 1, kind: 'release', execute: false, version: release.version,
      bucket: config.bucket, ...(config.region ? { region: config.region } : {}), ...(config.endpoint ? { endpoint: config.endpoint } : {}),
      publicOrigin: config.publicOrigin, downloadAccess: config.downloadAccess,
      backupProbeOrigin: config.backupProbeOrigin,
      ...(config.signedOrigin ? { signedOrigin: config.signedOrigin } : {}), downloadBaseUrl: `${config.publicOrigin}/${prefix}`,
      preconditions: ['existing_bucket_confirmed', 'bucket_acl_private', 'bucket_never_versioned',
        'no_public_bucket_policy_covering_backups', 'review_source_archive', 'set_object_content_types_from_plan',
        ...(config.downloadAccess === 'private-signed' ? ['gateway_signs_only_this_whitelist', 'signed_redirect_ttl_at_most_300_seconds', 'no_file_body_proxy_through_ecs'] : ['review_block_public_access_before_allowing_only_these_objects'])],
      cors: { allowedOrigins: config.origins, allowedMethods: ['GET', 'HEAD'], allowedHeaders: ['Range', 'If-None-Match'],
        exposedHeaders: ['ETag', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'x-oss-meta-sha256'], maxAgeSeconds: 600, varyOrigin: true },
      objects: assets.map(asset => ({ ...asset, localFile: join(out, 'public', asset.key),
        upload: { program: 'ossutil', args: uploadArguments(config, asset, join(out, 'public', asset.key)) } })) };
    await privateWrite(join(out, 'release-plan.json'), `${JSON.stringify(plan, null, 2)}\n`);
    if (config.downloadAccess === 'public-objects') {
      // A review template only. Never merge this blindly into an existing bucket policy.
      const policy = { Version: '1', Statement: [{ Effect: 'Allow', Principal: ['*'], Action: ['oss:GetObject'],
        Resource: assets.map(asset => `acs:oss:*:*:${config.bucket}/${asset.key}`) }] };
      await privateWrite(join(out, 'public-object-policy.review.json'), `${JSON.stringify(policy, null, 2)}\n`);
    }
    return plan;
  } catch (error) { await rm(out, { recursive: true, force: true }); throw error; }
}

export async function stageRelease(options) {
  return prepareRelease({ ...options, localOnly: true });
}

export function validateBackup(bytes, expectedSha) {
  if (!SHA.test(expectedSha || '') || bytes.length <= 34 || bytes.length > MAX_BACKUP_BYTES ||
      !bytes.subarray(0, 6).equals(Buffer.from('BGBK01')) || sha256(bytes) !== expectedSha)
    throw new Error('encrypted_backup_invalid');
}

export async function prepareBackup({ inputFile, expectedSha, outputDir, env = process.env }) {
  if (!inputFile || !outputDir) throw new Error('backup_and_new_output_required');
  const config = ossConfig(env, { backup: true });
  const bytes = await boundedFile(inputFile, MAX_BACKUP_BYTES);
  validateBackup(bytes, expectedSha);
  const out = await newPrivateDirectory(outputDir);
  try {
    const filename = 'migration-20261003.bgbak';
    const localFile = join(out, filename);
    await privateWrite(localFile, bytes);
    const asset = { key: BACKUP_KEY, filename, bytes: bytes.length, sha256: expectedSha,
      acl: 'private', cacheControl: 'no-store', contentType: 'application/octet-stream' };
    const plan = { v: 1, kind: 'encrypted-backup', execute: false, bucket: config.bucket,
      preconditions: ['existing_bucket_confirmed', 'bucket_acl_private', 'bucket_never_versioned',
        'no_anonymous_bucket_policy_covering_backups', 'decrypt_original_and_readback_locally', 'never_upload_decryption_key'],
      objects: [{ ...asset, localFile, upload: { program: 'ossutil', args: uploadArguments(config, asset, localFile) } }] };
    await privateWrite(join(out, 'backup-plan.json'), `${JSON.stringify(plan, null, 2)}\n`);
    return plan;
  } catch (error) { await rm(out, { recursive: true, force: true }); throw error; }
}

async function main(argv) {
  const mode = argv.shift();
  const options = parseOptions(argv, ['release', 'stage'].includes(mode) ? { '--release': 'releaseFile', '--assets': 'assetsDir', '--license': 'licenseFile', '--output': 'outputDir' } :
    mode === 'backup' ? { '--input': 'inputFile', '--sha256': 'expectedSha', '--output': 'outputDir' } : {});
  const plan = mode === 'release' ? await prepareRelease(options) : mode === 'stage' ? await stageRelease(options) : mode === 'backup' ? await prepareBackup(options) : null;
  if (!plan) throw new Error('invalid_mode');
  console.log(JSON.stringify({ v: 1, ok: true, kind: plan.kind, objects: plan.objects.length, execute: false }));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).catch(() => { console.error('oss_preparation_failed; check inputs and README'); process.exitCode = 1; });
}
