import { createHash } from 'node:crypto';
import { constants } from 'node:fs';
import { mkdir, open, realpath, writeFile } from 'node:fs/promises';
import { isIP } from 'node:net';
import { resolve } from 'node:path';

export const BACKUP_KEY = 'backups/migration-20261003.bgbak';
export const MAX_BACKUP_BYTES = 2 * 1024 * 1024;
export const IMMUTABLE_CACHE = 'public, max-age=31536000, immutable';

export function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

export function httpsOrigin(value) {
  let url;
  try { url = new URL(value); } catch { throw new Error('invalid_https_origin'); }
  const host = url.hostname.toLowerCase();
  if (url.protocol !== 'https:' || url.username || url.password || url.port ||
      url.pathname !== '/' || url.search || url.hash || isIP(host) ||
      !host.includes('.') || host.endsWith('.') || host.endsWith('.local') ||
      /(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(host))
    throw new Error('invalid_https_origin');
  return url.origin;
}

export function ossConfig(env, { backup = false } = {}) {
  const bucket = backup ? (env.BANGBANG_OSS_BACKUP_BUCKET || env.BANGBANG_OSS_BUCKET) : env.BANGBANG_OSS_BUCKET;
  if (typeof bucket !== 'string' || !/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(bucket))
    throw new Error('invalid_existing_bucket');
  const versioning = backup ? (env.BANGBANG_OSS_BACKUP_VERSIONING || env.BANGBANG_OSS_BUCKET_VERSIONING) : env.BANGBANG_OSS_BUCKET_VERSIONING;
  if (versioning !== 'unversioned')
    throw new Error('confirm_unversioned_bucket_before_preparing_upload');
  const config = { bucket, versioning: 'unversioned' };
  if (env.BANGBANG_OSS_REGION) {
    if (!/^[a-z]{2}-[a-z0-9-]{2,40}$/.test(env.BANGBANG_OSS_REGION)) throw new Error('invalid_oss_region');
    config.region = env.BANGBANG_OSS_REGION;
  }
  if (env.BANGBANG_OSS_ENDPOINT) {
    const endpoint = httpsOrigin(env.BANGBANG_OSS_ENDPOINT);
    if (!new URL(endpoint).hostname.endsWith('.aliyuncs.com')) throw new Error('invalid_oss_endpoint');
    config.endpoint = endpoint;
  }
  if (backup) return config;
  if (!config.region) throw new Error('oss_region_required');
  config.downloadAccess = env.BANGBANG_OSS_DOWNLOAD_ACCESS || 'private-signed';
  if (!['public-objects', 'private-signed'].includes(config.downloadAccess)) throw new Error('invalid_download_access');
  config.publicOrigin = httpsOrigin(env.BANGBANG_OSS_PUBLIC_ORIGIN);
  if (config.downloadAccess === 'private-signed') {
    config.signedOrigin = `https://${bucket}.oss-${config.region}.aliyuncs.com`;
  }
  const backupBucket = env.BANGBANG_OSS_BACKUP_BUCKET || bucket;
  if (!/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(backupBucket)) throw new Error('invalid_existing_backup_bucket');
  config.backupProbeOrigin = `https://${backupBucket}.oss-${config.region}.aliyuncs.com`;
  config.origins = [...new Set((env.BANGBANG_OSS_CORS_ORIGINS || '').split(',').map(v => v.trim()).filter(Boolean).map(httpsOrigin))];
  if (config.origins.length < 1 || config.origins.length > 6) throw new Error('explicit_cors_origins_required');
  return config;
}

export async function boundedFile(filename, max, expected) {
  const handle = await open(resolve(filename), constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const info = await handle.stat();
    if (!info.isFile() || info.size < 1 || info.size > max || (expected && info.size !== expected.bytes))
      throw new Error('asset_size_or_type_invalid');
    const bytes = await handle.readFile();
    if (bytes.length !== info.size || (expected && sha256(bytes) !== expected.sha256))
      throw new Error('asset_checksum_invalid');
    return bytes;
  } finally { await handle.close(); }
}

export function auditText(bytes) {
  if (/-----BEGIN (?:[A-Z ]* )?PRIVATE KEY-----|\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,}|\bLTAI[A-Za-z0-9]{12,}/u.test(bytes.toString('utf8')))
    throw new Error('private_material_detected');
}

export async function newPrivateDirectory(filename) {
  const directory = resolve(filename);
  await mkdir(directory, { mode: 0o700 }); // Existing directories are never replaced.
  return realpath(directory);
}

export async function privateWrite(filename, bytes) {
  await writeFile(filename, bytes, { flag: 'wx', mode: 0o600 });
}

export function uploadArguments(config, asset, localPath) {
  const args = ['api', 'put-object', '--bucket', config.bucket, '--key', asset.key,
    '--body', `file://${localPath}`, '--object-acl', asset.acl, '--forbid-overwrite=true', '--content-type', asset.contentType,
    '--storage-class', 'Standard', '--cache-control', asset.cacheControl,
    '--content-disposition', `attachment; filename="${asset.filename}"`,
    '--metadata', `sha256=${asset.sha256}`, '--metadata', `bytes=${asset.bytes}`];
  if (config.region) args.push('--region', config.region);
  if (config.endpoint) args.push('--endpoint', config.endpoint);
  return args;
}

export function parseOptions(argv, allowed) {
  const options = {};
  for (let i = 0; i < argv.length; i += 2) {
    const name = allowed[argv[i]];
    if (!name || argv[i + 1] == null || argv[i + 1].startsWith('--') || options[name] != null)
      throw new Error('invalid_arguments');
    options[name] = argv[i + 1];
  }
  return options;
}
