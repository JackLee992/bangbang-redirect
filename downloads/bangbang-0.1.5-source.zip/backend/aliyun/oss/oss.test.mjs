import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { mkdtemp, mkdir, readFile, rm, stat, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { promisify } from 'node:util';
import { BACKUP_KEY, httpsOrigin, MAX_BACKUP_BYTES, ossConfig, sha256 } from './common.mjs';
import { prepareBackup, prepareRelease, stageRelease, validateBackup } from './prepare.mjs';
import { validatePlan, validateSignedRedirect, verifyBackupReadback, verifyRelease } from './verify.mjs';

const execFileAsync = promisify(execFile);
const env = { BANGBANG_OSS_BUCKET: 'bangbang-review-bucket', BANGBANG_OSS_REGION: 'cn-beijing',
  BANGBANG_OSS_BUCKET_VERSIONING: 'unversioned', BANGBANG_OSS_PUBLIC_ORIGIN: 'https://downloads.example.com',
  BANGBANG_OSS_CORS_ORIGINS: 'https://bangbang-download.s419505080.chatgpt.site,https://bangbang.example.com',
  BANGBANG_OSS_ENDPOINT: 'https://oss-cn-beijing.aliyuncs.com',
  OSS_ACCESS_KEY_ID: 'do-not-copy', OSS_ACCESS_KEY_SECRET: 'do-not-copy-secret' };
const commit = '1'.repeat(40);

async function makeZip(filename, entries) {
  await execFileAsync('python3', ['-c',
    'import json,sys,zipfile\nwith zipfile.ZipFile(sys.argv[1],"w",compression=zipfile.ZIP_DEFLATED) as z:\n for name,data in json.loads(sys.argv[2]): z.writestr(name,data)\n', filename, JSON.stringify(entries)]);
}

async function fixture(t, entries = [['README.md', 'public project sources'], ['src/lib.rs', 'pub fn hello() {}']]) {
  const directory = await mkdtemp(join(tmpdir(), 'bangbang-oss-test-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const assetsDir = join(directory, 'assets');
  await mkdir(assetsDir);
  const release = { version: '0.1.2', sourceCommit: commit,
    android: { filename: 'bangbang-0.1.2-arm.apk' }, source: { filename: 'bangbang-0.1.2-source.zip' },
    arbitrary: { private: 'must-not-appear' } };
  // Controlled ZIP-like APK bytes test packaging only, not Android signatures/installability.
  await writeFile(join(assetsDir, release.android.filename), Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.from('controlled-apk-fixture')]));
  await makeZip(join(assetsDir, release.source.filename), entries);
  for (const kind of ['android', 'source']) {
    const bytes = await readFile(join(assetsDir, release[kind].filename));
    Object.assign(release[kind], { bytes: bytes.length, sha256: sha256(bytes) });
  }
  const info = Buffer.from(JSON.stringify({ version: release.version, release_commit: commit, build_commit: '2'.repeat(40) }));
  await writeFile(join(assetsDir, 'build-info.json'), info);
  release.buildInfoSha256 = sha256(info);
  const releaseFile = join(directory, 'release.json');
  await writeFile(releaseFile, JSON.stringify(release));
  const licenseFile = join(directory, 'LICENCE');
  await writeFile(licenseFile, 'GNU AFFERO GENERAL PUBLIC LICENSE\nVersion 3\n');
  return { directory, release, releaseFile, assetsDir, licenseFile, outputDir: join(directory, 'out'), env };
}

test('origin/config reject credential URLs, non-HTTPS, IPs, paths, missing versioning confirmation', () => {
  assert.equal(httpsOrigin('https://downloads.bangbang.yilin.fun/'), 'https://downloads.bangbang.yilin.fun');
  for (const value of ['http://downloads.example.com', 'https://user:secret@downloads.example.com', 'https://127.0.0.1',
    'https://downloads.example.com:444', 'https://downloads.example.com/path', 'https://downloads.example.com/?token=x', 'https://localhost.local'])
    assert.throws(() => httpsOrigin(value), /invalid_https_origin/);
  for (const value of [undefined, 'enabled', 'suspended'])
    assert.throws(() => ossConfig({ ...env, BANGBANG_OSS_BUCKET_VERSIONING: value }), /confirm_unversioned/);
  assert.equal(ossConfig(env).downloadAccess, 'private-signed');
  assert.equal(ossConfig({ ...env, BANGBANG_OSS_ENDPOINT: 'https://oss-cn-beijing-internal.aliyuncs.com' }).endpoint,
    'https://oss-cn-beijing-internal.aliyuncs.com');
  assert.throws(() => ossConfig({ ...env, BANGBANG_OSS_CORS_ORIGINS: '*' }), /invalid_https_origin/);
});

test('release default is six immutable private objects with sanitized manifest and explicit single-file commands', async t => {
  const input = await fixture(t);
  await writeFile(join(input.assetsDir, 'family-records.json'), '{"secret":"not allowed"}');
  const plan = await prepareRelease(input);
  assert.equal(plan.objects.length, 6);
  assert.equal(plan.downloadAccess, 'private-signed');
  assert.equal(plan.downloadBaseUrl, 'https://downloads.example.com/releases/0.1.2/');
  assert.equal(plan.signedOrigin, 'https://bangbang-review-bucket.oss-cn-beijing.aliyuncs.com');
  for (const object of plan.objects) {
    assert.match(object.key, /^releases\/0\.1\.2\//);
    assert.equal(object.acl, 'private');
    assert.ok(object.upload.args.includes('--forbid-overwrite=true'));
    assert.equal(object.upload.args[object.upload.args.indexOf('--content-type') + 1], object.contentType);
    assert.ok(!object.upload.args.includes('--recursive'));
    assert.ok(!object.upload.args.includes('--force'));
    assert.equal(sha256(await readFile(object.localFile)), object.sha256);
    assert.equal((await stat(object.localFile)).mode & 0o777, 0o600);
  }
  assert.equal((await stat(input.outputDir)).mode & 0o777, 0o700);
  const publicManifest = await readFile(plan.objects.find(o => o.filename === 'manifest.json').localFile, 'utf8');
  assert.ok(!publicManifest.includes(input.directory));
  assert.ok(!publicManifest.includes('must-not-appear'));
  const planText = JSON.stringify(plan);
  assert.ok(!planText.includes('do-not-copy'));
  assert.ok(!planText.includes('family-records'));
  assert.ok(!planText.includes(BACKUP_KEY));
  assert.equal(validatePlan(plan), plan);
});

test('public mode permits only the six object keys; no bucket-wide ACL or wildcard resource is generated', async t => {
  const input = await fixture(t);
  const plan = await prepareRelease({ ...input, env: { ...env, BANGBANG_OSS_DOWNLOAD_ACCESS: 'public-objects' } });
  assert.ok(plan.objects.every(object => object.acl === 'public-read'));
  const policy = JSON.parse(await readFile(join(input.outputDir, 'public-object-policy.review.json')));
  assert.deepEqual(policy.Statement[0].Action, ['oss:GetObject']);
  assert.equal(policy.Statement[0].Resource.length, 6);
  assert.ok(policy.Statement[0].Resource.every(value => value.startsWith('acs:oss:*:*:bangbang-review-bucket/releases/0.1.2/') && !value.endsWith('*')));
  assert.ok(!JSON.stringify(policy).includes('backups/'));
});

test('local staging validates the six real bytes without assuming a bucket, ACL or upload authorization', async t => {
  const input = await fixture(t);
  const unconfigured = { ...env, BANGBANG_OSS_BUCKET: undefined, BANGBANG_OSS_BUCKET_VERSIONING: undefined };
  const review = await stageRelease({ ...input, env: unconfigured });
  assert.equal(review.kind, 'release-assets');
  assert.equal(review.execute, false);
  assert.equal(review.cloudVerified, false);
  assert.equal(review.bucket, undefined);
  assert.equal(review.objects.length, 6);
  assert.ok(!JSON.stringify(review).includes('do-not-copy'));
  assert.ok(review.objects.every(o => !o.acl && !o.upload));
  for (const object of review.objects) assert.equal(sha256(await readFile(object.localFile)), object.sha256);
  await assert.rejects(stat(join(input.outputDir, 'release-plan.json')), { code: 'ENOENT' });
  assert.throws(() => validatePlan(review), /invalid_release_plan/);
  await assert.rejects(prepareRelease({ ...input, outputDir: join(input.directory, 'upload'), env: unconfigured }), /invalid_existing_bucket/);
});

test('mismatched release hash/size, metadata and symlink inputs fail without leaving an upload plan', async t => {
  for (const kind of ['hash', 'size', 'metadata', 'symlink']) {
    const input = await fixture(t);
    const apk = join(input.assetsDir, input.release.android.filename);
    if (kind === 'hash') await writeFile(apk, Buffer.alloc(input.release.android.bytes, 0));
    if (kind === 'size') await writeFile(apk, 'short');
    if (kind === 'metadata') {
      const info = Buffer.from(JSON.stringify({ version: '0.1.1', release_commit: commit }));
      await writeFile(join(input.assetsDir, 'build-info.json'), info);
      input.release.buildInfoSha256 = sha256(info);
      await writeFile(input.releaseFile, JSON.stringify(input.release));
    }
    if (kind === 'symlink') {
      const other = join(input.directory, 'other.apk');
      await writeFile(other, await readFile(apk));
      await rm(apk); await symlink(other, apk);
    }
    await assert.rejects(prepareRelease(input));
    await assert.rejects(stat(input.outputDir), { code: 'ENOENT' });
  }
});

test('source ZIP rejects traversal, private filenames, raw log and embedded credential material', async t => {
  for (const entries of [[['../outside.txt', 'x']], [['.env', 'x']], [['credentials/signing.p8', 'x']],
    [['session.log', 'x']], [['family-records.json', '{"records":[]}']], [['source.txt', 'ghp_' + 'x'.repeat(36)]]]) {
    const input = await fixture(t, entries);
    await assert.rejects(prepareRelease(input), /source_zip_audit_failed/);
    await assert.rejects(stat(input.outputDir), { code: 'ENOENT' });
  }
});

test('only the unchanged tracked public env template passes; changed bytes or other env paths fail', async t => {
  const template = await readFile(new URL('../../../deploy/oracle/.env.example', import.meta.url), 'utf8');
  const input = await fixture(t, [['deploy/oracle/.env.example', template]]);
  assert.equal((await prepareRelease(input)).objects.length, 6);
  for (const entries of [[['deploy/oracle/.env.example', template + '\nRELAY_SECRET=live-value\n']],
    [['other/.env.example', template]], [['deploy/oracle/.env', template]]]) {
    const changed = await fixture(t, entries);
    await assert.rejects(prepareRelease(changed), /source_zip_audit_failed/);
    await assert.rejects(stat(changed.outputDir), { code: 'ENOENT' });
  }
});

test('public household template is pinned to reviewed empty secrets and its exact path', async t => {
  const template = await readFile(new URL('../../../deploy/household/.env.example', import.meta.url), 'utf8');
  assert.equal(sha256(Buffer.from(template)), '221a462187ddf2b9b1ed6be700da1953cd769d34832d031469fa10c085b55e3a');
  const input = await fixture(t, [['deploy/household/.env.example', template]]);
  assert.equal((await prepareRelease(input)).objects.length, 6);
  for (const entries of [[['deploy/household/.env.example', template.replace('BANGBANG_FAMILY_INTERNAL_SECRET=', 'BANGBANG_FAMILY_INTERNAL_SECRET=runtime-secret')]],
    [['deploy/household/.env.example', template + '\n']], [['other/.env.example', template]],
    [['deploy/household/.ENV.example', template]], [['deploy/household/.env', template]]]) {
    const changed = await fixture(t, entries);
    await assert.rejects(prepareRelease(changed), /source_zip_audit_failed/);
    await assert.rejects(stat(changed.outputDir), { code: 'ENOENT' });
  }
});

test('negative credential test exception rejects unreviewed bytes, other paths and key payloads', async t => {
  const path = 'site/scripts/build-distribution.test.mjs';
  const header = '-----BEGIN ' + 'PRIVATE KEY-----';
  for (const entries of [[[path, `test('rejects credentials', () => '${header}');`]],
    [['other/build-distribution.test.mjs', header]],
    [[path, `${header}\nZmFrZS1wYXlsb2Fk\n-----END PRIVATE KEY-----\n`]],
    [[path, header + '\nghp_' + 'x'.repeat(36)]], [[path, header + '\n' + header]]]) {
    const input = await fixture(t, entries);
    await assert.rejects(prepareRelease(input), /source_zip_audit_failed/);
    await assert.rejects(stat(input.outputDir), { code: 'ENOENT' });
  }
});

test('existing output is preserved; repeat preparation never overwrites an approved plan', async t => {
  const input = await fixture(t);
  await prepareRelease(input);
  const before = await readFile(join(input.outputDir, 'release-plan.json'));
  await assert.rejects(prepareRelease(input), { code: 'EEXIST' });
  assert.deepEqual(await readFile(join(input.outputDir, 'release-plan.json')), before);
});

function encryptedFixture() {
  const key = randomBytes(32), nonce = randomBytes(12), aad = Buffer.from('bangbang/migration-20261003/v1');
  const plaintext = Buffer.from(JSON.stringify({ records: Array.from({ length: 21 }, (_, id) => ({ id, type: 'controlled-record' })) }));
  const cipher = createCipheriv('aes-256-gcm', key, nonce);
  cipher.setAAD(aad);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return { key, aad, plaintext, bytes: Buffer.concat([Buffer.from('BGBK01'), nonce, cipher.getAuthTag(), ciphertext]) };
}

test('encrypted backup is prepared separately private, and local authenticated decrypt confirms exact fixture bytes', async t => {
  const input = await fixture(t), encrypted = encryptedFixture();
  const inputFile = join(input.directory, 'backup.bgbak');
  await writeFile(inputFile, encrypted.bytes);
  const plan = await prepareBackup({ inputFile, expectedSha: sha256(encrypted.bytes), outputDir: join(input.directory, 'private-backup'),
    env: { ...env, BANGBANG_OSS_BACKUP_BUCKET: 'bangbang-backup-only' } });
  assert.equal(plan.objects.length, 1);
  assert.equal(plan.objects[0].acl, 'private');
  assert.equal(plan.objects[0].key, BACKUP_KEY);
  assert.equal(plan.bucket, 'bangbang-backup-only');
  assert.ok(!JSON.stringify(plan).includes('publicOrigin'));
  assert.ok(!JSON.stringify(plan).includes(encrypted.key.toString('hex')));
  const downloaded = await readFile(plan.objects[0].localFile);
  const verified = await verifyBackupReadback(plan.objects[0].localFile, plan.objects[0].sha256);
  assert.equal(verified.envelopeChecked, true);
  assert.equal(verified.authenticatedDecryptionVerified, false);
  await assert.rejects(verifyBackupReadback(plan.objects[0].localFile, '0'.repeat(64)), /encrypted_backup_invalid/);
  const decipher = createDecipheriv('aes-256-gcm', encrypted.key, downloaded.subarray(6, 18));
  decipher.setAAD(encrypted.aad); decipher.setAuthTag(downloaded.subarray(18, 34));
  assert.deepEqual(Buffer.concat([decipher.update(downloaded.subarray(34)), decipher.final()]), encrypted.plaintext);
});

test('backup preparation rejects plaintext, bad checksum and size bounds', () => {
  const good = encryptedFixture().bytes;
  for (const bytes of [Buffer.from('{"records":[]}'), Buffer.concat([Buffer.from('BGBK00'), good.subarray(6)]),
    Buffer.from('BGBK01' + 'x'.repeat(28)), Buffer.concat([Buffer.from('BGBK01'), Buffer.alloc(MAX_BACKUP_BYTES)])])
    assert.throws(() => validateBackup(bytes, sha256(bytes)), /encrypted_backup_invalid/);
  assert.throws(() => validateBackup(good, '0'.repeat(64)), /encrypted_backup_invalid/);
  assert.doesNotThrow(() => validateBackup(good, sha256(good)));
});

const now = Date.parse('2026-10-03T12:00:00Z');
function signedUrl(plan, object, extra = {}) {
  const url = new URL(object.key, `${plan.signedOrigin}/`);
  const values = { 'x-oss-signature-version': 'OSS4-HMAC-SHA256', 'x-oss-credential': 'TEST/20261003/cn-beijing/oss/aliyun_v4_request',
    'x-oss-date': '20261003T120000Z', 'x-oss-expires': '300', 'x-oss-signature': 'a'.repeat(64), ...extra };
  for (const [key, value] of Object.entries(values)) url.searchParams.set(key, value);
  return url.href;
}

async function transport(plan, mutation = {}) {
  const files = new Map(await Promise.all(plan.objects.map(async o => [o.key, await readFile(o.localFile)])));
  let privateCancelled = false;
  const fetchImpl = async (url, options) => {
    assert.equal(options.credentials, 'omit');
    assert.equal(options.redirect, 'manual');
    assert.equal(options.cache, 'no-store');
    assert.ok(!options.headers?.Authorization);
    const parsed = new URL(url), key = parsed.pathname.slice(1);
    if (key === BACKUP_KEY) {
      return { status: mutation.publicBackup ? 200 : 403, body: { cancel: async () => { privateCancelled = true; } } };
    }
    const object = plan.objects.find(o => o.key === key);
    assert.ok(object);
    const origin = options.headers?.Origin;
    const headers = { 'content-length': String(object.bytes), 'accept-ranges': 'bytes', 'etag': '"fixture"', 'x-oss-meta-sha256': object.sha256,
      ...(origin ? { 'access-control-allow-origin': mutation.badCors ? '*' : origin,
        'access-control-expose-headers': 'ETag, Content-Length, Content-Range, Accept-Ranges', 'vary': 'Origin' } : {}) };
    if (options.method === 'OPTIONS') return new Response(null, { status: 204, headers: { ...headers,
      'access-control-allow-methods': 'GET, HEAD', 'access-control-allow-headers': 'Range, If-None-Match' } });
    if (plan.downloadAccess === 'private-signed' && parsed.origin === plan.publicOrigin) {
      return new Response(null, { status: 302, headers: { ...headers, 'cache-control': 'no-store',
        location: mutation.badRedirect ? 'https://other.example.com/object' : signedUrl(plan, object) } });
    }
    let body = files.get(key);
    if (options.method === 'HEAD') return new Response(null, { status: 200, headers });
    if (options.headers?.Range) {
      const [, start, end] = /^bytes=(\d+)-(\d+)$/.exec(options.headers.Range);
      body = body.subarray(Number(start), Number(end) + 1);
      headers['content-length'] = String(body.length);
      headers['content-range'] = `bytes ${start}-${end}/${object.bytes}`;
      return new Response(body, { status: mutation.badRange ? 200 : 206, headers });
    }
    if (mutation.badHash) body = Buffer.alloc(body.length, 0);
    return new Response(body, { status: 200, headers });
  };
  return { fetchImpl, privateCancelled: () => privateCancelled };
}

test('read-only acceptance verifies private signed gateway and public objects: full SHA, HEAD, range, CORS and anonymous backup denial', async t => {
  for (const access of ['private-signed', 'public-objects']) {
    const input = await fixture(t);
    const plan = await prepareRelease({ ...input, env: { ...env, BANGBANG_OSS_DOWNLOAD_ACCESS: access } });
    const mock = await transport(plan);
    const report = await verifyRelease(plan, { fetchImpl: mock.fetchImpl, now: () => now });
    assert.equal(report.ok, true);
    assert.equal(report.objects.length, 6);
    assert.ok(report.objects.every(o => o.fullDownload && o.range && o.head));
    assert.equal(report.backupAnonymousDenied, true);
    assert.equal(report.backupExistenceOrIntegrityVerified, false);
    assert.ok(mock.privateCancelled());
    assert.ok(!JSON.stringify(report).includes('x-oss-signature'));
    assert.ok(!JSON.stringify(report).includes(input.directory));
  }
});

test('bad SHA, range, wildcard CORS, wrong redirect and public backup each fail controlled acceptance', async t => {
  const input = await fixture(t), plan = await prepareRelease(input);
  for (const mutation of [{ badHash: true }, { badRange: true }, { badCors: true }, { badRedirect: true }, { publicBackup: true }]) {
    const mock = await transport(plan, mutation);
    await assert.rejects(verifyRelease(plan, { fetchImpl: mock.fetchImpl, now: () => now }));
    if (mutation.publicBackup) assert.ok(mock.privateCancelled());
  }
});

test('signed redirect is fixed origin/key, unique known query fields, valid OSS4 and at most five minutes', async t => {
  const input = await fixture(t), plan = await prepareRelease(input), object = plan.objects[0];
  assert.equal(validateSignedRedirect(signedUrl(plan, object), plan.signedOrigin, object.key, now), signedUrl(plan, object));
  for (const url of [signedUrl(plan, object, { 'x-oss-expires': '301' }), signedUrl(plan, object, { 'x-oss-date': '20261003T110000Z' }),
    signedUrl(plan, object, { callback: 'x' }), signedUrl(plan, object) + '&x-oss-signature=duplicate',
    signedUrl(plan, object).replace(object.key, BACKUP_KEY), signedUrl(plan, object).replace(plan.signedOrigin, 'https://evil.example.com')])
    assert.throws(() => validateSignedRedirect(url, plan.signedOrigin, object.key, now));
});

test('tampered plan cannot turn the verifier into arbitrary file/key/URL requests', async t => {
  const input = await fixture(t), plan = await prepareRelease(input);
  for (const mutation of [p => p.objects.push({ ...p.objects[0], key: BACKUP_KEY }),
    p => p.objects[0].key = BACKUP_KEY, p => p.objects[0].url += '?token=x', p => p.publicOrigin = 'https://127.0.0.1']) {
    const changed = structuredClone(plan); mutation(changed);
    let called = false;
    await assert.rejects(verifyRelease(changed, { fetchImpl: async () => { called = true; } }));
    assert.equal(called, false);
  }
});
