# 阿里云 OSS 分发和私有备份准备

这组工具只在本机准备、校验文件，**不会调用云写入接口、开通服务、创建桶、改桶 ACL、上传或切换线上入口**。截至 2026-10-03 本轮检查，ECS 是北京 `cn-beijing`、99 元套餐；控制台负责人刷新后只读复核 OSS 仍显示尚未开通，页面说明开通后默认按量后付费，目前没有可用桶。本轮未点击协议或开通按钮。`downloads.bangbang.yilin.fun` 是拟用域名，尚不能当作已可下载的线上证据。

费用控制台已核实存在生效中的“标准存储包（中国大陆）”：40.000000 GB/小时、周期用量型、中国内地通用，仅对应标准存储的本地冗余 LRS 容量；有效期为 2026-10-03 09:00 至 2027-04-03 09:00（UTC+8）。页面抵扣项列出 OSS Storage 标准 LRS 容量及 ECS SnapshotSize 快照容量，**没有外网下载流出项**。近 30 天使用率和剩余额度都显示 `-`，表示本轮没有可用数值，不解释为 0 或无限。这个存储容量规格不能当作下载流量额度；实际开通和匹配的桶/冗余类型确认后，才可核实抵扣结果。

先由发布负责人在控制台核对已经购买的资源、开通状态及桶，再把实际桶名填入环境变量。本工具不建议或购买任何额外套餐。后续执行使用已存在的桶；北京 OSS 与北京 ECS 配套。Mac 上传使用外网 endpoint；只有同地域 ECS 上的上传、备份取回才使用 `https://oss-cn-beijing-internal.aliyuncs.com`，手机始终使用公网地址。[地域与 endpoint](https://help.aliyun.com/zh/oss/user-guide/regions-and-endpoints)、[同地域性能实践](https://help.aliyun.com/zh/oss/user-guide/oss-performance-best-practices)

## 文件和权限

发布路径固定为 `releases/<version>/`，只允许六个文件：

| 文件 | 输入与校验 |
| --- | --- |
| `bangbang-<version>-arm.apk` | `site/release.json` 指定的精确大小与 SHA-256，ZIP 签名；不替代 Android 签名/真机验收 |
| `bangbang-<version>-source.zip` | 同一清单的精确大小与 SHA；ZIP 内容隐私检查 |
| `build-info.json` | 清单的 `buildInfoSha256`，版本和 `release_commit` 匹配 |
| `AGPL-3.0.txt` | 仓库 `LICENCE`，生成 SHA |
| `SHA256SUMS` | 由前四项生成，明确固定文件名 |
| `manifest.json` | 只生成版本、源码提交和公开资产文件名/大小/SHA/URL |

任意其他文件不会进入清单。不会递归上传目录，不会生成桶级公共 ACL、对象列表或整个前缀的公开通配符。源码下载仍作为固定发布资产保存，不在宣发首页增加源码入口。源码 ZIP 不解压，拒绝越界/重复路径、软链接、加密 ZIP、超过 20,000 条目/单条 16 MiB/展开总量 256 MiB、私钥/签名文件、`.env`、缓存目录、原始 `.log`/数据库/备份文件及常见真实凭据模式；检查的是实际暂存上传的字节。已有 0.1.2 的 `deploy/oracle/.env.example` 只含文档注释和 `RELAY_HOST=relay.example.com`，允许该精确路径且 SHA 为 `5cf3348ffe642f34df5ca5b7ddc2d164e264db03787e5611c1d429eb5e40d289` 的原样模板。0.1.3 冻结源码的 `deploy/household/.env.example` 只含明确需替换的公开示例 endpoint、空 internal secret 和 16/8 的成员/家庭默认上限；允许该精确路径且 SHA 为 `221a462187ddf2b9b1ed6be700da1953cd769d34832d031469fa10c085b55e3a` 的原样模板。两项例外的改动字节、其他环境文件和其他路径的同名模板仍拒绝。发布负责人仍需审核源代码和同一构建来源，模式检查不等于证明所有敏感数据类型已被识别。

固定备份对象 `backups/migration-20261003.bgbak` **不属于公开白名单**。备份必须为本机已生成的 AES-256-GCM envelope：`BGBK01` 6 字节 + nonce 12 字节 + tag 16 字节 + ciphertext，长度 35 字节至 2 MiB，核对原文件 SHA-256。沿用现有 `bangbang/migration-20261003/v1` AAD；工具不读取、上传或记录解密密钥，不接受明文 JSON/原始日志/家庭记录。这是现有迁移快照备份，不能宣称已覆盖以后新增数据；周期备份由 API 运维单独设计。

桶保持 `private`。同桶时，公开规则不得覆盖 `backups/`；如已有第二个私有桶，可配置 `BANGBANG_OSS_BACKUP_BUCKET`，无需为本工具另建桶。**Bucket Policy 对匿名请求的 Allow 可以先于对象 private 生效**，不能仅凭对象 ACL 判断备份安全。[OSS 鉴权流程](https://help.aliyun.com/zh/oss/user-guide/authentication)

冻结 0.1.3 源码的 `site/scripts/build-distribution.test.mjs` 含一条只写入裸 `PRIVATE KEY` header 的公开负向测试，没有密钥正文。审计只允许该精确路径、完整文件 SHA `dae67f6c6d83b8d88695d91cb44e0921bd1ed55a9609bcc6d0a1e3d76e2f2cd3` 且只命中这一裸 header 的已审查字节；改动内容、追加密钥正文/令牌或其他路径仍拒绝，不删除冻结源码测试来满足扫描。

## 两种分发计划

默认 `private-signed`：所有六个对象为 `private`，保留阻止公共访问；独立下载网关仅对这六个路径生成不超过 300 秒的 OSS4 签名 `302`，手机直连 `https://<bucket>.oss-cn-beijing.aliyuncs.com/<key>`。网关只处理轻量响应，不能把约 49 MiB 的 APK 代理经过 ECS 的 3 Mbps 出口。GET/HEAD 必须按原方法签名，网关响应 `Cache-Control: no-store`，CORS 也要在网关和 OSS 两段配置。**本目录没有实现或部署网关**；只有这一计划而没有网关时下载尚不可用。

`public-objects`：确认可以精细开放后，只有六个审核对象设置 `public-read`。下载域名 CNAME 绑定 OSS、公网正文直接由 OSS 提供。准备器另输出 `public-object-policy.review.json`，只有六个精确资源键和 `oss:GetObject`，用于人工审核已有策略；逐对象 ACL 已能完成公开，不需要再盲目叠加该策略。不要用该模板覆盖现有桶策略，也不要把桶改为 public-read/public-read-write。阻止公共访问会覆盖公开权限；如必须调整，由发布负责人核查已有策略后进行，工具不自动调整。[访问控制概述](https://help.aliyun.com/zh/oss/user-guide/permissions-and-access-control-overview)、[阻止公共访问](https://help.aliyun.com/zh/oss/user-guide/block-public-access/)

## 本机准备

依赖 Node 24（项目已有）和 Python 3 标准库，不新增 npm/SDK 依赖。以下均为占位配置，替换为控制台真实值；不要把 AccessKey 或解密密钥写进命令、仓库、公开计划或聊天。正式上传使用官方 ossutil 2 已配置的本机凭据，或 ECS 的最小 RAM 角色，不把凭据复制给 App。

尚未确认真实桶时，可以先只生成六项本机资产。`stage` 只需要拟用的 HTTPS origin，完整核对正式 APK、源码和构建信息，并在新目录写 `asset-review.json`。该报告明确 `cloudVerified: false`，没有桶名、ACL 或上传命令，不能传给线上验收器；不能为了提前生成上传计划而虚构桶名或版本控制状态。

```sh
export BANGBANG_OSS_PUBLIC_ORIGIN='https://downloads.bangbang.yilin.fun'
node backend/aliyun/oss/prepare.mjs stage \
  --release site/releases/0.1.2.json \
  --assets artifacts/aliyun-migration/web-inputs-0.1.2 \
  --output artifacts/aliyun-migration/oss/assets-0.1.2-review
```

真实桶和权限核对完成后，再从这些同一 SHA 的资产执行下面的 `release` 准备。两种模式都只写本机私有目录。

0.1.3（18）预览资产使用发布负责人准备的独立清单及原 b8 构建产物，输出另一个目录，0.1.2 保留。APK 的 build/release source 是 b8；353 是独立验收 harness，不替代 APK 来源。

```sh
node backend/aliyun/oss/prepare.mjs stage \
  --release artifacts/android-release-0.1.3-18/release-0.1.3.json \
  --assets artifacts/android-release-0.1.3-18/assets \
  --output artifacts/aliyun-migration/oss/assets-0.1.3-preview-review
```

```sh
export BANGBANG_OSS_BUCKET='控制台实际桶名'
export BANGBANG_OSS_REGION='cn-beijing'
export BANGBANG_OSS_ENDPOINT='https://oss-cn-beijing.aliyuncs.com'
export BANGBANG_OSS_PUBLIC_ORIGIN='https://downloads.bangbang.yilin.fun'
export BANGBANG_OSS_CORS_ORIGINS='https://bangbang-download.s419505080.chatgpt.site,https://bangbang-services.s419505080.chatgpt.site'
export BANGBANG_OSS_DOWNLOAD_ACCESS='private-signed'
# 仅在控制台确认该桶从未开启版本控制后填写：
export BANGBANG_OSS_BUCKET_VERSIONING='unversioned'

node backend/aliyun/oss/prepare.mjs release \
  --release site/release.json \
  --assets /私有路径/已核验的正式发布产物 \
  --output artifacts/aliyun-migration/oss/release-review
```

`--assets` 必须同时含精确 APK、源码 ZIP、对应 `build-info.json`；不从工作区 debug 产物或网络地址自动兜底。当前仓库 `site/.downloads` 仍只有旧版产物，不能直接把它当作 0.1.2 的输入。`--output` 父目录必须存在，输出目录必须是新目录；既有目录不会覆盖。目录权限 0700、文件 0600，文件只存在本机 Git 忽略的 artifacts 中。

输出 `release-plan.json` 列出每个对象的本机路径、目标 key、ACL、MIME、大小、SHA、缓存和官方 ossutil `program`/`args` 数组。程序不会执行数组；发布负责人审核后逐条执行，执行器应使用 `execFile(program,args)` 并禁止 shell 拼接。上传命令固定 `api put-object --forbid-overwrite=true`、单文件 body、精确 object ACL、SHA/bytes 元数据和 MIME，参数已用校验 SHA 的官方 ossutil 2.4.0 **本机 help** 核对；未调用 OSS 接口。安装来源、工具版本和凭据配置见 [官方 ossutil](https://help.aliyun.com/zh/oss/developer-reference/ossutil-overview)、[put-object 参数](https://help.aliyun.com/zh/oss/developer-reference/put-object)。

**防覆盖前提：** OSS 的 forbid-overwrite 在开启或暂停版本控制的桶上无效，因此没有显式 `unversioned` 确认就拒绝准备计划。不要为满足脚本而关闭现有版本控制；这种桶应保留配置，由负责人设计带版本 ID 的发布流程。重试收到 409 时停止，读取既有精确对象并校验，只有大小/SHA 相同才可视作已完成；不同内容必须发布新版本，不能强制覆盖。[PutObject 防覆盖边界](https://help.aliyun.com/zh/oss/developer-reference/putobject)

备份单独准备到另一目录，不与 public 文件混合：

```sh
# 可选：已经存在的独立私有桶，不填写时使用同桶 backups/。
export BANGBANG_OSS_BACKUP_BUCKET='实际私有桶名'
# 单独桶也要先确认从未启用版本控制；同桶可继承前面的确认。
export BANGBANG_OSS_BACKUP_VERSIONING='unversioned'

node backend/aliyun/oss/prepare.mjs backup \
  --input /私有路径/migration-20261003.bgbak \
  --sha256 '原加密文件的小写64位SHA256' \
  --output artifacts/aliyun-migration/oss/private-backup-upload-review
```

此目录仅包含 ciphertext 和私有 `backup-plan.json`，无公开下载 URL；文件 format/SHA 验证不能验证 GCM tag，仍必须由保有密钥的本机完成解密核对。上传权限限制到该固定 key，且不授予公开读取、列桶、删除或改 ACL 的权限。

## 域名、CORS 和切换

北京桶的自定义域名需核查 `yilin.fun` 的备案状态、域名绑定/CNAME 和证书；生产地址必须直接支持 HTTPS，不依赖 HTTP 跳转。[自定义域名流程](https://help.aliyun.com/zh/oss/user-guide/access-buckets-via-custom-domain-names)、[HTTPS 配置](https://help.aliyun.com/zh/oss/how-to-access-oss-resources-through-https)

CORS 用计划列出的精确宣发/服务站来源，后续 `https://bangbang.yilin.fun` 等正式网站启用时显式加入；只允许 GET/HEAD，允许 Range/If-None-Match，暴露 ETag/Content-Length/Content-Range/Accept-Ranges/x-oss-meta-sha256，600 秒预检缓存、Vary: Origin，不携带 cookie/Authorization 或允许客户端直传。private-signed 还需网关 OPTIONS 就地响应而非重定向；Range 预检在网关和 OSS 都应通过。[OSS CORS 设置](https://help.aliyun.com/zh/oss/user-guide/configure-cross-origin-resource-sharing)

上传和配置完成后，从真实公网完整读回并验收：

```sh
node backend/aliyun/oss/verify.mjs \
  --plan artifacts/aliyun-migration/oss/release-review/release-plan.json
```

验收器只接受六个固定版本 key，所有请求省略凭据、禁自动跳转和缓存；逐文件 HEAD/完整 SHA/范围 206 与字节比对，检查精确来源 CORS 及 Range 预检。签名模式仅跟随一次计划里的 OSS 公网 origin、同一 key、合法 OSS4 且未过期的 1–300 秒签名；不持久化或输出签名 URL。再从 OSS 原域名匿名访问固定备份对象，必须拒绝 403，并取消响应正文。匿名 403 **不能证明备份存在或内容正确**，验收报告明确保留这一边界。

另由有权限的负责人下载私有备份到本机，再核对原 SHA 和封装：

```sh
node backend/aliyun/oss/verify.mjs \
  --backup-readback /私有路径/下载回来的migration-20261003.bgbak \
  --sha256 '原加密文件的小写64位SHA256'
```

最后仅在本机用原密钥/原 AAD 解密并核对原始快照；不要把密钥上传到 OSS/ECS/Sites。服务器 API、原 SQLite 家庭关系和新的会员数据不由这些下载工具迁移。

验收通过后，现有 `site/scripts/build.mjs --download-base-url` 可以指向计划的 `https://downloads.bangbang.yilin.fun/releases/<version>/`。版本发布按“新版本文件 → 完整核验 → 最后切网站版本/链接”进行；旧 `releases/<version>/` 原样保留。回滚只将网站清单/入口切回已核验旧前缀，不覆盖文件、不删除备份、不回滚家庭数据库。当前 `/downloads/...` legacy 元数据链接与新 version prefix 的别名需网站发布负责人一并核查，不在本目录改原站点实现。

## 成本与证据

OSS 存储包只抵扣匹配的存储计费项，**不是公网下载免费**；手机下载另有外网流出流量和请求费用。49,491,396 字节 APK 下载 1,000 次约为 49.5 GB（46.1 GiB），还要计重试、更新和源码下载。签名 302 省的是 ECS 文件转发带宽，不免除 OSS 公网流量；北京 ECS 通过北京 OSS 内网取回不产生该段流量费，读写请求仍按对应规则计费。先核实当前已买套餐的类型/适用地域/剩余额度、设置账单告警，再按实际下载量判断，不预先增加 CDN、传输加速或新资源包。[OSS 计费概述](https://help.aliyun.com/zh/oss/billing-overview)、[流量计费](https://help.aliyun.com/zh/oss/traffic-fees)、[同区 ECS 文件传输计费](https://help.aliyun.com/zh/ecs/user-guide/transfer-files-to-an-instance-using-object-storage)

本轮证据是 16 项本地受控测试、0.1.2 及冻结 0.1.3 源码 ZIP 的受限审计、Node 语法检查；既有官方工具本机参数核对记录保留。0.1.3 本机 stage 的六项 SHA 已核对、源码 ZIP 1281 文件/展开 27,356,556 字节审计通过，报告明确 `cloudVerified: false`；0.1.2 回退六项 SHA 保留。原 Sites 0.1.2 APK、源码 ZIP 和构建信息的真实完整 SHA、HEAD 与 Range 读回记录位于本机 `artifacts/aliyun-migration/oss/`，不是新桶线上上传、备案/HTTPS/CORS、下载量、真机安装或跨网远控验收。当前 PATH 无 `ossutil` 或 `aliyun`；本机准备可运行，实际上传另需已授权工具与凭据。

```sh
node --test backend/aliyun/oss/oss.test.mjs
```
