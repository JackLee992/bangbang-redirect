import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { BACKUP_KEY, boundedFile, httpsOrigin, MAX_BACKUP_BYTES, parseOptions } from './common.mjs';
import { validateBackup } from './prepare.mjs';

const SHA = /^[a-f0-9]{64}$/;
const VERSION = /^(?:0|[1-9]\d{0,3})\.(?:0|[1-9]\d{0,3})\.(?:0|[1-9]\d{0,3})$/;
const SIGNED_FIELDS = new Set(['x-oss-signature-version', 'x-oss-credential', 'x-oss-date', 'x-oss-expires',
  'x-oss-signature', 'x-oss-security-token', 'x-oss-additional-headers']);

function ossOrigin(value) {
  const origin = httpsOrigin(value);
  if (!/^[a-z0-9][a-z0-9-]+\.oss-[a-z0-9-]+\.aliyuncs\.com$/.test(new URL(origin).hostname))
    throw new Error('invalid_oss_read_origin');
  return origin;
}

export function validateSignedRedirect(location, origin, key, now = Date.now()) {
  let url;
  try { url = new URL(location); } catch { throw new Error('download_redirect_invalid'); }
  if (url.origin !== ossOrigin(origin) || url.username || url.password || url.hash ||
      url.pathname !== `/${key}` || !url.search || url.href.length > 8192)
    throw new Error('download_redirect_invalid');
  const names = new Set();
  for (const [name, value] of url.searchParams) {
    if (!SIGNED_FIELDS.has(name) || names.has(name) || !value || value.length > 4096)
      throw new Error('download_redirect_invalid');
    names.add(name);
  }
  const expires = url.searchParams.get('x-oss-expires');
  const created = url.searchParams.get('x-oss-date');
  if (url.searchParams.get('x-oss-signature-version') !== 'OSS4-HMAC-SHA256' ||
      !url.searchParams.get('x-oss-credential') || !SHA.test(url.searchParams.get('x-oss-signature') || '') ||
      !/^[1-9]\d{0,2}$/.test(expires || '') || Number(expires) > 300 ||
      !/^\d{8}T\d{6}Z$/.test(created || '')) throw new Error('download_redirect_invalid');
  const timestamp = Date.parse(`${created.slice(0, 4)}-${created.slice(4, 6)}-${created.slice(6, 8)}T${created.slice(9, 11)}:${created.slice(11, 13)}:${created.slice(13, 15)}Z`);
  if (!Number.isFinite(timestamp) || timestamp > now + 60000 || timestamp + Number(expires) * 1000 <= now)
    throw new Error('download_redirect_expired');
  return url.href; // Used only in memory. Never included in reports or errors.
}

export function validatePlan(plan) {
  if (plan?.v !== 1 || plan.kind !== 'release' || plan.execute !== false || !VERSION.test(plan.version) ||
      !['public-objects', 'private-signed'].includes(plan.downloadAccess)) throw new Error('invalid_release_plan');
  const origin = httpsOrigin(plan.publicOrigin);
  const names = new Set([`bangbang-${plan.version}-arm.apk`, `bangbang-${plan.version}-source.zip`,
    'build-info.json', 'AGPL-3.0.txt', 'SHA256SUMS', 'manifest.json']);
  if (!Array.isArray(plan.objects) || plan.objects.length !== names.size) throw new Error('invalid_release_plan');
  for (const object of plan.objects) {
    if (!names.delete(object.filename) || object.key !== `releases/${plan.version}/${object.filename}` ||
        object.url !== new URL(object.key, `${origin}/`).href || !SHA.test(object.sha256) ||
        !Number.isSafeInteger(object.bytes) || object.bytes < 1 || object.bytes > 128 * 1024 * 1024 ||
        object.acl !== (plan.downloadAccess === 'private-signed' ? 'private' : 'public-read'))
      throw new Error('invalid_release_plan');
  }
  if (plan.downloadAccess === 'private-signed') ossOrigin(plan.signedOrigin);
  ossOrigin(plan.backupProbeOrigin);
  if (!Array.isArray(plan.cors?.allowedOrigins) || plan.cors.allowedOrigins.length < 1 || plan.cors.allowedOrigins.length > 6)
    throw new Error('invalid_release_plan');
  plan.cors.allowedOrigins.forEach(httpsOrigin);
  return plan;
}

async function requestObject(plan, object, { method = 'GET', headers = {} } = {}, fetchImpl, now) {
  const options = { method, headers: { 'Accept-Encoding': 'identity', ...headers }, credentials: 'omit',
    redirect: 'manual', cache: 'no-store', signal: AbortSignal.timeout(120000) };
  let response = await fetchImpl(object.url, options);
  if (plan.downloadAccess === 'private-signed') {
    if (response.status !== 302 || !/(?:^|,)\s*no-store\s*(?:,|$)/i.test(response.headers.get('cache-control') || '')) {
      await response.body?.cancel(); throw new Error('signed_gateway_response_invalid');
    }
    if (headers.Origin && (response.headers.get('access-control-allow-origin') !== headers.Origin ||
        response.headers.get('access-control-allow-credentials') === 'true')) {
      await response.body?.cancel(); throw new Error('signed_gateway_cors_invalid');
    }
    let target;
    try { target = validateSignedRedirect(response.headers.get('location'), plan.signedOrigin, object.key, now()); }
    finally { await response.body?.cancel(); }
    response = await fetchImpl(target, options);
  }
  if (response.status >= 300 && response.status < 400) {
    await response.body?.cancel(); throw new Error('unexpected_redirect');
  }
  return response;
}

function verifyHeaders(response, object, expectedBytes = object.bytes) {
  if (response.headers.get('content-length') !== String(expectedBytes) ||
      (response.headers.get('content-encoding') && response.headers.get('content-encoding') !== 'identity') ||
      response.headers.get('accept-ranges') !== 'bytes' ||
      (response.headers.get('x-oss-meta-sha256') && response.headers.get('x-oss-meta-sha256') !== object.sha256))
    throw new Error('download_headers_invalid');
}

async function streamHash(response, expectedSize) {
  const hash = createHash('sha256');
  let length = 0;
  try {
    if (!response.body) throw new Error('download_body_missing');
    for await (const chunk of response.body) {
      length += chunk.length;
      if (length > expectedSize) throw new Error('download_size_invalid');
      hash.update(chunk);
    }
    if (length !== expectedSize) throw new Error('download_size_invalid');
    return hash.digest('hex');
  } catch (error) { await response.body?.cancel().catch(() => {}); throw error; }
}

async function boundedResponse(response, expectedSize) {
  const parts = [];
  let length = 0;
  if (!response.body) throw new Error('download_body_missing');
  for await (const part of response.body) {
    length += part.length;
    if (length > expectedSize) throw new Error('download_size_invalid');
    parts.push(Buffer.from(part));
  }
  if (length !== expectedSize) throw new Error('download_size_invalid');
  return Buffer.concat(parts);
}

async function verifyCors(plan, object, fetchImpl, now) {
  for (const origin of plan.cors.allowedOrigins) {
    const response = await requestObject(plan, object, { method: 'HEAD', headers: { Origin: origin } }, fetchImpl, now);
    if (response.status !== 200 || response.headers.get('access-control-allow-origin') !== origin ||
        response.headers.get('access-control-allow-credentials') === 'true')
      throw new Error('download_cors_invalid');
    const exposed = new Set((response.headers.get('access-control-expose-headers') || '').toLowerCase().split(',').map(v => v.trim()));
    for (const header of ['etag', 'content-length', 'content-range', 'accept-ranges'])
      if (!exposed.has(header)) throw new Error('download_cors_exposure_invalid');
    if (plan.cors.allowedOrigins.length > 1 && !(response.headers.get('vary') || '').toLowerCase().split(',').some(v => v.trim() === 'origin'))
      throw new Error('download_cors_vary_invalid');
    const urls = [object.url];
    if (plan.downloadAccess === 'private-signed') urls.push(new URL(object.key, `${plan.signedOrigin}/`).href);
    for (const url of urls) {
      const preflight = await fetchImpl(url, { method: 'OPTIONS', credentials: 'omit', redirect: 'manual', cache: 'no-store',
        signal: AbortSignal.timeout(10000), headers: { Origin: origin, 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'range' } });
      await preflight.body?.cancel();
      const methods = (preflight.headers.get('access-control-allow-methods') || '').toUpperCase().split(',').map(v => v.trim());
      const headers = (preflight.headers.get('access-control-allow-headers') || '').toLowerCase().split(',').map(v => v.trim());
      if (![200, 204].includes(preflight.status) || preflight.headers.get('access-control-allow-origin') !== origin ||
          preflight.headers.get('access-control-allow-credentials') === 'true' || !methods.includes('GET') || !methods.includes('HEAD') ||
          !headers.includes('range') || methods.some(v => !['GET', 'HEAD'].includes(v)))
        throw new Error('download_cors_preflight_invalid');
    }
  }
}

export async function verifyRelease(plan, { fetchImpl = fetch, now = Date.now } = {}) {
  validatePlan(plan);
  const report = { v: 1, ok: true, version: plan.version, downloadAccess: plan.downloadAccess, objects: [] };
  for (const object of plan.objects) {
    const head = await requestObject(plan, object, { method: 'HEAD' }, fetchImpl, now);
    if (head.status !== 200) throw new Error('download_head_failed');
    verifyHeaders(head, object);
    const response = await requestObject(plan, object, {}, fetchImpl, now);
    if (response.status !== 200) { await response.body?.cancel(); throw new Error('download_get_failed'); }
    try { verifyHeaders(response, object); } catch (error) { await response.body?.cancel(); throw error; }
    if (await streamHash(response, object.bytes) !== object.sha256) throw new Error('download_checksum_invalid');
    const local = await boundedFile(object.localFile, 128 * 1024 * 1024, object);
    const start = Math.min(7, object.bytes - 1);
    const end = Math.min(start + 31, object.bytes - 1);
    const range = await requestObject(plan, object, { headers: { Range: `bytes=${start}-${end}` } }, fetchImpl, now);
    if (range.status !== 206 || range.headers.get('content-range') !== `bytes ${start}-${end}/${object.bytes}`) {
      await range.body?.cancel(); throw new Error('download_range_invalid');
    }
    try { verifyHeaders(range, object, end - start + 1); } catch (error) { await range.body?.cancel(); throw error; }
    const rangeBytes = await boundedResponse(range, end - start + 1);
    if (!rangeBytes.equals(local.subarray(start, end + 1))) throw new Error('download_range_checksum_invalid');
    report.objects.push({ filename: object.filename, bytes: object.bytes, sha256: object.sha256, fullDownload: true, range: true, head: true });
  }
  await verifyCors(plan, plan.objects[0], fetchImpl, now);
  // An anonymous rejection is separate evidence from authenticated backup readback.
  const backup = await fetchImpl(new URL(BACKUP_KEY, `${plan.backupProbeOrigin}/`).href,
    { method: 'GET', credentials: 'omit', redirect: 'manual', cache: 'no-store', signal: AbortSignal.timeout(10000) });
  await backup.body?.cancel();
  if (backup.status !== 403) throw new Error('backup_anonymous_access_not_denied');
  report.cors = true;
  report.backupAnonymousDenied = true;
  report.backupExistenceOrIntegrityVerified = false;
  return report;
}

async function main(argv) {
  const options = parseOptions(argv, { '--plan': 'planFile', '--backup-readback': 'backupFile', '--sha256': 'expectedSha' });
  if (options.backupFile) {
    if (options.planFile) throw new Error('choose_one_verification');
    console.log(JSON.stringify(await verifyBackupReadback(options.backupFile, options.expectedSha), null, 2));
    return;
  }
  if (options.expectedSha) throw new Error('backup_file_required');
  if (!options.planFile) throw new Error('plan_required');
  const bytes = await boundedFile(options.planFile, 32768);
  const report = await verifyRelease(JSON.parse(bytes.toString('utf8')));
  console.log(JSON.stringify(report, null, 2));
}

export async function verifyBackupReadback(filename, expectedSha) {
  const bytes = await boundedFile(filename, MAX_BACKUP_BYTES);
  validateBackup(bytes, expectedSha);
  return { v: 1, ok: true, kind: 'encrypted-backup-readback', bytes: bytes.length, sha256: expectedSha,
    envelopeChecked: true, authenticatedDecryptionVerified: false };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).catch(() => { console.error('oss_verification_failed; no signed URL or response body was recorded'); process.exitCode = 1; });
}
