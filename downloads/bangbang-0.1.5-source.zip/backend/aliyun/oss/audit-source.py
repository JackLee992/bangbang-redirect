#!/usr/bin/env python3
"""Read a bounded ZIP without extracting it. Errors never include source data."""
import hashlib
import json
from pathlib import PurePosixPath
import re
import stat
import sys
import unicodedata
import zipfile

MAX_ENTRIES = 20000
MAX_FILE = 16 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024
PRIVATE_PARTS = {'.git', '.gradle', '.dart_tool', '.idea', '__pycache__',
                 'node_modules', 'deriveddata', 'pods', 'artifacts', '.aws', '.ssh', '.codex', '.config'}
PRIVATE_NAMES = {'services-runtime-secrets.json', 'runtime-secrets.json', 'credentials.json',
                 'family-records.json', 'family-snapshot.json', 'migration-snapshot.json'}
PRIVATE_SUFFIX = re.compile(r'\.(p12|pfx|p8|pem|key|keystore|jks|mobileprovision|sqlite|sqlite3|db|log|bgbak|ipa)$', re.I)
SECRETS = re.compile(rb'-----BEGIN (?:[A-Z ]* )?PRIVATE KEY-----|\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,}|\bLTAI[A-Za-z0-9]{12,}')
# These tracked public templates contain only example endpoints, empty secrets,
# and documented numeric defaults. A different path or changed byte is rejected.
PUBLIC_TEMPLATES = {
    'deploy/oracle/.env.example': '5cf3348ffe642f34df5ca5b7ddc2d164e264db03787e5611c1d429eb5e40d289',
    'deploy/household/.env.example': '221a462187ddf2b9b1ed6be700da1953cd769d34832d031469fa10c085b55e3a',
}
# The frozen distribution test writes a bare header as a rejection fixture.
# Its full reviewed bytes contain no key payload. Runtime keys never qualify.
PUBLIC_NEGATIVE_TESTS = {
    'site/scripts/build-distribution.test.mjs': 'dae67f6c6d83b8d88695d91cb44e0921bd1ed55a9609bcc6d0a1e3d76e2f2cd3',
}


def audit(filename):
    with zipfile.ZipFile(filename) as archive:
        entries = archive.infolist()
        if not entries or len(entries) > MAX_ENTRIES:
            raise ValueError('source_zip_limits_invalid')
        total = 0
        names = set()
        files = 0
        for entry in entries:
            name = entry.filename
            components = name.rstrip('/').split('/')
            normalized = unicodedata.normalize('NFC', name).casefold()
            if (not name or len(name) > 1024 or '\\' in name or ':' in name or
                    PurePosixPath(name).is_absolute() or any(ord(c) < 32 or ord(c) == 127 for c in name) or
                    any(p in ('', '.', '..') for p in components) or normalized in names):
                raise ValueError('source_zip_path_invalid')
            names.add(normalized)
            private_path = (any(p.casefold() in PRIVATE_PARTS or p.casefold() == '.env' or
                                p.casefold().startswith('.env.') for p in components) or
                            components[-1].casefold() in PRIVATE_NAMES or PRIVATE_SUFFIX.search(name))
            mode = (entry.external_attr >> 16) & 0xFFFF
            if entry.flag_bits & 1 or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError('source_zip_type_invalid')
            if entry.is_dir():
                if entry.file_size != 0 or private_path:
                    raise ValueError('source_zip_type_invalid')
                continue
            if entry.file_size > MAX_FILE:
                raise ValueError('source_zip_limits_invalid')
            total += entry.file_size
            if total > MAX_EXPANDED:
                raise ValueError('source_zip_limits_invalid')
            # ZipFile.read checks CRC; nothing is written to the filesystem.
            data = archive.read(entry)
            if private_path and hashlib.sha256(data).hexdigest() != PUBLIC_TEMPLATES.get(name):
                raise ValueError('source_zip_private_path')
            matches = SECRETS.findall(data)
            reviewed_header_fixture = (matches == [b'-----BEGIN ' + b'PRIVATE KEY-----'] and
                                       hashlib.sha256(data).hexdigest() == PUBLIC_NEGATIVE_TESTS.get(name))
            if len(data) != entry.file_size or (matches and not reviewed_header_fixture):
                raise ValueError('source_zip_private_material')
            files += 1
        if not files:
            raise ValueError('source_zip_limits_invalid')
        return {'v': 1, 'ok': True, 'files': files, 'expandedBytes': total}


if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise ValueError('invalid_arguments')
        print(json.dumps(audit(sys.argv[1]), separators=(',', ':')))
    except Exception:
        print('source_zip_audit_failed', file=sys.stderr)
        sys.exit(1)
