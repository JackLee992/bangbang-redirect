import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, writeFileSync, readFileSync, statSync, chmodSync, mkdirSync, copyFileSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { SQLiteFamilyDatabase } from "./sqlite.mjs";
import { exportAuthoritySnapshot as exportSnapshot, authorityConfigurationFingerprint } from "./snapshot.mjs";
import { RUNTIME_FILES, runtimeManifest } from "./runtime-manifest.mjs";

import { installAuthorityFence, freezeAuthority } from "../../site/worker/authority-fence.mjs";
async function exportAuthoritySnapshot(db, options) {
  if ((options.purpose ?? "cutover") === "cutover") {
    await installAuthorityFence(db); await freezeAuthority(db, { scope: options.scope });
  }
  return exportSnapshot(db, options);
}
const cli = fileURLToPath(new URL("./cli.mjs", import.meta.url));
const random = bytes => randomBytes(bytes).toString("base64url");
function configurationFile(directory, scope) {
  const configuration = { BANGBANG_FAMILY_STORE_SCOPE: scope, BANGBANG_FAMILY_API_ENABLED: "false",
    BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "false", BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32) };
  const filename = join(directory, "migration.env");
  writeFileSync(filename, Object.entries(configuration).map(([key, value]) => `${key}=${value}`).join("\n"), { flag: "wx", mode: 0o600 });
  return { configuration, filename };
}
const command = args => spawnSync(process.execPath, [cli, ...args], { encoding: "utf8", timeout: 10_000 });
function folder(t) {
  const directory = mkdtempSync(join(tmpdir(), "bangbang-aliyun-cli-"));
  t.after(() => rmSync(directory, { recursive: true, force: true })); return directory;
}
test("offline CLI initializes, imports, verifies and exports through independent Node processes without printing records", async t => {
  const directory = folder(t), filename = join(directory, "target.sqlite"), file = join(directory, "snapshot.json"), output = join(directory, "export.json");
  const source = new SQLiteFamilyDatabase(":memory:", { initialize: true }); t.after(() => source.close());
  const scope = "controlled-test", id = random(16);
  const config = configurationFile(directory, scope);
  const privateToken = "synthetic-private-push-address";
  await source.prepare("INSERT INTO bangbang_family_records VALUES (?, ?, ?, ?, ?)")
    .bind(scope, `devices/${id}`, JSON.stringify({ revision: 2, revokedAt: 123, pushRegistration: { token: privateToken } }), "test-etag", 123).run();
  const snapshot = await exportAuthoritySnapshot(source, { scope, configuration: config.configuration, apiEnabled: "false" });
  writeFileSync(file, JSON.stringify(snapshot), { flag: "wx", mode: 0o600 });
  const init = command(["init", "--db", filename]);
  assert.equal(init.status, 0); assert.deepEqual(JSON.parse(init.stdout), { ok: true, initialized: true });
  const flags = ["--db", filename, "--scope", scope, "--snapshot", file, "--expected-digest", snapshot.digest,
    "--expected-source-epoch", snapshot.freezeEvidence.epoch, "--env-file", config.filename, "--paused"];
  for (const op of ["import", "verify", "import"]) {
    const result = command([op, ...flags]);
    assert.equal(result.status, 0, result.stderr);
    assert.equal(JSON.parse(result.stdout).digest, snapshot.digest);
    for (const value of [id, privateToken, "pushRegistration", config.configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET]) assert.equal(`${result.stdout}${result.stderr}`.includes(value), false);
  }
  const frozen = command(["freeze", "--db", filename, "--scope", scope, "--env-file", config.filename, "--paused"]);
  assert.equal(frozen.status, 0);
  const exported = command(["export", "--db", filename, "--scope", scope, "--output", output, "--env-file", config.filename, "--paused"]);
  assert.equal(exported.status, 0);
  assert.equal(statSync(output).mode & 0o777, 0o600);
  assert.deepEqual(JSON.parse(readFileSync(output, "utf8")).records, snapshot.records);
  assert.equal(command(["init", "--db", filename]).status, 1, "existing volume is never replaced");
  assert.equal(command(["export", "--db", filename, "--scope", scope, "--output", output, "--env-file", config.filename, "--paused"]).status, 1, "private backup is never replaced");
});

test("CLI rejects nonprivate snapshots, wrong independent digest or omitted maintenance assertion", async t => {
  const directory = folder(t), filename = join(directory, "target.sqlite"), file = join(directory, "snapshot.json");
  const source = new SQLiteFamilyDatabase(":memory:", { initialize: true }); t.after(() => source.close());
  const config = configurationFile(directory, "controlled-test");
  const snapshot = await exportAuthoritySnapshot(source, { scope: "controlled-test", configuration: config.configuration, apiEnabled: "false" });
  writeFileSync(file, JSON.stringify(snapshot), { flag: "wx", mode: 0o600 });
  assert.equal(command(["init", "--db", filename]).status, 0);
  const flags = ["--db", filename, "--scope", "controlled-test", "--snapshot", file, "--expected-digest", snapshot.digest,
    "--expected-source-epoch", snapshot.freezeEvidence.epoch, "--env-file", config.filename];
  const unpaused = command(["import", ...flags]);
  assert.equal(unpaused.status, 1); assert.equal(unpaused.stderr.trim(), "authority_operation_failed");
  chmodSync(file, 0o644);
  assert.equal(command(["import", ...flags, "--paused"]).status, 1);
  chmodSync(file, 0o600);
  assert.equal(command(["import", "--db", filename, "--scope", "controlled-test", "--snapshot", file,
    "--expected-digest", "0".repeat(64), "--env-file", config.filename, "--paused"]).status, 1);
  const db = new SQLiteFamilyDatabase(filename); t.after(() => db.close());
  assert.equal(db.isAuthorityVerified("controlled-test", authorityConfigurationFingerprint(config.configuration)), false);
});

test("only the explicit 17 runtime modules initialize and import the HTTP entry in a separate checkout", t => {
  const directory = folder(t), root = fileURLToPath(new URL("../../", import.meta.url));
  for (const path of RUNTIME_FILES) {
    const destination = join(directory, path);
    mkdirSync(dirname(destination), { recursive: true });
    copyFileSync(join(root, path), destination);
  }
  const initialized = spawnSync(process.execPath, [join(directory, "backend/aliyun/cli.mjs"), "init", "--db", join(directory, "family.sqlite")],
    { encoding: "utf8", timeout: 10_000 });
  assert.equal(initialized.status, 0, initialized.stderr);
  const httpEntry = pathToFileURL(join(directory, "backend/aliyun/http.mjs")).href;
  const imported = spawnSync(process.execPath, ["--input-type=module", "--eval", `await import(${JSON.stringify(httpEntry)});`],
    { encoding: "utf8", timeout: 10_000 });
  assert.equal(imported.status, 0, imported.stderr);
  const manifest = runtimeManifest();
  assert.equal(RUNTIME_FILES.length, 17);
  assert.equal(manifest.files.length, 19);
  assert.equal(manifest.dependencyInstallRequired, false);
  assert.ok(manifest.files.every(file => /^[a-f0-9]{64}$/.test(file.sha256) && file.bytes > 0));
});

test("a paused CLI assertion cannot export formal data until an explicit persistent freeze commits", async t => {
  const directory = folder(t), filename = join(directory, "source.sqlite"), output = join(directory, "formal.json");
  const config = configurationFile(directory, "controlled-test");
  assert.equal(command(["init", "--db", filename]).status, 0);
  const exportArgs = ["export", "--db", filename, "--scope", "controlled-test", "--output", output,
    "--env-file", config.filename, "--paused"];
  const denied = command(exportArgs); assert.equal(denied.status, 1);
  assert.equal(denied.stdout, ""); assert.equal(denied.stderr, "authority_operation_failed\n");
  const freezeArgs = ["freeze", "--db", filename, "--scope", "controlled-test", "--env-file", config.filename, "--paused"];
  const first = command(freezeArgs), repeated = command(freezeArgs);
  assert.equal(first.status, 0); assert.equal(repeated.status, 0);
  assert.deepEqual(JSON.parse(first.stdout), JSON.parse(repeated.stdout));
  assert.equal(command(exportArgs).status, 0);
  const snapshot = JSON.parse(readFileSync(output, "utf8"));
  assert.equal(snapshot.v, 3); assert.equal(snapshot.freezeEvidence.epoch, JSON.parse(first.stdout).epoch);
  const db = new SQLiteFamilyDatabase(filename); t.after(() => db.close());
  await assert.rejects(db.prepare("INSERT INTO bangbang_family_records VALUES (?, ?, '{}', 'new', 1)")
    .bind("controlled-test", `devices/${random(16)}`).run(), /authority_frozen/);
});

test("formal CLI import requires the independently recorded source epoch and trusted digest", async t => {
  const directory = folder(t), source = new SQLiteFamilyDatabase(":memory:", { initialize: true });
  t.after(() => source.close());
  const scope = "controlled-test", config = configurationFile(directory, scope);
  const snapshot = await exportAuthoritySnapshot(source, { scope, configuration: config.configuration, apiEnabled: "false" });
  const file = join(directory, "source.json"), filename = join(directory, "target.sqlite");
  writeFileSync(file, JSON.stringify(snapshot), { mode: 0o600 });
  assert.equal(command(["init", "--db", filename]).status, 0);
  const flags = ["import", "--db", filename, "--scope", scope, "--snapshot", file, "--expected-digest", snapshot.digest,
    "--env-file", config.filename, "--paused"];
  assert.equal(command(flags).status, 1, "a file's own proof is not an independent operator observation");
  assert.equal(command([...flags, "--expected-source-epoch", random(16)]).status, 1);
  assert.equal(command([...flags, "--expected-source-epoch", snapshot.freezeEvidence.epoch]).status, 0);
  const altered = structuredClone(snapshot); altered.freezeEvidence.epoch = random(16);
  // An attacker able to rewrite the file can also recompute its public digest;
  // neither matches the independently recorded source epoch/digest below.
  const { authoritySnapshotDigest } = await import("./snapshot.mjs");
  altered.digest = authoritySnapshotDigest(altered);
  writeFileSync(file, JSON.stringify(altered));
  assert.equal(command([...flags, "--expected-source-epoch", snapshot.freezeEvidence.epoch]).status, 1);
});

test("configuration audit reads only a private nonsymlink env file and prints a domain-separated fingerprint", t => {
  const directory = folder(t), scope = "controlled-test", config = configurationFile(directory, scope);
  const args = ["configuration", "--scope", scope, "--env-file", config.filename];
  const result = command(args);
  assert.equal(result.status, 0);
  assert.deepEqual(JSON.parse(result.stdout), { ok: true, configFingerprint: authorityConfigurationFingerprint(config.configuration) });
  assert.equal(`${result.stdout}${result.stderr}`.includes(config.configuration.BANGBANG_DIAGNOSTICS_HASH_SECRET), false);
  chmodSync(config.filename, 0o644); assert.equal(command(args).status, 1); chmodSync(config.filename, 0o600);
  const link = join(directory, "alias.env"); symlinkSync(config.filename, link);
  const symlink = command(["configuration", "--scope", scope, "--env-file", link]);
  assert.equal(symlink.status, 1); assert.equal(symlink.stderr.trim(), "authority_operation_failed");
  assert.equal(command(["configuration", "--scope", "other", "--env-file", config.filename]).status, 1);
  assert.equal(command([...args, "--env-file", config.filename]).status, 1);
});

test("offline import fails closed for wrong target secret or enabled target and rehearsal cannot create an activation marker", async t => {
  const directory = folder(t), scope = "controlled-test", config = configurationFile(directory, scope);
  const source = new SQLiteFamilyDatabase(":memory:", { initialize: true }); t.after(() => source.close());
  const snapshot = await exportAuthoritySnapshot(source, { scope, configuration: config.configuration, apiEnabled: "false", purpose: "rehearsal" });
  const file = join(directory, "rehearsal.json"), filename = join(directory, "target.sqlite");
  writeFileSync(file, JSON.stringify(snapshot), { flag: "wx", mode: 0o600 });
  assert.equal(command(["init", "--db", filename]).status, 0);
  const args = ["import", "--db", filename, "--scope", scope, "--snapshot", file, "--expected-digest", snapshot.digest,
    "--env-file", config.filename, "--paused"];
  const result = command(args); assert.equal(result.status, 0); assert.equal(JSON.parse(result.stdout).activationEligible, false);
  const db = new SQLiteFamilyDatabase(filename); t.after(() => db.close());
  assert.equal(db.isAuthorityVerified(scope, authorityConfigurationFingerprint(config.configuration)), false);
  const replace = changes => writeFileSync(config.filename,
    Object.entries({ ...config.configuration, ...changes }).map(([key, value]) => `${key}=${value}`).join("\n"), { mode: 0o600 });
  replace({ BANGBANG_DIAGNOSTICS_HASH_SECRET: random(32) }); assert.equal(command(args).status, 1);
  replace({ BANGBANG_FAMILY_API_ENABLED: "true" }); assert.equal(command(args).status, 1);
  replace({ BANGBANG_DIAGNOSTICS_INGEST_ENABLED: "true" }); assert.equal(command(args).status, 1);
  assert.equal(db.isAuthorityVerified(scope, authorityConfigurationFingerprint(config.configuration)), false);
});
