import { createPushProviders } from "../../site/server/push-providers.mjs";
import { createSitesFamilyBackend, sitesFamilyFetch, sitesPushDispatchFetch,
  sitesFamilyResponse, SITES_FAMILY_PATH, SITES_PUSH_DISPATCH_PATH } from "../../site/server/sites_family_service.mjs";
import { handleDiagnosticRequest } from "../../site/worker/diagnostics.mjs";
import { handleFamilyMigrationRequest } from "../../site/worker/family-migration.mjs";
import { authorityConfigurationFingerprint } from "./snapshot.mjs";

const unavailable = () => sitesFamilyResponse(503, { ok: false, error: "service_unavailable" });

/** Exactly one local authority. No D1/Blobs fallback or new account system.
 * First activation requires a full, verified offline migration; an empty
 * accidentally-created volume cannot replace the existing family authority.
 */
export function createAliyunFamilyApplication({ db, env = process.env, now = Date.now,
  pushProviders, fetchImpl = fetch } = {}) {
  if (!db || typeof db.isAuthorityVerified !== "function") throw new Error("storage_unavailable");
  const config = { ...env, DB: db, BANGBANG_FAMILY_API_ENABLED: env.BANGBANG_FAMILY_API_ENABLED ?? "false" };
  if (config.BANGBANG_FAMILY_API_ENABLED === "true") {
    let verified = false;
    try { verified = db.isAuthorityVerified(config.BANGBANG_FAMILY_STORE_SCOPE, authorityConfigurationFingerprint(config)); }
    catch { /* Missing/malformed continuity configuration never opens the API. */ }
    if (!verified) throw new Error("authority_migration_not_verified");
  }
  const backend = createSitesFamilyBackend({ env: config, now,
    pushProviders: pushProviders ?? createPushProviders({ env: config, now, fetchImpl }) });
  let nextCleanup = 0;
  async function maintenance() {
    if (now() < nextCleanup) return;
    nextCleanup = now() + 60_000;
    await backend.store.cleanupTransient();
  }
  return {
    async fetch(request) {
      try {
        const url = new URL(request.url);
        if (url.search) return sitesFamilyResponse(400, { ok: false, error: "invalid_request" });
        if (url.pathname === "/api/health" && request.method === "GET") {
          await backend.store.getWithMetadata("health", { type: "json", consistency: "strong" });
          return sitesFamilyResponse(200, { ok: true, service: "bangbang-family", authority: "ecs-sqlite",
            familyApiEnabled: backend.enabled() });
        }
        const migrated = await handleFamilyMigrationRequest(request, config);
        if (migrated) {
          if (migrated.status === 200 && (await migrated.clone().json()).inserted > 0) {
            await db.invalidateAuthorityVerification(config.BANGBANG_FAMILY_STORE_SCOPE);
          }
          return migrated;
        }
        const diagnostics = await handleDiagnosticRequest(request, config, now());
        if (diagnostics) return diagnostics;
        if (url.pathname === SITES_FAMILY_PATH) return await sitesFamilyFetch(request, backend);
        if (url.pathname === SITES_PUSH_DISPATCH_PATH) return await sitesPushDispatchFetch(request, { env: config, backend, now });
        return sitesFamilyResponse(404, { ok: false, error: "not_found" });
      } catch { return unavailable(); }
    },
    async dispatch() {
      if (!backend.enabled()) return;
      await backend.dispatch();
      await maintenance();
    },
  };
}
