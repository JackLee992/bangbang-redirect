import { constants, openSync, closeSync, fstatSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, isAbsolute } from "node:path";
import { pathToFileURL } from "node:url";
import { parseEnv } from "node:util";
import { SQLiteFamilyDatabase } from "./sqlite.mjs";
import { installAuthorityFence, freezeAuthority } from "../../site/worker/authority-fence.mjs";
import { exportAuthoritySnapshot, importAuthoritySnapshot, verifyAuthoritySnapshot,
  authorityConfigurationFingerprint, MAX_SNAPSHOT_BYTES } from "./snapshot.mjs";

function argumentsFor(argv) {
  const [command, ...flags] = argv;
  const required = { init: ["db"], configuration: ["scope", "env-file"],
    freeze: ["db", "scope", "env-file", "paused"],
    export: ["db", "scope", "output", "env-file", "paused"],
    import: ["db", "scope", "snapshot", "expected-digest", "env-file", "paused"],
    verify: ["db", "scope", "snapshot", "expected-digest", "env-file", "paused"] }[command];
  const allowed = required && [...required, ...(command === "export" ? ["purpose"] : []),
    ...(["import", "verify"].includes(command) ? ["expected-source-epoch"] : [])];
  if (!allowed) throw new Error("invalid_command");
  const options = {};
  for (let i = 0; i < flags.length; i++) {
    const name = flags[i].startsWith("--") ? flags[i].slice(2) : "";
    if (!allowed.includes(name) || Object.hasOwn(options, name)) throw new Error("invalid_command");
    const value = name === "paused" ? true : flags[++i];
    if (!value || (typeof value === "string" && value.startsWith("--"))) throw new Error("invalid_command");
    options[name] = value;
  }
  if (required.some(name => !Object.hasOwn(options, name))) throw new Error("invalid_command");
  if (options.purpose && !["cutover", "rehearsal"].includes(options.purpose)) throw new Error("invalid_command");
  for (const name of ["db", "snapshot", "output", "env-file"]) {
    if (options[name] && !isAbsolute(options[name])) throw new Error("invalid_command");
  }
  return { command, options };
}
function privateText(filename, maximum) {
  const fd = openSync(filename, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || (stat.mode & 0o077) || stat.size < 1 || stat.size > maximum) throw new Error("snapshot_invalid");
    return readFileSync(fd, "utf8");
  } finally { closeSync(fd); }
}
const readSnapshot = filename => JSON.parse(privateText(filename, MAX_SNAPSHOT_BYTES));
function readConfiguration(filename, scope) {
  const configuration = parseEnv(privateText(filename, 65_536));
  if (configuration.BANGBANG_FAMILY_STORE_SCOPE !== scope) throw new Error("authority_configuration_mismatch");
  authorityConfigurationFingerprint(configuration);
  return configuration;
}

/** CLI arguments carry paths/digests only. Full records stay in private 0600
 * files; credentials are never accepted as arguments or printed on failure.
 * --paused is an operator assertion, not remote source-freeze automation.
 */
export async function runAuthorityCLI(argv) {
  const { command, options } = argumentsFor(argv);
  const configuration = command === "init" ? undefined : readConfiguration(options["env-file"], options.scope);
  if (command === "configuration") return { ok: true, configFingerprint: authorityConfigurationFingerprint(configuration) };
  let db;
  try {
    db = new SQLiteFamilyDatabase(options.db, { initialize: command === "init", readOnly: command === "export" || command === "verify" });
    if (command === "init") return { ok: true, initialized: true };
    const context = { scope: options.scope, apiEnabled: "false", expectedDigest: options["expected-digest"], configuration,
      expectedSourceEpoch: options["expected-source-epoch"],
      purpose: options.purpose ?? "cutover" };
    if (command === "freeze") {
      if (configuration.BANGBANG_FAMILY_API_ENABLED !== "false" || configuration.BANGBANG_DIAGNOSTICS_INGEST_ENABLED !== "false") {
        throw new Error("authority_must_be_paused");
      }
      await installAuthorityFence(db);
      return { ok: true, ...await freezeAuthority(db, { scope: options.scope }) };
    }
    if (command === "export") {
      const snapshot = await exportAuthoritySnapshot(db, context);
      mkdirSync(dirname(options.output), { recursive: true, mode: 0o700 });
      writeFileSync(options.output, JSON.stringify(snapshot), { flag: "wx", mode: 0o600 });
      return { ok: true, purpose: snapshot.purpose, digest: snapshot.digest, counts: snapshot.counts,
        ...(snapshot.freezeEvidence ? { freezeEvidence: snapshot.freezeEvidence } : {}) };
    }
    const snapshot = readSnapshot(options.snapshot);
    if (snapshot?.purpose === "cutover") {
      const epoch = options["expected-source-epoch"];
      if (typeof epoch !== "string" || !/^[A-Za-z0-9_-]{22}$/.test(epoch) ||
          Buffer.from(epoch, "base64url").toString("base64url") !== epoch || epoch !== snapshot.freezeEvidence?.epoch) {
        throw new Error("source_epoch_mismatch");
      }
    } else if (options["expected-source-epoch"] !== undefined) throw new Error("source_epoch_mismatch");
    const result = command === "import" ? await importAuthoritySnapshot(db, snapshot, context) :
      await verifyAuthoritySnapshot(db, snapshot, context);
    return { ok: true, ...result };
  } finally { db?.close(); }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.umask(0o077);
  try { process.stdout.write(`${JSON.stringify(await runAuthorityCLI(process.argv.slice(2)))}\n`); }
  catch { process.stderr.write("authority_operation_failed\n"); process.exitCode = 1; }
}
