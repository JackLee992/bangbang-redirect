CREATE TABLE IF NOT EXISTS attempts (
  attempt_id TEXT PRIMARY KEY,
  call_id TEXT NOT NULL,
  role TEXT NOT NULL,
  kind TEXT NOT NULL,
  platform TEXT NOT NULL,
  app_version TEXT NOT NULL,
  build TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  elapsed_ms INTEGER NOT NULL,
  phase TEXT NOT NULL,
  outcome TEXT NOT NULL,
  error TEXT NOT NULL,
  path TEXT NOT NULL,
  revision INTEGER NOT NULL,
  received_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS attempts_started ON attempts(started_at);
CREATE INDEX IF NOT EXISTS attempts_call ON attempts(call_id);
