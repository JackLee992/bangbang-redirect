# 连接诊断

当前生产入口是 Sites D1 的 `https://bangbang-services.s419505080.chatgpt.site/v1/attempts`，使用现有安装身份认证，不需要用户登录。接收、统计和阿里云迁移共用本目录的固定字段校验。独立 Cloudflare Worker 是备用部署实现，以下 Cloudflare 配置步骤不代表它已经上线。Node 22.13+ 可执行 `node --test backend/diagnostics/worker.test.mjs`；测试实际执行 SQLite schema 和查询。

## 数据与统计口径

客户端本地最多保存 100 条、7 天；“更多 → 连接诊断”可查看或复制。普通客户端默认使用上述认证入口，也可在同页关闭上传。上传失败后在前台等待 60 秒自动补报，每批最多 20 条；成功后分批清空剩余队列。进入后台暂停新上传和定时重试，回到前台恢复。统计和传输失败不阻塞协助流程。

原生层新增连接服务、服务握手、查找家人、直连、中继、安全握手六个阶段，保留最高已观察进度，随后仍以首次画面计入成功。网络错误细分为地址解析、连接拒绝、连接重置、不可达、网络权限等；握手、服务限制、协议及中继故障单独分类。TCP 底层保留系统错误链供手机本地分类，上报和导出只含固定分类，不含异常原文。旧包已丢弃的详情无法事后恢复。

新增阶段和分类沿用 v1 的 15 个固定字段，数据库没有新增列，旧记录继续可读。必须先部署接收端再发布新客户端；iOS 和 Android 都需要重编原生库。hbb_common 的改动保存在版本化补丁中，`scripts/qinban/apply_native_patches.py` 只接受指定原始或已修补哈希。iOS 冻结源码前需执行此脚本，Android 构建和正式发布流程已经接入；归档源码包含原始子模块及对应补丁。

只有固定字段：随机 attemptId、随机 callId、双方角色、客户端版本、平台、阶段、耗时、错误分类、直连/中继、递增 revision。没有账号、手机号、设备号码、家人称呼、屏幕、剪贴板、邀请口令、认证令牌或原始异常。已保存家人的求助以同一个 requestId 作为 callId 串起两端。首次 BB1 分享邀请目前没有共同的呼叫编号，准备和连接日志分开保存；不能宣称首次邀请也已有全链路追踪。

`kind=connection, role=helper` 的首次画面回调才计入 success；准备完成是 ready，授权完成仍是 pending。成功率为 success / (success + failure)，取消、进程中断和未完成另列。按 attemptId 去重，迟到的旧版本不会覆盖成功或失败。数据是客户端报告，不参与控制权限或家人认证。

接口：

- `POST /v1/attempts`：2 KB 上限，严格白名单校验，7 天离线补报窗口。默认关闭。
- `GET /v1/summary`：管理 Bearer token 才可看最近 7 天的成功率、错误分类、平台、版本和路径分组。
- `GET /health`：仅表示 Worker 可响应，不证明 D1 或手机连接成功。
- 每天定时删除超过 7 天的数据。

## 账号就绪后的部署

```sh
cd backend/diagnostics
cp wrangler.example.toml wrangler.toml
npx wrangler login
npx wrangler d1 create bangbang-diagnostics
# 将返回的 database_id 写入 wrangler.toml
npx wrangler d1 execute bangbang-diagnostics --remote --file schema.sql
npx wrangler secret put ADMIN_TOKEN
# 输入至少 32 字符的随机管理密钥；不放进客户端或 Git
npx wrangler deploy --dry-run
# 核对当前账号免费额度，然后将 INGEST_ENABLED 改成 "true"
npx wrangler deploy
```

独立 Worker 的地址配置不改变普通客户端的认证生产入口；修改客户端上传目标时还需核对 `diagnostics_transport.dart` 的受信目标约束。测试样例仅用随机模拟字段，不用真实家庭身份或邀请码。下面独立 Worker 的匿名接口及配额与当前生产安装认证入口是不同实现。

管理 token 只用于运营查询，不是匿名上传的密钥。公开匿名入口不能防止伪造统计，免费阶段通过请求体限制、30 次/分钟的 IP 限流和 Cloudflare 免费账户上限控制滥用。IP 仅作为限流服务的瞬时键，不写入 D1；共享移动出口可能导致诊断延迟，客户端会退避重试且不影响连接。上线后应观察数据量和限流，再决定是否增加安装级签发或配额。不要为了统计开启付费自动续费。

官方：[Workers 价格](https://developers.cloudflare.com/workers/platform/pricing/)、[D1 价格](https://developers.cloudflare.com/d1/platform/pricing/)、[限流绑定](https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/)。部署前重新确认额度和账号实际套餐。
