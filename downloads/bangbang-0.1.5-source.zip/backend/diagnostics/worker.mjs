const keys = ['v', 'attemptId', 'callId', 'role', 'kind', 'platform', 'appVersion', 'build',
  'startedAt', 'elapsedMs', 'phase', 'outcome', 'error', 'path', 'revision'];
export const diagnosticPhases = ['starting', 'serviceReady', 'calling', 'ringing',
  'signalingConnecting', 'signalingHandshake', 'peerLookup', 'directConnecting',
  'relayConnecting', 'peerHandshake', 'contacting', 'waitingApproval', 'authorized', 'firstFrame'];
export const diagnosticErrors = ['none', 'offline', 'network', 'timeout', 'rejected', 'password', 'keyMismatch', 'capture', 'unknown',
  'dns', 'refused', 'reset', 'unreachable', 'handshake', 'relay', 'signaling', 'serviceRejected', 'permission', 'protocol'];
const phases = diagnosticPhases;
const week = 7 * 86400000;
const response = (status, body) => new Response(JSON.stringify(body), { status,
  headers: { 'content-type': 'application/json', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });
const oneOf = (value, list) => list.includes(value);
const integer = (value, min, max) => Number.isSafeInteger(value) && value >= min && value <= max;
const token = value => typeof value === 'string' && /^[A-Za-z0-9_-]{22}$/.test(value);

export function validateRecord(data, now = Date.now()) {
  if (!data || Array.isArray(data) || typeof data !== 'object' || Object.keys(data).length !== keys.length ||
      Object.keys(data).some(key => !keys.includes(key)) || data.v !== 1 ||
      !token(data.attemptId) || !token(data.callId) || !oneOf(data.role, ['elder', 'helper']) ||
      !oneOf(data.kind, ['connection', 'preparation', 'call']) || !oneOf(data.platform, ['ios', 'android']) ||
      typeof data.appVersion !== 'string' || data.appVersion.length > 40 ||
      !/^\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.]+)?$/.test(data.appVersion) ||
      typeof data.build !== 'string' || !/^\d{1,12}$/.test(data.build) ||
      !integer(data.startedAt, now - week, now + 300000) || !integer(data.elapsedMs, 0, 600000) ||
      !integer(data.revision, 0, 64) || !oneOf(data.phase, phases) ||
      !oneOf(data.outcome, ['pending', 'ready', 'success', 'failure', 'cancelled', 'interrupted']) ||
      !oneOf(data.error, diagnosticErrors) ||
      !oneOf(data.path, ['unknown', 'direct', 'relay']) ||
      (data.outcome === 'success' && data.phase !== 'firstFrame') ||
      (data.outcome === 'ready' && (data.kind !== 'preparation' || data.phase !== 'serviceReady'))) return null;
  return Object.fromEntries(keys.map(key => [key, data[key]]));
}

async function readBody(request) {
  if (!/^application\/json(?:;|$)/i.test(request.headers.get('content-type') ?? '')) return null;
  const reader = request.body?.getReader();
  if (!reader) return null;
  const chunks = []; let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      size += value.length;
      if (size > 2048) { await reader.cancel(); return null; }
      chunks.push(value);
    }
    const bytes = new Uint8Array(size); let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  } catch { return null; } finally { reader.releaseLock(); }
}

const insert = `INSERT INTO attempts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(attempt_id) DO UPDATE SET elapsed_ms=excluded.elapsed_ms, phase=excluded.phase,
    outcome=excluded.outcome, error=excluded.error, path=excluded.path,
    revision=excluded.revision, received_at=excluded.received_at
  WHERE excluded.revision > attempts.revision AND attempts.outcome='pending'
    AND excluded.elapsed_ms >= attempts.elapsed_ms AND excluded.call_id=attempts.call_id
    AND excluded.role=attempts.role AND excluded.kind=attempts.kind
    AND excluded.platform=attempts.platform AND excluded.app_version=attempts.app_version
    AND excluded.build=attempts.build AND excluded.started_at=attempts.started_at`;

export async function handle(request, env, now = Date.now()) {
  const url = new URL(request.url);
  try {
    if (url.pathname === '/health' && request.method === 'GET') return response(200, { ok: true });
    if (url.pathname === '/v1/summary' && request.method === 'GET') {
      if (!env.ADMIN_TOKEN || env.ADMIN_TOKEN.length < 32 ||
          request.headers.get('authorization') !== `Bearer ${env.ADMIN_TOKEN}`) return response(401, { error: 'unauthorized' });
      const data = await env.DB.prepare(`SELECT platform, app_version, outcome, error, path,
        COUNT(*) AS count, AVG(elapsed_ms) AS mean_ms FROM attempts
        WHERE started_at >= ? AND kind='connection' AND role='helper'
        GROUP BY platform, app_version, outcome, error, path`).bind(now - week).all();
      const rows = data.results ?? [];
      const count = outcome => rows.filter(row => row.outcome === outcome).reduce((sum, row) => sum + row.count, 0);
      const success = count('success'), failure = count('failure');
      return response(200, { windowDays: 7, success, failure,
        successRate: success + failure ? success / (success + failure) : null,
        cancelled: count('cancelled'), interrupted: count('interrupted'), pending: count('pending'), rows });
    }
    if (url.pathname !== '/v1/attempts' || request.method !== 'POST') return response(404, { error: 'not_found' });
    // Ingestion is opt-in and remains disabled until the deployment is ready.
    if (env.INGEST_ENABLED !== 'true' || !env.RATE_LIMITER) return response(503, { error: 'not_configured' });
    if (request.headers.has('origin')) return response(403, { error: 'native_clients_only' });
    const limit = await env.RATE_LIMITER.limit({ key: request.headers.get('cf-connecting-ip') ?? 'unknown' });
    if (!limit.success) return response(429, { error: 'rate_limited' });
    const data = validateRecord(await readBody(request), now);
    if (!data) return response(400, { error: 'invalid_record' });
    // Public ingestion is intentionally not an authorization channel. These
    // metrics are client reports; never use them to approve a remote session.
    await env.DB.prepare(insert).bind(data.attemptId, data.callId, data.role, data.kind, data.platform,
      data.appVersion, data.build, data.startedAt, data.elapsedMs, data.phase, data.outcome,
      data.error, data.path, data.revision, now).run();
    return response(202, { ok: true });
  } catch { return response(503, { error: 'temporarily_unavailable' }); }
}

export default {
  fetch(request, env) { return handle(request, env); },
  async scheduled(_event, env) {
    await env.DB.prepare('DELETE FROM attempts WHERE started_at < ?').bind(Date.now() - week).run();
  },
};
