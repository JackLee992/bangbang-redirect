import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import worker, { handle, validateRecord } from './worker.mjs';

const now = Date.now();
const record = () => ({ v: 1, attemptId: 'AAAAAAAAAAAAAAAAAAAAAA', callId: 'BBBBBBBBBBBBBBBBBBBBBB',
  role: 'helper', kind: 'connection', platform: 'ios', appVersion: '0.1.2', build: '11',
  startedAt: now, elapsedMs: 0, phase: 'starting', outcome: 'pending', error: 'none', path: 'unknown', revision: 0 });
function fixture() {
  const sql = new DatabaseSync(':memory:');
  sql.exec(readFileSync(new URL('schema.sql', import.meta.url), 'utf8'));
  const env = { INGEST_ENABLED: 'true', ADMIN_TOKEN: 'test-only-'.repeat(5), RATE_LIMITER: { limit: async () => ({ success: true }) },
    DB: { prepare(query) { return { bind(...args) { return { run: async () => sql.prepare(query).run(...args),
      all: async () => ({ results: sql.prepare(query).all(...args) }) }; } }; } } };
  const send = (data) => handle(new Request('https://example.test/v1/attempts', {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(data) }), env, now);
  const summary = () => handle(new Request('https://example.test/v1/summary', {
    headers: { authorization: `Bearer ${env.ADMIN_TOKEN}` } }), env, now).then(r => r.json());
  return { env, send, summary, sql };
}
test('ingestion is allowlisted, bounded, and rejects raw identifiers or false success', () => {
  assert.ok(validateRecord(record(), now));
  for (const extra of [{ peerId: '123456789' }, { clipboard: 'BB1-secret' }, { ip: '192.0.2.1' },
    { outcome: 'success' }, { startedAt: now - 8 * 86400000 }, { elapsedMs: -1 }, { platform: 'other' }]) {
    assert.equal(validateRecord({ ...record(), ...extra }, now), null);
  }
});
test('the Cloudflare execution context is not used as the record timestamp', async () => {
  const f = fixture();
  const request = new Request('https://example.test/v1/attempts', {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(record()) });
  assert.equal((await worker.fetch(request, f.env, { waitUntil() {} })).status, 202);
});
test('replays and late pending records never double-count or undo a first frame', async () => {
  const f = fixture();
  assert.equal((await f.send(record())).status, 202);
  const finished = { ...record(), phase: 'firstFrame', outcome: 'success', elapsedMs: 1700, revision: 3 };
  await f.send(finished); await f.send(finished); await f.send(record());
  await f.send({ ...record(), outcome: 'failure', revision: 4, elapsedMs: 2000, error: 'timeout' });
  const summary = await f.summary();
  assert.equal(summary.success, 1); assert.equal(summary.failure, 0); assert.equal(summary.successRate, 1);
  assert.equal(f.sql.prepare('SELECT COUNT(*) AS count FROM attempts').get().count, 1);
});
test('preparation and cancellations are separate from completed connection rate', async () => {
  const f = fixture();
  await f.send({ ...record(), kind: 'preparation', phase: 'serviceReady', outcome: 'ready' });
  await f.send({ ...record(), attemptId: 'CCCCCCCCCCCCCCCCCCCCCC', outcome: 'cancelled' });
  const summary = await f.summary();
  assert.equal(summary.successRate, null); assert.equal(summary.cancelled, 1);
});
test('disabled collection, unauthorized summaries and denied rate limits fail closed', async () => {
  const f = fixture();
  f.env.INGEST_ENABLED = 'false'; assert.equal((await f.send(record())).status, 503);
  f.env.INGEST_ENABLED = 'true'; f.env.RATE_LIMITER.limit = async () => ({ success: false });
  assert.equal((await f.send(record())).status, 429);
  assert.equal((await handle(new Request('https://example.test/v1/summary'), f.env, now)).status, 401);
});
test('seven-day cleanup removes old rows', async () => {
  const f = fixture(); await f.send(record());
  f.sql.prepare('UPDATE attempts SET started_at=?').run(now - 8 * 86400000);
  await worker.scheduled({}, f.env);
  assert.equal(f.sql.prepare('SELECT COUNT(*) AS count FROM attempts').get().count, 0);
});
