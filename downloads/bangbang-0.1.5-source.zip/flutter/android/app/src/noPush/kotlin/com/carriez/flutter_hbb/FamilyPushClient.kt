package com.carriez.flutter_hbb

import android.content.Context

/** Builds without a provider still receive foreground family requests. */
object FamilyPushClient {
    fun enable(context: Context) {}
    fun state(context: Context): Map<String, Any> = mapOf("status" to "unavailable", "enabled" to false)
}

// Disabled by the merged manifest in builds without a configured provider.
class FamilyFirebaseMessagingService : android.app.Service() {
    override fun onBind(intent: android.content.Intent?) : android.os.IBinder? = null
}
