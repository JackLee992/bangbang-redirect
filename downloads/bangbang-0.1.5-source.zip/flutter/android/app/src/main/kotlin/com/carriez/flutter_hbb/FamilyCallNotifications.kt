package com.carriez.flutter_hbb

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

/** Foreground request presentation. Remote delivery is a separate push adapter. */
class FamilyCallNotifications(private val activity: MainActivity, messenger: BinaryMessenger) {
    private val channel = MethodChannel(messenger, "qinban/call-alerts")
    private val manager = activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val handler = Handler(Looper.getMainLooper())
    private var ringtone: Ringtone? = null
    private var requestId: String? = null
    private var pendingAction: Map<String, String>? = null
    private val notificationId = 73021
    private val channelId = "bangbang-family-calls"
    private var permissionResult: MethodChannel.Result? = null

    init {
        FamilyPushDelivery.createChannel(activity)
        FamilyPushDelivery.onAction = { action ->
            pendingAction = action
            channel.invokeMethod("actionAvailable", null)
        }
        FamilyPushDelivery.onStateChanged = { channel.invokeMethod("pushStateChanged", null) }
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "家人求助", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "家人发起的协助请求"
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            })
        }
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "show" -> { show(call.arguments as? Map<*, *>); result.success(null) }
                "dismiss" -> { dismiss(); result.success(null) }
                "takeAction" -> { result.success(pendingAction); pendingAction = null }
                "pushState" -> result.success(FamilyPushClient.state(activity))
                "requestPermission" -> {
                    FamilyPushClient.enable(activity)
                    if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        permissionResult?.success(false)
                        permissionResult = result
                        activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7302)
                    } else result.success(true)
                }
                else -> result.notImplemented()
            }
        }
        onIntent(activity.intent)
    }

    fun onIntent(intent: Intent?) {
        val data = listOf("v", "kind", "pairId", "requestId").mapNotNull { key ->
            intent?.getStringExtra(key)?.let { key to it }
        }.toMap()
        val pushed = FamilyPushDelivery.action(data)
        if (pushed != null) {
            data.keys.forEach { intent?.removeExtra(it) }
            pendingAction = pushed
            channel.invokeMethod("actionAvailable", null)
            return
        }
        val id = intent?.getStringExtra("qinban_request_id") ?: return
        val action = intent.getStringExtra("qinban_request_action") ?: return
        intent.removeExtra("qinban_request_id")
        intent.removeExtra("qinban_request_action")
        if (!id.matches(Regex("[A-Za-z0-9_-]{22}")) || action !in listOf("accept", "decline", "open")) return
        pendingAction = mapOf("requestId" to id, "action" to action)
        dismiss()
        // Dart re-fetches the authenticated request and checks its ID and expiry.
        channel.invokeMethod("actionAvailable", null)
    }

    fun onPermissionResult(requestCode: Int, grantResults: IntArray) {
        if (requestCode != 7302) return
        val allowed = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (allowed) FamilyPushClient.enable(activity)
        permissionResult?.success(allowed)
        permissionResult = null
    }

    fun close() {
        dismiss()
        FamilyPushDelivery.onAction = null
        FamilyPushDelivery.onStateChanged = null
        permissionResult?.success(false)
        permissionResult = null
        channel.setMethodCallHandler(null)
    }

    private fun action(id: String, name: String, index: Int): PendingIntent {
        val intent = Intent(activity, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("qinban_request_id", id)
            putExtra("qinban_request_action", name)
        }
        return PendingIntent.getActivity(activity, index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun show(data: Map<*, *>?) {
        val id = data?.get("requestId") as? String ?: return
        val expires = (data["expiresAt"] as? Number)?.toLong() ?: return
        val remaining = expires - System.currentTimeMillis()
        if (!id.matches(Regex("[A-Za-z0-9_-]{22}")) || remaining !in 1..120000) return
        if (requestId == id) return
        dismiss()
        requestId = id
        val name = (data["name"] as? String)?.take(24) ?: "家人"
        if (Build.VERSION.SDK_INT < 33 || activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            manager.notify(notificationId, NotificationCompat.Builder(activity, channelId)
                .setSmallIcon(R.mipmap.ic_stat_logo)
                .setContentTitle("家人需要帮忙")
                .setContentText("$name 正在呼叫你")
                .setContentIntent(action(id, "open", 0))
                .addAction(0, "接听", action(id, "accept", 1))
                .addAction(0, "暂不接听", action(id, "decline", 2))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setTimeoutAfter(remaining).setAutoCancel(true).setOnlyAlertOnce(true).build())
        }
        try {
            ringtone = RingtoneManager.getRingtone(activity, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)).apply {
                audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build()
                if (Build.VERSION.SDK_INT >= 28) isLooping = true
                play()
            }
        } catch (_: Exception) { /* The visual controls remain available without sound. */ }
        handler.postDelayed({ if (requestId == id) dismiss() }, remaining)
    }

    fun dismiss() {
        requestId = null
        handler.removeCallbacksAndMessages(null)
        ringtone?.stop()
        ringtone = null
        manager.cancel(notificationId)
    }
}
