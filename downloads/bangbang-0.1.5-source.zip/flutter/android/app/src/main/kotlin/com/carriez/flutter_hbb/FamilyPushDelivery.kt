package com.carriez.flutter_hbb

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Push data carries opaque references, never connection credentials. */
object FamilyPushDelivery {
    private const val CHANNEL_ID = "family_help"
    var foreground = false
    var onAction: ((Map<String, String>) -> Unit)? = null
    var onStateChanged: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())

    fun stateChanged() { handler.post { onStateChanged?.invoke() } }

    fun action(data: Map<String, String>): Map<String, String>? {
        if (data["v"] != "1" || data["kind"] != "family.request") return null
        val pair = data["pairId"] ?: return null
        val request = data["requestId"] ?: return null
        val opaque = Regex("[A-Za-z0-9_-]{22}")
        if (!pair.matches(opaque) || !request.matches(opaque)) return null
        return mapOf("source" to "push", "action" to "open", "pairId" to pair, "requestId" to request)
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "家人求助通知", NotificationManager.IMPORTANCE_HIGH).apply {
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
                })
        }
    }

    fun notificationsEnabled(context: Context): Boolean {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT < 26) return true
        // Creating an existing channel preserves the user's blocked setting.
        createChannel(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = manager.getNotificationChannel(CHANNEL_ID) ?: return false
        return channel.importance != NotificationManager.IMPORTANCE_NONE
    }

    fun receive(context: Context, payload: Map<String, String>) {
        val parsed = action(payload) ?: return
        handler.post {
            if (foreground && onAction != null) { onAction?.invoke(parsed); return@post }
            if (!notificationsEnabled(context)) return@post
            val key = "${parsed["pairId"]}.${parsed["requestId"]}"
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                this.data = Uri.parse("bangbang-internal://notification/$key")
                payload.forEach { (name, value) -> putExtra(name, value) }
            }
            val pending = PendingIntent.getActivity(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            NotificationManagerCompat.from(context).notify(key, 73022,
                NotificationCompat.Builder(context, CHANNEL_ID).setSmallIcon(R.mipmap.ic_stat_logo)
                    .setContentTitle("家人正在请求帮助").setContentText("打开帮帮，查看家人的求助")
                    .setContentIntent(pending).setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setAutoCancel(true)
                    .setOnlyAlertOnce(true).setTimeoutAfter(120000).build())
        }
    }
}
