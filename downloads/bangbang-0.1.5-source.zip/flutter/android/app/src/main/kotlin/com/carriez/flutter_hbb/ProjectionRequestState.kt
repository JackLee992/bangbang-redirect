package com.carriez.flutter_hbb

/** Process-local consent requests. A revoked request can never authorize a later service. */
class ProjectionRequestState {
    private var generation = 0L
    private var pendingId: Long? = null
    private var completion: ((Boolean) -> Unit)? = null

    @Synchronized
    fun begin(onComplete: ((Boolean) -> Unit)? = null): Long {
        cancel()
        val id = ++generation
        pendingId = id
        completion = onComplete
        return id
    }

    @Synchronized
    fun isPending(id: Long): Boolean = pendingId == id

    @Synchronized
    fun complete(id: Long, approved: Boolean): Boolean {
        if (!isPending(id)) return false
        val callback = completion
        pendingId = null
        completion = null
        callback?.invoke(approved)
        return true
    }

    @Synchronized
    fun cancel() {
        pendingId?.let { complete(it, false) }
    }
}

object ProjectionRequests {
    val state = ProjectionRequestState()
}
