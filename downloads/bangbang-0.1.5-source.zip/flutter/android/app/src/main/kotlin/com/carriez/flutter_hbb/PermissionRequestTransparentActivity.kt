package com.carriez.flutter_hbb

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.util.Log

class PermissionRequestTransparentActivity: Activity() {
    private val logTag = "permissionRequest"
    private var requestId = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(logTag, "onCreate PermissionRequestTransparentActivity: intent.action: ${intent.action}")
        requestId = intent.getLongExtra(EXT_MEDIA_PROJECTION_REQUEST_ID, -1L)
        setResult(RES_FAILED, Intent().putExtra(EXT_MEDIA_PROJECTION_REQUEST_ID, requestId))
        if (!ProjectionRequests.state.isPending(requestId)) {
            finish()
            return
        }

        when (intent.action) {
            ACT_REQUEST_MEDIA_PROJECTION -> {
                // Android restores the outstanding result after recreation; don't ask twice.
                if (savedInstanceState == null) {
                    val mediaProjectionManager =
                        getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val intent = mediaProjectionManager.createScreenCaptureIntent()
                    startActivityForResult(intent, REQ_REQUEST_MEDIA_PROJECTION)
                }
            }
            else -> finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_REQUEST_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null && ProjectionRequests.state.isPending(requestId)) {
                try {
                    launchService(data)
                    setResult(RESULT_OK, Intent().putExtra(EXT_MEDIA_PROJECTION_REQUEST_ID, requestId))
                } catch (e: Exception) {
                    Log.e(logTag, "Unable to start screen sharing service", e)
                    cancelRequest()
                }
            } else {
                cancelRequest()
            }
        }

        finish()
    }

    private fun cancelRequest() {
        if (ProjectionRequests.state.complete(requestId, false)) {
            stopService(Intent(this, MainService::class.java))
        }
    }

    private fun launchService(mediaProjectionResultIntent: Intent) {
        Log.d(logTag, "Launch MainService")
        val serviceIntent = Intent(this, MainService::class.java)
        serviceIntent.action = ACT_INIT_MEDIA_PROJECTION_AND_SERVICE
        serviceIntent.putExtra(EXT_MEDIA_PROJECTION_RES_INTENT, mediaProjectionResultIntent)
        serviceIntent.putExtra(EXT_MEDIA_PROJECTION_REQUEST_ID, requestId)
        serviceIntent.putExtra(EXT_INIT_FROM_BOOT, intent.getBooleanExtra(EXT_INIT_FROM_BOOT, false))

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

}
