package com.carriez.flutter_hbb

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

object FamilyPushClient {
    private var loading = false
    private var failed = false
    private var refreshedAt = 0L
    private fun preferences(context: Context) = context.getSharedPreferences("bangbang-push", Context.MODE_PRIVATE)
    private fun configured(context: Context) = context.getString(R.string.bangbang_push_mode) == "production"
    private fun configurationHash(context: Context) = context.getString(R.string.bangbang_push_config_sha256)

    fun enable(context: Context) {
        preferences(context).edit().putBoolean("enabled", true).apply()
        refresh(context)
    }

    fun saveToken(context: Context, token: String) {
        if (!configured(context) || token.length !in 20..4096 || token.any { it.isWhitespace() }) return
        preferences(context).edit().putString("token", token)
            .putString("configuration", configurationHash(context)).apply()
        failed = false
    }

    private fun refresh(context: Context) {
        if (!configured(context) || loading || !FamilyPushDelivery.notificationsEnabled(context)) return
        loading = true
        refreshedAt = System.currentTimeMillis()
        try {
            FirebaseApp.initializeApp(context)
            FirebaseMessaging.getInstance().isAutoInitEnabled = true
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                loading = false
                failed = !task.isSuccessful
                if (task.isSuccessful) saveToken(context, task.result)
                FamilyPushDelivery.stateChanged()
            }
        } catch (_: Exception) { loading = false; failed = true }
    }

    fun state(context: Context): Map<String, Any> {
        // This client never requests tokens or claims readiness in compile-only builds.
        if (!configured(context)) return mapOf("status" to "unavailable", "enabled" to false)
        val prefs = preferences(context)
        val optedIn = prefs.getBoolean("enabled", false)
        val allowed = FamilyPushDelivery.notificationsEnabled(context)
        if (optedIn && allowed && !loading && System.currentTimeMillis() - refreshedAt > 60000) refresh(context)
        val token = if (prefs.getString("configuration", null) == configurationHash(context))
            prefs.getString("token", null) else null
        // Refresh failure does not revoke permission or invalidate a saved token.
        // Keep its address registered, but expose unavailable until refresh succeeds.
        return mutableMapOf<String, Any>("provider" to "fcm", "enabled" to (optedIn && allowed),
            "clientConfig" to mapOf("appId" to context.packageName, "projectId" to context.getString(R.string.project_id)),
            "status" to when { !allowed -> "denied"; !optedIn -> "disabled"; failed -> "unavailable"; token == null -> "registering"; else -> "ready" }).apply {
            if (token != null) put("token", token)
        }
    }
}

class FamilyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        FamilyPushClient.saveToken(this, token)
        FamilyPushDelivery.stateChanged()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        FamilyPushDelivery.receive(this, message.data)
    }
}
