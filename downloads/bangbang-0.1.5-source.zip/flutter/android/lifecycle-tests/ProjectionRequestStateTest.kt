package com.carriez.flutter_hbb

/** JVM regressions use the exact state object consumed by both Android entry points. */
fun main() {
    var passed = 0
    fun test(name: String, body: () -> Unit) {
        body()
        println("PASS $name")
        passed++
    }

    test("stop invalidates consent before a late approval can launch capture") {
        val state = ProjectionRequestState()
        val results = mutableListOf<Boolean>()
        val id = state.begin { results.add(it) }
        check(state.isPending(id))
        state.cancel()
        var launches = 0
        // The permission Activity and the Service both use this production gate.
        if (state.isPending(id)) launches++
        check(!state.complete(id, true))
        check(launches == 0)
        check(results == listOf(false))
    }

    test("consent remains pending until the service reports actual readiness") {
        val state = ProjectionRequestState()
        val results = mutableListOf<Boolean>()
        val id = state.begin { results.add(it) }
        check(results.isEmpty())
        check(state.isPending(id)) // approval intent may be queued but not delivered yet
        check(state.complete(id, true))
        check(results == listOf(true))
        check(!state.isPending(id))
    }

    test("cancelled system consent resolves false exactly once") {
        val state = ProjectionRequestState()
        val results = mutableListOf<Boolean>()
        val id = state.begin { results.add(it) }
        check(state.complete(id, false))
        state.cancel()
        check(!state.complete(id, true))
        check(results == listOf(false))
    }

    test("an older result cannot approve or cancel the next request") {
        val state = ProjectionRequestState()
        val oldResults = mutableListOf<Boolean>()
        val newResults = mutableListOf<Boolean>()
        val old = state.begin { oldResults.add(it) }
        state.cancel()
        val current = state.begin { newResults.add(it) }
        check(old != current)
        check(!state.complete(old, true))
        check(!state.complete(old, false))
        check(state.isPending(current))
        check(newResults.isEmpty())
        check(state.complete(current, true))
        check(oldResults == listOf(false))
        check(newResults == listOf(true))
    }

    test("replacing an outstanding request releases its waiting channel result") {
        val state = ProjectionRequestState()
        val results = mutableListOf<Boolean>()
        val old = state.begin { results.add(it) }
        val current = state.begin()
        check(results == listOf(false))
        check(!state.isPending(old))
        check(state.isPending(current))
    }

    test("boot requests are revocable even without a Flutter callback") {
        val state = ProjectionRequestState()
        val id = state.begin()
        state.cancel()
        check(!state.isPending(id))
        check(!state.complete(id, true))
    }

    println("$passed projection lifecycle regressions passed")
}
