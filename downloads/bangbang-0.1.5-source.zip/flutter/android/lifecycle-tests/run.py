#!/usr/bin/env python3
"""Run the pure Kotlin consent regressions with the project's cached compiler."""
import os
from pathlib import Path
import subprocess
import tempfile


here = Path(__file__).resolve().parent
cache = Path(os.environ.get("GRADLE_USER_HOME", str(Path.home() / ".gradle"))) / "caches"
modules = cache / "modules-2/files-2.1"


def jar(group, artifact, version=None):
    base = modules / group / artifact
    candidates = sorted(base.glob(f"{version or '*'}/**/{artifact}-*.jar"))
    if not candidates:
        raise SystemExit(f"Missing cached {artifact}; run the Android build's dependency preparation first.")
    return candidates[-1]


compiler = jar("org.jetbrains.kotlin", "kotlin-compiler-embeddable", "1.9.10")
stdlib = jar("org.jetbrains.kotlin", "kotlin-stdlib", "1.9.10")
dependencies = [compiler, stdlib,
    jar("org.jetbrains.kotlin", "kotlin-reflect", "1.6.10"),
    jar("org.jetbrains.intellij.deps", "trove4j"),
    jar("org.jetbrains", "annotations")]
java_home = os.environ.get("JAVA_HOME")
java = str(Path(java_home) / "bin/java") if java_home else "java"
classpath = os.pathsep.join(map(str, dependencies))
source = here.parent / "app/src/main/kotlin/com/carriez/flutter_hbb/ProjectionRequestState.kt"

with tempfile.TemporaryDirectory(prefix="projection-lifecycle-") as output:
    subprocess.run([java, "-cp", classpath,
        "org.jetbrains.kotlin.cli.jvm.K2JVMCompiler", "-no-stdlib", "-no-reflect",
        "-classpath", str(stdlib), "-d", output,
        str(source), str(here / "ProjectionRequestStateTest.kt")], check=True)
    subprocess.run([java, "-cp", os.pathsep.join([str(stdlib), output]),
        "com.carriez.flutter_hbb.ProjectionRequestStateTestKt"], check=True)
