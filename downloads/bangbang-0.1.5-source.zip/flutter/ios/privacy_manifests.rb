# Backport reviewed upstream SDK privacy resources without changing Android.
require 'digest'
require 'json'
require 'pathname'

module BangbangPrivacyManifests
  def self.install(installer, ios_directory)
    root = Pathname.new(ios_directory).join('PrivacyManifests')
    evidence = JSON.parse(root.join('provenance.json').read).fetch('sdks')
    evidence.each do |name, entry|
      sdk = Pathname.new(ios_directory).join('.symlinks', 'plugins', name, 'ios')
      actual = Dir.glob(sdk.join('**', '*').to_s).select do |path|
        File.file?(path) && %w[.m .h .mm .swift .podspec].include?(File.extname(path))
      end.to_h do |path|
        [Pathname.new(path).relative_path_from(sdk).to_s, Digest::SHA256.file(path).hexdigest]
      end
      unless actual == entry.fetch('reviewedIOSSourceSHA256')
        raise "#{name} iOS SDK changed; review its privacy declaration before building"
      end
      manifest = root.join(name, 'PrivacyInfo.xcprivacy')
      unless Digest::SHA256.file(manifest).hexdigest == entry.fetch('bundledManifestSHA256')
        raise "#{name} privacy resource differs from its reviewed provenance"
      end
      target = installer.pods_project.targets.find { |item| item.name == name }
      raise "Missing expected privacy SDK target: #{name}" unless target

      # Use a relative project path so isolated source copies retain the resource.
      relative = manifest.relative_path_from(installer.sandbox.root).to_s
      reference = installer.pods_project.files.find { |item| item.path == relative }
      reference ||= installer.pods_project.new_file(relative)
      phase = target.resources_build_phase
      phase.add_file_reference(reference, true)
    end
  end
end
