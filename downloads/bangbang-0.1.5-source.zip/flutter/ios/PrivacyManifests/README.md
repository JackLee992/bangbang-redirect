# Reviewed SDK privacy resources

Build 13 was rejected with ITMS-91061 for seven frameworks. This iOS-only repair
does not upgrade shared Flutter packages or Android dependencies.

`Pod::PICKER_MEDIA = false` and `Pod::PICKER_AUDIO = false` use file_picker 5.5.0's
official compile options. The current iOS controller has no media/audio picker
entry; document selection remains compiled. This removes the otherwise unused
DKImagePickerController, DKPhotoGallery and SwiftyGif dependency chain.

The other four SDK manifests are sourced from released pub.dev archives; URLs,
archive hashes, original manifest hashes, reviewed iOS source hashes and bundled
manifest hashes are in `provenance.json`. `privacy_manifests.rb` refuses to build
if either the reviewed SDK source or the bundled declaration changes. CocoaPods
adds each resource to its own framework, not only the application bundle.

| SDK used | Manifest source | Review |
| --- | --- | --- |
| device_info_plus 9.1.2 | 10.1.0 | iOS source differs only in physical-device result representation (string to Boolean). UIDevice/uname results are returned to the app; no SDK network collection, tracking or Required Reason API found. |
| package_info_plus 4.2.0 | 8.0.0 | iOS Classes are byte-identical. Reads bundle metadata and receipt path; no timestamp access or SDK network collection found. |
| sqflite 2.2.0 | 2.3.3 | iOS wrapper handles local SQLite operations. No direct Required Reason API found in reviewed wrapper source; its FMDB dependency has its own manifest. |
| file_picker 5.5.0 | 8.0.3, with the correction below | Upstream declares no tracking/collection. FileUtils.m reads selected/cached file sizes using attributesOfItemAtPath. |

The empty API and collection arrays for the first three SDKs are **upstream
declarations**, checked against the versions actually compiled. They do not claim
the application collects no data. In particular, the app derives an installation
identifier from device information; application-level data handling must be
reviewed separately.

For file_picker, the upstream manifest (also checked in 8.3.7 and 10.3.10) omits
Required Reason APIs. This backport adds FileTimestamp reasons `C617.1` for files
in the app's cache/container and `3B52.1` for documents explicitly selected by the
user. `FileUtils.m:92` reads file size; Apple's category includes file size and
other metadata, not only timestamps. There is no blanket addition of unrelated
reasons. Upstream no-tracking/no-SDK-collection declarations remain unchanged.

Official references:

- [Apple third-party SDK requirements](https://developer.apple.com/support/third-party-SDK-requirements/)
- [Apple Required Reason API rules](https://developer.apple.com/documentation/bundleresources/describing-use-of-required-reason-api)
- [Apple approved reason definitions](https://developer.apple.com/documentation/bundleresources/app-privacy-configuration/nsprivacyaccessedapitypes/nsprivacyaccessedapitypereasons)
- [device_info_plus privacy addition](https://github.com/fluttercommunity/plus_plugins/commit/34fe31eb29e21fa9ea336e61d8df6858eb441a00)
- [package_info_plus privacy addition](https://github.com/fluttercommunity/plus_plugins/commit/895fe1a2658f7f1d61b830d769e0b251e82991b4)
- [file_picker 8.0.3](https://pub.dev/packages/file_picker/versions/8.0.3)
- [sqflite 2.3.3](https://pub.dev/packages/sqflite/versions/2.3.3)

After a dependency upgrade, review the SDK source and its then-current upstream
manifest, update provenance intentionally, and inspect the final archive/IPA.
Do not simply replace expected hashes to make the check pass. Preserve upstream
license notices in `UPSTREAM_LICENSES.txt`.
