import UIKit
import Flutter
import UserNotifications
import AudioToolbox

@main
@objc class AppDelegate: FlutterAppDelegate {
  private var shareChannel: FlutterMethodChannel?
  private var callChannel: FlutterMethodChannel?
  private var callAlertId: String?
  private var callAlertTimer: Timer?
  private var pendingCallAction: [String: String]?
  private var pushRegistrationFailed = false
  private var pushRegisteredThisLaunch = false
  private var pushRefreshedAt: TimeInterval?

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    dummyMethodToEnforceBundling();
    let initialized = super.application(application, didFinishLaunchingWithOptions: launchOptions)
    if let controller = window?.rootViewController as? FlutterViewController {
      configureCallAlerts(controller)
      let channel = FlutterMethodChannel(name: "qinban/share", binaryMessenger: controller.binaryMessenger)
      channel.setMethodCallHandler { [weak self] call, result in
        guard call.method == "share_text" else {
          result(FlutterMethodNotImplemented)
          return
        }
        guard let text = call.arguments as? String,
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
          result(false)
          return
        }
        DispatchQueue.main.async {
          guard var presenter = self?.window?.rootViewController else {
            result(false)
            return
          }
          while let presented = presenter.presentedViewController {
            presenter = presented
          }
          guard !(presenter is UIActivityViewController),
                presenter.viewIfLoaded?.window != nil,
                !presenter.isBeingPresented,
                !presenter.isBeingDismissed else {
            result(false)
            return
          }
          let activity = UIActivityViewController(activityItems: [text], applicationActivities: nil)
          if let popover = activity.popoverPresentationController {
            popover.sourceView = presenter.view
            popover.sourceRect = CGRect(x: presenter.view.bounds.midX,
                                       y: presenter.view.bounds.maxY - 1,
                                       width: 1, height: 1)
            popover.permittedArrowDirections = []
          }
          presenter.present(activity, animated: true) {
            result(true)
          }
        }
      }
      shareChannel = channel
    }
    return initialized
  }

  private func configureCallAlerts(_ controller: FlutterViewController) {
    let center = UNUserNotificationCenter.current()
    center.delegate = self
    center.setNotificationCategories([UNNotificationCategory(identifier: "BANGBANG_HELP",
      actions: [
        UNNotificationAction(identifier: "accept", title: "接听", options: [.foreground, .authenticationRequired]),
        UNNotificationAction(identifier: "decline", title: "暂不接听", options: [.foreground])
      ], intentIdentifiers: [], options: [])])
    let channel = FlutterMethodChannel(name: "qinban/call-alerts", binaryMessenger: controller.binaryMessenger)
    channel.setMethodCallHandler { [weak self] call, result in
      guard let self = self else { result(nil); return }
      switch call.method {
      case "requestPermission":
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
          DispatchQueue.main.async {
            UserDefaults.standard.set(granted, forKey: "bangbang.push.enabled")
            if granted { self.refreshPushRegistration() }
            result(granted)
          }
        }
      case "pushState": self.readPushState(result)
      case "show":
        self.showCallAlert(call.arguments as? [String: Any]); result(nil)
      case "dismiss":
        self.dismissCallAlert(); result(nil)
      case "takeAction":
        result(self.pendingCallAction); self.pendingCallAction = nil
      default: result(FlutterMethodNotImplemented)
      }
    }
    callChannel = channel
  }

  private func refreshPushRegistration() {
    let now = ProcessInfo.processInfo.systemUptime
    if let previous = pushRefreshedAt, now - previous < 60 { return }
    pushRefreshedAt = now
    UIApplication.shared.registerForRemoteNotifications()
  }

  private func readPushState(_ result: @escaping FlutterResult) {
    UNUserNotificationCenter.current().getNotificationSettings { settings in
      DispatchQueue.main.async {
        let optedIn = UserDefaults.standard.bool(forKey: "bangbang.push.enabled")
        let allowed = settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional
        let token = UserDefaults.standard.string(forKey: "bangbang.push.token")
        // This explicit declaration is checked against the FINAL exported app's
        // signing entitlements/profile by the release gate. Never infer it from
        // DEBUG/Release or invoke macOS-only SecTask/private iOS symbols.
        let declaredEnvironment = Bundle.main.object(forInfoDictionaryKey: "BangbangPushEnvironment") as? String
        let environment = ["sandbox", "production"].contains(declaredEnvironment ?? "") ? declaredEnvironment : nil
        // A temporary APNs registration error is not a permission revocation.
        // Preserve a saved address while reporting unavailable until it recovers.
        let enabled = optedIn && allowed
        if enabled { self.refreshPushRegistration() }
        var state: [String: Any] = ["provider": "apns", "enabled": enabled,
          "status": !allowed ? "denied" : !optedIn ? "disabled" : self.pushRegistrationFailed ? "unavailable" : environment == nil ? "unverified" : token == nil || !self.pushRegisteredThisLaunch ? "registering" : "ready"]
        if let token = token { state["token"] = token }
        if self.pushRegisteredThisLaunch, let environment = environment, let appId = Bundle.main.bundleIdentifier {
          state["clientConfig"] = ["appId": appId, "environment": environment]
        }
        result(state)
      }
    }
  }

  override func application(_ application: UIApplication,
    didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
    super.application(application, didRegisterForRemoteNotificationsWithDeviceToken: deviceToken)
    let token = deviceToken.map { String(format: "%02x", $0) }.joined()
    let changed = UserDefaults.standard.string(forKey: "bangbang.push.token") != token || pushRegistrationFailed || !pushRegisteredThisLaunch
    UserDefaults.standard.set(token, forKey: "bangbang.push.token")
    pushRegistrationFailed = false
    pushRegisteredThisLaunch = true
    if changed { callChannel?.invokeMethod("pushStateChanged", arguments: nil) }
  }

  override func application(_ application: UIApplication,
    didFailToRegisterForRemoteNotificationsWithError error: Error) {
    super.application(application, didFailToRegisterForRemoteNotificationsWithError: error)
    // Do not log addresses, tokens, or provider errors containing device data.
    let changed = !pushRegistrationFailed
    pushRegistrationFailed = true
    if changed { callChannel?.invokeMethod("pushStateChanged", arguments: nil) }
  }

  private func remoteCallAction(_ data: [AnyHashable: Any]) -> [String: String]? {
    guard data["v"] as? String == "1", data["kind"] as? String == "family.request",
          let pair = data["pairId"] as? String, let request = data["requestId"] as? String,
          pair.range(of: "^[A-Za-z0-9_-]{22}$", options: .regularExpression) != nil,
          request.range(of: "^[A-Za-z0-9_-]{22}$", options: .regularExpression) != nil else { return nil }
    return ["source": "push", "action": "open", "pairId": pair, "requestId": request]
  }

  private func showCallAlert(_ data: [String: Any]?) {
    guard let id = data?["requestId"] as? String,
          id.range(of: "^[A-Za-z0-9_-]{22}$", options: .regularExpression) != nil,
          let expires = data?["expiresAt"] as? NSNumber else { return }
    let remaining = expires.doubleValue / 1000 - Date().timeIntervalSince1970
    guard remaining > 0, remaining <= 120, callAlertId != id else { return }
    dismissCallAlert()
    callAlertId = id
    let content = UNMutableNotificationContent()
    content.title = "家人需要帮忙"
    content.body = "\(String((data?["name"] as? String ?? "家人").prefix(24))) 正在呼叫你"
    content.sound = .default
    content.categoryIdentifier = "BANGBANG_HELP"
    content.userInfo = ["requestId": id]
    UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "bangbang-call-\(id)",
      content: content, trigger: nil), withCompletionHandler: nil)
    // Foreground sound respects the user's sound settings. This is not PushKit
    // and cannot receive a new call while iOS has suspended the application.
    AudioServicesPlayAlertSound(1007)
    callAlertTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
      guard let self = self, self.callAlertId == id else { return }
      if Date().timeIntervalSince1970 >= expires.doubleValue / 1000 {
        self.dismissCallAlert()
      } else if UIApplication.shared.applicationState == .active {
        AudioServicesPlayAlertSound(1007)
      }
    }
  }

  private func dismissCallAlert() {
    callAlertTimer?.invalidate(); callAlertTimer = nil
    if let id = callAlertId {
      let center = UNUserNotificationCenter.current()
      center.removePendingNotificationRequests(withIdentifiers: ["bangbang-call-\(id)"])
      center.removeDeliveredNotifications(withIdentifiers: ["bangbang-call-\(id)"])
    }
    callAlertId = nil
  }

  override func userNotificationCenter(_ center: UNUserNotificationCenter,
    willPresent notification: UNNotification,
    withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    if let action = remoteCallAction(notification.request.content.userInfo) {
      pendingCallAction = action
      callChannel?.invokeMethod("actionAvailable", arguments: nil)
      completionHandler([]) // Fresh authenticated polling owns foreground ringing.
    } else if notification.request.content.categoryIdentifier == "BANGBANG_HELP" {
      completionHandler([.alert]) // Foreground ringing is managed above.
    } else {
      super.userNotificationCenter(center, willPresent: notification, withCompletionHandler: completionHandler)
    }
  }

  override func userNotificationCenter(_ center: UNUserNotificationCenter,
    didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
    if let action = remoteCallAction(response.notification.request.content.userInfo) {
      pendingCallAction = action
      center.removeDeliveredNotifications(withIdentifiers: [response.notification.request.identifier])
      callChannel?.invokeMethod("actionAvailable", arguments: nil)
      completionHandler()
      return
    }
    guard response.notification.request.content.categoryIdentifier == "BANGBANG_HELP",
          let id = response.notification.request.content.userInfo["requestId"] as? String else {
      super.userNotificationCenter(center, didReceive: response, withCompletionHandler: completionHandler)
      return
    }
    let action = ["accept", "decline"].contains(response.actionIdentifier) ? response.actionIdentifier : "open"
    pendingCallAction = ["requestId": id, "action": action]
    dismissCallAlert()
    callChannel?.invokeMethod("actionAvailable", arguments: nil)
    completionHandler()
  }
    
  public func dummyMethodToEnforceBundling() {
      dummy_method_to_enforce_bundling();
    session_get_rgba(nil, 0);
  }
}
