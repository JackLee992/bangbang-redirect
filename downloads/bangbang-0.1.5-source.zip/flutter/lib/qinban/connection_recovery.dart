import 'package:flutter/material.dart';
import 'connection_diagnostics.dart';

/// A failed invitation is not always retryable: rejected or expired credentials
/// require a new decision/invitation, and a saved-family call is already ended.
class ConnectionRecoveryPlan {
  const ConnectionRecoveryPlan._(
      this.title, this.nextStep, this.icon, this.canRetry);

  final String title;
  final String nextStep;
  final IconData icon;
  final bool canRetry;

  factory ConnectionRecoveryPlan({
    required DiagnosticError error,
    required bool sawFrame,
    required bool familyCall,
  }) {
    if (sawFrame) {
      return const ConnectionRecoveryPlan._(
          '协助已结束', '需要继续帮忙时，让家人在帮帮里重新呼叫。', Icons.call_end_rounded, false);
    }
    final (title, nextStep, icon, retryable) = switch (error) {
      DiagnosticError.offline => (
          '家人的手机还没就绪',
          '让家人打开帮帮，先开启权限，再发起邀请。',
          Icons.phonelink_off_rounded,
          false
        ),
      DiagnosticError.rejected => (
          '家人暂未允许',
          '先和家人说一声，方便时再发起协助。',
          Icons.front_hand_rounded,
          false
        ),
      DiagnosticError.password => (
          '这条邀请需要更新',
          '让家人重新发一条邀请，复制后回到帮帮。',
          Icons.mark_chat_unread_rounded,
          false
        ),
      DiagnosticError.keyMismatch => (
          '两台手机的设置不一致',
          '返回后，在“更多 → 连接与高级设置”中核对连接服务。',
          Icons.settings_outlined,
          false
        ),
      DiagnosticError.capture => (
          '家人还没共享屏幕',
          '让家人回到帮帮，按提示开启屏幕共享。',
          Icons.screen_share_outlined,
          false
        ),
      DiagnosticError.timeout => (
          '这次连接等得有点久',
          '让家人查看手机上的“允许协助”，确认两边网络正常后再试。',
          Icons.hourglass_bottom_rounded,
          true
        ),
      DiagnosticError.dns || DiagnosticError.refused || DiagnosticError.unreachable ||
          DiagnosticError.signaling || DiagnosticError.relay => (
          '暂时连不上连接服务',
          '试着切换 Wi-Fi 或手机流量，再发起连接。',
          Icons.wifi_off_rounded,
          true
        ),
      DiagnosticError.permission => (
          '还没允许联网',
          '到手机设置里，允许帮帮使用网络后再试。',
          Icons.settings_outlined,
          true
        ),
      DiagnosticError.serviceRejected => (
          '连接服务拒绝了请求',
          '确认两台手机使用同一连接服务后，再发起协助。',
          Icons.cloud_off_outlined,
          false
        ),
      DiagnosticError.handshake || DiagnosticError.protocol => (
          '连接验证没有完成',
          '确认两台手机都更新了帮帮，稍后再试。',
          Icons.verified_user_outlined,
          true
        ),
      _ => ('暂时没能连上', '检查两边的网络，让家人保持帮帮打开后再试。', Icons.wifi_off_rounded, true),
    };
    // A saved-family request has terminal semantics. Reconnecting its native
    // session would reuse a request that the other side has already released.
    final step =
        familyCall && retryable ? '$nextStep\n然后让家人重新呼叫，再接听一次。' : nextStep;
    return ConnectionRecoveryPlan._(
        title, step, icon, retryable && !familyCall);
  }
}

class ConnectionRecoveryContent extends StatelessWidget {
  const ConnectionRecoveryContent({super.key, required this.plan});
  final ConnectionRecoveryPlan plan;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 68,
        height: 68,
        decoration: BoxDecoration(
            color: colors.primaryContainer,
            borderRadius: BorderRadius.circular(16)),
        child: Icon(plan.icon, size: 34, color: colors.onPrimaryContainer),
      ),
      const SizedBox(height: 20),
      Text(plan.nextStep,
          key: const Key('connection-recovery-next-step'),
          style: Theme.of(context).textTheme.bodyLarge,
          textAlign: TextAlign.center),
    ]);
  }
}
