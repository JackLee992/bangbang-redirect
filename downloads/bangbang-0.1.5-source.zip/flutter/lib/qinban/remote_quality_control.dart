import 'package:flutter/material.dart';
import 'remote_quality_settings.dart';

/// A reversible shortcut to the engine's existing reaction-time preset.
/// Codec negotiation is unchanged. The native preset may change its FPS limit;
/// switching back to custom mode resends its captured quality and FPS settings.
class RemoteQualityControl extends StatefulWidget {
  const RemoteQualityControl({super.key, required this.access});
  final RemoteQualityAccess access;

  @override
  State<RemoteQualityControl> createState() => _RemoteQualityControlState();
}

class _RemoteQualityControlState extends State<RemoteQualityControl> {
  String? _quality;
  RemoteQualitySettings? _beforeLow;
  RemoteQualitySettings? _pending;
  bool _busy = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final quality = await widget.access.mode();
      if (mounted) setState(() => _quality = quality);
    } catch (_) {
      // A failed read must not overwrite the user's saved engine preference.
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggle() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      // The advanced display menu may have changed the preference meanwhile.
      if (_pending == null) {
        final current = await widget.access.capture();
        if (!mounted) return;
        if (current.mode == 'low') {
          _pending = _beforeLow ?? const RemoteQualitySettings('balanced');
        } else {
          // Preserve these values even when a native write partly succeeds.
          _beforeLow = current;
          _pending = const RemoteQualitySettings('low');
        }
      }
      final next = _pending!;
      await widget.access.apply(next);
      if (!mounted) return;
      setState(() {
        _pending = null;
        _quality = next.mode;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(next.mode == 'low'
            ? '流畅设置已发送，画面细节会减少'
            : _beforeLow == null
                ? '均衡画质设置已发送'
                : '原画质设置已发送'),
        duration: const Duration(seconds: 2),
      ));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('暂时没能切换画质，再试一次'),
        ));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = _quality == 'low';
    return Tooltip(
      message: active ? '关闭流畅优先，恢复画质' : '流畅优先：减少画面细节，优先响应操作',
      child: Semantics(
          toggled: active,
          child: TextButton.icon(
            key: const Key('remote-smooth-quality'),
            onPressed: _busy ? null : _toggle,
            style: TextButton.styleFrom(
              foregroundColor: active ? const Color(0xFFFFBF8C) : Colors.white,
              disabledForegroundColor: Colors.white54,
              backgroundColor: active ? Colors.white10 : Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              minimumSize: const Size(48, 48),
            ),
            icon: Icon(active ? Icons.bolt_rounded : Icons.bolt_outlined,
                size: 22),
            label: Text(active ? '流畅已开' : '流畅优先'),
          )),
    );
  }
}
