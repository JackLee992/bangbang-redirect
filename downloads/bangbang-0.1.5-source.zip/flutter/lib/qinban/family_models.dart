import 'package:flutter/foundation.dart';

enum FamilyDirection { incomingHelper, outgoingElder }

enum FamilyRequestStatus {
  idle,
  sending,
  waiting,
  ringing,
  received,
  connecting,
  active,
  failed
}

class FamilyCallEnd {
  const FamilyCallEnd(this.requestId, this.peerId, this.incoming, this.reason);
  final String requestId;
  final String peerId;
  final bool incoming;
  final String reason;
}

@immutable
class FamilyMember {
  const FamilyMember(
      {required this.peerId,
      required this.name,
      required this.direction,
      required this.lastHelpAt,
      this.directReady = false});
  final String peerId;
  final String name;
  final FamilyDirection direction;
  final DateTime lastHelpAt;
  final bool directReady;
}

@immutable
class FamilyHelpRequest {
  const FamilyHelpRequest(
      {required this.requestId,
      required this.familyPeerId,
      required this.familyName,
      required this.elderPeerId,
      required this.expiresAt});
  final String requestId;
  final String familyPeerId;
  final String familyName;
  final String elderPeerId;
  final DateTime expiresAt;
}
