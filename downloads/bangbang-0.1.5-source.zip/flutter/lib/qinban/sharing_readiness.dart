import 'dart:async';
import 'package:flutter/foundation.dart';

enum SharingReadinessResult { ready, stopped, timedOut }

/// A stored device number is not proof that the phone can receive a connection.
class SharingReadiness {
  SharingReadiness({required this.changes, required this.isActive,
      required this.isOnline, Duration timeout = const Duration(seconds: 20)}) {
    _deadline = Timer(timeout, () => _finish(SharingReadinessResult.timedOut));
    changes.addListener(_check);
    _check();
  }

  final Listenable changes;
  final bool Function() isActive;
  final bool Function() isOnline;
  final _result = Completer<SharingReadinessResult>();
  late final Timer _deadline;
  Future<SharingReadinessResult> get result => _result.future;

  void _check() {
    if (!isActive()) {
      _finish(SharingReadinessResult.stopped);
    } else if (isOnline()) {
      _finish(SharingReadinessResult.ready);
    }
  }

  void cancel() => _finish(SharingReadinessResult.stopped);

  void _finish(SharingReadinessResult value) {
    if (_result.isCompleted) return;
    _deadline.cancel();
    changes.removeListener(_check);
    _result.complete(value);
  }
}
