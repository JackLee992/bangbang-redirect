import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../common.dart';
import '../consts.dart';
import '../models/platform_model.dart';
import '../models/server_model.dart';
import '../models/state_model.dart';
import '../mobile/pages/settings_page.dart';
import 'assist_model.dart';
import 'invitation.dart';
import 'invitation_sharing.dart';
import 'family_bridge.dart';
import 'family_service.dart';
import 'sharing_readiness.dart';
import 'diagnostics_bridge.dart';
import 'diagnostics_page.dart';
import 'connection_diagnostics.dart';
import 'call_alerts.dart';
import 'background_push.dart';
import 'household_service.dart';
import 'remote_server_configuration.dart';

/// UI adapter only: the pinned upstream engine owns capture, transport and input.
class RustDeskAssistController extends AssistController with WidgetsBindingObserver {
  RustDeskAssistController(this.contextProvider, {this.helperOnly = false}) {
    final saved = bind.mainGetLocalOption(key: 'qinban-role');
    _role = resolveInitialAssistRole(saved, helperOnly: helperOnly);
    _fullInterface = bind.mainGetLocalOption(key: 'qinban-helper-interface') == 'full';
    _lastPeer = bind.mainGetLocalOption(key: 'qinban-last-peer');
    _family = FamilyBridge.initialize();
    _household = HouseholdService(store: _family.store,
      ensureRegistered: _family.ensureRegistered,
      contacts: () => _family.store.members.where((member) =>
        member.confirmed && member.hasCapability &&
        member.serverScope == _family.context().serverScope &&
        member.ownPeerId == _family.context().peerId).map((member) =>
          HouseholdContact(member.remoteInstallationId, member.name)).toList(),
      prepareRecovery: (scope) async {
        if (state.sharing || state.preparing || state.connections > 0 ||
            _connecting || _preparingSharing || !stateGlobal.isInMainPage ||
            _family.pendingRequest != null) {
          throw const HouseholdException('recovery_unavailable');
        }
        await _family.prepareHouseholdRecovery(confirmed: true, householdScope: scope);
        _pushRegistration.invalidateIdentity();
      });
    _pushRegistration = FamilyPushRegistration(readState: _callAlerts.pushState,
        publish: _family.configurePush);
    _family.onRemoteEnd = (call) {
      if (_disposed) return;
      if (call.incoming) {
        if (!stateGlobal.isInMainPage && gFFI.id == call.peerId) closeConnection();
      } else if (_sharingReady) {
        unawaited(stopSharing());
      }
    };
    _family.addListener(_familyChanged);
    FamilyCallAlerts.channel.setMethodCallHandler((call) async {
      if (call.method == 'actionAvailable') await _takeCallAction();
      if (call.method == 'pushStateChanged') await _syncPush();
    });
    _family.setForeground(true);
    // Foreground call signalling; suspended apps need remote push delivery.
    _familyTimer = Timer.periodic(const Duration(seconds: 2), (_) => _family.poll());
    _pushTimer = Timer.periodic(const Duration(seconds: 30), (_) => _syncPush());
    if (!helperOnly) {
      gFFI.serverModel.addListener(_changed);
    }
    WidgetsBinding.instance.addObserver(this);
    _inviteSubscription = qinbanInvitationInbox.changes.listen((_) => _applyInvitation());
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_disposed) {
        _takeCallAction();
        _syncPush();
        _applyInvitation();
        _readClipboard();
      }
    });
  }

  final BuildContext Function() contextProvider;
  final bool helperOnly;
  @override
  bool get supportsSharing => !helperOnly;
  late final HouseholdService _household;
  @override
  HouseholdService get householdService => _household;
  AssistRole? _role;
  bool _fullInterface = false;
  String _lastPeer = '';
  String? _error;
  Timer? _timer;
  bool _disposed = false;
  bool _foreground = true;
  bool _polling = false;
  bool _preparingSharing = false;
  SharingReadiness? _sharingReadiness;
  int _sharingGeneration = 0;
  bool _stoppingSharing = false;
  bool _connecting = false;
  bool _readingClipboard = false;
  QinbanInvitation? _invitation;
  String? _appliedInvitation;
  int _invitationRevision = -1;
  StreamSubscription? _inviteSubscription;
  late final FamilyService _family;
  Timer? _familyTimer;
  final _callAlerts = FamilyCallAlerts();
  late final FamilyPushRegistration _pushRegistration;
  Timer? _pushTimer;
  bool _handlingCallAction = false;
  DiagnosticAttempt? _familyDiagnostic;
  String? _handledCallEnd;

  void _familyChanged() {
    if (_disposed) return;
    _updateCallDiagnostic();
    final ended = _family.lastEnd;
    if (_family.pendingRequest == null && ended != null && _handledCallEnd != ended.requestId) {
      _handledCallEnd = ended.requestId;
      if (!ended.incoming && !helperOnly && !_stoppingSharing && gFFI.serverModel.isStart) {
        unawaited(stopSharing());
      }
    }
    _callAlerts.update(_family.pendingRequest, _family.requestStatus,
      helper: _role == AssistRole.helper && _family.pendingIncoming);
    if (!_sharingReady && !_family.pendingIncoming && _family.pendingRequest != null) {
      unawaited(_family.cancelOutgoing());
    }
    notifyListeners();
  }

  void _updateCallDiagnostic() {
    final store = DiagnosticsBridge.service;
    if (store == null) return;
    final request = _family.pendingRequest;
    if (request == null) {
      final attempt = _familyDiagnostic;
      if (attempt != null) {
        final reason = _family.lastEnd?.reason;
        final failure = ['expired', 'failed', 'declined'].contains(reason);
        store.finish(attempt, failure ? DiagnosticOutcome.failure : DiagnosticOutcome.cancelled,
          error: reason == 'expired' ? DiagnosticError.timeout : reason == 'declined'
            ? DiagnosticError.rejected : reason == 'failed' ? DiagnosticError.network : DiagnosticError.none);
      }
      _familyDiagnostic = null;
      return;
    }
    if (_familyDiagnostic?.data['callId'] != request.requestId) {
      _familyDiagnostic = store.begin(kind: 'call', callId: request.requestId,
        role: _family.pendingIncoming ? 'helper' : 'elder');
    }
    final phase = switch (_family.requestStatus) {
      FamilyRequestStatus.sending || FamilyRequestStatus.waiting => DiagnosticPhase.calling,
      FamilyRequestStatus.ringing || FamilyRequestStatus.received => DiagnosticPhase.ringing,
      FamilyRequestStatus.connecting => DiagnosticPhase.contacting,
      FamilyRequestStatus.active => DiagnosticPhase.firstFrame,
      _ => null,
    };
    if (phase != null) store.advance(_familyDiagnostic!, phase);
  }

  Future<void> _takeCallAction() async {
    if (_disposed || !_foreground || _handlingCallAction) return;
    _handlingCallAction = true;
    try {
      final action = await _callAlerts.takeAction();
      if (action == null) return;
      final remote = action['source'] == 'push';
      if (remote && (_role != AssistRole.helper ||
          !await _family.resolvePush(action['pairId'], action['requestId']))) return;
      await _family.poll();
      final request = _family.pendingRequest;
      if (_disposed || !_foreground || request == null || !_family.pendingIncoming ||
          request.requestId != action['requestId'] || !request.expiresAt.isAfter(DateTime.now()) ||
          _family.requestStatus != FamilyRequestStatus.received) return;
      if (!remote && action['action'] == 'accept') await acceptFamilyRequest();
      if (!remote && action['action'] == 'decline') await declineFamilyRequest();
    } catch (_) {
      // A stale push or unavailable server never authorizes a remote session.
    } finally { _handlingCallAction = false; }
  }

  Future<void> _syncPush() async {
    if (!_disposed && _foreground) await _pushRegistration.sync(helper: _role == AssistRole.helper);
  }

  @override
  Future<void> enableCallNotifications() async {
    await _callAlerts.requestPermission();
    await _syncPush();
    if (_disposed || !_foreground) return;
    final message = familyPushStatusMessage(_pushRegistration.status);
    await showDialog<void>(context: contextProvider(), builder: (context) => AlertDialog(
      title: Text('来电提醒'), content: Text(message), actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('知道了')),
      ]));
  }

  bool get _sharingReady => !helperOnly && !_disposed && !_stoppingSharing &&
      !_preparingSharing && gFFI.serverModel.isStart &&
      gFFI.serverModel.inputOk && gFFI.serverModel.mediaOk;

  bool get _helperIdle => !_disposed && _role == AssistRole.helper &&
      !_connecting && !_invitationBlocked && _invitation == null;

  bool get _invitationBlocked => !_foreground || _connecting || _stoppingSharing ||
      !stateGlobal.isInMainPage || (!helperOnly &&
        (gFFI.serverModel.isStart || gFFI.serverModel.isStarting || _preparingSharing));

  @override
  AssistState get state {
    if (helperOnly) {
      return AssistState(role: AssistRole.helper, lastPeerId: _lastPeer, error: _error,
        familyMembers: _family.members, pendingFamilyRequest: _family.pendingRequest,
        familyRequestStatus: _family.requestStatus, familyRequestError: _family.requestError,
        fullInterface: _fullInterface && _invitation == null,
        invitationCode: _invitation?.deviceId, invitationBlocked: _invitationBlocked);
    }
    final model = gFFI.serverModel;
    final id = normalizeDeviceId(model.serverId.text);
    return AssistState(
      role: _role, deviceId: RegExp(r'^\d+$').hasMatch(id) ? id : '',
      lastPeerId: _lastPeer, online: model.connectStatus > 0,
      inputReady: model.inputOk, sharing: model.isStart, captureReady: model.mediaOk,
      preparing: _preparingSharing || model.isStarting,
      connections: model.clients.where((c) => c.authorized && !c.disconnected).length,
      error: _error,
      familyMembers: _family.members, pendingFamilyRequest: _family.pendingRequest,
      familyRequestStatus: _family.requestStatus, familyRequestError: _family.requestError,
      fullInterface: _role == AssistRole.helper && _fullInterface && _invitation == null,
      invitationCode: _invitation?.deviceId, invitationBlocked: _invitationBlocked,
    );
  }

  void _changed() {
    if (!_disposed) {
      FamilyBridge.syncIncoming(gFFI.serverModel);
      if (!_sharingReady && !_family.pendingIncoming && _family.pendingRequest != null) {
        unawaited(_family.cancelOutgoing());
      }
      _applyInvitation(notify: false);
      notifyListeners();
    }
  }

  void _applyInvitation({bool notify = true}) {
    if (_disposed) return;
    final invitation = qinbanInvitationInbox.current;
    _invitation = invitation;
    if (invitation == null) _appliedInvitation = null;
    if (invitation != null) {
      if (_invitationRevision != qinbanInvitationInbox.revision) {
        _invitationRevision = qinbanInvitationInbox.revision;
        _appliedInvitation = null;
        resetInvitationPrompt(invitation.deviceId);
      }
      final ownId = normalizeDeviceId(gFFI.serverModel.serverId.text);
      if (invitation.deviceId == ownId) {
        if (qinbanInvitationInbox.source != InvitationSource.clipboard) {
          _error = '这条邀请来自这台手机，把它发给家人就好。';
        }
        qinbanInvitationInbox.dismiss();
        return;
      }
      if (!_invitationBlocked && _appliedInvitation != invitation.deviceId) {
        _appliedInvitation = invitation.deviceId;
        _role = AssistRole.helper;
        _lastPeer = invitation.deviceId;
        _error = null;
        unawaited(bind.mainSetLocalOption(key: 'qinban-role', value: 'helper'));
        unawaited(bind.mainSetLocalOption(key: 'qinban-last-peer', value: _lastPeer));
      }
    }
    if (notify) notifyListeners();
  }

  Future<void> _readClipboard({bool explicit = false}) async {
    if (_disposed || _readingClipboard) return;
    if (!explicit && qinbanInvitationInbox.current != null &&
        qinbanInvitationInbox.source == InvitationSource.link) return;
    _readingClipboard = true;
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      if (_disposed || !_foreground) return;
      final offered = qinbanInvitationInbox.offerClipboard(data?.text ?? '', explicit: explicit);
      if (explicit && !offered) {
        _error = '没有找到帮帮邀请。复制整条邀请或“BB1-”开头的配对口令，再点粘贴邀请。';
        _changed();
      }
    } on PlatformException {
      if (explicit) {
        _error = '暂时无法读取剪贴板，复制邀请后再试一次。';
        _changed();
      }
    } finally {
      _readingClipboard = false;
    }
  }

  Future<void> _poll() async {
    if (_polling || _disposed) return;
    _polling = true;
    try {
      await gFFI.serverModel.fetchID();
      if (!helperOnly) await gFFI.invokeMethod('check_service');
      if (!helperOnly) FamilyBridge.syncIncoming(gFFI.serverModel);
      _family.expire();
      _applyInvitation();
    } catch (_) {
      _error = '暂时无法获取设备状态，请重新打开应用后重试。';
      _changed();
    } finally { _polling = false; }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (state == AppLifecycleState.resumed) {
      _family.setForeground(true);
      DiagnosticsBridge.service?.setUploadActive(true);
      unawaited(_takeCallAction());
      unawaited(_syncPush());
      unawaited(DiagnosticsBridge.service?.flush());
      _poll();
      _readClipboard();
    } else if (state == AppLifecycleState.inactive) {
      // The notification shade or a system permission sheet can make the app
      // inactive without putting it in the background. Keep call cancellation
      // delivery alive while the user is interacting with the notification.
      _family.setForeground(true);
    } else {
      _family.setForeground(false);
      DiagnosticsBridge.service?.setUploadActive(false);
    }
    _applyInvitation();
  }

  @override
  Future<void> selectRole(AssistRole? role) async {
    if (helperOnly) return;
    if (gFFI.serverModel.isStart || gFFI.serverModel.isStarting || _preparingSharing || _stoppingSharing) return;
    final selected = role ?? AssistRole.elder;
    await bind.mainSetLocalOption(key: 'qinban-role', value: selected.name);
    _role = selected;
    unawaited(_syncPush());
    _error = null;
    _changed();
  }

  @override
  Future<void> setFullInterface(bool enabled) async {
    if (_role != AssistRole.helper || (enabled && _invitationBlocked)) return;
    await bind.mainSetLocalOption(key: 'qinban-helper-interface', value: enabled ? 'full' : 'simple');
    _fullInterface = enabled;
    _changed();
  }

  @override
  Future<void> enableInput() async {
    if (helperOnly) return;
    if (!gFFI.serverModel.inputOk) await gFFI.serverModel.toggleInput();
  }

  @override
  Future<void> startSharing() async {
    if (helperOnly) return;
    if (_preparingSharing || _stoppingSharing) return;
    if (!gFFI.serverModel.inputOk) {
      _error = '请先开启“帮帮远程操作”权限，再开始协助。';
      _changed();
      return;
    }
    _error = null;
    final generation = ++_sharingGeneration;
    final diagnostic = DiagnosticsBridge.service?.begin(kind: 'preparation', role: 'elder');
    _preparingSharing = true;
    _changed();
    try {
      if (!gFFI.serverModel.isStart) {
        // Revocation covers settings/notification waits as well as screen consent.
        await gFFI.serverModel.setApproveMode('click');
        if (generation != _sharingGeneration) return;
        await gFFI.serverModel.setVerificationMethod(kUseTemporaryPassword);
        if (generation != _sharingGeneration) return;
        await gFFI.serverModel.updatePasswordModel();
        if (generation != _sharingGeneration) return;
        await gFFI.serverModel.checkRequestNotificationPermission();
        if (generation != _sharingGeneration) return;
        await gFFI.serverModel.startService();
      }
      if (generation != _sharingGeneration) return;
      final model = gFFI.serverModel;
      if (!model.isStart || !model.mediaOk) {
        _error = '还没开启屏幕共享，邀请没有发出。再点一次“邀请家人”即可重试。';
        return;
      }
      final readiness = SharingReadiness(changes: model,
        isActive: () => !_disposed && generation == _sharingGeneration &&
          !_stoppingSharing && model.isStart && model.mediaOk && model.inputOk,
        isOnline: () => model.connectStatus > 0);
      _sharingReadiness = readiness;
      final result = await readiness.result;
      if (identical(_sharingReadiness, readiness)) _sharingReadiness = null;
      if (generation != _sharingGeneration) return;
      if (result == SharingReadinessResult.timedOut) {
        if (diagnostic != null) {
          DiagnosticsBridge.service?.finish(diagnostic,
            DiagnosticOutcome.failure, error: DiagnosticError.timeout);
        }
        await model.stopService();
        if (generation == _sharingGeneration) {
          _error = '暂时连不上连接服务，邀请没有发出。检查网络后，再点“邀请家人”重试。';
        }
      } else if (result == SharingReadinessResult.ready && diagnostic != null) {
        DiagnosticsBridge.service?.advance(diagnostic, DiagnosticPhase.serviceReady);
      }
    } catch (_) {
      if (generation != _sharingGeneration) return;
      if (diagnostic != null) {
        DiagnosticsBridge.service?.finish(diagnostic,
          DiagnosticOutcome.failure, error: DiagnosticError.capture);
      }
      await gFFI.serverModel.stopService();
      _error = '屏幕共享未能开启，请回到应用重试。';
      _changed();
      rethrow;
    } finally {
      if (diagnostic != null) {
        DiagnosticsBridge.service?.finish(diagnostic, DiagnosticOutcome.cancelled);
      }
      if (generation == _sharingGeneration) {
        _preparingSharing = false;
        _changed();
      }
    }
  }

  @override
  Future<void> stopSharing() async {
    if (helperOnly) return;
    // No extra confirmation: revocation should be immediate.
    ++_sharingGeneration;
    _sharingReadiness?.cancel();
    _sharingReadiness = null;
    _preparingSharing = false;
    _stoppingSharing = true;
    unawaited(_family.requestStatus == FamilyRequestStatus.active
        ? _family.endCall() : _family.cancelOutgoing());
    _changed();
    try {
      await gFFI.serverModel.stopService();
      _error = null;
      await _poll();
    } finally {
      _stoppingSharing = false;
      _changed();
    }
  }

  @override
  Future<void> connectTo(String id) async {
    if (_connecting || _invitationBlocked) {
      _error = '先结束当前协助，再连接这个邀请。';
      _changed();
      return;
    }
    final error = validatePeerId(id, state.deviceId);
    if (error != null) { _error = error; _changed(); return; }
    _connecting = true;
    _changed();
    try {
      _lastPeer = id;
      await bind.mainSetLocalOption(key: 'qinban-last-peer', value: id);
      if (_disposed || !_foreground) return;
      final context = contextProvider();
      if (!context.mounted) return;
      if (_invitation?.deviceId == id) qinbanInvitationInbox.dismiss();
      await connect(context, id);
    } finally {
      _connecting = false;
      _changed();
    }
  }

  QinbanInvitation? _localInvitation() {
    if (!_sharingReady || gFFI.serverModel.connectStatus <= 0) {
      _error = '手机还没准备好，点“邀请家人”完成屏幕共享后再发送。';
      _changed();
      return null;
    }
    final id = normalizeDeviceId(gFFI.serverModel.serverId.text);
    if (RegExp(r'^\d{6,16}$').hasMatch(id)) return QinbanInvitation(id);
    _error = '设备号码还在准备，稍后再分享邀请。';
    _changed();
    return null;
  }

  @override
  Future<void> shareInvitation() async {
    if (helperOnly) return;
    final invitation = _localInvitation();
    if (invitation == null) return;
    final shared = await shareInvitationText(invitation.message);
    _error = shared ? null : '整条邀请已复制。打开微信或聊天，粘贴发给家人。';
    _changed();
  }

  @override
  Future<void> copyInvitation() async {
    if (helperOnly) return;
    final invitation = _localInvitation();
    if (invitation == null) return;
    await Clipboard.setData(ClipboardData(text: invitation.message));
    _error = '整条邀请已复制，发给家人后，让家人复制消息并打开帮帮。';
    _changed();
  }

  @override
  Future<void> shareInstall() async {
    if (helperOnly) return;
    final shared = await shareInvitationText('我在用帮帮，离得远也能帮忙弄手机。点这里下载安装：\n'
      '$qinbanWebsite\n\niPhone版目前未开放公开下载。');
    _error = shared ? null : '安装链接已复制，打开微信或聊天发给家人。';
    _changed();
  }

  @override
  Future<void> pasteInvitation() => _readClipboard(explicit: true);

  @override
  Future<void> requestFamilyHelp(String peerId) async {
    if (_role != AssistRole.elder || helperOnly) return;
    await _family.requestHelp(peerId,
      () => _sharingReady && gFFI.serverModel.connectStatus > 0);
  }

  @override
  Future<void> acceptFamilyRequest() async {
    final peerId = await _family.accept(() => _helperIdle);
    if (peerId == null || !_helperIdle) return;
    try { await connectTo(peerId); } catch (_) {
      await _family.endCall(reason: 'failed');
      rethrow;
    }
  }

  @override
  Future<void> declineFamilyRequest() => _family.decline();

  @override
  Future<void> cancelFamilyRequest() => stopSharing();

  @override
  Future<void> renameFamilyMember(String peerId, String name) => _family.rename(peerId, name);

  @override
  Future<void> forgetFamilyMember(String peerId) => _family.forget(peerId);

  @override
  void dismissInvitation() {
    qinbanInvitationInbox.dismiss();
  }

  @override
  void openSettings() {
    final context = contextProvider();
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => Scaffold(
      appBar: AppBar(title: const Text('连接与高级设置')),
      body: SettingsPage(),
    )));
  }

  @override
  Future<void> openPrivacyPolicy() async {
    if (!await launchUrl(Uri.parse(qinbanPrivacyUrl),
        mode: LaunchMode.externalApplication)) {
      throw StateError('Unable to open privacy policy');
    }
  }

  @override
  void openDiagnostics() {
    final diagnostics = DiagnosticsBridge.service;
    if (diagnostics == null) {
      _error = '诊断暂时不可用，请重新打开应用后重试。';
      _changed();
      return;
    }
    Navigator.of(contextProvider()).push(MaterialPageRoute<void>(
      builder: (_) => DiagnosticsPage(diagnostics: diagnostics,
        performance: DiagnosticsBridge.performance)));
  }

  @override
  void openSource() {
    final context = contextProvider();
    showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('帮帮 · 开源说明'),
      content: const Text('帮帮基于 RustDesk 1.4.9，是采用 GNU AGPL v3 许可的独立衍生项目。\n\n完整源码位于 GitHub 仓库，私有仓库需登录有权限的账户。'),
      actions: [
        TextButton(onPressed: () {
          Navigator.pop(dialogContext);
          showLicensePage(context: context, applicationName: '帮帮',
            applicationVersion: DiagnosticsBridge.service?.appVersion);
        }, child: const Text('查看许可证')),
        TextButton(onPressed: () async {
          final opened = await launchUrl(Uri.parse('https://github.com/JackLee992/bangbang-android'),
            mode: LaunchMode.externalApplication);
          if (!opened && dialogContext.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('无法打开浏览器，请访问 github.com/JackLee992/bangbang-android')));
          }
        }, child: const Text('打开源码')),
      ],
    ));
  }

  @override
  void dispose() {
    _disposed = true;
    ++_sharingGeneration;
    _sharingReadiness?.cancel();
    _sharingReadiness = null;
    _timer?.cancel();
    _familyTimer?.cancel();
    _pushTimer?.cancel();
    _pushRegistration.dispose();
    _family.removeListener(_familyChanged);
    _household.dispose();
    _callAlerts.dispose();
    _family.onRemoteEnd = null;
    FamilyCallAlerts.channel.setMethodCallHandler(null);
    _family.setForeground(false);
    _inviteSubscription?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    if (!helperOnly) {
      gFFI.serverModel.removeListener(_changed);
    }
    super.dispose();
  }
}

Future<void> initializeQinban({
  RemoteServerConfigurationManager? remoteConfiguration,
}) async {
  final profileResult = await (remoteConfiguration ??
          RemoteServerConfigurationManager(
            readOptions: () => bind.mainGetOptionsSync(),
            writeOptions: (options) => bind.mainSetOptions(json: options),
            readLocalOption: (key) => bind.mainGetLocalOption(key: key),
            writeLocalOption: (key, value) =>
                bind.mainSetLocalOption(key: key, value: value),
            restartRegistration: (server) => bind.mainSetOption(
                key: 'custom-rendezvous-server', value: server),
          ))
      .apply();
  if (profileResult != RemoteServerConfigurationResult.disabled) {
    debugPrint('Remote server profile: ${profileResult.name}');
  }
  await DiagnosticsBridge.initialize();
  FamilyBridge.initialize();
  LicenseRegistry.addLicense(() async* {
    yield LicenseEntryWithLineBreaks(['帮帮 / RustDesk'],
      await rootBundle.loadString('assets/qinban_agpl.txt'));
  });
  // Configure once; later explicit advanced-setting choices remain user-owned.
  if (bind.mainGetLocalOption(key: 'qinban-initialized') == '1') return;
  await bind.mainSetLocalOption(key: kCommConfKeyLang, value: 'zh-cn');
  for (final key in [kOptionEnableFileTransfer, kOptionEnableAudio,
    kOptionEnableClipboard, kOptionEnableCamera, kOptionEnableTerminal, kOptionEnableTunnel]) {
    await bind.mainSetOption(key: key, value: 'N');
  }
  await bind.mainSetOption(key: kOptionApproveMode, value: 'click');
  // Floating windows remain optional; notifications and the home screen expose Stop.
  await bind.mainSetLocalOption(key: kOptionDisableFloatingWindow, value: 'Y');
  await bind.mainSetLocalOption(key: 'qinban-initialized', value: '1');
}
