import 'dart:convert';
import 'family_store.dart';

/// Production builds use the verified remote-control service by default. An
/// explicit empty define disables management for controlled fixtures. Family
/// and diagnostics endpoints are independent of this engine configuration.
const qinbanRemoteBuildProfile = String.fromEnvironment('QINBAN_REMOTE_PROFILE',
    defaultValue: aliyunEcsRemoteProfileId);
const qinbanRemoteManagedKey = 'qinban-remote-profile-v1';
const qinbanRemoteRecoveryKey = 'qinban-remote-profile-recovery-v1';
const aliyunEcsRemoteProfileId = 'aliyun-ecs-v1';
const aliyunEcsRemoteOptions = <String, String>{
  'custom-rendezvous-server': '123.57.57.202:21116',
  'relay-server': '123.57.57.202:21117',
  'api-server': '',
  'key': 'lMADRklrhk4PQsqe1sy1VCqF6amA0WS6GImbUKnmbTo=',
};
const _remoteKeys = [
  'custom-rendezvous-server',
  'relay-server',
  'api-server',
  'key'
];

enum RemoteServerConfigurationResult {
  disabled,
  applied,
  alreadyApplied,
  preservedUserConfiguration,
  preservedFamilyHistory,
  restored,
}

class RemoteServerConfigurationException implements Exception {
  const RemoteServerConfigurationException(this.code);
  final String code;
  @override
  String toString() => 'RemoteServerConfigurationException: $code';
}

class RemoteServerConfigurationManager {
  RemoteServerConfigurationManager({
    this.configuredProfile = qinbanRemoteBuildProfile,
    required this.readOptions,
    required this.writeOptions,
    required this.readLocalOption,
    required this.writeLocalOption,
    required this.restartRegistration,
  });

  final String configuredProfile;
  final String Function() readOptions;
  final Future<void> Function(String) writeOptions;
  final String Function(String) readLocalOption;
  final Future<void> Function(String, String) writeLocalOption;
  final Future<void> Function(String) restartRegistration;
  Future<RemoteServerConfigurationResult>? _pending;

  Future<RemoteServerConfigurationResult> apply() =>
      _pending ??= _apply().whenComplete(() => _pending = null);

  Future<RemoteServerConfigurationResult> _apply() async {
    // Explicitly disabled fixtures must not inspect a managed recovery journal.
    if (configuredProfile.isEmpty) {
      return RemoteServerConfigurationResult.disabled;
    }
    if (configuredProfile != aliyunEcsRemoteProfileId &&
        configuredProfile != 'restore-managed') {
      throw const RemoteServerConfigurationException('profile_not_trusted');
    }
    try {
      final pending = readLocalOption(qinbanRemoteRecoveryKey);
      if (pending.isNotEmpty) {
        final recovery = _Recovery.decode(pending);
        await _rollback(recovery);
        // Recovery never silently continues into family registration on a
        // different server, or reapplies the failed profile in the same startup.
        throw const RemoteServerConfigurationException(
            'profile_transaction_recovered');
      }
      final options = _readOptions();
      final before = _tuple(options);
      final marker = readLocalOption(qinbanRemoteManagedKey);
      final managed = _ManagedProfile.tryDecode(marker);
      if ((marker.isNotEmpty && managed == null) ||
          (managed != null && !_sameTuple(before, managed.applied)) ||
          options['allow-websocket'] == 'Y' ||
          options['disable-udp'] == 'Y') {
        return RemoteServerConfigurationResult.preservedUserConfiguration;
      }
      final restoring = configuredProfile == 'restore-managed';
      if ((restoring && managed == null) ||
          (managed == null && before.values.any((value) => value.isNotEmpty))) {
        return RemoteServerConfigurationResult.preservedUserConfiguration;
      }
      if (!restoring &&
          managed?.profile == configuredProfile &&
          _sameTuple(before, aliyunEcsRemoteOptions)) {
        return RemoteServerConfigurationResult.alreadyApplied;
      }
      final after = restoring ? managed!.original : aliyunEcsRemoteOptions;
      if (_familyHistoryBlocks(after)) {
        return RemoteServerConfigurationResult.preservedFamilyHistory;
      }
      final nextMarker = restoring
          ? ''
          : _ManagedProfile(
                  configuredProfile, after, managed?.original ?? before)
              .encode();
      await _change(_Recovery(before, after, marker, nextMarker));
      return restoring
          ? RemoteServerConfigurationResult.restored
          : RemoteServerConfigurationResult.applied;
    } on RemoteServerConfigurationException {
      rethrow;
    } catch (_) {
      throw const RemoteServerConfigurationException(
          'profile_configuration_unreadable');
    }
  }

  Map<String, String> _readOptions() =>
      Map<String, String>.from(jsonDecode(readOptions()) as Map);

  bool _familyHistoryBlocks(Map<String, String> after) {
    final raw = readLocalOption('qinban-family-v1');
    if (raw.isEmpty) return false;
    try {
      if (raw.length > 65536) return true;
      final data = jsonDecode(raw);
      if (data is! Map ||
          data['v'] != 1 ||
          data['members'] is! List ||
          data['householdRecovery'] != null) {
        return true;
      }
      final scope =
          familyServerScope(after['custom-rendezvous-server']!, after['key']!);
      for (final entry in data['members'] as List) {
        if (entry is! Map ||
            !validFamilyScope(entry['serverScope']) ||
            entry['serverScope'] != scope) {
          return true;
        }
      }
      return false;
    } catch (_) {
      // An unreadable archive is never evidence of a fresh installation.
      return true;
    }
  }

  Future<void> _writeLocalVerified(String key, String value) async {
    await writeLocalOption(key, value);
    if (readLocalOption(key) != value) {
      throw const RemoteServerConfigurationException(
          'profile_write_unverified');
    }
  }

  Future<void> _writeTuple(Map<String, String> target) async {
    final options = _readOptions()..addAll(target);
    // Keep the four empty keys when restoring public settings: the existing
    // native bulk setter ignores an entirely empty map. Unrelated options stay.
    await writeOptions(jsonEncode(options));
    if (!_sameTuple(_tuple(_readOptions()), target)) {
      throw const RemoteServerConfigurationException(
          'profile_write_unverified');
    }
  }

  Future<void> _change(_Recovery recovery) async {
    var journalVerified = false;
    try {
      await _writeLocalVerified(qinbanRemoteRecoveryKey, recovery.encode());
      journalVerified = true;
      if (!_sameTuple(_tuple(_readOptions()), recovery.before) ||
          readLocalOption(qinbanRemoteManagedKey) != recovery.beforeManaged) {
        throw const RemoteServerConfigurationException(
            'profile_recovery_conflict');
      }
      // One native bulk replacement prevents a server being paired with a key
      // or relay from another profile. The native API does not report disk errors.
      await _writeTuple(recovery.after);
      await _writeLocalVerified(qinbanRemoteManagedKey, recovery.afterManaged);
      await restartRegistration(recovery.after['custom-rendezvous-server']!);
      if (!_sameTuple(_tuple(_readOptions()), recovery.after)) {
        throw const RemoteServerConfigurationException(
            'profile_write_unverified');
      }
      await _writeLocalVerified(qinbanRemoteRecoveryKey, '');
    } catch (_) {
      if (journalVerified) await _rollback(recovery);
      // A verified rollback still stops this startup before family/diagnostics.
      throw const RemoteServerConfigurationException('profile_apply_failed');
    }
  }

  Future<void> _rollback(_Recovery recovery) async {
    final current = _tuple(_readOptions());
    final marker = readLocalOption(qinbanRemoteManagedKey);
    if (!_remoteKeys.every((key) =>
            current[key] == recovery.before[key] ||
            current[key] == recovery.after[key]) ||
        (marker != recovery.beforeManaged && marker != recovery.afterManaged)) {
      // A later user choice wins over an interrupted app transaction.
      throw const RemoteServerConfigurationException(
          'profile_recovery_conflict');
    }
    try {
      await _writeTuple(recovery.before);
      await _writeLocalVerified(qinbanRemoteManagedKey, recovery.beforeManaged);
      await restartRegistration(recovery.before['custom-rendezvous-server']!);
      if (!_sameTuple(_tuple(_readOptions()), recovery.before)) {
        throw const RemoteServerConfigurationException(
            'profile_write_unverified');
      }
      await _writeLocalVerified(qinbanRemoteRecoveryKey, '');
    } catch (_) {
      // Keep the journal for a separately verified recovery on the next enabled
      // startup. No fallback family registration follows an uncertain tuple.
      throw const RemoteServerConfigurationException('profile_recovery_failed');
    }
  }
}

Map<String, String> _tuple(Map<String, String> options) => {
      for (final key in _remoteKeys) key: options[key] ?? '',
    };

bool _sameTuple(Map<String, String> a, Map<String, String> b) =>
    _remoteKeys.every((key) => a[key] == b[key]);

Map<String, String> _recordTuple(Object? value) {
  if (value is! Map ||
      value.length != _remoteKeys.length ||
      !_remoteKeys.every((key) =>
          value[key] is String && (value[key] as String).length <= 4096)) {
    throw const FormatException('Invalid remote profile record');
  }
  return Map<String, String>.from(value);
}

class _ManagedProfile {
  const _ManagedProfile(this.profile, this.applied, this.original);
  final String profile;
  final Map<String, String> applied;
  final Map<String, String> original;

  String encode() => jsonEncode({
        'v': 1,
        'profile': profile,
        'applied': applied,
        'original': original,
      });

  static _ManagedProfile? tryDecode(String raw) {
    try {
      if (raw.isEmpty || raw.length > 32768) return null;
      final data = jsonDecode(raw);
      if (data is! Map ||
          data.length != 4 ||
          data['v'] != 1 ||
          data['profile'] is! String ||
          !RegExp(r'^[a-z0-9][a-z0-9-]{0,63}$').hasMatch(data['profile'])) {
        return null;
      }
      return _ManagedProfile(data['profile'], _recordTuple(data['applied']),
          _recordTuple(data['original']));
    } catch (_) {
      return null;
    }
  }
}

class _Recovery {
  const _Recovery(
      this.before, this.after, this.beforeManaged, this.afterManaged);
  final Map<String, String> before;
  final Map<String, String> after;
  final String beforeManaged;
  final String afterManaged;

  String encode() => jsonEncode({
        'v': 1,
        'before': before,
        'after': after,
        'beforeManaged': beforeManaged,
        'afterManaged': afterManaged,
      });

  static _Recovery decode(String raw) {
    try {
      if (raw.length > 131072) throw const FormatException('Too large');
      final data = jsonDecode(raw);
      if (data is! Map ||
          data.length != 5 ||
          data['v'] != 1 ||
          data['beforeManaged'] is! String ||
          data['afterManaged'] is! String) {
        throw const FormatException('Invalid recovery record');
      }
      final before = _recordTuple(data['before']);
      final after = _recordTuple(data['after']);
      for (final entry in [
        MapEntry(data['beforeManaged'] as String, before),
        MapEntry(data['afterManaged'] as String, after),
      ]) {
        if (entry.key.isEmpty) continue;
        final managed = _ManagedProfile.tryDecode(entry.key);
        if (managed == null || !_sameTuple(managed.applied, entry.value)) {
          throw const FormatException('Invalid recovery ownership');
        }
      }
      return _Recovery(
          before, after, data['beforeManaged'], data['afterManaged']);
    } catch (_) {
      throw const RemoteServerConfigurationException('profile_recovery_failed');
    }
  }
}
