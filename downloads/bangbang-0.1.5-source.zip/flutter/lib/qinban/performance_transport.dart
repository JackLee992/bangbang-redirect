import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'family_store.dart';
import 'performance_report.dart';
import 'service_configuration.dart';

Uri? performanceServiceEndpoint(String configured) {
  final expected = Uri.parse('$qinbanServiceOrigin/v1/performance');
  return configured.isEmpty || configured == expected.toString()
      ? expected
      : null;
}

class AuthenticatedPerformanceTransport {
  AuthenticatedPerformanceTransport(
      {required this.authorize,
      required this.allowed,
      String configuredEndpoint = '',
      http.Client Function()? clientFactory})
      : endpoint = performanceServiceEndpoint(configuredEndpoint),
        _clientFactory = clientFactory ?? http.Client.new;
  final Future<FamilyIdentity?> Function() authorize;
  final bool Function() allowed;
  final Uri? endpoint;
  final http.Client Function() _clientFactory;
  http.Client? _active;
  bool _busy = false;
  int _generation = 0;
  void cancel() {
    ++_generation;
    _active?.close();
    _active = null;
  }

  Future<bool> upload(Map<String, dynamic> value) async {
    final record = parsePerformanceReport(value);
    if (endpoint == null || record == null || !allowed() || _busy) return false;
    _busy = true;
    final generation = _generation;
    http.Client? client;
    try {
      return await (() async {
        final identity = await authorize();
        if (generation != _generation ||
            !allowed() ||
            identity == null ||
            !validFamilyToken(identity.installationId, 16) ||
            !validFamilyToken(identity.authSecret, 32)) return false;
        client = _clientFactory();
        _active = client;
        final request = http.Request('POST', endpoint!)
          ..followRedirects = false
          ..headers.addAll({
            'Content-Type': 'application/json',
            'Authorization':
                'Bearer ${identity.installationId}.${identity.authSecret}'
          })
          ..body = jsonEncode(record);
        final response = await client!.send(request);
        if (![200, 202].contains(response.statusCode) ||
            (response.contentLength ?? 0) > 4096) return false;
        final bytes = <int>[];
        await for (final chunk in response.stream) {
          if (bytes.length + chunk.length > 4096 ||
              generation != _generation ||
              !allowed()) return false;
          bytes.addAll(chunk);
        }
        final result = jsonDecode(utf8.decode(bytes));
        return generation == _generation &&
            allowed() &&
            result is Map &&
            result['v'] == 1 &&
            result['ok'] == true;
      })()
          .timeout(const Duration(seconds: 4));
    } catch (_) {
      return false;
    } finally {
      if (_generation == generation) ++_generation;
      client?.close();
      if (identical(_active, client)) _active = null;
      _busy = false;
    }
  }
}
