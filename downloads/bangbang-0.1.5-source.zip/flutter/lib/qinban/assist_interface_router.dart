import 'package:flutter/material.dart';
import 'assist_home.dart';
import 'assist_model.dart';
import 'qinban_theme.dart';

/// Both interfaces share a controller, so switching never starts a service.
class AssistInterfaceRouter extends StatelessWidget {
  const AssistInterfaceRouter({super.key, required this.controller,
    required this.fullInterfaceBuilder});

  final AssistController controller;
  final Widget Function(BuildContext, VoidCallback) fullInterfaceBuilder;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) {
      final state = controller.state;
      final familyRequestReady = state.pendingFamilyRequest != null &&
          state.pendingFamilyRequest!.expiresAt.isAfter(DateTime.now()) &&
          !state.sharing && !state.preparing && !state.invitationBlocked;
      if (state.role != AssistRole.helper || !state.fullInterface || state.invitationCode != null || familyRequestReady) {
        return AssistHome(controller: controller);
      }
      return Theme(data: qinbanTheme(Theme.of(context).brightness),
        child: Builder(builder: (context) => fullInterfaceBuilder(context,
          () => controller.setFullInterface(false))));
    },
  );
}
