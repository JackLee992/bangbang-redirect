import 'dart:convert';
import 'family_store.dart';

const performanceMaxBodyBytes = 16384;
const performanceRetention = Duration(days: 7);
const performanceWindowFields = <String>[
  'v',
  'windowStartMs',
  'durationMs',
  'nativeDecodeFps',
  'nativeSamples',
  'uiImageDeliveryFps',
  'deliveredFrames',
  'rgbaDeliveryMeanMs',
  'rgbaDeliveryMaxMs',
  'rgbaDeliveryP95Ms',
  'latencySamples',
  'codec',
  'networkDelayMs',
  'targetBitrateKbps',
  'receiveBytesPerSecond',
  'width',
  'height'
];
const _reportFields = <String>[
  'v',
  'attemptId',
  'platform',
  'appVersion',
  'build',
  'startedAt',
  'durationMs',
  'path',
  'windows'
];
bool _integer(dynamic value, int maximum, [int minimum = 0]) =>
    value is int && value >= minimum && value <= maximum;
bool _number(dynamic value, double maximum) =>
    value == null ||
    value is num && value.isFinite && value >= 0 && value <= maximum;
bool _keys(dynamic value, List<String> fields) =>
    value is Map &&
    value.length == fields.length &&
    fields.every(value.containsKey);

Map<String, dynamic>? parsePerformanceWindow(dynamic value) {
  if (!_keys(value, performanceWindowFields) ||
      value['v'] != 1 ||
      !_integer(value['windowStartMs'], 86400000) ||
      !_integer(value['durationMs'], 5000) ||
      !_number(value['nativeDecodeFps'], 240) ||
      !_integer(value['nativeSamples'], 1000000) ||
      !_number(value['uiImageDeliveryFps'], 1000000000) ||
      !_integer(value['deliveredFrames'], 1000000) ||
      !_integer(value['latencySamples'], 128) ||
      !_number(value['networkDelayMs'], 60000) ||
      !_number(value['targetBitrateKbps'], 1000000) ||
      !_number(value['receiveBytesPerSecond'], 125000000) ||
      !(value['codec'] == null ||
          const ['vp8', 'vp9', 'av1', 'h264', 'h265']
              .contains(value['codec'])) ||
      ['rgbaDeliveryMeanMs', 'rgbaDeliveryMaxMs', 'rgbaDeliveryP95Ms']
          .any((field) => !_number(value[field], 10000))) return null;
  final width = value['width'], height = value['height'];
  if (!(width == null && height == null ||
      _integer(width, 16384, 1) && _integer(height, 16384, 1))) return null;
  final frames = value['deliveredFrames'] as int;
  if ((value['nativeSamples'] == 0) != (value['nativeDecodeFps'] == null) ||
      value['latencySamples'] > frames) return null;
  final rgba = ['rgbaDeliveryMeanMs', 'rgbaDeliveryMaxMs', 'rgbaDeliveryP95Ms'];
  if (frames == 0) {
    if (rgba.any((field) => value[field] != null) ||
        value['latencySamples'] != 0) return null;
  } else if (rgba.any((field) => value[field] == null) ||
      value['latencySamples'] < 1 ||
      value['rgbaDeliveryMeanMs'] > value['rgbaDeliveryMaxMs'] ||
      value['rgbaDeliveryP95Ms'] > value['rgbaDeliveryMaxMs']) {
    return null;
  }
  final duration = value['durationMs'] as int;
  final fps = value['uiImageDeliveryFps'];
  if (duration == 0) {
    if (fps != null) return null;
  } else {
    final expected = frames * 1000 / duration;
    if (fps is! num ||
        (fps - expected).abs() >
            (expected.abs() > 1 ? expected.abs() : 1) * 1e-9) return null;
  }
  return {for (final field in performanceWindowFields) field: value[field]};
}

/// Only the last <=12 measured event windows within the final 60 seconds.
/// These are not whole-call statistics, and quiet gaps are not invented.
Map<String, dynamic>? parsePerformanceReport(dynamic value, {DateTime? now}) {
  final timestamp = (now ?? DateTime.now()).millisecondsSinceEpoch;
  if (!_keys(value, _reportFields) ||
      value['v'] != 1 ||
      !validFamilyToken(value['attemptId'], 16) ||
      !const ['ios', 'android'].contains(value['platform']) ||
      value['appVersion'] is! String ||
      (value['appVersion'] as String).length > 40 ||
      !RegExp(r'^\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.]+)?$')
          .hasMatch(value['appVersion']) ||
      value['build'] is! String ||
      !RegExp(r'^\d{1,12}$').hasMatch(value['build']) ||
      !_integer(value['startedAt'], timestamp + 300000,
          timestamp - performanceRetention.inMilliseconds) ||
      !_integer(value['durationMs'], 86400000) ||
      !const ['direct', 'relay', 'unknown'].contains(value['path']) ||
      value['windows'] is! List ||
      value['windows'].isEmpty ||
      value['windows'].length > 12) return null;
  final windows = <Map<String, dynamic>>[];
  final duration = value['durationMs'] as int;
  final minimum = duration > 60000 ? duration - 60000 : 0;
  var previousStart = -1, previousEnd = 0;
  for (final item in value['windows']) {
    final window = parsePerformanceWindow(item);
    if (window == null) return null;
    final start = window['windowStartMs'] as int;
    final end = start + (window['durationMs'] as int);
    if (start < minimum ||
        start <= previousStart ||
        start < previousEnd ||
        end > duration) return null;
    previousStart = start;
    previousEnd = end;
    windows.add(window);
  }
  final result = {
    for (final field in _reportFields)
      field: field == 'windows' ? windows : value[field]
  };
  return utf8.encode(jsonEncode(result)).length <= performanceMaxBodyBytes
      ? result
      : null;
}
