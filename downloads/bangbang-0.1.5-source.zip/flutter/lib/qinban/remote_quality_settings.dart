/// Saved engine preferences, not measured FPS or a remote acknowledgement.
class RemoteQualitySettings {
  const RemoteQualitySettings(this.mode, {this.customQuality, this.customFps});
  final String mode;
  final int? customQuality;
  final int? customFps;
}

/// Presets may reset the native FPS limit. Restoring custom mode must send both
/// its quality and FPS explicitly; saving the mode string sends neither value.
class RemoteQualityAccess {
  const RemoteQualityAccess({
    required this.isCurrent,
    required this.readQuality,
    required this.readCustomQuality,
    required this.readCustomFps,
    required this.writeQuality,
    required this.writeCustomQuality,
    required this.writeCustomFps,
  });

  final bool Function() isCurrent;
  final Future<String?> Function() readQuality;
  final Future<List<int>?> Function() readCustomQuality;
  final Future<String?> Function() readCustomFps;
  final Future<void> Function(String) writeQuality;
  final Future<void> Function(int) writeCustomQuality;
  final Future<void> Function(int) writeCustomFps;

  Future<T> _current<T>(Future<T> Function() operation) async {
    if (!isCurrent()) throw StateError('Session closed');
    final value = await operation();
    if (!isCurrent()) throw StateError('Session closed');
    return value;
  }

  Future<String> mode() async {
    final value = await _current(readQuality);
    // A null native result means there is no session, not a default preference.
    if (value == null) throw StateError('Session unavailable');
    final mode = value.isEmpty ? 'balanced' : value;
    if (!const {'balanced', 'low', 'best', 'custom'}.contains(mode)) {
      throw const FormatException('Unknown image quality');
    }
    return mode;
  }

  Future<RemoteQualitySettings> capture() async {
    final current = await mode();
    if (current != 'custom') return RemoteQualitySettings(current);
    final quality = await _current(readCustomQuality);
    final fps = await _current(readCustomFps);
    if (quality == null || fps == null) throw StateError('Session unavailable');
    // Defaults and bounds match the existing custom-quality dialog.
    final customQuality = quality.isEmpty ? 50 : quality.first;
    final customFps = fps.isEmpty ? 30 : int.tryParse(fps);
    if (customQuality < 10 ||
        customQuality > 2000 ||
        customFps == null ||
        customFps < 5 ||
        customFps > 120) {
      throw const FormatException('Invalid custom image quality');
    }
    return RemoteQualitySettings(current,
        customQuality: customQuality, customFps: customFps);
  }

  Future<void> apply(RemoteQualitySettings settings) async {
    if (settings.mode == 'custom') {
      final quality = settings.customQuality;
      final fps = settings.customFps;
      if (quality == null ||
          quality < 10 ||
          quality > 2000 ||
          fps == null ||
          fps < 5 ||
          fps > 120) {
        throw const FormatException('Invalid custom image quality');
      }
      // save_image_quality("custom") does not generate an option message.
      await _current(() => writeCustomQuality(quality));
      await _current(() => writeCustomFps(fps));
    } else {
      if (!const {'balanced', 'low', 'best'}.contains(settings.mode)) {
        throw const FormatException('Unknown image quality');
      }
      await _current(() => writeQuality(settings.mode));
    }
    final actual = await capture();
    if (actual.mode != settings.mode ||
        (settings.mode == 'custom' &&
            (actual.customQuality != settings.customQuality ||
                actual.customFps != settings.customFps))) {
      throw StateError('Engine preference was not saved');
    }
  }
}
