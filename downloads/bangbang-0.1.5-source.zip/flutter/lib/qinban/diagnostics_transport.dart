import 'dart:convert';
import 'package:http/http.dart' as http;
import 'connection_diagnostics.dart';
import 'family_store.dart';
import 'service_configuration.dart';

/// Uploads only structured diagnostics after installation authorization. Failure
/// keeps the local queue; it never opens login or delays a remote-control session.
class AuthenticatedDiagnosticsTransport {
  AuthenticatedDiagnosticsTransport({
    required this.authorize,
    required this.allowed,
    String configuredEndpoint = '',
    http.Client Function()? clientFactory,
  })  : endpoint = diagnosticsServiceEndpoint(configuredEndpoint),
        _clientFactory = clientFactory ?? http.Client.new;

  final Future<FamilyIdentity?> Function() authorize;
  final bool Function() allowed;
  final Uri? endpoint;
  final http.Client Function() _clientFactory;

  Future<bool> upload(Map<String, dynamic> value) async {
    final record = parseDiagnosticRecord(value);
    if (endpoint == null || record == null || !allowed()) return false;
    final body = jsonEncode(record);
    if (utf8.encode(body).length > 2048) return false;
    http.Client? client;
    try {
      final identity = await authorize();
      if (identity == null ||
          !allowed() ||
          !validFamilyToken(identity.installationId, 16) ||
          !validFamilyToken(identity.authSecret, 32)) return false;
      client = _clientFactory();
      final request = http.Request('POST', endpoint!)
        ..followRedirects = false
        ..headers.addAll({
          'Content-Type': 'application/json',
          'Authorization':
              'Bearer ${identity.installationId}.${identity.authSecret}',
        })
        ..body = body;
      final response = await (() async {
        final streamed = await client!.send(request);
        return http.Response.fromStream(streamed);
      })()
          .timeout(const Duration(seconds: 4));
      if (![200, 202].contains(response.statusCode) ||
          response.bodyBytes.length > 4096) return false;
      final result = jsonDecode(response.body);
      return result is Map && result['ok'] == true && result['v'] == 1;
    } catch (_) {
      // Errors never contain owner credentials, clipboard data or HTTP bodies.
      return false;
    } finally {
      client?.close();
    }
  }
}
