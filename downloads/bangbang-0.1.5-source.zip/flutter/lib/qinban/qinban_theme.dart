import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../common.dart' show MyTheme;

const qinbanOrange = Color(0xFFCF5811);

/// Warm accents match the icon; plain surfaces keep actions easy to identify.
ThemeData qinbanTheme(Brightness brightness, {bool elderMode = false}) {
  final dark = brightness == Brightness.dark;
  final orange = dark ? const Color(0xFFFFA45D) : qinbanOrange;
  final ink = dark ? const Color(0xFFF5F5F7) : const Color(0xFF1D1D1F);
  final secondary = dark ? const Color(0xFFADADB5) : const Color(0xFF63636B);
  final background = dark ? const Color(0xFF151311) : const Color(0xFFF8F7F5);
  final surface = dark ? const Color(0xFF1C1C1E) : Colors.white;
  final colors = ColorScheme.fromSeed(seedColor: orange, brightness: brightness).copyWith(
    primary: orange, onPrimary: dark ? const Color(0xFF301700) : Colors.white,
    surface: surface, onSurface: ink, onSurfaceVariant: secondary,
    surfaceContainerHighest: dark ? const Color(0xFF2B2723) : const Color(0xFFF2EEEA),
    primaryContainer: dark ? const Color(0xFF3E281A) : const Color(0xFFFFEEDD),
    onPrimaryContainer: orange,
    tertiary: dark ? const Color(0xFF8CD1A2) : const Color(0xFF287343),
    tertiaryContainer: dark ? const Color(0xFF223D2C) : const Color(0xFFEDF6EF),
    onTertiaryContainer: dark ? const Color(0xFF8CD1A2) : const Color(0xFF287343),
    outline: dark ? const Color(0xFF545458) : const Color(0xFFBEBEC5),
    outlineVariant: dark ? const Color(0xFF38383A) : const Color(0xFFE5E5EA),
    error: dark ? const Color(0xFFFF6961) : const Color(0xFFC9342D),
  );
  final baseText = ThemeData(brightness: brightness).textTheme.apply(
    bodyColor: ink, displayColor: ink,
  );
  return ThemeData(
    useMaterial3: true, brightness: brightness, colorScheme: colors,
    // The full interface uses the upstream theme's required extensions.
    extensions: (dark ? MyTheme.darkTheme : MyTheme.lightTheme).extensions.values,
    scaffoldBackgroundColor: background,
    splashFactory: NoSplash.splashFactory,
    textTheme: elderMode ? baseText.copyWith(
      bodyLarge: baseText.bodyLarge?.copyWith(fontSize: 22),
      bodyMedium: baseText.bodyMedium?.copyWith(fontSize: 20),
      bodySmall: baseText.bodySmall?.copyWith(fontSize: 20),
      titleMedium: baseText.titleMedium?.copyWith(fontSize: 22),
      labelLarge: baseText.labelLarge?.copyWith(fontSize: 22),
    ) : baseText,
    appBarTheme: AppBarTheme(
      backgroundColor: background, foregroundColor: ink, elevation: 0,
      scrolledUnderElevation: 0, surfaceTintColor: Colors.transparent,
      centerTitle: false,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: background,
        statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        statusBarBrightness: dark ? Brightness.dark : Brightness.light,
        systemNavigationBarColor: background,
        systemNavigationBarIconBrightness: dark ? Brightness.light : Brightness.dark,
      ),
      titleTextStyle: TextStyle(color: ink, fontSize: 22, fontWeight: FontWeight.w600),
    ),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      backgroundColor: orange, foregroundColor: colors.onPrimary,
      disabledBackgroundColor: dark ? const Color(0xFF342920) : const Color(0xFFECE0D4),
      disabledForegroundColor: dark ? const Color(0xFFB49C87) : const Color(0xFF8C715A),
      minimumSize: Size.fromHeight(elderMode ? 64 : 52), elevation: 0,
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
      textStyle: TextStyle(fontSize: elderMode ? 22 : 17, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    )),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
      backgroundColor: colors.primaryContainer, foregroundColor: orange,
      side: BorderSide.none, minimumSize: Size.fromHeight(elderMode ? 56 : 48),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      textStyle: TextStyle(fontSize: elderMode ? 20 : 16, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    )),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(
      foregroundColor: orange, minimumSize: Size(48, elderMode ? 56 : 48),
      textStyle: TextStyle(fontSize: elderMode ? 20 : 16, fontWeight: FontWeight.w500),
    )),
    dialogTheme: DialogTheme(
      backgroundColor: surface, surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
    ),
    dividerTheme: DividerThemeData(color: colors.outlineVariant, thickness: .5),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: colors.surfaceContainerHighest,
      hintStyle: TextStyle(color: secondary, fontSize: elderMode ? 22 : 18, fontWeight: FontWeight.w400),
      contentPadding: const EdgeInsets.all(20),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: orange, width: 1.5)),
    ),
  );
}
