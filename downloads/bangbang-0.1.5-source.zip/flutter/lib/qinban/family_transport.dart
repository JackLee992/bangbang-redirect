import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'family_store.dart';
import 'service_configuration.dart';

abstract class FamilyTransport {
  Future<Map<String, dynamic>> call(String op, Map<String, dynamic> data);
  void suspend();
  void resume();
  void dispose();
}

class FamilyNetworkException implements Exception {
  const FamilyNetworkException();
}

abstract class FamilyRegistrationScope {
  String get registrationScope;
}

// Retains the existing class name for callers; the registered Sites service is
// the only production authority, with no separate Netlify database fallback.
class NetlifyFamilyTransport implements FamilyTransport, FamilyRegistrationScope {
  NetlifyFamilyTransport(this.identity, {http.Client Function()? clientFactory})
      : _clientFactory = clientFactory ?? http.Client.new;
  final FamilyIdentity identity;
  final http.Client Function() _clientFactory;
  @override
  String get registrationScope => endpoint.toString();
  static final endpoint = _endpoint();
  static Uri _endpoint() {
    const production = String.fromEnvironment('QINBAN_FAMILY_URL');
    const local = String.fromEnvironment('QINBAN_TEST_FAMILY_URL');
    return familyServiceEndpoint(
        configured: production, localFixture: local, debug: kDebugMode);
  }
  final Set<http.Client> _clients = {};
  bool _paused = false;
  bool _disposed = false;
  int _generation = 0;

  @override
  Future<Map<String, dynamic>> call(
      String op, Map<String, dynamic> data) async {
    if (_paused || _disposed) throw const FamilyNetworkException();
    final generation = _generation;
    final client = _clientFactory();
    _clients.add(client);
    try {
      final request = http.Request('POST', endpoint)
        ..followRedirects = false
        ..headers.addAll({
                'Content-Type': 'application/json',
                'Authorization':
                    'Bearer ${identity.installationId}.${identity.authSecret}',
              })
        ..body = jsonEncode({'v': 1, 'op': op, ...data});
      final response = await (() async {
        final streamed = await client.send(request);
        return http.Response.fromStream(streamed);
      })().timeout(const Duration(seconds: 8));
      if (generation != _generation ||
          response.statusCode != 200 ||
          response.bodyBytes.length > 65536) {
        throw const FamilyNetworkException();
      }
      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic> ||
          decoded['ok'] != true ||
          decoded['v'] != 1) {
        throw const FamilyNetworkException();
      }
      return decoded;
    } catch (_) {
      // Never include HTTP payloads, owner credentials or capabilities in logs/errors.
      throw const FamilyNetworkException();
    } finally {
      _clients.remove(client);
      client.close();
    }
  }

  @override
  void suspend() {
    _paused = true;
    ++_generation;
    for (final client in _clients.toList()) {
      client.close();
    }
    _clients.clear();
  }

  @override
  void resume() {
    if (!_disposed) _paused = false;
  }

  @override
  void dispose() {
    _disposed = true;
    suspend();
  }
}
