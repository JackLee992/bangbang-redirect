import 'dart:async';
import 'dart:io';
import 'package:flutter/widgets.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'connection_diagnostics.dart';
import 'diagnostics_transport.dart';
import 'family_bridge.dart';
import 'family_store.dart';
import 'remote_performance.dart';
import 'performance_report.dart';
import 'performance_queue.dart';
import 'performance_transport.dart';

class DiagnosticsBridge {
  static ConnectionDiagnostics? service;
  static final Map<String, DiagnosticAttempt> _sessions = {};
  static File? _performanceFile;
  static String? _pendingPerformance;
  static bool _savingPerformance = false;
  static RemotePerformanceQueue? performanceUploads;
  static final _lifecycle = _PerformanceLifecycle();
  static Future<FamilyIdentity?> authorizeInstallation() async {
    final family = FamilyBridge.service;
    if (family == null) return null;
    try {
      await family.ensureRegistered();
    } catch (_) {
      /* Existing server identity may remain valid without a peer ID. */
    }
    return FamilyBridge.service?.store.identity;
  }

  static final RemotePerformanceMetrics performance = RemotePerformanceMetrics(
      onSnapshot: (_) {
        if (_performanceFile == null) return;
        _pendingPerformance = performance.export();
        unawaited(_savePerformance());
      },
      onClose: _queuePerformance);

  static void _queuePerformance(
      String session, List<Map<String, dynamic>> windows, int duration) {
    final attempt = _sessions[session];
    final queue = performanceUploads;
    if (attempt == null || queue == null) return;
    final minimum = duration > 60000 ? duration - 60000 : 0;
    final recent =
        windows.where((item) => item['windowStartMs'] >= minimum).toList();
    final record = parsePerformanceReport({
      'v': 1,
      'attemptId': attempt.data['attemptId'],
      'platform': attempt.data['platform'],
      'appVersion': attempt.data['appVersion'],
      'build': attempt.data['build'],
      'startedAt': attempt.data['startedAt'],
      'durationMs': duration,
      'path': attempt.data['path'],
      'windows':
          recent.length <= 12 ? recent : recent.sublist(recent.length - 12),
    });
    if (record != null) unawaited(queue.enqueue(record));
  }

  static Future<void> _savePerformance() async {
    if (_savingPerformance) return;
    _savingPerformance = true;
    while (_pendingPerformance != null) {
      final raw = _pendingPerformance!;
      _pendingPerformance = null;
      final file = _performanceFile!;
      try {
        await file.parent.create(recursive: true);
        final temporary = File('${file.path}.tmp');
        await temporary.writeAsString(raw, flush: true);
        await temporary.rename(file.path);
      } catch (_) {
        // Local metrics are optional and cannot interrupt screen delivery.
      }
    }
    _savingPerformance = false;
  }

  static Future<void> initialize() async {
    if (service != null || !(Platform.isAndroid || Platform.isIOS)) return;
    try {
      final directory = await getApplicationSupportDirectory();
      final performanceFile =
          File('${directory.path}/bangbang-remote-performance.json');
      _performanceFile = performanceFile;
      if (await performanceFile.exists() &&
          await performanceFile.length() <= 102400) {
        try {
          performance.restore(await performanceFile.readAsString());
        } catch (_) {}
      }
      final file =
          File('${directory.path}/bangbang-connection-diagnostics.json');
      final info = await PackageInfo.fromPlatform();
      const configured = String.fromEnvironment('QINBAN_DIAGNOSTICS_URL');
      final uploader = AuthenticatedDiagnosticsTransport(
        configuredEndpoint: configured,
        allowed: () => service?.uploadEnabled == true,
        authorize: authorizeInstallation,
      );
      final store = ConnectionDiagnostics(
          platform: Platform.isIOS ? 'ios' : 'android',
          appVersion: info.version,
          build: info.buildNumber,
          write: (raw) async {
            await directory.create(recursive: true);
            final temporary = File('${file.path}.tmp');
            await temporary.writeAsString(raw, flush: true);
            await temporary.rename(file.path);
          },
          upload: uploader.endpoint == null ? null : uploader.upload);
      if (await file.exists() && await file.length() <= 131072) {
        store.restore(await file.readAsString());
      }
      service = store;
      final queueFile =
          File('${directory.path}/bangbang-performance-uploads.json');
      late final AuthenticatedPerformanceTransport performanceUploader;
      final queue = RemotePerformanceQueue(
          enabled: store.uploadEnabled,
          cancelUpload: () => performanceUploader.cancel(),
          write: (raw) async {
            await directory.create(recursive: true);
            final temporary = File('${queueFile.path}.tmp');
            await temporary.writeAsString(raw, flush: true);
            await temporary.rename(queueFile.path);
          },
          upload: (record) => performanceUploader.upload(record));
      performanceUploader = AuthenticatedPerformanceTransport(
          configuredEndpoint:
              const String.fromEnvironment('QINBAN_PERFORMANCE_URL'),
          allowed: () => queue.allowed && service?.uploadEnabled == true,
          authorize: authorizeInstallation);
      performanceUploads = queue;
      if (await queueFile.exists() && await queueFile.length() <= 131072) {
        queue.restore(await queueFile.readAsString());
      }
      store.addListener(() {
        unawaited(queue.setEnabled(store.uploadEnabled));
      });
      WidgetsBinding.instance.addObserver(_lifecycle);
      queue.setForeground(
          WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed);
      if (!store.uploadEnabled) {
        await queueFile.writeAsString(queue.export(), flush: true);
      }
      unawaited(queue.flush());
      unawaited(store.flush());
    } catch (_) {
      // Diagnostics are optional; failing storage/platform APIs cannot block the app.
    }
  }

  static void start(String session) {
    performance.close(session);
    performance.start(session);
    final store = service;
    if (store == null) return;
    final old = _sessions.remove(session);
    if (old != null) store.finish(old, DiagnosticOutcome.interrupted);
    _sessions[session] =
        store.begin(callId: FamilyBridge.service?.pendingRequest?.requestId);
  }

  static bool tracking(String session) => _sessions.containsKey(session);
  static bool sawFrame(String session) =>
      _sessions[session]?.data['outcome'] == 'success';

  static void event(String session, String name, Map<String, dynamic> event) {
    if (name == 'update_quality_status') performance.quality(session, event);
    final attempt = _sessions[session];
    final store = service;
    if (attempt == null || store == null) return;
    if (name == 'connection_progress') {
      // Never accept arbitrary event text as a phase or persist native details.
      final phase = DiagnosticPhase.values
          .where((value) => value.name == event['phase'])
          .firstOrNull;
      if (phase != null &&
          const {
            DiagnosticPhase.signalingConnecting,
            DiagnosticPhase.signalingHandshake,
            DiagnosticPhase.peerLookup,
            DiagnosticPhase.directConnecting,
            DiagnosticPhase.relayConnecting,
            DiagnosticPhase.peerHandshake,
          }.contains(phase)) store.advance(attempt, phase);
    } else if (name == 'connection_ready') {
      store.advance(attempt, DiagnosticPhase.contacting,
          direct: event['direct'] == 'true');
    } else if (name == 'peer_info') {
      store.advance(attempt, DiagnosticPhase.authorized);
    } else if (name == 'msgbox') {
      final type = event['type'];
      if (event['title'] == 'Connection Error' ||
          type == 'relay-hint' ||
          type == 'relay-hint2') {
        store.finish(attempt, DiagnosticOutcome.failure,
            error: classifyConnectionError(event['text']?.toString() ?? ''));
      } else if ([
        'wait-remote-accept-nook',
        'input-password',
        'input-2fa',
        're-input-password'
      ].contains(type)) {
        store.advance(attempt, DiagnosticPhase.waitingApproval);
      }
    }
  }

  static void firstFrame(String session) {
    final attempt = _sessions[session];
    if (attempt != null) service?.advance(attempt, DiagnosticPhase.firstFrame);
  }

  static void frameDelivered(String session,
      {required int width, required int height, required int elapsedMicros}) {
    performance.delivered(session,
        width: width, height: height, elapsedMicros: elapsedMicros);
  }

  static void close(String session) {
    performance.close(session);
    final attempt = _sessions.remove(session);
    if (attempt != null) service?.finish(attempt, DiagnosticOutcome.cancelled);
    unawaited(service?.flush());
  }
}

class _PerformanceLifecycle extends WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) =>
      DiagnosticsBridge.performanceUploads
          ?.setForeground(state == AppLifecycleState.resumed);
}
