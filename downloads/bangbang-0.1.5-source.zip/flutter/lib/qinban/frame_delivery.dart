/// Constructs and hands off one frame without retaining its borrowed pixel data.
///
/// The caller must keep the native buffer valid until this future completes.
/// [install] synchronously takes ownership and must not throw; before that point,
/// this function owns the frame and releases it on cancellation or failure.
/// [elapsedMicros] in [onDelivered] covers construction and handoff, not native
/// decoding, network latency, or painting the frame on the screen.
Future<bool> deliverDecodedFrame<T extends Object>({
  required Future<T?> Function() decode,
  required Future<void> Function(T) prepare,
  required bool Function() isCurrent,
  required void Function(T) install,
  required void Function(T) dispose,
  required void Function(T, int elapsedMicros) onDelivered,
}) async {
  if (!isCurrent()) return false;
  final stopwatch = Stopwatch()..start();
  T? frame;
  var installed = false;
  try {
    frame = await decode();
    if (frame == null || !isCurrent()) return false;
    await prepare(frame);
    if (!isCurrent()) return false;
    install(frame);
    installed = true;
    stopwatch.stop();
    onDelivered(frame, stopwatch.elapsedMicroseconds);
    return true;
  } finally {
    if (frame != null && !installed) dispose(frame);
  }
}
