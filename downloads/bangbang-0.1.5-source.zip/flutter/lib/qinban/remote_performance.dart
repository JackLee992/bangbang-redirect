import 'dart:collection';
import 'dart:convert';
import 'package:flutter/foundation.dart';

/// Local, bounded measurements, not screen-presented FPS or touch latency.
///
/// The session string is used only as an in-memory callback guard. No session,
/// peer, pixels, wall-clock dates or raw native events enter exported records.
/// Event-driven windows are five seconds long; gaps with no callbacks are not
/// filled with invented measurements. A close may flush a shorter final window.
class RemotePerformanceMetrics extends ChangeNotifier {
  RemotePerformanceMetrics(
      {DateTime Function()? now, this.onSnapshot, this.onClose})
      : _now = now ?? DateTime.now;

  static const _windowMs = 5000;
  static const _maxWindows = 60;
  static const _maxSamples = 128;
  static const _codecs = {'vp8', 'vp9', 'av1', 'h264', 'h265'};
  static const _fields = {
    'v',
    'windowStartMs',
    'durationMs',
    'nativeDecodeFps',
    'nativeSamples',
    'uiImageDeliveryFps',
    'deliveredFrames',
    'rgbaDeliveryMeanMs',
    'rgbaDeliveryMaxMs',
    'rgbaDeliveryP95Ms',
    'latencySamples',
    'codec',
    'networkDelayMs',
    'targetBitrateKbps',
    'receiveBytesPerSecond',
    'width',
    'height',
  };
  static final _decimal = RegExp(r'^\d+(?:\.\d+)?$');
  static final _speed = RegExp(r'^(\d{1,8}(?:\.\d{1,2})?)kB/s$');
  static final _display = RegExp(r'^\d{1,2}$');
  final DateTime Function() _now;
  final void Function(Map<String, dynamic>)? onSnapshot;
  final void Function(String, List<Map<String, dynamic>>, int)? onClose;
  final ListQueue<Map<String, dynamic>> _windows = ListQueue();
  String? _session;
  int _startedAt = 0;
  int _lastElapsed = 0;
  int _windowStart = 0;
  int? _width;
  int? _height;
  String? _codec;
  bool _disposed = false;
  _PerformanceWindow _window = _PerformanceWindow();

  void start(String session) {
    if (_disposed ||
        session.isEmpty ||
        session.length > 256 ||
        session == _session) return;
    if (_session != null) close(_session!);
    _session = session;
    _startedAt = _now().millisecondsSinceEpoch;
    _lastElapsed = 0;
    _windowStart = 0;
    _width = null;
    _height = null;
    _codec = null;
    _window = _PerformanceWindow();
    _windows.clear();
  }

  bool _current(String session) => !_disposed && _session == session;

  int _elapsed() {
    final elapsed = _now().millisecondsSinceEpoch - _startedAt;
    if (elapsed > _lastElapsed) _lastElapsed = elapsed;
    return _lastElapsed;
  }

  void quality(String session, Map<String, dynamic> nativeEvent) {
    if (!_current(session)) return;
    _advance(_elapsed());
    // src/client/io_loop.rs counts decoded frame callbacks per display over
    // about one second. Without a selected-display argument, never sum screens.
    final fps = _nativeFps(nativeEvent['fps']);
    if (fps != null && _window.nativeSamples < 1000000) {
      _window.nativeTotal += fps;
      _window.nativeSamples++;
    }
    final codec = nativeEvent['codec_format'];
    if (codec is String &&
        codec.length <= 5 &&
        _codecs.contains(codec.toLowerCase())) {
      _codec = codec.toLowerCase();
    }
    // server/connection.rs measures the preceding TestDelay round trip in ms.
    _window.delay = _number(nativeEvent['delay'], 60000) ?? _window.delay;
    // VIDEO_QOS stores EncoderApi.bitrate(): hwcodec kbs / VPx target kbps.
    _window.bitrate =
        _number(nativeEvent['target_bitrate'], 1000000) ?? _window.bitrate;
    // io_loop.rs formats byte count / seconds / 1024 as "{:.2}kB/s".
    // Restore B/s approximately; the native two-decimal formatting is lossy.
    final speed = nativeEvent['speed'];
    if (speed is String && speed.length <= 20) {
      final match = _speed.firstMatch(speed);
      final value =
          match == null ? null : _number(match.group(1), 125000000 / 1024);
      if (value != null) _window.bytesPerSecond = value * 1024;
    }
  }

  void delivered(String session,
      {required int width, required int height, required int elapsedMicros}) {
    if (!_current(session) ||
        width < 1 ||
        width > 16384 ||
        height < 1 ||
        height > 16384 ||
        elapsedMicros < 0 ||
        elapsedMicros > 10000000) return;
    _advance(_elapsed());
    _width = width;
    _height = height;
    // O(1) accumulation per ui.Image callback. Sorting happens only on publish.
    _window.delivered(elapsedMicros);
  }

  void _advance(int elapsed) {
    if (elapsed - _windowStart < _windowMs) return;
    _publish(_windowMs);
    _windowStart = elapsed ~/ _windowMs * _windowMs;
    _window = _PerformanceWindow();
  }

  void close(String session) {
    if (!_current(session)) return;
    final elapsed = _elapsed();
    _advance(elapsed);
    final duration = elapsed - _windowStart;
    if (duration > 0 || _window.frames > 0 || _window.nativeSamples > 0) {
      _publish(duration);
    }
    _session = null;
    try {
      onClose?.call(
          session,
          _windows.map((item) => Map<String, dynamic>.of(item)).toList(),
          elapsed);
    } catch (_) {/* An optional uploader cannot interrupt session teardown. */}
  }

  void _publish(int durationMs) {
    final samples = _window.samples.take(_window.sampleCount).toList()..sort();
    final record = <String, dynamic>{
      'v': 1,
      'windowStartMs': _windowStart,
      'durationMs': durationMs,
      'nativeDecodeFps': _window.nativeSamples == 0
          ? null
          : _window.nativeTotal / _window.nativeSamples,
      'nativeSamples': _window.nativeSamples,
      'uiImageDeliveryFps':
          durationMs == 0 ? null : _window.frames * 1000 / durationMs,
      'deliveredFrames': _window.frames,
      'rgbaDeliveryMeanMs': _window.frames == 0
          ? null
          : _window.totalMicros / _window.frames / 1000,
      'rgbaDeliveryMaxMs':
          _window.frames == 0 ? null : _window.maxMicros / 1000,
      // Nearest-rank P95 of the most recent <=128 deliveries in this window;
      // mean/max above include every valid delivery in the window.
      'rgbaDeliveryP95Ms': samples.isEmpty
          ? null
          : samples[(samples.length * .95).ceil() - 1] / 1000,
      'latencySamples': samples.length,
      'codec': _codec,
      'networkDelayMs': _window.delay,
      'targetBitrateKbps': _window.bitrate,
      'receiveBytesPerSecond': _window.bytesPerSecond,
      'width': _width,
      'height': _height,
    };
    _windows.add(record);
    if (_windows.length > _maxWindows) _windows.removeFirst();
    try {
      onSnapshot?.call(Map.of(record));
    } catch (_) {
      // A diagnostic persistence failure must not interrupt remote assistance.
    }
    notifyListeners();
  }

  Map<String, dynamic>? get latest =>
      _windows.isEmpty ? null : Map.of(_windows.last);

  String export() =>
      jsonEncode({'v': 1, 'windows': _windows.toList(), 'latest': latest});

  /// Restores only completed, allowlisted windows. Never replaces a live call.
  /// The untrusted envelope's "latest" is ignored and derived from windows.
  void restore(String raw) {
    if (_disposed || _session != null || raw.length > 102400) return;
    try {
      final data = jsonDecode(raw);
      if (data is! Map || data['v'] != 1 || data['windows'] is! List) return;
      final restored = <Map<String, dynamic>>[];
      for (final item in (data['windows'] as List).reversed) {
        final record = _restoreWindow(item);
        if (record == null) continue;
        if (restored.isNotEmpty &&
            record['windowStartMs'] >= restored.last['windowStartMs']) continue;
        restored.add(record);
        if (restored.length == _maxWindows) break;
      }
      _windows.clear();
      _windows.addAll(restored.reversed);
    } catch (_) {
      // Truncated or unsupported local files are not a connection error.
    }
  }

  static Map<String, dynamic>? _restoreWindow(dynamic item) {
    if (item is! Map ||
        item.length != _fields.length ||
        item.keys.any((key) => !_fields.contains(key)) ||
        item['v'] != 1) return null;
    bool valid(String key, double max,
        {bool nullable = true, bool integer = false, double min = 0}) {
      final value = item[key];
      if (value == null) return nullable;
      return value is num &&
          value.isFinite &&
          value >= min &&
          value <= max &&
          (!integer || value == value.roundToDouble());
    }

    if (!valid('windowStartMs', 31536000000, nullable: false, integer: true) ||
        !valid('durationMs', 5000, nullable: false, integer: true) ||
        !valid('nativeDecodeFps', 240) ||
        !valid('nativeSamples', 1000000, nullable: false, integer: true) ||
        !valid('uiImageDeliveryFps', 1000000000) ||
        !valid('deliveredFrames', 1000000, nullable: false, integer: true) ||
        !valid('rgbaDeliveryMeanMs', 10000) ||
        !valid('rgbaDeliveryMaxMs', 10000) ||
        !valid('rgbaDeliveryP95Ms', 10000) ||
        !valid('latencySamples', _maxSamples.toDouble(),
            nullable: false, integer: true) ||
        !valid('networkDelayMs', 60000) ||
        !valid('targetBitrateKbps', 1000000) ||
        !valid('receiveBytesPerSecond', 125000000) ||
        !valid('width', 16384, integer: true, min: 1) ||
        !valid('height', 16384, integer: true, min: 1) ||
        (item['codec'] != null && !_codecs.contains(item['codec']))) {
      return null;
    }
    return Map<String, dynamic>.from(item);
  }

  static double? _nativeFps(dynamic raw) {
    if (raw is! String || raw.length > 128) return null;
    try {
      final values = jsonDecode(raw);
      if (values is! Map || values.length != 1) return null;
      final key = values.keys.single;
      if (key is! String || !_display.hasMatch(key)) return null;
      return _number(values.values.single, 240);
    } catch (_) {
      return null;
    }
  }

  static double? _number(dynamic raw, double max) {
    double? value;
    if (raw is num) {
      value = raw.toDouble();
    } else if (raw is String && raw.length <= 24 && _decimal.hasMatch(raw)) {
      value = double.tryParse(raw);
    }
    return value != null && value.isFinite && value >= 0 && value <= max
        ? value
        : null;
  }

  @override
  void dispose() {
    _disposed = true;
    _session = null;
    super.dispose();
  }
}

class _PerformanceWindow {
  int frames = 0;
  int totalMicros = 0;
  int maxMicros = 0;
  int sampleCount = 0;
  int sampleIndex = 0;
  final List<int> samples =
      List.filled(RemotePerformanceMetrics._maxSamples, 0);
  int nativeSamples = 0;
  double nativeTotal = 0;
  double? delay;
  double? bitrate;
  double? bytesPerSecond;

  void delivered(int micros) {
    if (frames >= 1000000) return;
    frames++;
    totalMicros += micros;
    if (micros > maxMicros) maxMicros = micros;
    samples[sampleIndex] = micros;
    sampleIndex = (sampleIndex + 1) % samples.length;
    if (sampleCount < samples.length) sampleCount++;
  }
}
