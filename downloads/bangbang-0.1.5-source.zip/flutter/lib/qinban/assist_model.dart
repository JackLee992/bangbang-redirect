import 'package:flutter/foundation.dart';
import 'family_models.dart';
import 'household_service.dart';
export 'family_models.dart';

enum AssistRole { elder, helper }

AssistRole resolveInitialAssistRole(String saved, {bool helperOnly = false}) =>
    helperOnly || saved == 'helper' ? AssistRole.helper : AssistRole.elder;

@immutable
class AssistState {
  const AssistState({
    this.role = AssistRole.elder,
    this.deviceId = '',
    this.lastPeerId = '',
    this.online = false,
    this.inputReady = false,
    this.sharing = false,
    this.preparing = false,
    this.captureReady = false,
    this.connections = 0,
    this.error,
    this.invitationCode,
    this.invitationBlocked = false,
    this.fullInterface = false,
    this.familyMembers = const [],
    this.pendingFamilyRequest,
    this.familyRequestStatus = FamilyRequestStatus.idle,
    this.familyRequestError,
  });

  final AssistRole? role;
  final String deviceId;
  final String lastPeerId;
  final bool online;
  final bool inputReady;
  final bool sharing;
  final bool preparing;
  final bool captureReady;
  final int connections;
  final String? error;
  final String? invitationCode;
  final bool invitationBlocked;
  final bool fullInterface;
  final List<FamilyMember> familyMembers;
  final FamilyHelpRequest? pendingFamilyRequest;
  final FamilyRequestStatus familyRequestStatus;
  final String? familyRequestError;
}

abstract class AssistController extends ChangeNotifier {
  final Set<String> _promptedInvitations = {};

  /// A prompt remains claimed when the home view is rebuilt or remounted.
  bool claimInvitationPrompt(String code) {
    if (state.invitationCode != code ||
        state.invitationBlocked ||
        _promptedInvitations.contains(code)) {
      return false;
    }
    _promptedInvitations.add(code);
    return true;
  }

  @protected
  void resetInvitationPrompt(String code) => _promptedInvitations.remove(code);

  bool get supportsSharing => true;
  HouseholdService? get householdService => null;
  AssistState get state;
  Future<void> selectRole(AssistRole? role);
  Future<void> enableInput();
  Future<void> startSharing();
  Future<void> stopSharing();
  Future<void> connectTo(String id);
  void openSettings();
  void openSource();
  Future<void> openPrivacyPolicy();
  void openDiagnostics() {}
  Future<void> shareInvitation() async {}
  Future<void> copyInvitation() async {}
  Future<void> shareInstall() async {}
  Future<void> pasteInvitation() async {}
  void dismissInvitation() {}
  Future<void> setFullInterface(bool enabled) async {}
  Future<void> requestFamilyHelp(String peerId) async {}
  Future<void> acceptFamilyRequest() async {}
  Future<void> enableCallNotifications() async {}
  Future<void> declineFamilyRequest() async {}
  Future<void> cancelFamilyRequest() async {}
  Future<void> renameFamilyMember(String peerId, String name) async {}
  Future<void> forgetFamilyMember(String peerId) async {}
}

String normalizeDeviceId(String input) => input.replaceAll(RegExp(r'\s'), '');

String? validatePeerId(String input, String ownId) {
  final id = normalizeDeviceId(input);
  if (!RegExp(r'^\d{6,16}$').hasMatch(id)) {
    return '请输入家人手机上显示的 6–16 位设备号码';
  }
  if (id == normalizeDeviceId(ownId)) return '这是本机号码，请填写家人的设备号码';
  return null;
}

String readableId(String input) {
  final id = normalizeDeviceId(input);
  return RegExp(r'^\d+$').hasMatch(id)
      ? [for (int i = 0; i < id.length; i += 3)
          id.substring(i, i + 3 < id.length ? i + 3 : id.length)].join(' ')
      : id;
}
