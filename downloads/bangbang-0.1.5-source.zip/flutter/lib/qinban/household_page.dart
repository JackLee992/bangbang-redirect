import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'household_service.dart';

class HouseholdPage extends StatefulWidget {
  const HouseholdPage({super.key, required this.service, this.elder = false});
  final HouseholdService service;
  final bool elder;
  @override
  State<HouseholdPage> createState() => _HouseholdPageState();
}

class _HouseholdPageState extends State<HouseholdPage> {
  final _scroll = ScrollController();
  bool _busy = false;
  bool _showingSecret = false;
  String? _error;
  String? _notice;
  String _userId = '';
  String _installationId = '';
  List<Map<String, dynamic>> _households = [];
  List<Map<String, dynamic>>? _devices;
  String? _transferCode;
  int? _transferExpires;
  HouseholdService get service => widget.service;

  @override
  void initState() {
    super.initState();
    _transferCode = service.transferCode;
    _transferExpires = service.transferExpires;
    if (service.available) _run(_refresh);
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _maps(Object? value) => value is List
      ? value
          .whereType<Map>()
          .take(128)
          .map((v) => Map<String, dynamic>.from(v))
          .toList()
      : [];

  Future<void> _refresh() async {
    final recovered = await service.resumeRecovery();
    if (recovered != null) {
      await _saveRecoveredCard(recovered);
      if (!mounted) return;
      _notice = '家庭已找回，请重新与家人配对。';
    }
    final data = await service.call('household.list');
    final households = <Map<String, dynamic>>[];
    for (final item in _maps(data['households'])) {
      final detail =
          await service.call('household.get', {'familyId': item['familyId']});
      if (detail['household'] is Map) {
        households.add(Map<String, dynamic>.from(detail['household']));
      }
    }
    if (!mounted) return;
    setState(() {
      _userId = data['userId'] is String ? data['userId'] : '';
      _installationId = data['currentInstallationId'] is String
          ? data['currentInstallationId']
          : service.identity().installationId;
      _households = households;
    });
    if (_devices != null) await _loadDevices();
  }

  Future<void> _loadDevices() async {
    final data = await service.call('device.list');
    if (mounted) {
      setState(() {
        _devices = _maps(data['devices']);
      });
    }
  }

  Future<void> _run(Future<void> Function() action) async {
    if (_busy || !mounted) return;
    setState(() {
      _busy = true;
      _error = null;
      _notice = null;
    });
    try {
      await action();
    } on HouseholdException catch (error) {
      if (mounted) {
        setState(() {
          _error = error.message;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _error = '暂时无法完成，请稍后重试。';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
        });
        if ((_error != null || _notice != null) && _scroll.hasClients) {
          _scroll.animateTo(0,
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut);
        }
      }
    }
  }

  Future<bool> _confirm(String title, String message, String action) async =>
      await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
                  scrollable: true,
                  title: Text(title),
                  content: Text(message),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(dialogContext, false),
                        child: Text('取消')),
                    FilledButton(
                        onPressed: () => Navigator.pop(dialogContext, true),
                        child: Text(action)),
                  ])) ==
      true;

  Future<String?> _code(
          String title, String prefix, String message, String action) =>
      showDialog<String>(
          context: context,
          builder: (_) => _CodeDialog(
              title: title, prefix: prefix, message: message, action: action));

  Future<void> _secret(String code, {required bool recovery}) async {
    if (!mounted) return;
    setState(() {
      _showingSecret = true;
    });
    try {
      await showDialog<void>(
          context: context,
          barrierDismissible: !recovery,
          builder: (_) => _SecretDialog(code: code, recovery: recovery));
    } finally {
      if (mounted) {
        setState(() {
          _showingSecret = false;
        });
      }
    }
  }

  Future<void> _recoveryResult(Map<String, dynamic> data) async {
    final code = data['recoveryCode'];
    if (code is String && validHouseholdCode(code, 'BHR1')) {
      await _secret(code, recovery: true);
    }
  }

  Map<String, dynamic> _revision(Map<String, dynamic> home) =>
      {'familyId': home['familyId'], 'expectedRevision': home['revision']};

  Future<void> _create() async {
    if (!await _confirm('创建家庭', '创建后可以邀请已配对的家人。家庭成员不会自动获得远程协助权限。', '创建')) {
      return;
    }
    await _run(() async {
      final data = await service.call('household.create');
      await _recoveryResult(data);
      await _refresh();
    });
  }

  Future<void> _join() async {
    final code = await _code(
        '加入家庭', 'BH1', '粘贴家人发来的家庭邀请。加入家庭只建立成员关系，每次远程协助仍需授权。', '确认加入');
    if (code == null) return;
    await _run(() async {
      final result = await service
          .call('invite.confirm', {'inviteCode': code, 'confirmed': true});
      // Elder joining stays one confirmation. Discard the one-time card; an
      // explicit advanced "rotate recovery card" action can generate a new one.
      if (!widget.elder) await _recoveryResult(result);
      await _refresh();
      if (mounted) {
        setState(() {
          _notice = '已加入家庭';
        });
      }
    });
  }

  Future<void> _invite(Map<String, dynamic> home) async {
    final contacts = service.contacts();
    final contact = await showDialog<HouseholdContact>(
        context: context,
        builder: (dialogContext) =>
            SimpleDialog(title: Text('邀请已配对的家人'), children: [
              if (contacts.isEmpty)
                Padding(
                    padding: EdgeInsets.all(24), child: Text('请先和家人完成一次协助配对。')),
              for (final contact in contacts)
                SimpleDialogOption(
                    onPressed: () => Navigator.pop(dialogContext, contact),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    child: Text(contact.name)),
              TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: Text('取消')),
            ]));
    if (contact == null) return;
    await _run(() async {
      final result = await service.call('member.invite', {
        ..._revision(home),
        'targetInstallationId': contact.installationId,
        'displayName': contact.name
      });
      final code = result['inviteCode'];
      if (code is String && validHouseholdCode(code, 'BH1')) {
        await _secret(code, recovery: false);
      }
      await _refresh();
    });
  }

  Future<void> _change(String title, String message, String op,
      Map<String, dynamic> fields) async {
    if (!await _confirm(title, message, '确认')) return;
    await _run(() async {
      await service.call(op, fields);
      await _refresh();
    });
  }

  static const _newDeviceWarning = '本机会生成新的设备身份，并清除本机原有家人配对。'
      '请只在新手机上继续。找回家庭后，仍需重新配对并确认每次协助，不会自动连接家人。';

  Future<void> _prepareNewDevice() async {
    await service.prepareNewDevice();
    if (!mounted) return;
    setState(() {
      _userId = '';
      _installationId = service.identity().installationId;
      _households = [];
      _devices = null;
      _transferCode = service.transferCode;
      _transferExpires = service.transferExpires;
    });
  }

  Future<void> _saveRecoveredCard(Map<String, dynamic> data) async {
    final code = data['recoveryCode'];
    if (code is! String || !validHouseholdCode(code, 'BHR1')) {
      throw const HouseholdException('network');
    }
    await _secret(code, recovery: true);
    if (!mounted) return;
    await service.recoveryCompleted();
    _transferCode = null;
    _transferExpires = null;
  }

  Future<void> _recover() async {
    final code = await _code('用恢复卡找回家庭', 'BHR1',
        '$_newDeviceWarning\n\n成功后旧设备会被撤销，旧恢复卡失效，请保存新恢复卡。', '确认找回');
    if (code == null) return;
    await _run(() async {
      await _prepareNewDevice();
      final data = await service
          .call('recovery.redeem', {'recoveryCode': code, 'confirmed': true});
      await _saveRecoveredCard(data);
      if (!mounted) return;
      await _refresh();
      if (mounted) {
        setState(() {
          _notice = '家庭已找回，请重新与家人配对。';
        });
      }
    });
  }

  Future<void> _beginTransfer() async {
    if (!await _confirm('这是新手机', _newDeviceWarning, '开始换机')) return;
    await _run(() async {
      await _prepareNewDevice();
      final data = await service.call('device.transfer.begin');
      if (data['recoveryCode'] != null) {
        await _saveRecoveredCard(data);
        if (!mounted) return;
        await _refresh();
        if (mounted) setState(() { _notice = '家庭已找回，请重新与家人配对。'; });
        return;
      }
      final code = data['transferCode'];
      if (code is! String || !validHouseholdCode(code, 'BHT1')) {
        throw const HouseholdException('network');
      }
      if (mounted) {
        setState(() {
          _transferCode = code;
          _transferExpires =
              data['expiresAt'] is int ? data['expiresAt'] : null;
          _households = [];
          _devices = null;
        });
      }
    });
  }

  Future<void> _approveTransfer() async {
    final code = await _code('在旧手机确认换机', 'BHT1',
        '请当面核对新手机上的换机码，仅确认自己的新手机。确认后在新手机点“完成换机”。', '确认这是我的新手机');
    if (code == null) return;
    await _run(() async {
      await service.call(
          'device.transfer.approve', {'transferCode': code, 'confirmed': true});
      if (mounted) {
        setState(() {
          _notice = '已确认，请回到新手机完成换机。';
        });
      }
    });
  }

  Future<void> _completeTransfer() async {
    final code = _transferCode;
    if (code == null) return;
    await _run(() async {
      final data = await service.call('device.transfer.complete',
          {'transferCode': code, 'confirmed': true});
      await _saveRecoveredCard(data);
      if (!mounted) return;
      await _refresh();
      if (mounted) {
        setState(() {
          _notice = '换机完成，请重新与家人配对。';
        });
      }
    });
  }

  Future<void> _rotateRecovery() async {
    if (!await _confirm('更换恢复卡', '旧恢复卡会立即失效。新恢复卡仅展示一次，请妥善保存，不要发给他人。', '更换')) {
      return;
    }
    await _run(() async {
      await _recoveryResult(
          await service.call('recovery.rotate', {'confirmed': true}));
    });
  }

  Widget _button(String key, String label, VoidCallback action,
          {bool enabled = true}) =>
      Padding(
          padding: EdgeInsets.symmetric(vertical: 4),
          child: OutlinedButton(
              key: Key(key),
              onPressed: _busy || !enabled ? null : action,
              style: OutlinedButton.styleFrom(
                  minimumSize: Size(double.infinity, 48),
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
              child: Text(label, textAlign: TextAlign.center)));

  String _date(Object? milliseconds) => milliseconds is int
      ? DateTime.fromMillisecondsSinceEpoch(milliseconds)
          .toLocal()
          .toString()
          .substring(0, 16)
      : '';

  Widget _household(Map<String, dynamic> home, int index) {
    final members = _maps(home['members']);
    final owner =
        members.any((m) => m['userId'] == _userId && m['role'] == 'owner');
    return Card(
        child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(_households.length == 1 ? '我的家庭' : '家庭 ${index + 1}',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                  for (final member in members)
                    Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                  '${member['displayName'] ?? '家人'}${member['userId'] == _userId ? '（我）' : ''}'),
                              Text(
                                  member['role'] == 'owner' ? '家庭管理者' : '家庭成员'),
                              if (owner && member['role'] != 'owner')
                                _button(
                                    'household-remove-${member['userId']}',
                                    '移除成员',
                                    () => _change(
                                            '移除这位成员？',
                                            '对方将不再属于这个家庭。此操作不会代替远程协助的停止和设备授权。',
                                            'member.remove', {
                                          ..._revision(home),
                                          'targetUserId': member['userId']
                                        })),
                            ])),
                  if (owner)
                    _button('household-invite-${home['familyId']}', '邀请已配对的家人',
                        () => _invite(home)),
                  if (!owner)
                    _button(
                        'household-leave-${home['familyId']}',
                        '离开家庭',
                        () => _change('离开这个家庭？', '离开后需要家庭管理者重新发邀请才能加入。',
                            'member.leave', _revision(home))),
                  if (owner)
                    for (final invite in _maps(home['invites']))
                      Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Text(
                                    '待确认邀请 · ${_date(invite['expiresAt'])} 到期'),
                                _button(
                                    'household-revoke-invite-${invite['inviteId']}',
                                    '撤销邀请',
                                    () => _change('撤销这个邀请？', '对方将无法再用这条邀请加入。',
                                            'invite.revoke', {
                                          ..._revision(home),
                                          'inviteId': invite['inviteId']
                                        })),
                              ])),
                ])));
  }

  @override
  Widget build(BuildContext context) {
    final enabled = service.available;
    return Theme(
        data: Theme.of(context).copyWith(
            textTheme: Theme.of(context)
                .textTheme
                .apply(fontSizeFactor: widget.elder ? 1.2 : 1)),
        child: Scaffold(
          appBar: AppBar(title: Text('我的家庭')),
          body: SafeArea(
              child: ListView(
                  controller: _scroll,
                  padding: EdgeInsets.all(16),
                  children: [
                if (_busy && !_showingSecret)
                  LinearProgressIndicator(key: Key('household-busy')),
                if (!enabled)
                  Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Text(
                          const HouseholdException('not_configured').message,
                          key: Key('household-unavailable'))),
                if (_error != null)
                  Semantics(
                      liveRegion: true,
                      child: Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(_error!,
                              key: Key('household-error'),
                              style: TextStyle(
                                  color:
                                      Theme.of(context).colorScheme.error)))),
                if (_notice != null)
                  Semantics(
                      liveRegion: true,
                      child: Text(_notice!, key: Key('household-notice'))),
                if (enabled) ...[
                  _button('household-refresh', '刷新', () => _run(_refresh)),
                  for (var i = 0; i < _households.length; i++)
                    _household(_households[i], i),
                  if (_households.isEmpty && !_busy) Text('还没有加入家庭'),
                  _button('household-create', '创建家庭', _create,
                      enabled: !widget.elder),
                  if (widget.elder) Text('请让帮助你的家人创建家庭，再发邀请给你。'),
                  _button('household-join', '粘贴家庭邀请', _join),
                  Divider(height: 32),
                  Text('设备与找回',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                  _button(
                      'household-devices', '查看我的设备', () => _run(_loadDevices)),
                  for (var i = 0; i < (_devices?.length ?? 0); i++) ...[
                    Text(
                        '${_devices![i]['installationId'] == _installationId ? '本机' : '设备 ${i + 1}'} · '
                        '${_devices![i]['status'] == 'revoked' ? '已撤销' : '有效'}'),
                    Text('加入于 ${_date(_devices![i]['createdAt'])}'),
                    if (_devices![i]['status'] == 'revoked')
                      Text(_devices![i]['familyCredentialRevocation'] ==
                              'confirmed'
                          ? '协助凭据已撤销'
                          : _devices![i]['familyCredentialRevocation'] ==
                                  'not_required'
                              ? '没有需要撤销的协助凭据'
                              : '协助凭据撤销尚未确认'),
                    if (_devices![i]['installationId'] != _installationId &&
                        _devices![i]['familyCredentialRevocation'] !=
                            'confirmed')
                      _button(
                          'household-device-$i',
                          '撤销此设备',
                          () => _change(
                                  '撤销此设备？',
                                  '此设备将不能再管理家庭。请同时结束正在进行的协助；协助凭据的撤销结果会单独显示。',
                                  'device.revoke', {
                                'installationId': _devices![i]
                                    ['installationId'],
                                'confirmed': true
                              })),
                  ],
                  _button('household-transfer-begin', '新手机：用旧手机确认换机',
                      _beginTransfer),
                  if (_transferCode != null)
                    Card(
                        child: Padding(
                            padding: EdgeInsets.all(16),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Text('把换机码交给自己的旧手机，在旧手机打开“确认新手机”。'),
                                  if (_transferExpires != null)
                                    Text('${_date(_transferExpires)} 到期'),
                                  SelectableText(_transferCode!,
                                      key: Key('household-transfer-code')),
                                  _button('household-transfer-copy', '复制换机码',
                                      () async {
                                    await Clipboard.setData(
                                        ClipboardData(text: _transferCode!));
                                    if (mounted) {
                                      setState(() {
                                        _notice = '换机码已复制';
                                      });
                                    }
                                  }),
                                  _button('household-transfer-complete',
                                      '旧手机已确认，完成换机', _completeTransfer),
                                ]))),
                  _button('household-transfer-approve', '旧手机：确认新手机',
                      _approveTransfer),
                  _button('household-recover', '新手机：用恢复卡找回', _recover),
                  _button(
                      'household-recovery-rotate', '更换恢复卡', _rotateRecovery),
                ],
              ])),
        ));
  }
}

class _CodeDialog extends StatefulWidget {
  const _CodeDialog(
      {required this.title,
      required this.prefix,
      required this.message,
      required this.action});
  final String title, prefix, message, action;
  @override
  State<_CodeDialog> createState() => _CodeDialogState();
}

class _CodeDialogState extends State<_CodeDialog> {
  final _input = TextEditingController();
  String? _error;
  @override
  void dispose() {
    _input.clear();
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
          scrollable: true,
          title: Text(widget.title),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(widget.message),
            SizedBox(height: 16),
            TextField(
                key: Key('household-code-input'),
                controller: _input,
                maxLength: 4096,
                minLines: 2,
                maxLines: 4,
                autocorrect: false,
                enableSuggestions: false,
                decoration: InputDecoration(
                    labelText: '粘贴完整内容', errorText: _error, counterText: '')),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context), child: Text('取消')),
            FilledButton(
                key: Key('household-code-confirm'),
                onPressed: () {
                  final value = _input.text.trim();
                  if (!validHouseholdCode(value, widget.prefix)) {
                    setState(() {
                      _error = '请粘贴完整的 ${widget.prefix} 内容';
                    });
                    return;
                  }
                  Navigator.pop(context, value);
                },
                child: Text(widget.action)),
          ]);
}

class _SecretDialog extends StatefulWidget {
  const _SecretDialog({required this.code, required this.recovery});
  final String code;
  final bool recovery;
  @override
  State<_SecretDialog> createState() => _SecretDialogState();
}

class _SecretDialogState extends State<_SecretDialog> {
  bool _saved = false;
  bool _copied = false;
  @override
  Widget build(BuildContext context) => PopScope(
      canPop: !widget.recovery || _saved,
      child: AlertDialog(
          scrollable: true,
          title: Text(widget.recovery ? '保存恢复卡' : '家庭邀请已生成'),
          content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(widget.recovery
                    ? '恢复卡只展示这一次，持有它可以找回家庭身份。请保存到安全位置，不要发给别人。旧恢复卡现已失效。'
                    : '只发给刚才选择的家人，请对方及时在“我的家庭”中粘贴并确认。'),
                SizedBox(height: 16),
                SelectableText(widget.code, key: Key('household-secret')),
                SizedBox(height: 16),
                OutlinedButton(
                    key: Key('household-secret-copy'),
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: widget.code));
                      if (mounted) {
                        setState(() {
                          _copied = true;
                        });
                      }
                    },
                    child: Text(_copied
                        ? '已复制，请妥善保存'
                        : (widget.recovery ? '复制恢复卡' : '复制家庭邀请'))),
                if (widget.recovery)
                  CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      key: Key('household-secret-saved'),
                      value: _saved,
                      onChanged: (value) => setState(() {
                            _saved = value == true;
                          }),
                      title: Text('我已复制或另行安全保存')),
              ]),
          actions: [
            FilledButton(
                key: Key('household-secret-done'),
                onPressed: widget.recovery && !_saved
                    ? null
                    : () => Navigator.pop(context),
                child: Text('完成'))
          ]));
}
