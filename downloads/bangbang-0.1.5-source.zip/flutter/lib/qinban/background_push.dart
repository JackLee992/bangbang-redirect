import 'dart:async';

/// A provider token is only an address. It never authorizes a family connection.
class FamilyPushState {
  const FamilyPushState(this.status, {this.provider, this.token, this.enabled = false, this.clientConfig});
  final String status;
  final String? provider;
  final String? token;
  final bool enabled;
  final Map<String, String>? clientConfig;

  factory FamilyPushState.parse(dynamic value) {
    if (value is! Map) return const FamilyPushState('unavailable');
    final provider = value['provider'];
    final token = value['token'];
    final valid = provider == 'apns'
        ? token is String && token.length.isEven && RegExp(r'^[a-fA-F0-9]{64,512}$').hasMatch(token)
        : provider == 'fcm' && token is String &&
            RegExp(r'^[A-Za-z0-9_:.\-]{20,4096}$').hasMatch(token);
    final config = value['clientConfig'];
    Map<String, String>? clientConfig;
    if (config is Map && config['appId'] is String &&
        RegExp(r'^[A-Za-z0-9][A-Za-z0-9.-]{0,254}$').hasMatch(config['appId'])) {
      if (provider == 'apns' && const ['sandbox', 'production'].contains(config['environment'])) {
        clientConfig = {'appId': config['appId'], 'environment': config['environment']};
      } else if (provider == 'fcm' && config['projectId'] is String &&
          RegExp(r'^[a-z][a-z0-9-]{4,62}$').hasMatch(config['projectId'])) {
        clientConfig = {'appId': config['appId'], 'projectId': config['projectId']};
      }
    }
    final status = value['status'] is String ? value['status'] as String : 'unavailable';
    return FamilyPushState(!valid && status == 'ready' ? 'unavailable' : status,
        provider: valid ? provider : null, token: valid ? token : null,
        enabled: value['enabled'] == true && valid, clientConfig: clientConfig);
  }
}

/// Serializes token rotation and role/permission changes. Failed writes retry on
/// the next foreground refresh; they do not affect an assistance session.
class FamilyPushRegistration {
  FamilyPushRegistration({required this.readState, required this.publish,
    DateTime Function()? now}) : _now = now ?? DateTime.now;
  final Future<FamilyPushState> Function() readState;
  final Future<String> Function(String provider, String token, bool enabled, Map<String, String>? clientConfig) publish;
  final DateTime Function() _now;
  static const _refreshInterval = Duration(minutes: 15);
  Future<void>? _syncing;
  String? _registered;
  DateTime? _registeredAt;
  bool _helper = false;
  bool _again = false;
  bool _disposed = false;
  int _revision = 0;
  String status = 'unavailable';

  Future<void> sync({required bool helper}) {
    _helper = helper;
    if (_disposed) return Future.value();
    if (_syncing != null) { _again = true; return _syncing!; }
    final future = _run();
    _syncing = future;
    return future.whenComplete(() { _syncing = null; });
  }

  Future<void> _run() async {
    do {
      _again = false;
      final revision = _revision;
      try {
        final native = await readState();
        if (_disposed) return;
        if (revision != _revision) { _again = true; continue; }
        // A native address alone never establishes server compatibility.
        status = native.status == 'ready' ? 'unverified' : native.status;
        if (native.provider == null || native.token == null) continue;
        // A failed token refresh is not a permission revocation. Older native
        // versions may report enabled=false while retaining a valid address.
        if (_helper && !native.enabled && native.status != 'denied' &&
            native.status != 'disabled') continue;
        final enabled = _helper && native.enabled;
        if (enabled && native.clientConfig == null) { status = 'unverified'; continue; }
        final configKey = native.clientConfig?.entries.map((e) => '${e.key}=${e.value}').join('&') ?? '';
        final key = '${native.provider}/${native.token}/$enabled/$configKey';
        final age = _registeredAt == null ? null : _now().difference(_registeredAt!);
        if (key == _registered && (!enabled ||
            (age != null && !age.isNegative && age < _refreshInterval))) {
          if (!enabled) {
            status = native.status == 'denied' ? 'denied' : 'disabled';
          } else if (native.status == 'ready') {
            status = 'configured';
          }
          continue;
        }
        final result = await publish(native.provider!, native.token!, enabled, native.clientConfig);
        if (_disposed) return;
        if (revision != _revision) { _again = true; continue; }
        // Retain the address only in memory. A failed/unconfigured registration
        // is retried, including when the server is configured after app launch.
        // Reconfirm stable tokens periodically: the provider may have invalidated
        // the server registration since the last successful foreground sync.
        final confirmed = enabled ? result == 'matched' : result == 'disabled';
        if (confirmed) { _registered = key; _registeredAt = _now(); }
        status = enabled ? (result == 'matched' ? (native.status == 'ready' ? 'configured' : native.status) :
            result == 'mismatch' ? 'configurationMismatch' : result == 'missingClient' || result == 'unverified' ? 'unverified' : 'serverUnavailable') :
            !confirmed ? 'serverUnavailable' : native.status == 'denied' ? 'denied' : 'disabled';
      } catch (_) {
        status = 'serverUnavailable';
      }
    } while (_again && !_disposed);
  }

  void invalidateIdentity() {
    ++_revision;
    _registered = null;
    _registeredAt = null;
    if (_syncing != null) _again = true;
  }

  void dispose() { _disposed = true; _registered = null; _registeredAt = null; }
}

/// Configuration and permission are not proof of vendor acceptance or delivery.
String familyPushStatusMessage(String status) => switch (status) {
  'configured' => '通知设置已保存。实际提醒仍受系统与网络影响，收到后点通知回到帮帮接听。',
  'denied' => '通知还没有开启，可以到手机设置中允许帮帮通知。',
  'registering' => '正在设置来电提醒，请稍后再查看。',
  'unverified' => '应用内来电提醒已开启。这个版本的后台提醒配置尚未确认，请先保持帮帮打开。',
  _ => '应用内来电提醒已开启。后台提醒暂未就绪，先和家人保持帮帮打开。',
};
