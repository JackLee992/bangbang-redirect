/// One authority owns saved family relationships. A download mirror is never a
/// second family database and invitation text cannot select an API endpoint.
const qinbanServiceOrigin = 'https://bangbang-services.s419505080.chatgpt.site';
const qinbanFamilyServiceUrl = '$qinbanServiceOrigin/.netlify/functions/family';
const qinbanDiagnosticsServiceUrl = '$qinbanServiceOrigin/v1/attempts';

Uri familyServiceEndpoint(
    {String configured = '', String localFixture = '', bool debug = false}) {
  final local = Uri.tryParse(localFixture);
  if (debug &&
      local != null &&
      local.scheme == 'http' &&
      const ['127.0.0.1', '10.0.2.2', 'localhost'].contains(local.host) &&
      local.userInfo.isEmpty &&
      !local.hasQuery &&
      !local.hasFragment) {
    return local;
  }
  // An invalid build define cannot redirect installation credentials. The
  // registered authority remains the default, including when Netlify is down.
  if (configured == qinbanFamilyServiceUrl) {
    return Uri.parse(configured);
  }
  return Uri.parse(qinbanFamilyServiceUrl);
}

Uri? diagnosticsServiceEndpoint(String configured) {
  if (configured.isEmpty || configured == qinbanDiagnosticsServiceUrl) {
    return Uri.parse(qinbanDiagnosticsServiceUrl);
  }
  // Diagnostics are optional. An obsolete or untrusted URL disables upload
  // instead of disclosing the installation bearer to another service.
  return null;
}
