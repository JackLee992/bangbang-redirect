import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'family_models.dart';
import 'family_store.dart';
import 'family_transport.dart';

const familyChatPrefix = '__BANGBANG_FAMILY_V1__:';
const familyNativePingInterval = Duration(seconds: 10);
const familyNativeHealthFreshness = Duration(seconds: 30);
const familyNativeProbeTimeout = Duration(seconds: 5);
const familyEndRetryWindow = Duration(minutes: 10);

class FamilyContext {
  const FamilyContext(this.peerId, this.serverScope);
  final String peerId;
  final String serverScope;
  bool get valid => validFamilyPeer(peerId) && validFamilyScope(serverScope);
}

class FamilyChannel {
  FamilyChannel(
      {required this.id,
      required this.peerId,
      required this.name,
      required this.direction,
      required this.encrypted,
      required this.isActive,
      required this.send});
  final String id;
  final String peerId;
  final String name;
  final FamilyDirection direction;
  final bool encrypted;
  final bool Function() isActive;
  final Future<void> Function(String) send;
}

class _Handshake {
  _Handshake(this.channel, this.scope);
  final FamilyChannel channel;
  final String scope;
  final String localNonce = familyToken(16);
  String remoteNonce = '';
  String remoteInstallationId = '';
  bool offering = false;
  final List<Timer> timers = [];
}

class _Request {
  _Request(this.binding, this.requestId, this.expiresAt, this.incoming);
  final FamilyBinding binding;
  final String requestId;
  DateTime expiresAt;
  final bool incoming;
  String? channelId;
  bool nativeStarted = false;
  bool nativeLease = false;
  bool publishingProgress = false;
  DateTime? healthyAt;
  String? challenge;
  Completer<bool>? probe;
  Timer? probeTimer;
  bool expiryProbeStarted = false;
  bool probeFailed = false;
  FamilyHelpRequest get view => FamilyHelpRequest(
      requestId: requestId,
      familyPeerId: binding.peerId,
      familyName: binding.name,
      elderPeerId: incoming ? binding.peerId : binding.ownPeerId,
      expiresAt: expiresAt);
}

class _PendingEnd {
  const _PendingEnd(this.request, this.reason, this.retryUntil);
  final _Request request;
  final String reason;
  final DateTime retryUntil;
}

/// Foreground request delivery never changes engine authorization or capture consent.
class FamilyService extends ChangeNotifier {
  FamilyService(
      {required this.store,
      required this.transport,
      required this.context,
      FamilyTransport Function(FamilyIdentity)? freshTransport,
      DateTime Function()? now})
      : freshTransport = freshTransport ?? NetlifyFamilyTransport.new,
        now = now ?? DateTime.now;
  final FamilyStore store;
  FamilyTransport transport;
  final FamilyTransport Function(FamilyIdentity) freshTransport;
  final FamilyContext Function() context;
  final DateTime Function() now;
  final Map<String, _Handshake> _channels = {};
  final Map<String, _Request> _withdrawals = {};
  final Map<String, _PendingEnd> _ends = {};
  String _registeredContext = '';
  bool _serverRecovery = false;
  bool _serverBackgroundPush = false;
  bool _serverPushConfiguration = false;
  Timer? _healthTimer;
  Future<void>? _registering;
  bool _disposed = false;
  bool _rekeying = false;
  bool _foreground = true;
  bool _polling = false;
  bool _sending = false;
  bool _responding = false;
  int _generation = 0;
  int _requestEpoch = 0;
  _Request? _request;
  bool _acceptedLocally = false;
  DateTime? _lastProgressAt;
  String? _firstFramePeer;
  String? _firstFrameChannelId;
  void Function(FamilyCallEnd)? onRemoteEnd;
  FamilyCallEnd? lastEnd;
  FamilyRequestStatus requestStatus = FamilyRequestStatus.idle;
  String? requestError;

  List<FamilyMember> get members {
    final own = context();
    return List.unmodifiable(store.members
        .where((m) => m.serverScope == own.serverScope)
        .map((m) => FamilyMember(
            peerId: m.peerId,
            name: m.name,
            direction: m.direction,
            lastHelpAt: m.lastHelpAt,
            directReady:
                m.confirmed && m.hasCapability && m.ownPeerId == own.peerId)));
  }

  FamilyHelpRequest? get pendingRequest => _request?.view;
  bool get pendingIncoming => _request?.incoming == true;

  void _clearRequest() {
    final request = _request;
    request?.probeTimer?.cancel();
    if (request?.probe?.isCompleted == false) request!.probe!.complete(false);
    _healthTimer?.cancel();
    _healthTimer = null;
    _request = null;
    _acceptedLocally = false;
    _firstFramePeer = null;
    _firstFrameChannelId = null;
    _lastProgressAt = null;
    ++_requestEpoch;
    // In-flight operations retain their locks until their own finally blocks.
  }

  void _changed() {
    if (!_disposed) notifyListeners();
  }

  bool _active(_Handshake handshake) => _foreground && _live(handshake);

  // Native chat may still deliver while Android is backgrounded. HTTP polling
  // remains foreground-only; cached authorization alone is not health proof.
  bool _live(_Handshake handshake) =>
      !_disposed &&
      handshake.channel.isActive() &&
      _channels[handshake.channel.id] == handshake &&
      context().valid &&
      context().serverScope == handshake.scope;

  Future<void> _save() async {
    try {
      await store.save();
    } catch (_) {
      requestError = '家人记录暂时无法保存，请稍后重试。';
      _changed();
    }
  }

  Future<void> _register() async {
    final own = context();
    if (!own.valid || !_foreground || _disposed || _rekeying) {
      throw const FamilyNetworkException();
    }
    final registeringTransport = transport;
    final scopedTransport = registeringTransport is FamilyRegistrationScope
        ? registeringTransport as FamilyRegistrationScope : null;
    final scope = scopedTransport?.registrationScope ?? '';
    final key = '${store.identity!.installationId}/$scope/${own.peerId}/${own.serverScope}';
    if (_registeredContext == key) return;
    if (_registering != null) {
      await _registering;
      if (_registeredContext == key) return;
    }
    final generation = _generation;
    final future = () async {
      await store.save(); // Persist owner auth before first registration/claim.
      final response = await registeringTransport.call(
          'register', {'peerId': own.peerId, 'serverScope': own.serverScope});
      if (generation != _generation ||
          !identical(transport, registeringTransport) ||
          (scopedTransport != null && scopedTransport.registrationScope != scope) ||
          context().peerId != own.peerId ||
          context().serverScope != own.serverScope) {
        throw const FamilyNetworkException();
      }
      _serverRecovery = response['activeLeaseRecovery'] == 1;
      _serverBackgroundPush = response['backgroundPush'] == 1;
      _serverPushConfiguration = response['pushConfiguration'] == 1;
      _registeredContext = key;
    }();
    _registering = future;
    try {
      await future;
    } finally {
      if (identical(_registering, future)) _registering = null;
    }
  }

  Future<String> configurePush(String provider, String token, bool enabled,
      Map<String, String>? clientConfig) async {
    await _register();
    if (!_serverBackgroundPush) return 'unavailable';
    if (enabled && !_serverPushConfiguration) return 'unverified';
    final result = await transport.call(enabled ? 'push.register' : 'push.unregister',
        {'provider': provider, 'token': token, if (enabled && clientConfig != null) 'clientConfig': clientConfig});
    final push = result['push'];
    if (push is! Map || push['registered'] != enabled) return 'unavailable';
    if (!enabled) return 'disabled';
    final status = push['configurationStatus'];
    if (status == 'matched' && push['deliveryConfigured'] == true) return 'matched';
    return const ['missingClient', 'mismatch', 'unconfigured'].contains(status) ? status : 'unverified';
  }

  Future<void> ensureRegistered() => _register();

  /// Explicit new-phone setup, never ordinary startup or an invitation tap.
  /// The caller must explain loss of this device's saved pairings and invoke
  /// this once per recovery flow, before submitting recovery proof.
  Future<FamilyIdentity> prepareHouseholdRecovery({required bool confirmed, required String householdScope}) async {
    if (!confirmed || _disposed || _rekeying || _sending || _responding || _request != null ||
        _channels.values.any((handshake) => handshake.channel.isActive())) {
      throw StateError('recovery_requires_idle_confirmation');
    }
    _rekeying = true;
    ++_generation;
    final oldTransport = transport;
    oldTransport.suspend();
    try {
      final replacement = await store.replaceIdentity(householdScope: householdScope);
      oldTransport.dispose();
      transport = freshTransport(replacement);
      _registeredContext = '';
      _registering = null;
      _serverRecovery = false;
      _serverBackgroundPush = false;
      _serverPushConfiguration = false;
      _ends.clear();
      _withdrawals.clear();
      for (final handshake in _channels.values) {
        for (final timer in handshake.timers) { timer.cancel(); }
      }
      _channels.clear();
      _clearRequest();
      requestStatus = FamilyRequestStatus.idle;
      requestError = null;
      lastEnd = null;
      return replacement;
    } finally {
      _rekeying = false;
      if (_disposed) { transport.dispose(); }
      else if (_foreground) { transport.resume(); }
      else { transport.suspend(); }
      _changed();
    }
  }

  /// Revalidate the opaque push reference before displaying the current call.
  /// The notification cannot supply a capability or trigger remote acceptance.
  Future<bool> resolvePush(dynamic pairId, dynamic requestId) async {
    if (!validFamilyToken(pairId, 16) || !validFamilyToken(requestId, 16)) return false;
    await _register();
    if (!_serverBackgroundPush) return false;
    final result = await transport.call('push.resolve', {'pairId': pairId, 'requestId': requestId});
    return result['actionable'] == true && result['pairId'] == pairId &&
        result['requestId'] == requestId;
  }

  /// Only call after incoming authorization or a fresh outgoing LoginResponse peer_info.
  void connected(FamilyChannel channel) {
    final own = context();
    if (_disposed || _rekeying ||
        !channel.isActive() ||
        !validFamilyPeer(channel.peerId) ||
        !validFamilyScope(own.serverScope) ||
        channel.peerId == own.peerId) return;
    final previous = _channels[channel.id];
    if (previous != null) return;
    store.remember(channel.peerId, channel.name, own.serverScope,
        channel.direction, now());
    unawaited(_save());
    // Authorization is only one step of a call. Keep the request until the
    // helper reports a first frame, either side hangs up, or the lease expires.
    final handshake = _Handshake(channel, own.serverScope);
    _channels[channel.id] = handshake;
    if (channel.direction == FamilyDirection.outgoingElder &&
        _firstFramePeer == channel.peerId &&
        (_firstFrameChannelId == null || _firstFrameChannelId == channel.id)) {
      unawaited(firstFrame(channel.peerId, channelId: channel.id));
    }
    if (channel.direction == FamilyDirection.outgoingElder &&
        !channel.encrypted) {
      _changed();
      return; // Remember the successful session, but do not exchange capabilities.
    }
    for (final seconds in [0, 2, 5, 10]) {
      handshake.timers.add(Timer(Duration(seconds: seconds), () {
        if (_active(handshake)) unawaited(_hello(handshake));
      }));
    }
    _changed();
  }

  void disconnected(String channelId) {
    final handshake = _channels.remove(channelId);
    for (final timer in handshake?.timers ?? <Timer>[]) {
      timer.cancel();
    }
    if (_request?.channelId == channelId) {
      unawaited(endCall(
          reason: requestStatus == FamilyRequestStatus.active
              ? 'ended'
              : 'failed'));
    }
  }

  Future<void> _hello(_Handshake handshake) async {
    try {
      await _register();
      if (!_active(handshake)) return;
      await _send(handshake, {'type': 'hello', 'nonce': handshake.localNonce});
    } catch (_) {
      /* No network errors or capability contents enter chat/logs. */
    }
  }

  Future<void> _send(_Handshake handshake, Map<String, dynamic> fields,
      {bool native = false}) async {
    if (!(native ? _live(handshake) : _active(handshake))) return;
    final own = context();
    await handshake.channel.send('$familyChatPrefix${jsonEncode({
          'v': 1,
          'installationId': store.identity!.installationId,
          'peerId': own.peerId,
          'serverScope': own.serverScope,
          ...fields
        })}');
  }

  /// Recognized internal frames are hidden even when malformed or unauthorized.
  bool consumeChat(String channelId, String text) {
    if (!text.startsWith(familyChatPrefix)) return false;
    final handshake = _channels[channelId];
    if (handshake == null || !_live(handshake) || text.length > 8192) {
      return true;
    }
    try {
      final data = jsonDecode(text.substring(familyChatPrefix.length));
      if (data is! Map<String, dynamic> ||
          data.length > 16 ||
          data['v'] != 1 ||
          data['peerId'] != handshake.channel.peerId ||
          data['serverScope'] != handshake.scope ||
          !validFamilyToken(data['installationId'], 16) ||
          data['installationId'] == store.identity!.installationId) return true;
      final allowed = switch (data['type']) {
        'call.ping' || 'call.pong' => {
            'v',
            'type',
            'installationId',
            'peerId',
            'serverScope',
            'pairId',
            'requestId',
            'challenge',
            'firstFrame'
          },
        'call.end' => {
            'v',
            'type',
            'installationId',
            'peerId',
            'serverScope',
            'pairId',
            'requestId',
            'reason'
          },
        'hello' => {
            'v',
            'type',
            'installationId',
            'peerId',
            'serverScope',
            'nonce'
          },
        'offer' => {
            'v',
            'type',
            'installationId',
            'peerId',
            'serverScope',
            'nonce',
            'pairId',
            'capability',
            'elderInstallationId',
            'elderPeerId',
            'helperInstallationId',
            'helperPeerId',
            'recipientNonce',
            'senderNonce'
          },
        'confirmed' => {
            'v',
            'type',
            'installationId',
            'peerId',
            'serverScope',
            'nonce',
            'pairId',
            'recipientNonce',
            'senderNonce'
          },
        _ => <String>{},
      };
      if (data.keys.any((key) => !allowed.contains(key))) return true;
      unawaited(_receive(handshake, data).catchError((Object _) {}));
    } catch (_) {
      /* Invalid internal payloads are dropped, never shown as chat. */
    }
    return true;
  }

  Future<void> _receive(_Handshake handshake, Map<String, dynamic> data) async {
    if (['call.ping', 'call.pong', 'call.end'].contains(data['type'])) {
      await _receiveCall(handshake, data);
      return;
    }
    if (!_active(handshake)) return;
    if (data['type'] == 'hello') {
      if (!validFamilyToken(data['nonce'], 16)) return;
      // An installation cannot change midway through an authorized channel.
      if (handshake.remoteInstallationId.isNotEmpty &&
          handshake.remoteInstallationId != data['installationId']) return;
      if (handshake.remoteNonce.isNotEmpty &&
          handshake.remoteNonce != data['nonce']) return;
      handshake.remoteInstallationId = data['installationId'];
      handshake.remoteNonce = data['nonce'];
      if (handshake.channel.direction == FamilyDirection.outgoingElder &&
          handshake.channel.encrypted) await _offer(handshake);
    } else if (data['type'] == 'offer') {
      if (handshake.channel.direction != FamilyDirection.incomingHelper ||
          data['recipientNonce'] != handshake.localNonce ||
          data['senderNonce'] != handshake.remoteNonce ||
          data['installationId'] != handshake.remoteInstallationId ||
          !validFamilyToken(data['pairId'], 16) ||
          !validFamilyToken(data['capability'], 32) ||
          !validFamilyToken(data['nonce'], 16) ||
          data['elderInstallationId'] != store.identity!.installationId ||
          data['elderPeerId'] != context().peerId ||
          data['helperInstallationId'] != handshake.remoteInstallationId ||
          data['helperPeerId'] != handshake.channel.peerId) return;
      final binding = store.find(handshake.channel.peerId, handshake.scope,
          FamilyDirection.incomingHelper);
      if (binding == null) return;
      await _register();
      if (!_active(handshake)) return;
      await transport.call('pair.confirm', {
        'pairId': data['pairId'],
        'capability': data['capability'],
        'nonce': data['nonce']
      });
      if (!_active(handshake)) return;
      binding.ownPeerId = context().peerId;
      binding.pairId = data['pairId'];
      binding.capability = data['capability'];
      binding.nonce = data['nonce'];
      binding.remoteInstallationId = handshake.remoteInstallationId;
      // Only the backend's confirmed pair record makes a contact directReady.
      binding.confirmed = false;
      await _save();
      await _send(handshake, {
        'type': 'confirmed',
        'pairId': binding.pairId,
        'nonce': binding.nonce,
        'recipientNonce': handshake.remoteNonce,
        'senderNonce': handshake.localNonce
      });
      await poll();
    } else if (data['type'] == 'confirmed') {
      if (handshake.channel.direction != FamilyDirection.outgoingElder ||
          data['recipientNonce'] != handshake.localNonce ||
          data['senderNonce'] != handshake.remoteNonce ||
          data['installationId'] != handshake.remoteInstallationId) return;
      final binding = store.find(handshake.channel.peerId, handshake.scope,
          FamilyDirection.outgoingElder);
      if (binding == null ||
          binding.pairId != data['pairId'] ||
          binding.nonce != data['nonce']) return;
      await poll();
    }
  }

  Future<void> _offer(_Handshake handshake) async {
    if (handshake.offering || !_active(handshake)) return;
    final binding = store.find(handshake.channel.peerId, handshake.scope,
        FamilyDirection.outgoingElder);
    if (binding == null) return;
    handshake.offering = true;
    try {
      await _register();
      if (!_active(handshake)) return;
      // The other side may have sent hello before our registration completed.
      // Put our public nonce on the ordered channel before sending its bound offer.
      await _send(handshake, {'type': 'hello', 'nonce': handshake.localNonce});
      if (!binding.hasCapability ||
          binding.remoteInstallationId != handshake.remoteInstallationId ||
          binding.ownPeerId != context().peerId) {
        binding.pairId = familyToken(16);
        binding.capability = familyToken(32);
        binding.nonce = familyToken(16);
        binding.remoteInstallationId = handshake.remoteInstallationId;
        binding.ownPeerId = context().peerId;
        binding.confirmed = false;
        await store.save();
      }
      final fields = {
        'pairId': binding.pairId,
        'capability': binding.capability,
        'nonce': binding.nonce,
        'elderInstallationId': binding.remoteInstallationId,
        'elderPeerId': binding.peerId,
        'helperInstallationId': store.identity!.installationId,
        'helperPeerId': binding.ownPeerId,
        'serverScope': binding.serverScope
      };
      await transport.call('pair.offer', fields);
      if (!_active(handshake)) return;
      await _send(handshake, {
        'type': 'offer',
        ...fields,
        'recipientNonce': handshake.remoteNonce,
        'senderNonce': handshake.localNonce
      });
    } finally {
      handshake.offering = false;
    }
  }

  _Handshake? _requestChannel(_Request request) {
    final handshake = _channels[request.channelId];
    if (handshake == null ||
        !_live(handshake) ||
        handshake.channel.peerId != request.binding.peerId ||
        handshake.scope != request.binding.serverScope ||
        handshake.channel.direction != request.binding.direction ||
        (request.incoming && !handshake.channel.encrypted)) return null;
    return handshake;
  }

  bool _healthy(_Request request) =>
      request.nativeStarted &&
      _requestChannel(request) != null &&
      request.healthyAt != null &&
      now().difference(request.healthyAt!).inMilliseconds >= 0 &&
      now().difference(request.healthyAt!) < familyNativeHealthFreshness;

  void _startHealthChecks() {
    _healthTimer ??= Timer.periodic(familyNativePingInterval, (_) {
      final request = _request;
      if (request != null && request.nativeStarted) {
        unawaited(_probeNative(request, force: true));
      }
    });
  }

  Future<bool> _probeNative(_Request request, {bool force = false}) async {
    if (!identical(_request, request) || !request.nativeStarted) return false;
    if (!force && _healthy(request)) return true;
    if (request.probe != null) return request.probe!.future;
    final channel = _requestChannel(request);
    if (channel == null) return false;
    final probe = Completer<bool>();
    request.probe = probe;
    request.challenge = familyToken(16);
    request.probeFailed = false;
    void failed() {
      if (!identical(_request, request) || request.probe != probe) return;
      request.probeTimer?.cancel();
      request.probe = null;
      request.challenge = null;
      request.probeFailed = true;
      if (!request.expiresAt.isAfter(now())) request.expiryProbeStarted = true;
      if (!probe.isCompleted) probe.complete(false);
      expire();
    }

    request.probeTimer = Timer(familyNativeProbeTimeout, failed);
    unawaited(_send(
            channel,
            {
              'type': 'call.ping',
              'pairId': request.binding.pairId,
              'requestId': request.requestId,
              'challenge': request.challenge,
              'firstFrame':
                  request.incoming && _firstFramePeer == request.binding.peerId,
            },
            native: true)
        .catchError((Object _) {
      failed();
    }));
    return probe.future;
  }

  Future<void> _receiveCall(
      _Handshake channel, Map<String, dynamic> data) async {
    final request = _request;
    if (request == null ||
        !_live(channel) ||
        !request.binding.confirmed ||
        data['requestId'] != request.requestId ||
        data['pairId'] != request.binding.pairId ||
        data['installationId'] != request.binding.remoteInstallationId ||
        channel.channel.peerId != request.binding.peerId ||
        channel.channel.direction != request.binding.direction ||
        channel.scope != request.binding.serverScope ||
        request.binding.ownPeerId != context().peerId ||
        (request.incoming &&
            (!channel.channel.encrypted || !_acceptedLocally)) ||
        (request.channelId != null && request.channelId != channel.channel.id)) {
      return;
    }
    if (data['type'] == 'call.end') {
      if (['ended', 'failed', 'cancelled'].contains(data['reason'])) {
        _finishRemote(request, data['reason'] as String);
      }
      return;
    }
    if (!request.nativeStarted && !request.expiresAt.isAfter(now())) {
      expire();
      return;
    }
    if (!validFamilyToken(data['challenge'], 16) || data['firstFrame'] is! bool) {
      return;
    }
    if (data['type'] == 'call.pong' &&
        (request.probe == null || request.challenge != data['challenge'])) {
      return;
    }
    // The helper must have observed a native frame. The elder learns that only
    // from this exact authorized helper/channel, never from an HTTP 'active'.
    if (request.incoming
        ? _firstFramePeer != request.binding.peerId
        : data['firstFrame'] != true) return;
    request.channelId ??= channel.channel.id;
    request.nativeStarted = true;
    requestStatus = FamilyRequestStatus.active;
    _startHealthChecks();
    if (data['type'] == 'call.ping') {
      await _send(
          channel,
          {
            'type': 'call.pong',
            'pairId': request.binding.pairId,
            'requestId': request.requestId,
            'challenge': data['challenge'],
            'firstFrame': request.incoming,
          },
          native: true);
      // Receipt alone is one-way evidence; also require our own random round trip.
      unawaited(_probeNative(request));
    } else {
      request.healthyAt = now();
      request.expiryProbeStarted = false;
      request.probeFailed = false;
      request.probeTimer?.cancel();
      final probe = request.probe!;
      request.probe = null;
      request.challenge = null;
      probe.complete(true);
      _changed();
    }
  }

  void _finishRemote(_Request request, String reason) {
    if (!identical(_request, request)) return;
    store.markCompleted(request.requestId);
    _clearRequest();
    requestStatus = FamilyRequestStatus.idle;
    requestError = switch (reason) {
      'declined' => '家人暂时不方便，稍后再打。',
      'expired' => '这次呼叫已超时，可以重新呼叫。',
      'failed' => '这次没有接通，可以重新呼叫。',
      'cancelled' => '对方已取消呼叫。',
      'ended' => '协助已结束。',
      'revoked' => '家人配对已解除，请重新邀请。',
      _ => null,
    };
    lastEnd = FamilyCallEnd(
        request.requestId, request.binding.peerId, request.incoming, reason);
    onRemoteEnd?.call(lastEnd!);
    unawaited(_save());
    _changed();
  }

  bool _validTimes(Map data) {
    final created = data['createdAt'], expires = data['expiresAt'];
    final timestamp = now().millisecondsSinceEpoch;
    if (created is! int ||
        expires is! int ||
        created < 0 ||
        created > timestamp + 10000 ||
        expires <= created) return false;
    if (data['leaseMode'] == 'native-v1') {
      final connected = data['connectedAt'], updated = data['leaseUpdatedAt'];
      return connected is int &&
          updated is int &&
          connected >= created &&
          connected <= updated &&
          updated <= timestamp + 10000 &&
          expires > updated &&
          expires - updated <= 60000;
    }
    return expires - created <= (data['connectedAt'] is int ? 3600000 : 120000);
  }

  bool _matchesPair(FamilyBinding binding, Map data, {bool current = true}) {
    final owner = store.identity!.installationId;
    final incoming = binding.direction == FamilyDirection.incomingHelper;
    return data['pairId'] == binding.pairId &&
        data['serverScope'] == binding.serverScope &&
        data['elderInstallationId'] ==
            (incoming ? owner : binding.remoteInstallationId) &&
        data['helperInstallationId'] ==
            (incoming ? binding.remoteInstallationId : owner) &&
        data['elderPeerId'] ==
            (incoming ? binding.ownPeerId : binding.peerId) &&
        data['helperPeerId'] ==
            (incoming ? binding.peerId : binding.ownPeerId) &&
        (!current ||
            (binding.ownPeerId == context().peerId &&
                binding.serverScope == context().serverScope));
  }

  Future<void> poll() async {
    if (_polling ||
        _disposed ||
        _rekeying ||
        !_foreground ||
        !context().valid ||
        store.members.isEmpty) return;
    _polling = true;
    final generation = _generation;
    try {
      final checking = _request;
      if (checking != null && checking.nativeStarted) {
        await _probeNative(checking);
      }
      if (generation != _generation || _disposed) return;
      expire();
      await _register();
      if (_request?.incoming == true &&
          requestStatus == FamilyRequestStatus.active &&
          (_lastProgressAt == null ||
              now().difference(_lastProgressAt!).inSeconds >= 25)) {
        await firstFrame(_request!.binding.peerId,
            channelId: _request!.channelId);
      }
      for (final ending in _ends.values.toList()) {
        if (!ending.retryUntil.isAfter(now())) {
          _ends.remove(ending.request.requestId);
        } else {
          try {
            await _endRemote(ending);
          } catch (_) {/* Retry on the next foreground poll. */}
        }
      }
      for (final withdrawal in _withdrawals.values.toList()) {
        if (!withdrawal.expiresAt.isAfter(now())) {
          _withdrawals.remove(withdrawal.requestId);
        } else {
          try {
            await _cancelRemote(withdrawal);
            _withdrawals.remove(withdrawal.requestId);
          } catch (_) {
            /* Retry while foreground and before the short TTL expires. */
          }
        }
      }
      final polledRequest = _request;
      final polledEpoch = _requestEpoch;
      final data = await transport.call('poll', {
        'pairIds': store.members
            .where((m) => m.hasCapability)
            .map((m) => m.pairId)
            .toList()
      });
      if (generation != _generation ||
          _disposed ||
          polledEpoch != _requestEpoch ||
          !identical(polledRequest, _request)) return;
      final pairs = data['pairs'];
      final requests = data['requests'];
      if (pairs is! List ||
          requests is! List ||
          pairs.length > 40 ||
          requests.length > 100) return;
      for (final binding in store.members) {
        if (!binding.hasCapability) continue;
        if (pairs.any((p) =>
            p is Map &&
            _matchesPair(binding, p, current: false) &&
            ['revoked', 'expired', 'stale'].contains(p['status']))) {
          if (_request?.binding == binding) _finishRemote(_request!, 'revoked');
          binding.confirmed = false;
          binding.pairId = '';
          binding.capability = '';
          binding.nonce = '';
          binding.remoteInstallationId = '';
          // A revoked relation can only be re-established by a new approved session.
          for (final id in _channels.keys.toList()) {
            final channel = _channels[id]!;
            if (channel.channel.peerId == binding.peerId &&
                channel.scope == binding.serverScope &&
                channel.channel.direction == binding.direction) {
              disconnected(id);
            }
          }
          continue;
        }
        binding.confirmed = pairs.any((p) =>
            p is Map && _matchesPair(binding, p) && p['status'] == 'confirmed');
      }
      for (final item in requests) {
        if (item is! Map ||
            !validFamilyToken(item['requestId'], 16) ||
            item['expiresAt'] is! int ||
            item['createdAt'] is! int) continue;
        final expires = DateTime.fromMillisecondsSinceEpoch(item['expiresAt']);
        if (!_validTimes(item)) continue;
        FamilyBinding? binding;
        for (final member in store.members) {
          if (member.pairId == item['pairId'] &&
              member.confirmed &&
              member.ownPeerId == context().peerId &&
              member.serverScope == context().serverScope) {
            binding = member;
            break;
          }
        }
        if (binding == null) continue;
        final incoming = binding.direction == FamilyDirection.outgoingElder;
        if (item['elderPeerId'] !=
                (incoming ? binding.peerId : binding.ownPeerId) ||
            item['helperPeerId'] !=
                (incoming ? binding.ownPeerId : binding.peerId)) continue;
        final id = item['requestId'] as String;
        if (store.completed.contains(id)) continue;
        final status = item['status'];
        if (![
          'queued',
          'observed',
          'accepted',
          'active',
          'interrupted',
          'ended',
          'cancelled',
          'failed',
          'declined',
          'expired',
          'revoked'
        ].contains(status)) continue;
        final previous = _request;
        if (previous != null &&
            previous.nativeStarted &&
            previous.requestId != id &&
            previous.binding.pairId == binding.pairId &&
            requests
                    .where((r) => r is Map && r['pairId'] == binding!.pairId)
                    .length ==
                1) {
          _finishRemote(previous, 'superseded');
        }
        if (status == 'interrupted' ||
            (status == 'expired' && !_serverRecovery)) {
          final current = _request;
          if (current?.requestId == id &&
              current!.nativeStarted &&
              _healthy(current)) {
            // Keep only this already-running engine session. No accept, connect,
            // new call ID, capture permission, or ringing is triggered here.
            continue;
          }
          if (status == 'interrupted') {
            if (current?.requestId == id) _finishRemote(current!, 'expired');
            continue;
          }
        }
        if (!expires.isAfter(now()) &&
            ['queued', 'observed', 'accepted', 'active'].contains(status)) {
          continue;
        }
        if (status == 'queued' || status == 'observed') {
          if (_request == null) {
            _request = _Request(binding, id, expires, incoming);
            requestStatus = incoming
                ? FamilyRequestStatus.received
                : FamilyRequestStatus.waiting;
            requestError = null;
          }
          if (!incoming &&
              _request?.requestId == id &&
              status == 'observed' &&
              !_request!.nativeStarted) {
            requestStatus = FamilyRequestStatus.ringing;
          }
        } else if ((status == 'accepted' || status == 'active') &&
            (!incoming || (_acceptedLocally && _request?.requestId == id))) {
          // An active history record must never recreate a local native call.
          if (_request == null && status == 'active') continue;
          _request ??= _Request(binding, id, expires, incoming);
          if (_request?.requestId == id) {
            _request!.expiresAt = expires;
            _request!.nativeLease = item['leaseMode'] == 'native-v1';
            requestStatus = status == 'active' || _request!.nativeStarted
                ? FamilyRequestStatus.active
                : FamilyRequestStatus.connecting;
            requestError = null;
          }
        } else if (!['accepted', 'active'].contains(status)) {
          store.markCompleted(id);
          if (_request?.requestId == id) {
            _finishRemote(_request!, status.toString());
          }
        }
      }
      if (_request != null && !_request!.binding.confirmed) {
        _finishRemote(_request!, 'revoked');
      }
      await _save();
      _changed();
    } catch (_) {
      if (_request != null && generation == _generation) {
        // A service outage needs no elder action while this authorized native
        // call has fresh round-trip health. Also clear earlier retry copy.
        requestError = _healthy(_request!)
            ? null
            : '暂时无法更新求助状态，回到应用后可重试。';
        _changed();
      }
    } finally {
      _polling = false;
    }
  }

  void expire() {
    final request = _request;
    if (request != null &&
        (request.binding.serverScope != context().serverScope ||
            request.binding.ownPeerId != context().peerId ||
            !store.members.contains(request.binding))) {
      _finishRemote(request, 'revoked');
      return;
    }
    if (_request != null && !_request!.expiresAt.isAfter(now())) {
      final expired = _request!;
      if (expired.nativeStarted && _requestChannel(expired) != null) {
        // A suspended runtime cannot give fresh health evidence. Revalidate on
        // foreground return; native disconnect/revocation still ends immediately.
        if (!_foreground || _healthy(expired)) return;
        if (!expired.expiryProbeStarted) {
          expired.expiryProbeStarted = true;
          unawaited(_probeNative(expired, force: true));
          return;
        }
        if (expired.probe != null && !expired.probeFailed) return;
      }
      _finishRemote(expired, 'expired');
    }
  }

  Future<void> requestHelp(String peerId, bool Function() sharingReady) async {
    if (!sharingReady()) {
      requestError = '请先开启远程操作并开始屏幕共享，再邀请这个家人。';
      requestStatus = FamilyRequestStatus.failed;
      _changed();
      return;
    }
    if (_sending || _disposed || !_foreground) return;
    final own = context();
    final binding =
        store.find(peerId, own.serverScope, FamilyDirection.incomingHelper);
    if (binding == null ||
        !binding.confirmed ||
        !binding.hasCapability ||
        binding.ownPeerId != own.peerId) {
      requestError = '这位家人还未完成配对，请先通过分享邀请完成一次协助。';
      requestStatus = FamilyRequestStatus.failed;
      _changed();
      return;
    }
    expire();
    if (_request != null && requestStatus != FamilyRequestStatus.failed) return;
    if (_request != null &&
        (_request!.incoming || _request!.binding != binding)) {
      await cancelOutgoing();
    }
    final request = _request ??
        _Request(binding, familyToken(16),
            now().add(const Duration(seconds: 120)), false);
    _request = request;
    _acceptedLocally = false;
    _lastProgressAt = null;
    _firstFramePeer = null;
    _firstFrameChannelId = null;
    lastEnd = null;
    _sending = true;
    final epoch = ++_requestEpoch;
    bool ready() =>
        sharingReady() &&
        binding.serverScope == context().serverScope &&
        binding.ownPeerId == context().peerId &&
        store.members.contains(binding);
    requestStatus = FamilyRequestStatus.sending;
    requestError = null;
    _changed();
    try {
      await _register();
      if (!ready() || epoch != _requestEpoch) {
        if (epoch == _requestEpoch) {
          _clearRequest();
          requestStatus = FamilyRequestStatus.failed;
          requestError = '屏幕共享已结束，请重新开始后再邀请家人。';
        }
        return;
      }
      final response = await transport.call('request.create', {
        'pairId': binding.pairId,
        'capability': binding.capability,
        'requestId': request.requestId
      });
      if (!ready() || epoch != _requestEpoch || _disposed || !_foreground) {
        _withdrawals[request.requestId] = request;
        await _cancelRemote(request);
        _withdrawals.remove(request.requestId);
        if (identical(_request, request)) {
          _clearRequest();
          requestStatus = FamilyRequestStatus.idle;
        }
        return;
      }
      final returned = response['request'];
      if (returned is! Map ||
          !_validRequest(returned, request, {'queued', 'observed'})) {
        throw const FamilyNetworkException();
      }
      // A queued request means saved for the helper's next foreground poll, not delivered.
      requestStatus = FamilyRequestStatus.waiting;
      requestError = null;
      final serverExpiry =
          DateTime.fromMillisecondsSinceEpoch(returned['expiresAt']);
      _request = _Request(
          binding,
          request.requestId,
          serverExpiry.isBefore(request.expiresAt)
              ? serverExpiry
              : request.expiresAt,
          false);
    } catch (_) {
      if (epoch != _requestEpoch || !ready()) {
        _withdrawals[request.requestId] = request;
        if (identical(_request, request)) {
          _clearRequest();
          requestStatus = FamilyRequestStatus.idle;
        }
      }
      if (epoch == _requestEpoch && ready() && !_disposed) {
        requestStatus = FamilyRequestStatus.failed;
        requestError = '求助暂时无法发送，请检查网络后重试。';
      }
    } finally {
      _sending = false;
      _changed();
    }
  }

  bool _validRequest(Map data, _Request request, Set<String> statuses) {
    return data['pairId'] == request.binding.pairId &&
        data['requestId'] == request.requestId &&
        data['elderPeerId'] ==
            (request.incoming
                ? request.binding.peerId
                : request.binding.ownPeerId) &&
        data['helperPeerId'] ==
            (request.incoming
                ? request.binding.ownPeerId
                : request.binding.peerId) &&
        statuses.contains(data['status']) &&
        _validTimes(data) &&
        data['expiresAt'] > now().millisecondsSinceEpoch;
  }

  Future<void> _cancelRemote(_Request request) async {
    await transport.call('request.cancel', {
      'pairId': request.binding.pairId,
      'capability': request.binding.capability,
      'requestId': request.requestId
    });
  }

  Future<void> cancelOutgoing() async {
    final request = _request;
    if (request == null || request.incoming) return;
    lastEnd = FamilyCallEnd(
        request.requestId, request.binding.peerId, false, 'cancelled');
    _clearRequest();
    store.markCompleted(request.requestId);
    _withdrawals[request.requestId] = request;
    requestStatus = FamilyRequestStatus.idle;
    requestError = null;
    _changed();
    await _save();
    try {
      await _cancelRemote(request);
      _withdrawals.remove(request.requestId);
    } catch (_) {
      requestError = '本机已停止求助，网络未确认撤回；请求会在两分钟内过期。';
      _changed();
    }
  }

  Future<String?> accept(bool Function() idle) async {
    expire();
    final request = _request;
    if (request == null ||
        !request.incoming ||
        !idle() ||
        !_foreground ||
        _acceptedLocally ||
        _responding) {
      return null;
    }
    _responding = true;
    requestStatus = FamilyRequestStatus.connecting;
    requestError = null;
    _changed();
    final generation = _generation;
    bool current() =>
        generation == _generation &&
        !_disposed &&
        _foreground &&
        idle() &&
        request.expiresAt.isAfter(now()) &&
        identical(_request, request) &&
        request.binding.serverScope == context().serverScope &&
        request.binding.ownPeerId == context().peerId &&
        store.members.contains(request.binding);
    try {
      final response = await transport.call('request.respond', {
        'pairId': request.binding.pairId,
        'capability': request.binding.capability,
        'requestId': request.requestId,
        'decision': 'accept'
      });
      final returned = response['request'];
      if (returned is! Map || !_validRequest(returned, request, {'accepted'})) {
        throw const FamilyNetworkException();
      }
      if (!current()) {
        if (identical(_request, request)) await endCall(reason: 'cancelled');
        return null;
      }
      _acceptedLocally = true;
      await _save();
      if (!current()) {
        if (identical(_request, request)) await endCall(reason: 'cancelled');
        return null;
      }
      _changed();
      return request.binding
          .peerId; // The helper connects to the elder, never vice versa.
    } catch (_) {
      if (identical(_request, request) &&
          generation == _generation &&
          !_disposed) {
        requestStatus = FamilyRequestStatus.failed;
        requestError = '暂时无法接受求助，请重试。';
        _changed();
      }
      return null;
    } finally {
      _responding = false;
    }
  }

  /// Associates the helper's newly created page/session with an accepted call.
  /// This is routing only, and cannot confer native authorization or health.
  void attachOutgoingCall(String peerId, String channelId) {
    final request = _request;
    if (request == null ||
        !request.incoming ||
        !_acceptedLocally ||
        request.binding.peerId != peerId ||
        request.channelId != null ||
        channelId.isEmpty) return;
    request.channelId = channelId;
  }

  bool ownsOutgoingChannel(String channelId) =>
      _request?.incoming == true && _request?.channelId == channelId;

  void connectionFinished({String? channelId}) {
    unawaited(endCall(
        channelId: channelId,
        reason: requestStatus == FamilyRequestStatus.active
            ? 'ended'
            : 'cancelled'));
  }

  /// Called only by the native first-image callback; acceptance is insufficient.
  Future<void> firstFrame(String peerId, {String? channelId}) async {
    final request = _request;
    if (request == null ||
        !request.incoming ||
        !_acceptedLocally ||
        request.binding.peerId != peerId ||
        (request.channelId != null &&
            channelId != null &&
            request.channelId != channelId) ||
        request.publishingProgress) return;
    if (!request.nativeStarted && !request.expiresAt.isAfter(now())) {
      expire();
      return;
    }
    _firstFramePeer = peerId;
    _firstFrameChannelId = channelId;
    final matching = _channels.values.where((h) =>
        h.channel.peerId == peerId &&
        h.channel.direction == FamilyDirection.outgoingElder &&
        (channelId == null || h.channel.id == channelId) &&
        _live(h));
    if (matching.length != 1) return;
    final channel = matching.first;
    if (request.channelId != null && request.channelId != channel.channel.id) {
      return;
    }
    request.channelId = channel.channel.id;
    request.nativeStarted = true;
    _startHealthChecks();
    request.publishingProgress = true;
    _lastProgressAt = now();
    requestStatus = FamilyRequestStatus.active;
    _changed();
    try {
      await _probeNative(request);
      if (!identical(_request, request) || _disposed || !_foreground) return;
      if (request.nativeLease && !_healthy(request)) return;
      final response = await transport.call('request.progress', {
        'pairId': request.binding.pairId,
        'capability': request.binding.capability,
        'requestId': request.requestId,
        if (_serverRecovery && _healthy(request)) 'leaseMode': 'native-v1',
      });
      final data = response['request'];
      if (identical(_request, request) &&
          data is Map &&
          _validRequest(data, request, {'active'})) {
        request.expiresAt =
            DateTime.fromMillisecondsSinceEpoch(data['expiresAt']);
        request.nativeLease = data['leaseMode'] == 'native-v1';
      }
    } catch (_) {
      /* The native connection remains usable; retry the lease at next poll. */
    } finally {
      request.publishingProgress = false;
    }
  }

  Future<void> endCall({String reason = 'ended', String? channelId}) async {
    final request = _request;
    if (request == null ||
        (channelId != null && request.channelId != channelId)) return;
    final channel = _requestChannel(request);
    if (channel != null) {
      unawaited(_send(
              channel,
              {
                'type': 'call.end',
                'pairId': request.binding.pairId,
                'requestId': request.requestId,
                'reason': ['ended', 'failed', 'cancelled'].contains(reason)
                    ? reason
                    : 'ended',
              },
              native: true)
          .catchError((Object _) {}));
    }
    lastEnd = FamilyCallEnd(
        request.requestId, request.binding.peerId, request.incoming, reason);
    _clearRequest();
    store.markCompleted(request.requestId);
    requestStatus = FamilyRequestStatus.idle;
    final ending = _PendingEnd(
        request,
        ['ended', 'failed', 'cancelled'].contains(reason) ? reason : 'ended',
        now().add(familyEndRetryWindow));
    _ends[request.requestId] = ending;
    while (_ends.length > 20) {
      _ends.remove(_ends.keys.first);
    }
    _changed();
    await _save();
    try {
      await _endRemote(ending);
    } catch (_) {
      requestError = '本机已挂断，对方的提醒会在请求过期后结束。';
      _changed();
    }
  }

  Future<void> _endRemote(_PendingEnd ending) async {
    final request = ending.request;
    await transport.call('request.end', {
      'pairId': request.binding.pairId,
      'capability': request.binding.capability,
      'requestId': request.requestId,
      'reason': ending.reason,
    });
    _ends.remove(request.requestId);
  }

  Future<void> decline() async {
    final request = _request;
    if (request == null || !request.incoming || _responding) return;
    lastEnd = FamilyCallEnd(
        request.requestId, request.binding.peerId, true, 'declined');
    _clearRequest();
    store.markCompleted(request.requestId);
    requestStatus = FamilyRequestStatus.idle;
    requestError = null;
    _changed();
    await _save();
    try {
      await transport.call('request.respond', {
        'pairId': request.binding.pairId,
        'capability': request.binding.capability,
        'requestId': request.requestId,
        'decision': 'decline'
      });
    } catch (_) {
      requestError = '本机已忽略求助，网络未确认；请求会自动过期。';
      _changed();
    }
  }

  Future<void> rename(String peerId, String name) async {
    for (final binding in store.members.where(
        (m) => m.peerId == peerId && m.serverScope == context().serverScope)) {
      binding.name = familyDisplayName(name, peerId);
    }
    await _save();
    _changed();
  }

  Future<void> forget(String peerId) async {
    final removed = store.members
        .where(
            (m) => m.peerId == peerId && m.serverScope == context().serverScope)
        .toList();
    if (_request?.binding.peerId == peerId) {
      _finishRemote(_request!, 'revoked');
    }
    for (final channelId in _channels.keys.toList()) {
      if (_channels[channelId]!.channel.peerId == peerId) {
        disconnected(channelId);
      }
    }
    store.members.removeWhere(removed.contains);
    await _save();
    _changed();
    for (final binding in removed.where((m) => m.hasCapability)) {
      try {
        await transport.call('pair.forget',
            {'pairId': binding.pairId, 'capability': binding.capability});
      } catch (_) {
        requestError = '家人已从本机移除，网络未确认撤销；对方仍需你批准才能协助。';
        _changed();
      }
    }
  }

  void setForeground(bool active) {
    if (_disposed || _foreground == active) return;
    _foreground = active;
    ++_generation;
    if (_rekeying) return;
    final request = _request;
    if (request != null) {
      request.probeTimer?.cancel();
      final probe = request.probe;
      request.probe = null;
      request.challenge = null;
      if (probe != null && !probe.isCompleted) probe.complete(false);
    }
    if (active) {
      _request?.healthyAt = null;
      _request?.expiryProbeStarted = false;
      transport.resume();
      for (final handshake in _channels.values) {
        if (_active(handshake)) unawaited(_hello(handshake));
      }
      unawaited(poll());
    } else {
      transport.suspend();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _clearRequest();
    ++_generation;
    ++_requestEpoch;
    for (final id in _channels.keys.toList()) {
      disconnected(id);
    }
    transport.dispose();
    super.dispose();
  }
}
