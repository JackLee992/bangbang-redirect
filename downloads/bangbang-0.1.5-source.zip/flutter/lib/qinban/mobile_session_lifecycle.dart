import 'dart:async';

/// Mobile uses one shared FFI session. A new route must not start while the
/// previous route is still releasing that session after asynchronous teardown.
class MobileSessionLifecycle {
  static Future<void> _closing = Future.value();
  static Future<void> waitForIdle() => _closing;
  static Completer<void> beginClose() {
    final completion = Completer<void>();
    _closing = Future.wait<void>([_closing, completion.future]).then((_) {});
    return completion;
  }
}
