import 'dart:async';
import 'dart:convert';
import 'performance_report.dart';

/// A separate small queue. No session/peer/credential is persisted here.
/// Changing the upload preference drops this queue and aborts active transport.
class RemotePerformanceQueue {
  RemotePerformanceQueue(
      {required this.write,
      required this.upload,
      this.cancelUpload,
      DateTime Function()? now,
      bool enabled = true})
      : _now = now ?? DateTime.now,
        _enabled = enabled;
  final Future<void> Function(String) write;
  final Future<bool> Function(Map<String, dynamic>) upload;
  final void Function()? cancelUpload;
  final DateTime Function() _now;
  final List<Map<String, dynamic>> _records = [];
  bool _enabled, _foreground = true, _disposed = false, _flushing = false;
  int _generation = 0;
  Timer? _retry;
  Future<void> _writes = Future.value();
  bool get allowed => !_disposed && _enabled && _foreground;
  int get pending => _records.length;
  void _prune() {
    _records.removeWhere(
        (value) => parsePerformanceReport(value, now: _now()) == null);
    while (_records.length > 10 || utf8.encode(export()).length > 131072) {
      _records.removeAt(0);
    }
  }

  String export() => jsonEncode({'v': 1, 'records': _records});
  Future<void> _save() {
    final raw = export();
    _writes = _writes.then((_) async {
      try {
        await write(raw);
      } catch (_) {}
    });
    return _writes;
  }

  void restore(String raw) {
    if (_disposed || !_enabled || utf8.encode(raw).length > 131072) return;
    try {
      final value = jsonDecode(raw);
      if (value is! Map ||
          value.length != 2 ||
          value['v'] != 1 ||
          value['records'] is! List) return;
      final seen = <String>{};
      _records.clear();
      for (final item in (value['records'] as List).reversed) {
        final record = parsePerformanceReport(item, now: _now());
        if (record == null || !seen.add(record['attemptId'])) continue;
        _records.insert(0, record);
        if (_records.length == 10) break;
      }
      _prune();
    } catch (_) {}
  }

  Future<void> enqueue(Map<String, dynamic> value) async {
    if (_disposed || !_enabled) return;
    final record = parsePerformanceReport(value, now: _now());
    if (record == null ||
        _records.any((item) => item['attemptId'] == record['attemptId'])) {
      return;
    }
    _records.add(record);
    _prune();
    await _save();
    unawaited(flush());
  }

  Future<void> setEnabled(bool value) async {
    if (_disposed || _enabled == value) return;
    _enabled = value;
    if (!value) {
      ++_generation;
      _retry?.cancel();
      _retry = null;
      cancelUpload?.call();
      _records.clear();
      await _save();
    } else {
      unawaited(flush());
    }
  }

  void setForeground(bool value) {
    if (_disposed || _foreground == value) return;
    _foreground = value;
    if (!value) {
      ++_generation;
      _retry?.cancel();
      _retry = null;
      cancelUpload?.call();
    } else {
      unawaited(flush());
    }
  }

  Future<void> flush() async {
    if (!allowed || _flushing) return;
    _flushing = true;
    _retry?.cancel();
    _retry = null;
    final generation = _generation;
    try {
      _prune();
      while (allowed && generation == _generation && _records.isNotEmpty) {
        final record = _records.first;
        bool sent;
        try {
          sent = await upload(jsonDecode(jsonEncode(record)));
        } catch (_) {
          sent = false;
        }
        if (!allowed || generation != _generation) break;
        if (!sent) break;
        if (_records.isNotEmpty && identical(_records.first, record)) {
          _records.removeAt(0);
        }
        await _save();
      }
      await _save();
    } finally {
      _flushing = false;
      if (allowed && _records.isNotEmpty) {
        _retry = Timer(const Duration(seconds: 60), () {
          unawaited(flush());
        });
      }
    }
  }

  void dispose() {
    _disposed = true;
    ++_generation;
    _retry?.cancel();
    cancelUpload?.call();
  }
}
