import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'family_store.dart';

/// This service manages membership only. It has no remote-session callbacks.
class HouseholdContact {
  const HouseholdContact(this.installationId, this.name);
  final String installationId;
  final String name;
}

class HouseholdException implements Exception {
  const HouseholdException(this.code);
  final String code;
  String get message => switch (code) {
        'not_configured' => '家庭管理暂未上线，基础协助仍可正常使用。',
        'household_unavailable' => '家庭服务暂时连不上，请稍后重试。',
        'identity_unavailable' => '身份服务暂时不可用，请稍后重试。',
        'unauthorized' || 'device_revoked' => '此设备身份已失效，请使用换机确认或恢复卡找回家庭。',
        'helper_required' ||
        'confirmed_pair_required' =>
          '请先以家人身份完成一次配对，再创建家庭或邀请这位家人。',
        'owner_required' => '只有家庭管理者可以进行此操作。',
        'not_household_member' => '你已不在这个家庭中，请刷新查看。',
        'revision_conflict' => '家庭成员已变化，请刷新后再操作。',
        'member_limit' || 'household_limit' => '当前家庭名额已满，暂时不能添加。',
        'invalid_invite' || 'invite_expired' => '邀请已失效或不属于此设备，请家人重新发送。',
        'invalid_transfer' ||
        'deadline_expired' ||
        'transfer_consumed' ||
        'transfer_changed' ||
        'transfer_target_mismatch' =>
          '换机码已失效，请在新手机重新开始换机。',
        'transfer_not_approved' => '旧手机尚未确认，请确认后再点“完成换机”。',
        'invalid_recovery' || 'recovery_changed' => '恢复卡已失效，请使用最新保存的恢复卡。',
        'new_device_has_household' => '此设备已有家庭，请先确认正在使用新手机找回。',
        'current_device_required' => '请在当前有效设备上进行此操作。',
        'owner_cannot_leave' => '家庭管理者暂不能退出家庭。',
        'rate_limited' => '操作较频繁，请稍后重试。',
        'invalid_code' => '请粘贴完整的邀请、换机码或恢复卡。',
        'invalid_display_name' => '家人称呼不符合要求，请先修改称呼再邀请。',
        'recovery_scope_changed' => '这次找回尚未确认，请回到开始找回时的家庭服务后重试。',
        'recovery_unavailable' => '请先结束当前协助，再开始换机或恢复。',
        _ => '暂时无法确认结果，请先刷新查看。若已找回家庭但没有保存恢复卡，可点“更换恢复卡”。',
      };
  // Never stringify response bodies, credentials, or user-supplied codes.
  @override
  String toString() => 'HouseholdException';
}

Uri? householdEndpoint(String value, {required bool debug}) {
  final uri = Uri.tryParse(value);
  if (uri == null ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty ||
      uri.hasQuery ||
      uri.hasFragment ||
      uri.path != '/v1/household') return null;
  if (uri.scheme == 'https') return uri;
  if (debug &&
      uri.scheme == 'http' &&
      ['localhost', '127.0.0.1', '10.0.2.2'].contains(uri.host)) return uri;
  return null;
}

bool validHouseholdCode(String code, String prefix) =>
    code.length <= 4096 && RegExp('^$prefix\\.[A-Za-z0-9_-]+\$').hasMatch(code);

class HouseholdService {
  HouseholdService(
      {required this.store,
      required this.ensureRegistered,
      required this.contacts,
      required this.prepareRecovery,
      Uri? endpoint,
      http.Client Function()? clientFactory})
      : endpoint = endpoint ??
            householdEndpoint(
                const String.fromEnvironment('QINBAN_HOUSEHOLD_URL'),
                debug: kDebugMode),
        _clientFactory = clientFactory ?? http.Client.new;

  final FamilyStore store;
  FamilyIdentity identity() => store.identity!;
  final Future<void> Function() ensureRegistered;
  final List<HouseholdContact> Function() contacts;
  final Future<void> Function(String scope) prepareRecovery;
  final Uri? endpoint;
  final http.Client Function() _clientFactory;
  bool get available => endpoint != null;
  final Set<http.Client> _clients = {};
  bool _disposed = false;
  bool get recoveryPending => store.householdRecovery != null;
  String? get transferCode => store.householdRecovery?.transferCode;
  int? get transferExpires => store.householdRecovery?.transferExpires;
  Future<void>? _preparing;

  /// A new flow replaces the existing installation before registration.
  /// Its durable pending installation survives retries and process restarts.
  Future<void> prepareNewDevice() async {
    if (!available) throw const HouseholdException('not_configured');
    if (recoveryPending) {
      _pending();
      return;
    }
    if (_preparing != null) return _preparing;
    final future = () async {
      try {
        await prepareRecovery(endpoint!.toString());
      } catch (_) {
        throw const HouseholdException('recovery_unavailable');
      }
      _pending();
    }();
    _preparing = future;
    try {
      await future;
    } finally {
      _preparing = null;
    }
  }

  HouseholdRecoveryState _pending() {
    final pending = store.householdRecovery;
    if (pending == null) throw const HouseholdException('recovery_unavailable');
    if (pending.installationId != identity().installationId ||
        pending.scope != endpoint.toString()) {
      throw const HouseholdException('recovery_scope_changed');
    }
    return pending;
  }

  Future<void> recoveryCompleted() => store.saveHouseholdRecovery(null);

  /// A user-id change on this exact fresh installation proves the server has
  /// committed the replacement, including a recovery of an empty household.
  /// Never replay a one-time proof until this checkpoint has been checked.
  Future<Map<String, dynamic>?> resumeRecovery() async {
    if (!recoveryPending) return null;
    final pending = _pending();
    final current = await call('household.list');
    final userId = current['userId'];
    if (userId is! String ||
        userId.isEmpty ||
        current['currentInstallationId'] != pending.installationId) {
      throw const HouseholdException('network');
    }
    if (pending.initialUserId == null) {
      await store.saveHouseholdRecovery(HouseholdRecoveryState(
          installationId: pending.installationId,
          scope: pending.scope,
          initialUserId: userId,
          transferCode: pending.transferCode,
          transferExpires: pending.transferExpires));
      return null;
    }
    if (pending.initialUserId == userId) return null;
    final devices = await call('device.list');
    final entries = devices['devices'];
    if (devices['userId'] != userId ||
        entries is! List ||
        !entries.whereType<Map>().any((device) =>
            device['installationId'] == pending.installationId &&
            device['status'] == 'active')) {
      throw const HouseholdException('network');
    }
    // The previous one-time card may have been lost with the response. The
    // retained current identity can safely replace it and display a new card.
    final card = await call('recovery.rotate', {'confirmed': true});
    return {...current, ...card};
  }

  Future<Map<String, dynamic>> call(String op,
      [Map<String, dynamic> fields = const {}]) async {
    if (!available) throw const HouseholdException('not_configured');
    if (_disposed) throw const HouseholdException('network');
    if (['device.transfer.begin', 'device.transfer.complete', 'recovery.redeem']
        .contains(op)) {
      _pending();
      final completed = await resumeRecovery();
      if (completed != null) return completed;
      final pending = _pending();
      if (op == 'device.transfer.begin' &&
          pending.transferCode != null &&
          (pending.transferExpires ?? 0) >
              DateTime.now().millisecondsSinceEpoch) {
        return {
          'transferCode': pending.transferCode,
          'expiresAt': pending.transferExpires
        };
      }
    }
    final result = await _request(op, fields);
    if (op == 'device.transfer.begin') {
      final code = result['transferCode'];
      if (code is! String || !validHouseholdCode(code, 'BHT1')) {
        throw const HouseholdException('network');
      }
      final pending = _pending();
      await store.saveHouseholdRecovery(HouseholdRecoveryState(
          installationId: pending.installationId,
          scope: pending.scope,
          initialUserId: pending.initialUserId,
          transferCode: code,
          transferExpires:
              result['expiresAt'] is int ? result['expiresAt'] : null));
    }
    return result;
  }

  Future<Map<String, dynamic>> _request(
      String op, Map<String, dynamic> fields) async {
    http.Client? client;
    try {
      await ensureRegistered();
      if (_disposed) throw const HouseholdException('network');
      final owner = identity();
      client = _clientFactory();
      _clients.add(client);
      final request = http.Request('POST', endpoint!)
        ..followRedirects = false
        ..maxRedirects = 0
        ..headers.addAll({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${owner.installationId}.${owner.authSecret}'
        })
        ..body = jsonEncode({...fields, 'v': 1, 'op': op});
      final exchange = () async {
        final response = await client!.send(request);
        if (response.statusCode >= 300 && response.statusCode < 400) {
          throw const HouseholdException('network');
        }
        final bytes = <int>[];
        await for (final chunk in response.stream) {
          if (bytes.length + chunk.length > 65536) {
            throw const HouseholdException('network');
          }
          bytes.addAll(chunk);
        }
        final data = jsonDecode(utf8.decode(bytes));
        if (data is! Map<String, dynamic> || data['v'] != 1) {
          throw const HouseholdException('network');
        }
        if (response.statusCode != 200 || data['ok'] != true) {
          // The UI message map never exposes backend diagnostics.
          throw HouseholdException(
              data['error'] is String ? data['error'] : 'network');
        }
        return data;
      }();
      // A single deadline covers headers and the whole response; a peer cannot
      // hold the UI busy indefinitely by dripping bytes before an idle timeout.
      return await exchange.timeout(const Duration(seconds: 10));
    } on HouseholdException {
      rethrow;
    } catch (_) {
      throw const HouseholdException('network');
    } finally {
      if (client != null) {
        _clients.remove(client);
        client.close();
      }
    }
  }

  void dispose() {
    _disposed = true;
    for (final client in _clients) {
      client.close();
    }
    _clients.clear();
  }
}
