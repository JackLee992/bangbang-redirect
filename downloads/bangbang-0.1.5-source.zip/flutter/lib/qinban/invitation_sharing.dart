import 'package:flutter/services.dart';

const _shareChannel = MethodChannel('qinban/share');

/// Opens the native share sheet. Clipboard fallback preserves the complete message.
Future<bool> shareInvitationText(String text) async {
  try {
    if (await _shareChannel.invokeMethod<bool>('share_text', text) == true) return true;
  } on PlatformException {
    // Native sharing is unavailable; the same invitation can be pasted in chat.
  } on MissingPluginException {
    // Covers platforms without a native share adapter.
  }
  await Clipboard.setData(ClipboardData(text: text));
  return false;
}
