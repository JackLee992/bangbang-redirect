import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'family_models.dart';

bool validFamilyToken(Object? value, int bytes) {
  if (value is! String ||
      value.length != (bytes == 16 ? 22 : 43) ||
      !RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(value)) return false;
  try {
    final decoded = base64Url.decode(base64Url.normalize(value));
    return decoded.length == bytes &&
        base64Url.encode(decoded).replaceAll('=', '') == value;
  } on FormatException {
    return false;
  }
}

String familyToken(int bytes) {
  final random = Random.secure();
  return base64Url
      .encode(List<int>.generate(bytes, (_) => random.nextInt(256)))
      .replaceAll('=', '');
}

bool validFamilyPeer(Object? value) =>
    value is String && RegExp(r'^\d{6,16}$').hasMatch(value);

bool validFamilyScope(Object? value) =>
    value is String && RegExp(r'^[A-Za-z0-9._:/+=-]{1,200}$').hasMatch(value);

String familyServerScope(String host, String key) {
  final server = host.trim().toLowerCase();
  if (server.isEmpty) return 'rustdesk-public-v1';
  final configuration = jsonEncode([server, key.trim()]);
  return 'rustdesk-custom-v1:${sha256.convert(utf8.encode(configuration))}';
}

String familyDisplayName(String name, String peerId,
    {bool fromDevice = false}) {
  final clean = name.replaceAll(RegExp(r'[\x00-\x1f\x7f]'), '').trim();
  final defaultDevice = RegExp(
          r'^(android(?:[ -].*)?|iphone\d.*|ipad\d.*|sdk.*|unknown|localhost)$',
          caseSensitive: false)
      .hasMatch(clean);
  if (clean.isEmpty || (fromDevice && (defaultDevice || clean.length > 24))) {
    return '家人';
  }
  return String.fromCharCodes(clean.runes.take(24));
}

class FamilyIdentity {
  FamilyIdentity(this.installationId, this.authSecret);
  final String installationId;
  final String authSecret;
  factory FamilyIdentity.create() =>
      FamilyIdentity(familyToken(16), familyToken(32));
}

/// Stored only with the installation it belongs to, never with the recovery card.
class HouseholdRecoveryState {
  const HouseholdRecoveryState({required this.installationId, required this.scope,
      this.initialUserId, this.transferCode, this.transferExpires});
  final String installationId, scope;
  final String? initialUserId, transferCode;
  final int? transferExpires;
  Map<String, dynamic> toJson() => {
    'installationId': installationId, 'scope': scope,
    if (initialUserId != null) 'initialUserId': initialUserId,
    if (transferCode != null) 'transferCode': transferCode,
    if (transferExpires != null) 'transferExpires': transferExpires,
  };
}

/// Capabilities stay inside the local repository; UI projections never include them.
class FamilyBinding {
  FamilyBinding(
      {required this.peerId,
      required this.name,
      required this.direction,
      required this.serverScope,
      required this.lastHelpAt,
      this.ownPeerId = '',
      this.pairId = '',
      this.capability = '',
      this.nonce = '',
      this.remoteInstallationId = '',
      this.confirmed = false});
  final String peerId;
  String name;
  final FamilyDirection direction;
  final String serverScope;
  DateTime lastHelpAt;
  String ownPeerId;
  String pairId;
  String capability;
  String nonce;
  String remoteInstallationId;
  bool confirmed;
  bool get hasCapability =>
      validFamilyToken(pairId, 16) &&
      validFamilyToken(capability, 32) &&
      validFamilyToken(nonce, 16) &&
      validFamilyToken(remoteInstallationId, 16) &&
      validFamilyPeer(ownPeerId);
  FamilyMember get view => FamilyMember(
      peerId: peerId,
      name: name,
      direction: direction,
      lastHelpAt: lastHelpAt,
      directReady: confirmed && hasCapability);
  Map<String, dynamic> toJson() => {
        'peerId': peerId,
        'name': name,
        'direction': direction.name,
        'serverScope': serverScope,
        'lastHelpAt': lastHelpAt.millisecondsSinceEpoch,
        'ownPeerId': ownPeerId,
        'pairId': pairId,
        'capability': capability,
        'nonce': nonce,
        'remoteInstallationId': remoteInstallationId,
        'confirmed': confirmed
      };
}

class FamilyStore {
  FamilyStore(String raw, this.write) {
    try {
      if (raw.length > 65536) throw const FormatException('Too large');
      final data = jsonDecode(raw);
      if (data is! Map || data['v'] != 1) {
        throw const FormatException('Version');
      }
      final owner = data['owner'];
      if (owner is! Map ||
          !validFamilyToken(owner['installationId'], 16) ||
          !validFamilyToken(owner['authSecret'], 32)) {
        throw const FormatException('Owner');
      }
      identity = FamilyIdentity(owner['installationId'], owner['authSecret']);
      final recovery = data['householdRecovery'];
      if (recovery is Map &&
          recovery['installationId'] == identity!.installationId &&
          recovery['scope'] is String && recovery['scope'].isNotEmpty &&
          recovery['scope'].length <= 2048) {
        final transfer = recovery['transferCode'];
        householdRecovery = HouseholdRecoveryState(
          installationId: identity!.installationId, scope: recovery['scope'],
          initialUserId: recovery['initialUserId'] is String
              ? recovery['initialUserId'] : null,
          transferCode: transfer is String && transfer.length <= 4096 &&
              RegExp(r'^BHT1\.[A-Za-z0-9_-]+$').hasMatch(transfer) ? transfer : null,
          transferExpires: recovery['transferExpires'] is int
              ? recovery['transferExpires'] : null);
      }
      final entries = data['members'];
      if (entries is List) {
        for (final value in entries.take(20)) {
          if (value is! Map ||
              !validFamilyPeer(value['peerId']) ||
              !validFamilyScope(value['serverScope']) ||
              value['name'] is! String ||
              value['lastHelpAt'] is! int ||
              value['lastHelpAt'] <= 0) continue;
          final direction = switch (value['direction']) {
            'incomingHelper' => FamilyDirection.incomingHelper,
            'outgoingElder' => FamilyDirection.outgoingElder,
            _ => null,
          };
          if (direction == null) continue;
          final binding = FamilyBinding(
              peerId: value['peerId'],
              name: familyDisplayName(value['name'], value['peerId']),
              direction: direction,
              serverScope: value['serverScope'],
              lastHelpAt:
                  DateTime.fromMillisecondsSinceEpoch(value['lastHelpAt']),
              ownPeerId: value['ownPeerId'] is String ? value['ownPeerId'] : '',
              pairId: value['pairId'] is String ? value['pairId'] : '',
              capability:
                  value['capability'] is String ? value['capability'] : '',
              nonce: value['nonce'] is String ? value['nonce'] : '',
              remoteInstallationId: value['remoteInstallationId'] is String
                  ? value['remoteInstallationId']
                  : '');
          binding.confirmed =
              value['confirmed'] == true && binding.hasCapability;
          members.add(binding);
        }
      }
      final done = data['completed'];
      if (done is List) {
        completed.addAll(done
            .where((v) => validFamilyToken(v, 16))
            .cast<String>()
            .take(128));
      }
    } catch (_) {
      // A damaged archive cannot establish trusted family relationships.
      members.clear();
      completed.clear();
    }
    identity ??= FamilyIdentity.create();
  }

  final Future<void> Function(String) write;
  FamilyIdentity? identity;
  HouseholdRecoveryState? householdRecovery;
  final List<FamilyBinding> members = [];
  final Set<String> completed = {};
  Future<void> _saving = Future.value();
  bool _resetting = false;
  String _encoded(HouseholdRecoveryState? recovery) {
    final owner = identity!;
    return jsonEncode({
      'v': 1,
      'owner': {'installationId': owner.installationId, 'authSecret': owner.authSecret},
      'members': members.take(20).map((v) => v.toJson()).toList(),
      'completed': completed.take(128).toList(),
      if (recovery != null) 'householdRecovery': recovery.toJson(),
    });
  }

  Future<void> save() {
    if (_resetting) return Future.error(StateError('identity_change_in_progress'));
    // Read the recovery state when this ordered write runs, so a queued ordinary
    // save cannot restore a completed recovery or erase its checkpoint.
    _saving = _saving.catchError((Object _) {}).then((_) => write(_encoded(householdRecovery)));
    return _saving;
  }

  Future<void> saveHouseholdRecovery(HouseholdRecoveryState? recovery) {
    if (_resetting) return Future.error(StateError('identity_change_in_progress'));
    if (recovery != null && recovery.installationId != identity!.installationId) {
      return Future.error(StateError('recovery_identity_mismatch'));
    }
    _saving = _saving.catchError((Object _) {}).then((_) async {
      await write(_encoded(recovery));
      householdRecovery = recovery;
    });
    return _saving;
  }

  /// Persist the new installation and pending recovery in one write before
  /// exposing either. A retry after process death must keep this installation.
  Future<FamilyIdentity> replaceIdentity({required String householdScope}) async {
    if (_resetting) throw StateError('identity_change_in_progress');
    if (householdRecovery != null) {
      if (householdRecovery!.scope != householdScope) {
        throw StateError('recovery_scope_changed');
      }
      return identity!;
    }
    _resetting = true;
    final replacement = FamilyIdentity.create();
    final pending = HouseholdRecoveryState(
        installationId: replacement.installationId, scope: householdScope);
    final encoded = jsonEncode({'v': 1, 'owner': {
      'installationId': replacement.installationId,
      'authSecret': replacement.authSecret,
    }, 'members': [], 'completed': [], 'householdRecovery': pending.toJson()});
    _saving = _saving.catchError((Object _) {}).then((_) async {
      await write(encoded);
      identity = replacement;
      householdRecovery = pending;
      members.clear();
      completed.clear();
    });
    try {
      await _saving;
      return replacement;
    } finally { _resetting = false; }
  }

  FamilyBinding? find(String peerId, String scope, FamilyDirection direction) {
    for (final member in members) {
      if (member.peerId == peerId &&
          member.serverScope == scope &&
          member.direction == direction) return member;
    }
    return null;
  }

  FamilyBinding remember(String peerId, String name, String scope,
      FamilyDirection direction, DateTime now) {
    final existing = find(peerId, scope, direction);
    if (existing != null) {
      existing.lastHelpAt = now;
      members.remove(existing);
      members.insert(0, existing);
      return existing;
    }
    var displayName = familyDisplayName(name, peerId, fromDevice: true);
    if (displayName == '家人') {
      var suffix = 1;
      final existingNames = members.map((m) => m.name).toSet();
      while (existingNames.contains(displayName)) {
        displayName = '家人${++suffix}';
      }
    }
    final created = FamilyBinding(
        peerId: peerId,
        name: displayName,
        direction: direction,
        serverScope: scope,
        lastHelpAt: now);
    members.insert(0, created);
    if (members.length > 20) members.removeRange(20, members.length);
    return created;
  }

  void markCompleted(String requestId) {
    completed.add(requestId);
    while (completed.length > 128) {
      completed.remove(completed.first);
    }
  }
}
