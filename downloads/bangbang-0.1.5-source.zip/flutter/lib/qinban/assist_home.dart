import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'assist_model.dart';
import 'qinban_theme.dart';
import 'household_page.dart';

class AssistHome extends StatefulWidget {
  const AssistHome({super.key, required this.controller});
  final AssistController controller;
  @override
  State<AssistHome> createState() => _AssistHomeState();
}

class _AssistHomeState extends State<AssistHome> {
  final _peer = TextEditingController();
  final _scroll = ScrollController();
  bool _busy = false;
  bool _stoppingSharing = false;
  bool _preparingInvitation = false;
  String _invitationReadyHint = '连接好后会打开分享';
  String _invitationSendingLabel = '正在打开分享';
  int _invitationGeneration = 0;
  String? _inputError;
  String? _prefilledInvitation;
  bool _invitationPromptScheduled = false;
  _InvitationPromptRoute? _invitationPrompt;
  NavigatorState? _invitationPromptNavigator;
  String? _promptCode;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_watchInvitationPrompt);
  }

  @override
  void didUpdateWidget(covariant AssistHome oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_watchInvitationPrompt);
      widget.controller.addListener(_watchInvitationPrompt);
      _closeInvitationPrompt();
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_watchInvitationPrompt);
    _closeInvitationPrompt();
    _peer.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _stopSharing() async {
    if (!mounted || _stoppingSharing) return;
    ++_invitationGeneration;
    setState(() => _stoppingSharing = true);
    try {
      // Stop remains independent of a start awaiting system consent.
      await widget.controller.stopSharing();
    } catch (_) {
      if (mounted) _message('协助未能完全结束，请重试');
    } finally {
      if (mounted) setState(() => _stoppingSharing = false);
    }
  }

  Future<void> _run(Future<void> Function() action) async {
    if (!mounted || _busy) return;
    setState(() => _busy = true);
    try {
      await action();
    } catch (_) {
      if (mounted) _message('操作暂未完成，请重试');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(text)));

  bool _canConnectInvitation(AssistState state, String code) =>
      mounted && !_busy && !_stoppingSharing && state.role == AssistRole.helper &&
      state.invitationCode == code && !state.invitationBlocked &&
      !state.sharing && !state.preparing && state.connections == 0 &&
      (state.pendingFamilyRequest == null ||
        !state.pendingFamilyRequest!.expiresAt.isAfter(DateTime.now())) &&
      state.familyRequestStatus != FamilyRequestStatus.connecting &&
      state.familyRequestStatus != FamilyRequestStatus.sending &&
      state.familyRequestStatus != FamilyRequestStatus.waiting;

  void _watchInvitationPrompt() {
    final code = _promptCode;
    if (code != null && !_canConnectInvitation(widget.controller.state, code)) {
      _closeInvitationPrompt();
    }
  }

  void _closeInvitationPrompt() {
    final route = _invitationPrompt;
    final navigator = _invitationPromptNavigator;
    if (route == null || navigator == null) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (navigator.mounted && route.isActive) {
        route.cancel(navigator);
      }
    });
  }

  void _scheduleInvitationPrompt(AssistState state) {
    final code = state.invitationCode;
    if (code == null || _invitationPromptScheduled || _invitationPrompt != null ||
        !_canConnectInvitation(state, code)) return;
    _invitationPromptScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _invitationPromptScheduled = false;
      if (!mounted || ModalRoute.of(context)?.isCurrent != true ||
          !_canConnectInvitation(widget.controller.state, code)) return;
      _showInvitationPrompt(code);
    });
  }

  Future<void> _showInvitationPrompt(String code) async {
    final controller = widget.controller;
    if (!controller.claimInvitationPrompt(code)) return;
    final navigator = Navigator.of(context);
    final theme = qinbanTheme(Theme.of(context).brightness);
    final route = _InvitationPromptRoute(context: context,
      builder: (dialogContext) => Theme(data: theme,
        child: AnimatedBuilder(animation: controller, builder: (_, __) => AlertDialog(
          key: Key('invitation-prompt'),
          icon: Icon(Icons.link_rounded, color: theme.colorScheme.primary),
          title: Text('家人邀请'),
          content: Text('现在连接家人的手机？'),
          actions: [
            TextButton(key: Key('invitation-prompt-later'),
              style: TextButton.styleFrom(minimumSize: Size(64, 56)),
              onPressed: () => Navigator.pop(dialogContext, false), child: Text('稍后')),
            FilledButton(key: Key('invitation-prompt-connect'),
              style: FilledButton.styleFrom(minimumSize: Size(104, 56)),
              onPressed: _canConnectInvitation(controller.state, code) ?
                () { if (_canConnectInvitation(controller.state, code)) Navigator.pop(dialogContext, true); } : null,
              child: Text('连接家人')),
          ],
        ))));
    _invitationPrompt = route;
    _invitationPromptNavigator = navigator;
    _promptCode = code;
    try {
      final accepted = await navigator.push(route);
      if (accepted == true && mounted && widget.controller == controller &&
          _canConnectInvitation(controller.state, code)) {
        _connectInvitation(controller.state);
      }
    } finally {
      if (_invitationPrompt == route) {
        _invitationPrompt = null;
        _invitationPromptNavigator = null;
        _promptCode = null;
      }
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: widget.controller,
    builder: (context, _) {
      final state = widget.controller.state;
      _scheduleInvitationPrompt(state);
      if (state.invitationCode == null) _prefilledInvitation = null;
      if (state.invitationCode != null && !state.invitationBlocked &&
          _prefilledInvitation != state.invitationCode) {
        _prefilledInvitation = state.invitationCode;
        _peer.text = state.invitationCode!;
        _inputError = null;
      }
      final elder = widget.controller.supportsSharing && state.role != AssistRole.helper;
      final incomingRequest = !elder && !_busy && !_stoppingSharing &&
          state.familyRequestStatus == FamilyRequestStatus.received &&
          !state.sharing && !state.preparing && !state.invitationBlocked &&
          state.pendingFamilyRequest != null &&
          state.pendingFamilyRequest!.expiresAt.isAfter(DateTime.now());
      final theme = qinbanTheme(Theme.of(context).brightness, elderMode: elder);
      return Theme(data: theme, child: Builder(builder: (context) => Scaffold(
        appBar: AppBar(titleSpacing: 20,
          title: Text('帮帮', style: TextStyle(fontSize: elder ? 26 : 22, fontWeight: FontWeight.w600)),
          actions: [Padding(padding: EdgeInsets.only(right: 16),
            child: TextButton.icon(key: Key('more-actions'),
            style: TextButton.styleFrom(foregroundColor: theme.colorScheme.onSurfaceVariant,
              backgroundColor: theme.colorScheme.surface,
              side: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(.45)),
              padding: EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
            onPressed: () => _tools(context),
            icon: Icon(Icons.more_horiz_rounded), label: Text('更多')))],
        ),
        bottomNavigationBar: state.sharing || state.preparing ? Container(
          color: theme.scaffoldBackgroundColor,
          child: SafeArea(top: false, child: Padding(padding: EdgeInsets.fromLTRB(20, 12, 20, 16),
            child: DecoratedBox(decoration: BoxDecoration(borderRadius: BorderRadius.circular(22),
              boxShadow: [if (state.inputReady || state.sharing || state.preparing)
                BoxShadow(color: theme.colorScheme.primary.withOpacity(.14), blurRadius: 14, offset: Offset(0, 5))]),
              child: _sharingAction(context, state)))),
        ) : null,
        body: SafeArea(child: Center(child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 560),
          child: ListView(controller: _scroll, padding: EdgeInsets.fromLTRB(24, 20, 24, 24), children: [
            if (state.invitationCode != null) _invitation(context, state)
            else if (incomingRequest) _familyRequest(context, state.pendingFamilyRequest!)
            else if (elder && state.pendingFamilyRequest != null)
              _outgoingCall(context, state)
            else if (elder) ..._elder(context, state)
            else ..._helper(context, state),
            if (!elder && !incomingRequest) ...[
              SizedBox(height: 16),
              _manualPeer(context, state),
            ],
            if (state.error != null) Padding(padding: EdgeInsets.only(top: 16),
              child: Text(state.error!, style: TextStyle(fontSize: elder ? 20 : 16,
                height: 1.5, color: theme.colorScheme.error))),
            if (state.familyRequestError != null && state.familyRequestError != state.error)
              Padding(padding: EdgeInsets.only(top: 16),
                child: Text(state.familyRequestError!, key: Key('family-request-error'),
                  style: TextStyle(fontSize: elder ? 20 : 16, color: theme.colorScheme.error))),
          ]),
        ))),
      )));
    },
  );

  String? _preparationStatus(AssistState state) {
    if (_stoppingSharing || state.error != null || state.connections > 0) return null;
    if (state.preparing && !state.captureReady) return '等待确认';
    if (state.sharing && !state.online) return '正在连接';
    if (state.preparing) return '正在准备';
    if (_preparingInvitation && _busy && _readyToInvite(state)) return _invitationSendingLabel;
    return null;
  }

  List<Widget> _elder(BuildContext context, AssistState state) {
    final progress = _preparationStatus(state);
    final hint = progress == null || _readyToInvite(state) ? null :
      state.preparing && !state.captureReady ? '请完成屏幕共享授权' :
      _preparingInvitation ? _invitationReadyHint : '连接好后即可邀请';
    return [
      _heading(context,
        title: progress ?? (state.connections > 0 ? '家人在协助' : state.sharing ? (state.online ?
          state.familyRequestStatus == FamilyRequestStatus.sending ? '正在通知' :
          state.familyRequestStatus == FamilyRequestStatus.waiting ? '等待回应' : '等待家人' : '正在连接') :
          state.preparing ? '等待确认' : '请家人帮忙'), keyName: 'elder-title', elder: true,
        progress: progress != null, hint: hint,
        quiet: state.connections == 0 && !state.sharing && !state.preparing),
      SizedBox(height: 28),
      LayoutBuilder(builder: (context, constraints) {
        // Accessibility enables remote input; screen consent is a separate step.
        final permissionReady = state.inputReady;
        final scale = ((constraints.maxWidth - 12) / 285).clamp(0.0, 1.0);
        final primarySize = 190 * scale;
        final secondarySize = 95 * scale;
        final permission = _stepTile(context, keyName: 'enable-input',
          glyph: permissionReady ? _Glyph.completed : _Glyph.permission,
          label: permissionReady ? '已开启' : '开启权限',
          size: permissionReady ? secondarySize : primarySize,
          primary: !permissionReady, completed: permissionReady,
          onPressed: _busy || permissionReady ? null : () => _run(widget.controller.enableInput));
        final invitation = _stepTile(context, keyName: 'share-invitation', glyph: _Glyph.invitation,
          label: '邀请家人', size: permissionReady ? primarySize : secondarySize,
          primary: permissionReady, locked: !permissionReady,
          onPressed: _busy || !permissionReady || state.deviceId.isEmpty ? null : () => _inviteFamily(context));
        return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          permission, SizedBox(width: 12), invitation,
        ]);
      }),
    ];
  }

  List<Widget> _helper(BuildContext context, AssistState state) => [
    _heading(context, title: '帮家人',
      keyName: 'helper-title', elder: false),
    SizedBox(height: 20),
    _visualAction(context, keyName: 'paste-invitation', glyph: _Glyph.paste, accent: true,
      label: '粘贴邀请', onPressed: _busy ? null : () => _run(widget.controller.pasteInvitation)),
    if (_familyMembers(state).isNotEmpty) Padding(padding: EdgeInsets.only(top: 12),
      child: TextButton.icon(key: Key('family-shortcut'),
        onPressed: _busy ? null : () => _familySheet(context),
        icon: Icon(Icons.people_outline_rounded), label: Text('家人'))),
  ];

  List<FamilyMember> _familyMembers(AssistState state) => state.familyMembers.where((member) =>
    member.direction == (!widget.controller.supportsSharing || state.role == AssistRole.helper ? FamilyDirection.outgoingElder :
      FamilyDirection.incomingHelper)).toList();

  void _inviteFamily(BuildContext context) {
    if (_familyMembers(widget.controller.state).isEmpty) {
      _prepareInvitation(widget.controller.shareInvitation);
    } else {
      _familySheet(context);
    }
  }

  Widget _familyRequest(BuildContext context, FamilyHelpRequest request) => _panel(context, children: [
    Icon(Icons.ring_volume_rounded, size: 72, color: Theme.of(context).colorScheme.primary),
    SizedBox(height: 24),
    Center(child: Text('${request.familyName}需要帮忙', key: Key('family-request-title'),
      textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600))),
    SizedBox(height: 32),
    Row(children: [
      Expanded(child: _callButton(context, 'family-request-decline', Icons.call_end_rounded,
        '暂不接听', false, () => _run(widget.controller.declineFamilyRequest))),
      SizedBox(width: 16),
      Expanded(child: _callButton(context, 'family-request-accept', Icons.call_rounded,
        '接听', true, () => _run(widget.controller.acceptFamilyRequest))),
    ]),
  ]);

  Widget _callButton(BuildContext context, String keyName, IconData icon, String label,
      bool accept, VoidCallback action) => FilledButton(
    key: Key(keyName),
    style: FilledButton.styleFrom(padding: EdgeInsets.symmetric(vertical: 24),
      backgroundColor: accept ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.error,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
    onPressed: _busy ? null : action,
    child: Column(children: [Icon(icon, size: 36), SizedBox(height: 12), Text(label)]));

  Widget _outgoingCall(BuildContext context, AssistState state) {
    final title = switch (state.familyRequestStatus) {
      FamilyRequestStatus.sending => '正在呼叫',
      FamilyRequestStatus.ringing => '等待家人接听',
      FamilyRequestStatus.connecting => '家人已接听，正在接通',
      FamilyRequestStatus.active => '家人在协助',
      FamilyRequestStatus.failed => '暂时没有接通',
      _ => '等待家人接听',
    };
    return _panel(context, children: [
      SizedBox(height: 16),
      Icon(state.familyRequestStatus == FamilyRequestStatus.active ? Icons.connected_tv_rounded :
        Icons.call_rounded, size: 72, color: Theme.of(context).colorScheme.primary),
      SizedBox(height: 24),
      Text(state.pendingFamilyRequest!.familyName, textAlign: TextAlign.center,
        style: TextStyle(fontSize: 30, fontWeight: FontWeight.w600)),
      SizedBox(height: 12),
      Text(title, key: Key('family-call-status'), textAlign: TextAlign.center,
        style: TextStyle(fontSize: 22, color: Theme.of(context).colorScheme.onSurfaceVariant)),
      SizedBox(height: 24),
    ]);
  }

  void _familySheet(BuildContext context) {
    showModalBottomSheet<void>(context: context, isScrollControlled: true,
      showDragHandle: true, useSafeArea: true,
      builder: (sheetContext) => FractionallySizedBox(heightFactor: .85,
        child: AnimatedBuilder(animation: widget.controller, builder: (familyContext, _) {
          final state = widget.controller.state;
          final elder = widget.controller.supportsSharing && state.role != AssistRole.helper;
          final members = _familyMembers(state);
          final fontSize = elder ? 22.0 : 18.0;
          final colors = Theme.of(familyContext).colorScheme;
          return ListView(key: Key('family-list'), padding: EdgeInsets.fromLTRB(20, 4, 20, 24), children: [
            Row(children: [Expanded(child: Text('家人', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600))),
              IconButton(key: Key('family-sheet-close'), tooltip: '关闭',
                style: IconButton.styleFrom(minimumSize: Size.square(56)),
                onPressed: () => Navigator.pop(sheetContext), icon: Icon(Icons.close_rounded))]),
            if (members.isEmpty) Padding(padding: EdgeInsets.symmetric(vertical: 20),
              child: Text('还没有家人', style: TextStyle(fontSize: elder ? 20 : 16,
                color: colors.onSurfaceVariant))),
            for (final member in members) Padding(padding: EdgeInsets.only(top: 12),
              child: _panel(familyContext, children: [
                Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                  CircleAvatar(radius: 28, backgroundColor: colors.primaryContainer,
                    foregroundColor: colors.primary,
                    child: Text(member.name.trim().isEmpty ? '家' : member.name.characters.first,
                      style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600))),
                  SizedBox(width: 14), Expanded(child: Text(member.name,
                    key: Key('family-name-${member.peerId}'),
                    style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w600))),
                  PopupMenuButton<String>(key: Key('family-menu-${member.peerId}'), tooltip: '管理家人',
                    constraints: BoxConstraints(minWidth: 140),
                    iconSize: 24, padding: EdgeInsets.all(16), icon: Icon(Icons.more_horiz_rounded),
                    onSelected: (value) {
                      if (value == 'rename') {
                        _renameFamilyMember(context, member);
                      }
                      if (value == 'forget') {
                        _forgetFamilyMember(context, member);
                      }
                    }, itemBuilder: (_) => [
                      PopupMenuItem(value: 'rename', height: 56, child: Text('改名', style: TextStyle(fontSize: elder ? 20 : 16))),
                      PopupMenuItem(value: 'forget', height: 56, child: Text('移除', style: TextStyle(fontSize: elder ? 20 : 16))),
                    ]),
                ]),
                if (!member.directReady) Padding(padding: EdgeInsets.only(top: 12),
                  child: Text('尚未完成配对', style: TextStyle(fontSize: elder ? 20 : 16,
                    color: colors.onSurfaceVariant))),
                SizedBox(height: 16),
                FilledButton(key: Key('family-action-${member.peerId}'),
                  style: FilledButton.styleFrom(minimumSize: Size.fromHeight(64)),
                  onPressed: _busy || state.preparing || (!elder && state.invitationBlocked) ||
                      (elder ? !state.inputReady || !member.directReady || state.connections > 0 ||
                        state.familyRequestStatus == FamilyRequestStatus.waiting ||
                        state.familyRequestStatus == FamilyRequestStatus.sending : state.sharing) ? null : () {
                    Navigator.pop(sheetContext);
                    if (elder) {
                      _requestFamilyHelp(context, member.peerId);
                    } else {
                      _run(() => widget.controller.connectTo(member.peerId));
                    }
                  }, child: Text(elder ? '找TA帮忙' : '帮TA')),
              ])),
            SizedBox(height: 20),
            OutlinedButton.icon(key: Key('family-add'),
              onPressed: _busy || (elder && (!state.inputReady || state.deviceId.isEmpty)) ? null : () {
                Navigator.pop(sheetContext);
                if (elder) {
                  _prepareInvitation(widget.controller.shareInvitation);
                } else {
                  _run(widget.controller.pasteInvitation);
                }
              }, icon: Icon(Icons.add_rounded), label: Text(elder ? '添加家人' : '粘贴邀请')),
          ]);
        })),
    ).whenComplete(() { if (mounted) setState(() {}); });
  }

  Future<void> _requestFamilyHelp(BuildContext context, String peerId) async {
    await _prepareInvitation(() => widget.controller.requestFamilyHelp(peerId),
      readyHint: '连接好后会呼叫家人', sendingLabel: '正在呼叫');
  }

  bool _readyToInvite(AssistState state) => state.inputReady && state.captureReady &&
      state.sharing && state.online && !state.preparing;

  Future<void> _prepareInvitation(Future<void> Function() send, {
      String readyHint = '连接好后会打开分享', String sendingLabel = '正在打开分享'}) async {
    if (!mounted || _busy || _stoppingSharing || _preparingInvitation ||
        !widget.controller.state.inputReady) return;
    final generation = ++_invitationGeneration;
    setState(() {
      _preparingInvitation = true;
      _invitationReadyHint = readyHint;
      _invitationSendingLabel = sendingLabel;
    });
    try {
      if (!_readyToInvite(widget.controller.state) && !await _confirmStart(context)) return;
      if (!mounted || generation != _invitationGeneration || _stoppingSharing ||
          !_readyToInvite(widget.controller.state)) return;
      await _run(send);
    } finally {
      if (mounted) setState(() => _preparingInvitation = false);
    }
  }

  Future<void> _renameFamilyMember(BuildContext context, FamilyMember member) async {
    if (!mounted) return;
    var name = member.name;
    String? error;
    final updated = await showDialog<String>(context: context,
        builder: (dialogContext) => StatefulBuilder(builder: (context, update) => AlertDialog(
          title: Text('家人称呼'),
          content: TextFormField(key: Key('family-rename-input'), initialValue: name, maxLength: 20,
            onChanged: (value) => name = value,
            autofocus: true, decoration: InputDecoration(labelText: '称呼', errorText: error)),
          actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text('取消')),
            FilledButton(key: Key('family-rename-save'), onPressed: () {
              final value = name.trim();
              if (value.isEmpty) { update(() => error = '写个称呼'); return; }
              Navigator.pop(dialogContext, value);
            }, child: Text('保存'))],
        )));
    if (mounted && updated != null) await _run(() => widget.controller.renameFamilyMember(member.peerId, updated));
  }

  Future<void> _forgetFamilyMember(BuildContext context, FamilyMember member) async {
    if (!mounted) return;
    final confirmed = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text('移除${member.name}？'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text('取消')),
        FilledButton(key: Key('family-forget-confirm'),
          onPressed: () => Navigator.pop(context, true), child: Text('移除'))],
    ));
    if (mounted && confirmed == true) await _run(() => widget.controller.forgetFamilyMember(member.peerId));
  }

  Widget _heading(BuildContext context, {required String title,
      required String keyName, required bool elder, bool quiet = false,
      bool progress = false, String? hint}) => Column(children: [
    progress ? SizedBox(height: MediaQuery.textScalerOf(context).scale(22) > 30 ? 76 : 170,
      child: Center(child: SizedBox.square(dimension: 48,
        child: CircularProgressIndicator(key: Key('sharing-progress'),
          strokeWidth: 5, semanticsLabel: '请稍候')))) : _connectionArt(context),
    SizedBox(height: 16),
    Semantics(liveRegion: progress, child: Text(title, key: Key(keyName), textAlign: TextAlign.center,
      style: TextStyle(fontSize: quiet ? 22 : elder ? 30 : 24, height: 1.2,
        fontWeight: quiet ? FontWeight.w500 : FontWeight.w600,
        color: quiet ? Theme.of(context).colorScheme.onSurfaceVariant : null))),
    if (hint != null) Padding(padding: EdgeInsets.only(top: 12),
      child: Text(hint, key: Key('sharing-progress-hint'), textAlign: TextAlign.center,
        style: TextStyle(fontSize: elder ? 20 : 16, height: 1.35,
          color: Theme.of(context).colorScheme.onSurfaceVariant))),
  ]);

  Widget _connectionArt(BuildContext context) {
    final compact = MediaQuery.textScalerOf(context).scale(22) > 30;
    return SizedBox(height: compact ? 76 : 170, width: double.infinity,
      child: ExcludeSemantics(child: CustomPaint(painter: _ConnectionPainter(
        Theme.of(context).brightness == Brightness.dark))));
  }

  Widget _stepTile(BuildContext context, {required String keyName,
      required _Glyph glyph, required String label, required double size,
      required bool primary, required VoidCallback? onPressed,
      bool completed = false, bool locked = false}) {
    final colors = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final largeText = MediaQuery.textScalerOf(context).scale(22) > 30;
    final disabled = onPressed == null && !completed;
    final active = primary && !disabled;
    final background = completed ? colors.tertiaryContainer : active ? colors.primary :
      dark ? const Color(0xFF3F3F43) : const Color(0xFFD1D1D6);
    final foreground = completed ? colors.onTertiaryContainer : active ? colors.onPrimary : colors.onSurfaceVariant;
    final visibleLabel = primary ? (largeText ? '${label.substring(0, 2)}\n${label.substring(2)}' : label) :
      !completed && (largeText || size < 92) ? '邀请' : label;
    final showLabel = !completed || !largeText;
    final iconSize = completed && largeText ? 48.0 : primary ? (largeText ? 44.0 : 68.0) : (largeText ? 22.0 : 32.0);
    return Semantics(container: true, label: label, button: !completed,
      enabled: completed ? null : onPressed != null, onTap: onPressed,
      child: ExcludeSemantics(child: SizedBox.square(dimension: size,
        child: DecoratedBox(decoration: BoxDecoration(borderRadius: BorderRadius.circular(16),
          boxShadow: [if (active) BoxShadow(color: colors.primary.withOpacity(.18),
            blurRadius: 14, offset: const Offset(0, 6))]),
          child: Material(color: background,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: completed ? colors.onTertiaryContainer.withOpacity(.15) :
                active ? colors.primary : colors.outline.withOpacity(.45), width: .7)),
            clipBehavior: Clip.antiAlias,
            child: InkWell(key: Key(keyName), onTap: onPressed, child: Stack(children: [
              if (locked) Positioned(top: 8, right: 8,
                child: Icon(Icons.lock_rounded, size: 14, color: foreground)),
              Center(child: Padding(padding: EdgeInsets.all(primary ? (largeText ? 8 : 16) :
                  !largeText && size < 92 ? 3 : 6),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox.square(key: completed ? Key('permission-success-check') : null, dimension: iconSize,
                    child: CustomPaint(painter: _ActionPainter(glyph, foreground))),
                  if (showLabel) ...[
                    SizedBox(height: largeText ? (primary ? 8 : 4) : (primary ? 14 : 8)),
                    Text(visibleLabel, textAlign: TextAlign.center, style: TextStyle(color: foreground,
                      fontSize: primary ? 22 : 20, height: 1.1, fontWeight: FontWeight.w600)),
                  ],
                ]))),
            ])),
          )),
      )),
    );
  }

  Widget _visualAction(BuildContext context, {required String keyName,
      required _Glyph glyph, required String label, required VoidCallback? onPressed,
      bool vertical = false, bool accent = false, bool compact = false,
      bool completed = false, bool locked = false}) {
    final colors = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final disabled = onPressed == null && !completed;
    final highlighted = accent && !disabled;
    final badgeColor = completed ? colors.tertiaryContainer : disabled ? colors.outlineVariant.withOpacity(.5) :
      highlighted ? colors.primary : colors.primaryContainer;
    final glyphColor = completed ? colors.onTertiaryContainer : disabled ? colors.onSurfaceVariant.withOpacity(.65) :
      highlighted ? colors.onPrimary : colors.primary;
    final badgeSize = completed ? 48.0 : compact ? 40.0 : 52.0;
    final badge = Container(width: badgeSize, height: badgeSize,
      decoration: BoxDecoration(color: badgeColor,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: highlighted ? Colors.white.withOpacity(.16) : glyphColor.withOpacity(.05))),
      child: CustomPaint(painter: _ActionPainter(glyph, glyphColor)));
    final text = Text(label, style: TextStyle(color: disabled ? colors.onSurfaceVariant : colors.onSurface,
      fontSize: _elderMode(context) ? (compact ? 20 : 22) : 18, fontWeight: FontWeight.w600));
    final lock = Icon(Icons.lock_outline_rounded, size: 16, color: colors.onSurfaceVariant);
    return Semantics(container: true, button: !completed, enabled: completed ? null : onPressed != null, child: Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), boxShadow: [
        if (!disabled) BoxShadow(color: Colors.black.withOpacity(dark ? .12 : .035), blurRadius: 16, offset: Offset(0, 5)),
      ]),
      child: Material(color: disabled ? colors.surfaceContainerHighest :
          highlighted ? (dark ? Color(0xFF2D241D) : Color(0xFFFFF2E7)) : colors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26),
          side: BorderSide(color: dark ? colors.outlineVariant : Color(0xFFEBE5DD), width: .7)),
        clipBehavior: Clip.antiAlias,
        child: InkWell(key: Key(keyName), onTap: onPressed,
          child: Padding(padding: EdgeInsets.all(compact ? (vertical ? 14 : 12) : vertical ? 20 : 16),
            child: vertical ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [badge, if (locked) ...[Spacer(), lock]]),
              SizedBox(height: compact ? 12 : 20), text,
            ]) : Row(children: [badge, SizedBox(width: 14), Expanded(child: text),
              if (locked) ...[SizedBox(width: 4), lock]]))),
      ),
    ));
  }

  Widget _invitation(BuildContext context, AssistState state) => _panel(context, children: [
    _connectionArt(context),
    SizedBox(height: 16),
    Center(child: Text('家人邀请', key: Key('received-invitation'),
      style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600))),
    if (state.invitationBlocked) Padding(padding: EdgeInsets.only(top: 10),
      child: Text('先结束当前协助', style: TextStyle(fontSize: _elderMode(context) ? 20 : 16))),
    SizedBox(height: 20),
    FilledButton.icon(key: Key('invite-connect'),
      style: FilledButton.styleFrom(minimumSize: Size.fromHeight(64),
        textStyle: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
      onPressed: !_canConnectInvitation(state, state.invitationCode!) ? null : () => _connectInvitation(state),
      icon: Icon(Icons.arrow_forward_rounded), label: Text(_busy ? '正在连接' : '连接家人')),
  ]);

  Widget _sharingAction(BuildContext context, AssistState state) => FilledButton.icon(
    key: Key('stop-sharing'),
    style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error,
      foregroundColor: Colors.white, minimumSize: Size.fromHeight(64)),
    onPressed: _stoppingSharing ? null : _stopSharing,
    icon: Icon(Icons.stop_circle_outlined, size: 28),
    label: Text(state.sharing ? '结束协助' : '取消准备'),
  );

  Widget _manualPeer(BuildContext context, AssistState state) => _panel(context, children: [
    ExpansionTile(key: Key('manual-peer'), tilePadding: EdgeInsets.zero,
      title: Text('手动输入设备号码', style: TextStyle(fontSize: 16)),
      children: [
        TextField(key: Key('peer-id'), controller: _peer,
          keyboardType: TextInputType.number, textInputAction: TextInputAction.done,
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9\s]')),
            LengthLimitingTextInputFormatter(24)],
          style: TextStyle(fontSize: 20),
          decoration: InputDecoration(hintText: '输入设备号码', errorText: _inputError, errorMaxLines: 3),
          onChanged: (_) { if (_inputError != null) setState(() => _inputError = null); },
          onSubmitted: (_) => _connect(state)),
        SizedBox(height: 16),
        FilledButton.icon(key: Key('connect-peer'),
          onPressed: _busy || state.invitationBlocked ? null : () => _connect(state),
          icon: Icon(Icons.arrow_forward_rounded), label: Text(_busy ? '正在连接' : '连接家人')),
      ]),
  ]);

  Widget _panel(BuildContext context, {required List<Widget> children}) => Container(
    width: double.infinity, padding: EdgeInsets.all(20),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(26),
      border: Border.all(color: Theme.of(context).colorScheme.outlineVariant.withOpacity(.5), width: .7),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(.025), blurRadius: 16, offset: Offset(0, 5))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children));

  void _connectInvitation(AssistState state) {
    final id = state.invitationCode;
    if (id == null || !_canConnectInvitation(widget.controller.state, id)) return;
    final error = validatePeerId(id, state.deviceId);
    if (error != null) { _message(error); return; }
    FocusScope.of(context).unfocus();
    _run(() => widget.controller.connectTo(id));
  }

  void _connect(AssistState state) {
    final error = validatePeerId(_peer.text, state.deviceId);
    setState(() => _inputError = error);
    if (error != null) return;
    FocusScope.of(context).unfocus();
    _run(() => widget.controller.connectTo(normalizeDeviceId(_peer.text)));
  }

  Future<bool> _confirmStart(BuildContext context) async {
    if (!mounted || _busy || _stoppingSharing) return false;
    final alreadySharing = widget.controller.state.sharing && widget.controller.state.captureReady;
    final accepted = alreadySharing || await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text('允许家人帮忙', style: TextStyle(fontSize: 24)), scrollable: true,
      content: Text('接下来开启屏幕共享，准备好后就能发邀请。\n\n家人可以看到屏幕、帮你点击，随时点“结束协助”即可停止。',
        key: Key('stranger-warning'), style: TextStyle(fontSize: 22, height: 1.5)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text('暂不开启')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: Text('我知道了，继续')),
      ],
    )) == true;
    if (!mounted || accepted != true) return false;
    await _run(widget.controller.startSharing);
    if (!mounted) return false;
    final state = widget.controller.state;
    return _readyToInvite(state);
  }

  void _tools(BuildContext context) {
    showModalBottomSheet<void>(context: context, isScrollControlled: true,
      showDragHandle: true, useSafeArea: true,
      builder: (sheetContext) => FractionallySizedBox(heightFactor: .85,
        child: AnimatedBuilder(animation: widget.controller, builder: (toolContext, _) {
          final state = widget.controller.state;
          final elder = widget.controller.supportsSharing && state.role != AssistRole.helper;
          void action(Future<void> Function() callback) {
            Navigator.pop(sheetContext);
            _run(callback);
          }
          Widget tool(String keyName, IconData icon, String title, VoidCallback? onTap) =>
            ListTile(key: Key(keyName), leading: Icon(icon),
              enabled: onTap != null,
              contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              title: Text(title, style: TextStyle(fontSize: elder ? 20 : 16)), onTap: onTap);
          return ListView(padding: EdgeInsets.fromLTRB(4, 0, 4, 20), children: [
            Padding(padding: EdgeInsets.all(20), child: Text('更多', style: TextStyle(
              fontSize: elder ? 26 : 22, fontWeight: FontWeight.w700))),
            if (widget.controller.supportsSharing && !state.sharing && !state.preparing &&
                !state.invitationBlocked && state.invitationCode == null)
              tool(elder ? 'choose-helper' : 'choose-elder', Icons.swap_horiz_rounded,
                elder ? '我是家人，来帮忙' : '我需要家人帮忙',
                _busy ? null : () => action(() => widget.controller.selectRole(
                  elder ? AssistRole.helper : AssistRole.elder))),
            if (state.invitationCode != null)
              tool('dismiss-invitation', Icons.close_rounded, '暂不连接', () {
                Navigator.pop(sheetContext);
                widget.controller.dismissInvitation();
              }),
            tool('manage-family', Icons.people_outline_rounded, '家人', () {
              Navigator.pop(sheetContext);
              _familySheet(context);
            }),
            if (widget.controller.householdService != null)
              tool('manage-household', Icons.home_outlined, '我的家庭', () {
                Navigator.pop(sheetContext);
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => HouseholdPage(
                  service: widget.controller.householdService!, elder: elder)));
              }),
            if (!elder)
              tool('enable-call-notifications', Icons.notifications_active_outlined, '开启来电提醒',
                () => action(widget.controller.enableCallNotifications)),
            if (state.pendingFamilyRequest != null && elder)
              tool('cancel-family-request', Icons.close_rounded, '取消求助',
                _busy ? null : () => action(widget.controller.cancelFamilyRequest)),
            if (elder) ...[
              tool('copy-invitation', Icons.copy_rounded, '复制整条邀请',
                _busy || !state.inputReady || state.deviceId.isEmpty ? null : () {
                  Navigator.pop(sheetContext);
                  _prepareInvitation(widget.controller.copyInvitation,
                    readyHint: '连接好后会复制邀请', sendingLabel: '正在复制邀请');
                }),
              ExpansionTile(key: Key('show-device-id'), leading: Icon(Icons.dialpad_rounded),
                tilePadding: EdgeInsets.symmetric(horizontal: 20),
                title: Text('设备号码', style: TextStyle(fontSize: 20)), children: [
                  SelectableText(state.deviceId.isEmpty ? '正在获取' : readableId(state.deviceId),
                    key: Key('local-device-id'), style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
                  TextButton.icon(onPressed: state.deviceId.isEmpty ? null : () async {
                    await Clipboard.setData(ClipboardData(text: state.deviceId));
                    if (mounted) _message('设备号码已复制');
                  }, icon: Icon(Icons.copy_rounded), label: Text('复制号码')),
                ]),
              tool('paste-invitation', Icons.content_paste_rounded, '粘贴邀请',
                _busy ? null : () => action(widget.controller.pasteInvitation)),
            ],
            if (!elder && state.invitationCode == null)
              tool('full-interface', Icons.dashboard_outlined, '完整操作界面',
                _busy || state.invitationBlocked ? null : () => action(() => widget.controller.setFullInterface(true))),
            if (widget.controller.supportsSharing)
              tool('share-install', Icons.ios_share_rounded, '分享给家人安装',
                _busy ? null : () => action(widget.controller.shareInstall)),
            tool('use-help', Icons.help_outline_rounded, '使用帮助', () {
              Navigator.pop(sheetContext);
              _help(context);
            }),
            tool('advanced-settings', Icons.settings_outlined, '连接与高级设置', () {
              Navigator.pop(sheetContext);
              widget.controller.openSettings();
            }),
            tool('connection-diagnostics', Icons.monitor_heart_outlined, '连接诊断', () {
              Navigator.pop(sheetContext);
              widget.controller.openDiagnostics();
            }),
            tool('privacy-policy', Icons.privacy_tip_outlined, '隐私政策',
              () => action(widget.controller.openPrivacyPolicy)),
          ]);
        })),
    ).whenComplete(() { if (mounted) setState(() {}); });
  }

  bool _elderMode(BuildContext context) => Theme.of(context).textTheme.bodyMedium!.fontSize! >= 20;

  void _help(BuildContext context) => Navigator.of(context).push(MaterialPageRoute<void>(
    builder: (_) => Theme(data: Theme.of(context), child: Scaffold(
      appBar: AppBar(title: Text('使用帮助')),
      body: ListView(padding: EdgeInsets.all(24), children: [
        Text('家人怎么连接', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w700)),
        SizedBox(height: 20),
        Text('复制家人发来的邀请，再打开帮帮，点“连接家人”。\n\n被帮助者使用安卓手机：开启操作权限 → 点“邀请家人”，按提示共享整个屏幕。手机准备好后会自动打开分享；发完消息回到帮帮，收到请求时点“允许协助”。\n\niPhone 和 iPad 可以作为家人端。',
          style: TextStyle(fontSize: _elderMode(context) ? 20 : 16, height: 1.6)),
        SizedBox(height: 24),
        Text('常见问题', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700)),
        SizedBox(height: 12),
        Text('找不到权限？\n在手机设置 → 无障碍 → 已安装的应用中找到“帮帮远程操作”。\n\n提示受限设置？\nAndroid 13 及以上可能需要在应用信息页允许受限设置，再开启无障碍服务。\n\n黑屏或无法点击？\n共享时选择“整个屏幕”。锁屏、支付页和受保护页面需要手机主人操作。\n\n无法连接？\n两台手机都要联网，并保持被帮助者正在等待。可切换 Wi-Fi 或移动网络。',
          style: TextStyle(fontSize: _elderMode(context) ? 20 : 16, height: 1.6)),
        SizedBox(height: 24),
        TextButton(onPressed: widget.controller.openSource, child: Text('开源代码与许可证')),
        Text('帮帮 · 基于 RustDesk 1.4.9\nAGPL-3.0 · 非 RustDesk 官方客户端',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 14, height: 1.6)),
      ]),
    )),
  )).whenComplete(() { if (mounted) setState(() {}); });
}

class _InvitationPromptRoute extends DialogRoute<bool> {
  _InvitationPromptRoute({required super.context, required super.builder});

  void cancel(NavigatorState navigator) {
    // Flutter 3.24 removeRoute alone does not complete its push future.
    didComplete(false);
    navigator.removeRoute(this);
  }
}

enum _Glyph { permission, completed, invitation, paste }

class _ActionPainter extends CustomPainter {
  const _ActionPainter(this.glyph, this.color);
  final _Glyph glyph;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 52, size.height / 52);
    final pen = Paint()..color = color..style = PaintingStyle.stroke
      ..strokeWidth = 2.1..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    switch (glyph) {
      case _Glyph.permission:
        final shield = Path()..moveTo(26, 12)..cubicTo(30, 16, 35, 16, 38, 17)
          ..lineTo(38, 25)..cubicTo(38, 34, 31, 39, 26, 41)
          ..cubicTo(21, 39, 14, 34, 14, 25)..lineTo(14, 17)
          ..cubicTo(18, 16, 22, 16, 26, 12)..close();
        canvas.drawPath(shield, pen);
        canvas.drawPath(Path()..moveTo(20, 26)..lineTo(25, 31)..lineTo(33, 22), pen);
        break;
      case _Glyph.completed:
        canvas.drawPath(Path()..moveTo(14, 26)..lineTo(23, 35)..lineTo(39, 18), pen..strokeWidth = 3.2);
        break;
      case _Glyph.invitation:
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(12, 17, 28, 21), Radius.circular(5)), pen);
        canvas.drawPath(Path()..moveTo(13, 20)..lineTo(26, 29)..lineTo(39, 20), pen);
        canvas.drawLine(Offset(14, 36), Offset(21, 29), pen);
        canvas.drawLine(Offset(38, 36), Offset(31, 29), pen);
        break;
      case _Glyph.paste:
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(16, 14, 23, 28), Radius.circular(5)), pen);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(22, 11, 11, 7), Radius.circular(3)), pen);
        canvas.drawLine(Offset(22, 25), Offset(33, 25), pen);
        canvas.drawLine(Offset(22, 31), Offset(30, 31), pen);
        break;
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_ActionPainter oldDelegate) => oldDelegate.glyph != glyph || oldDelegate.color != color;
}

class _ConnectionPainter extends CustomPainter {
  const _ConnectionPainter(this.dark);
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    final scale = (size.width / 300).clamp(0.0, size.height / 170);
    canvas.save();
    canvas.translate((size.width - 300 * scale) / 2, (size.height - 170 * scale) / 2);
    canvas.scale(scale);
    canvas.drawOval(Rect.fromLTWH(64, 141, 172, 14), Paint()
      ..color = (dark ? Colors.black : Color(0xFF655145)).withOpacity(.05));
    canvas.drawCircle(Offset(149, 84), 66, Paint()
      ..color = dark ? Color(0xFF2B211A) : Color(0xFFF4E7D8));
    _phone(canvas, Offset(111, 81), -.13, false);
    _phone(canvas, Offset(191, 83), .13, true);
    final badge = Path()..addOval(Rect.fromCircle(center: Offset(150, 81), radius: 24));
    canvas.drawShadow(badge, Colors.black.withOpacity(.18), 7, false);
    canvas.drawPath(badge, Paint()..color = dark ? Color(0xFF342820) : Color(0xFFFFFBF6));
    canvas.drawCircle(Offset(150, 81), 23.5, Paint()..color = Colors.white.withOpacity(dark ? .1 : .9)
      ..style = PaintingStyle.stroke..strokeWidth = 1);
    canvas.save();
    canvas.translate(150, 81);
    canvas.rotate(-.65);
    final link = Paint()..color = dark ? Color(0xFFFFAE6F) : Color(0xFFDF620D)
      ..style = PaintingStyle.stroke..strokeWidth = 3.2;
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-14, -7, 18, 14), Radius.circular(7)), link);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-4, -7, 18, 14), Radius.circular(7)), link);
    canvas.restore();
    canvas.drawCircle(Offset(59, 54), 3.5, Paint()..color = dark ? Color(0xFF775139) : Color(0xFFEFC8A8));
    canvas.drawCircle(Offset(242, 112), 2.5, Paint()..color = dark ? Color(0xFF775139) : Color(0xFFEFC8A8));
    canvas.restore();
  }

  void _phone(Canvas canvas, Offset center, double angle, bool orange) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    final body = RRect.fromRectAndRadius(Rect.fromLTWH(-38, -65, 76, 130), Radius.circular(19));
    canvas.drawShadow(Path()..addRRect(body), Colors.black.withOpacity(.16), 9, false);
    canvas.drawRRect(body, Paint()..color = orange ? Color(0xFFDD641A) :
      dark ? Color(0xFF49413A) : Color(0xFFFFFEFC));
    canvas.drawRRect(body.deflate(.7), Paint()..color = orange ? Color(0xFFF19A53) :
      dark ? Color(0xFF65594F) : Color(0xFFE2D8CC)..style = PaintingStyle.stroke..strokeWidth = 1.3);
    final screen = RRect.fromRectAndRadius(Rect.fromLTWH(-30, -53, 60, 102), Radius.circular(12));
    canvas.drawRRect(screen, Paint()..color = dark ? Color(0xFF28221E) :
      orange ? Color(0xFFFFF6E9) : Color(0xFFF3EEE7));
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-11, -58, 22, 3), Radius.circular(2)),
      Paint()..color = orange ? Color(0xFFF3AF75) : Color(0xFFD0C7BC));
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-12, 55, 24, 3), Radius.circular(2)),
      Paint()..color = orange ? Color(0xFFF6C8A3) : Color(0xFFD0C7BC));
    canvas.drawCircle(Offset(0, -9), 20, Paint()..color = dark ? Color(0xFF423022) :
      orange ? Color(0xFFFFE5C7) : Color(0xFFEAE1D4));
    final heart = Path()..moveTo(0, 2)..cubicTo(-3, -1, -13, -6, -13, -13)
      ..cubicTo(-13, -22, -4, -24, 0, -17)..cubicTo(4, -24, 13, -22, 13, -13)
      ..cubicTo(13, -6, 3, -1, 0, 2)..close();
    canvas.drawPath(heart, Paint()..color = orange ? Color(0xFFDF620D) :
      dark ? Color(0xFF9E8065) : Color(0xFFBE9B79));
    for (final line in [(24.0, 34.0), (32.0, 22.0)]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-line.$2 / 2, line.$1, line.$2, 3), Radius.circular(2)),
        Paint()..color = dark ? Color(0xFF67594C) : Color(0xFFDAD0C3));
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_ConnectionPainter oldDelegate) => oldDelegate.dark != dark;
}
