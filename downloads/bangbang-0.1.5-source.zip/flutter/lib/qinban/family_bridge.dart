import '../common.dart';
import '../models/model.dart';
import '../models/platform_model.dart';
import '../models/server_model.dart';
import 'family_models.dart';
import 'family_service.dart';
import 'family_store.dart';
import 'family_transport.dart';

/// Keeps upstream model hooks inert outside the initialized mobile app.
class FamilyBridge {
  static FamilyService? service;
  static final Map<int, String> _incoming = {};
  static final _outgoing = Expando<String>('family-channel');
  static int _outgoingGeneration = 0;

  static FamilyService initialize() {
    return service ??= _create();
  }

  static FamilyContext _context() {
    final peerId = gFFI.serverModel.serverId.text.replaceAll(RegExp(r'\s'), '');
    final scope = familyServerScope(
        bind.mainGetOptionSync(key: 'custom-rendezvous-server'),
        bind.mainGetOptionSync(key: 'key'));
    return FamilyContext(peerId, validFamilyScope(scope) ? scope : '');
  }

  static FamilyService _create() {
    final store = FamilyStore(
        bind.mainGetLocalOption(key: 'qinban-family-v1'),
        (data) =>
            bind.mainSetLocalOption(key: 'qinban-family-v1', value: data));
    return FamilyService(
        store: store,
        transport: NetlifyFamilyTransport(store.identity!),
        context: _context);
  }

  // Mobile reuses one FFI and one native session ID. Each new connection still
  // needs a different family channel, so a late callback cannot end its successor.
  static String outgoingId(FFI ffi) =>
      _outgoing[ffi] ?? 'out:${ffi.sessionId}:0';

  static void outgoingStarted(FFI ffi, String peerId) {
    final previous = _outgoing[ffi];
    if (previous != null) service?.disconnected(previous);
    final channelId = 'out:${ffi.sessionId}:${++_outgoingGeneration}';
    _outgoing[ffi] = channelId;
    if (ffi.connType == ConnType.defaultConn) {
      service?.attachOutgoingCall(peerId, channelId);
    }
  }

  static String incomingId(int connId) => 'in:$connId';

  static void outgoingConnected(FFI ffi) {
    final current = service;
    if (current == null ||
        ffi.connType != ConnType.defaultConn ||
        ffi.closed ||
        !ffi.ffiModel.pi.isSet.value) return;
    final peerId = ffi.id;
    final encrypted = ffi.ffiModel.secure == true;
    final channelId = outgoingId(ffi);
    current.connected(FamilyChannel(
        id: channelId,
        peerId: peerId,
        name: ffi.ffiModel.pi.username,
        direction: FamilyDirection.outgoingElder,
        encrypted: encrypted,
        isActive: () =>
            !ffi.closed &&
            outgoingId(ffi) == channelId &&
            ffi.id == peerId &&
            ffi.ffiModel.pi.isSet.value &&
            (!encrypted || ffi.ffiModel.secure == true),
        send: (text) =>
            bind.sessionSendChat(sessionId: ffi.sessionId, text: text)));
  }

  static void outgoingDisconnected(FFI ffi) =>
      service?.disconnected(outgoingId(ffi));

  static void syncIncoming(ServerModel model) {
    final current = service;
    if (current == null) return;
    final clients = model.clients
        .where((c) =>
            c.authorized &&
            !c.disconnected &&
            !c.isFileTransfer &&
            !c.isViewCamera &&
            !c.isTerminal &&
            c.portForward.isEmpty)
        .toList();
    for (final id in _incoming.keys.toList()) {
      if (!clients.any((c) => c.id == id && c.peerId == _incoming[id])) {
        current.disconnected(incomingId(id));
        _incoming.remove(id);
      }
    }
    for (final client in clients) {
      if (_incoming[client.id] == client.peerId) continue;
      _incoming[client.id] = client.peerId;
      current.connected(FamilyChannel(
          id: incomingId(client.id),
          peerId: client.peerId,
          name: client.name,
          direction: FamilyDirection.incomingHelper,
          encrypted:
              false, // CM exposes no encryption flag; this side never sends a capability.
          isActive: () => model.clients.any((c) =>
              c.id == client.id &&
              c.peerId == client.peerId &&
              c.authorized &&
              !c.disconnected),
          send: (text) => bind.cmSendChat(connId: client.id, msg: text)));
    }
  }

  static bool receiveChat(FFI ffi, int connId, String text) {
    if (!text.startsWith(familyChatPrefix)) return false;
    if (connId >= 0) syncIncoming(ffi.serverModel);
    service?.consumeChat(
        connId < 0 ? outgoingId(ffi) : incomingId(connId), text);
    return true; // Invalid/unauthorized internal frames must not open the chat UI.
  }
}
