import 'dart:async';
import 'dart:convert';

const qinbanWebsite = 'https://bangbang-download.s419505080.chatgpt.site/';
const qinbanPrivacyUrl = '${qinbanWebsite}privacy.html';
const qinbanInviteHost = 'bangbang-download.s419505080.chatgpt.site';
const qinbanLegacyInviteHost = 'bangbang-jacklee992.netlify.app';
const qinbanBrandInviteHost = 'bangbang.yilin.fun';
const qinbanInviteMarker = '【帮帮邀请】';

String encodePairingCode(String deviceId) {
  if (!RegExp(r'^\d{6,16}$').hasMatch(deviceId)) {
    throw const FormatException('Invalid device number');
  }
  return 'BB1-${base64Url.encode(utf8.encode(deviceId)).replaceAll('=', '')}';
}

String? decodePairingCode(String token) {
  if (!RegExp(r'^BB1-[A-Za-z0-9_-]{8,22}$').hasMatch(token)) return null;
  try {
    final deviceId = utf8.decode(base64Url.decode(base64Url.normalize(token.substring(4))));
    if (!RegExp(r'^\d{6,16}$').hasMatch(deviceId)) return null;
    return encodePairingCode(deviceId) == token ? deviceId : null;
  } on FormatException {
    return null;
  }
}

class QinbanInvitation {
  const QinbanInvitation(this.deviceId);
  final String deviceId;
  String get token => encodePairingCode(deviceId);
  String get url => Uri.https(qinbanInviteHost, '/invite.html', {'code': token}).toString();
  String get message => '我这手机有个地方弄不明白，你有空帮我看看。\n\n'
      '把这条消息整个复制下来，再打开「帮帮」，点一下「连接家人」就行。\n\n'
      '$qinbanInviteMarker\n配对口令：$token\n$url\n\n'
      '还没装帮帮的话，点这里装：\n$qinbanWebsite';
}

bool isQinbanInvitationLink(String raw) {
  final uri = Uri.tryParse(raw);
  return uri != null && (uri.scheme == 'bangbang' ||
      const {qinbanInviteHost, qinbanLegacyInviteHost, qinbanBrandInviteHost}.contains(uri.host));
}

QinbanInvitation? parseInvitationUrl(String raw) {
  // Uri normalizes an explicitly written :443 away; enforce the canonical origin
  // before parsing so a default port does not bypass the origin restriction.
  final authority = RegExp(r'^[^:]+://([^/?#]+)').firstMatch(raw.trim())?.group(1);
  if (authority == null || authority.contains(':')) return null;
  final uri = Uri.tryParse(raw.trim());
  if (uri == null || uri.userInfo.isNotEmpty || uri.hasPort || uri.fragment.isNotEmpty) return null;
  final web = uri.scheme == 'https' &&
      ((uri.host == qinbanInviteHost && uri.path == '/invite.html') ||
       (uri.host == qinbanBrandInviteHost && uri.path == '/invite.html') ||
       (uri.host == qinbanLegacyInviteHost && uri.path == '/invite'));
  final app = uri.scheme == 'bangbang' && uri.host == 'invite' && uri.path.isEmpty;
  if (!web && !app) return null;
  try {
    final parameters = uri.queryParametersAll;
    if (parameters.length != 1 || parameters['code']?.length != 1) return null;
    final id = decodePairingCode(parameters['code']!.single);
    return id == null ? null : QinbanInvitation(id);
  } on FormatException {
    return null;
  }
}

/// Only our URL, a standalone versioned token, or marked invitation text qualifies.
QinbanInvitation? parseInvitationClipboard(String text) {
  final value = text.trim();
  if (value.length > 8192) return null;
  final tokenId = decodePairingCode(value);
  if (tokenId != null) return QinbanInvitation(tokenId);
  final direct = parseInvitationUrl(value);
  if (direct != null) return direct;
  if (!value.contains(qinbanInviteMarker)) return null;

  final ids = <String>{};
  final links = RegExp(r'(?:https?://|bangbang://)[^\s<>"“”]+', caseSensitive: false);
  for (final match in links.allMatches(value)) {
    final raw = match.group(0)!;
    if (!isQinbanInvitationLink(raw)) continue;
    // The installation URL is allowed in our share message.
    if (raw == qinbanWebsite || raw == 'https://$qinbanLegacyInviteHost/' ||
        raw == 'https://$qinbanBrandInviteHost/') continue;
    final invitation = parseInvitationUrl(raw);
    if (invitation == null) return null;
    ids.add(invitation.deviceId);
  }
  for (final match in RegExp(r'\bBB[0-9]+-[A-Za-z0-9_=-]+').allMatches(value)) {
    final id = decodePairingCode(match.group(0)!);
    if (id == null) return null;
    ids.add(id);
  }
  return ids.length == 1 ? QinbanInvitation(ids.single) : null;
}

enum InvitationSource { link, clipboard, paste }

/// Retains cold-start invitations until the home controller has attached.
class InvitationInbox {
  final _changes = StreamController<void>.broadcast(sync: true);
  String? _lastOfferedDeviceId;
  int _revision = 0;
  QinbanInvitation? current;
  InvitationSource? source;
  Stream<void> get changes => _changes.stream;
  int get revision => _revision;

  bool handleLink(String raw) {
    if (!isQinbanInvitationLink(raw)) return false;
    final invitation = parseInvitationUrl(raw);
    if (invitation != null) _offer(invitation, InvitationSource.link, explicit: true);
    return true; // Invalid owned URLs must never reach RustDesk's generic handler.
  }

  bool offerClipboard(String text, {bool explicit = false}) {
    if (!explicit && current != null && source == InvitationSource.link) return false;
    final invitation = parseInvitationClipboard(text);
    if (invitation == null) return false;
    return _offer(invitation, explicit ? InvitationSource.paste : InvitationSource.clipboard,
        explicit: explicit);
  }

  bool _offer(QinbanInvitation invitation, InvitationSource incoming, {bool explicit = false}) {
    if (current?.deviceId == invitation.deviceId && incoming != InvitationSource.paste) return explicit;
    if (!explicit && _lastOfferedDeviceId == invitation.deviceId) return false;
    _lastOfferedDeviceId = invitation.deviceId;
    current = invitation;
    source = incoming;
    _revision++;
    _changes.add(null);
    return true;
  }

  void dismiss() {
    current = null;
    source = null;
    _changes.add(null);
  }
}

final qinbanInvitationInbox = InvitationInbox();
