import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';

enum DiagnosticPhase { starting, serviceReady, calling, ringing,
  signalingConnecting, signalingHandshake, peerLookup, directConnecting,
  relayConnecting, peerHandshake, contacting, waitingApproval, authorized, firstFrame }
enum DiagnosticOutcome { pending, ready, success, failure, cancelled, interrupted }
enum DiagnosticError { none, offline, network, timeout, rejected, password, keyMismatch, capture, unknown,
  dns, refused, reset, unreachable, handshake, relay, signaling, serviceRejected, permission, protocol }

DiagnosticError classifyConnectionError(String message) {
  final text = message.toLowerCase();
  if (text.contains('offline') || text.contains('not exist')) return DiagnosticError.offline;
  if (text.contains('key mismatch')) return DiagnosticError.keyMismatch;
  if (text.contains('password')) return DiagnosticError.password;
  // Inspect the deepest cause before its generic "Failed to connect" context.
  // Only these fixed categories are retained; the native message stays local.
  if (text.contains('permission denied') || text.contains('operation not permitted')) return DiagnosticError.permission;
  if (text.contains('key overuse') || text.contains('license overuse') ||
      text.contains('access to mobile devices is restricted in your country')) {
    return DiagnosticError.serviceRejected;
  }
  if (text.contains('timeout') || text.contains('timed out') || text.contains('deadline')) return DiagnosticError.timeout;
  if (text.contains('dns') || text.contains('resolve') || text.contains('nodename nor servname') ||
      text.contains('name or service not known') || text.contains('getaddrinfo')) return DiagnosticError.dns;
  if (text.contains('connection refused')) return DiagnosticError.refused;
  if (text.contains('reset by') || text.contains('connection reset') || text.contains('broken pipe')) return DiagnosticError.reset;
  if (text.contains('unreachable') || text.contains('no route to host') || text.contains('network is down')) return DiagnosticError.unreachable;
  if (text.contains('websocket') && text.contains('http error:')) {
    if (RegExp(r'http error: (401|403|429)\b').hasMatch(text)) return DiagnosticError.serviceRejected;
    return DiagnosticError.protocol;
  }
  if (text.contains('handshake') || text.contains('secure tcp') || text.contains('decryption')) return DiagnosticError.handshake;
  if (text.contains('other punch hole failure') || text.contains('invalid message')) return DiagnosticError.protocol;
  if (text.contains('reject') || text.contains('denied')) return DiagnosticError.rejected;
  if (text.contains('relay server')) return DiagnosticError.relay;
  if (text.contains('rendezvous server')) return DiagnosticError.signaling;
  if (text.contains('network') || text.contains('connect') || text.contains('resolve') ||
      text.contains('reset') || text.contains('unreachable')) return DiagnosticError.network;
  return DiagnosticError.unknown;
}

String connectionProblemText(DiagnosticError error) => switch (error) {
  DiagnosticError.offline => '家人的手机还没准备好。让家人打开帮帮，点“邀请家人”，看到“等待家人”后再试。',
  DiagnosticError.rejected => '家人暂未允许这次协助。确认方便后，再发起连接。',
  DiagnosticError.password => '连接验证没有通过。让家人重新从帮帮发一条邀请，再试一次。',
  DiagnosticError.keyMismatch => '两台手机的连接服务设置不一致，请在“更多 → 连接与高级设置”中核对。',
  DiagnosticError.timeout => '暂时没有连上。让家人回到帮帮查看是否需要点“允许协助”，也可以检查网络后重试。',
  DiagnosticError.dns || DiagnosticError.refused || DiagnosticError.unreachable ||
    DiagnosticError.signaling || DiagnosticError.relay => '暂时连不上连接服务。试着切换 Wi-Fi 或手机流量后再连接。',
  DiagnosticError.serviceRejected => '连接服务拒绝了这次协助。确认两台手机使用同一连接服务后，再发起连接。',
  DiagnosticError.handshake || DiagnosticError.protocol =>
    '连接服务没有完成验证。确认两台手机都更新了帮帮，再试一次。',
  _ => '连接暂时中断。检查两台手机的网络，让家人保持帮帮打开，再试一次。',
};

class DiagnosticAttempt {
  DiagnosticAttempt._(this.data, this.elapsed);
  final Map<String, dynamic> data;
  final int Function() elapsed;
  bool get pending => data['outcome'] == 'pending';
  Map<String, dynamic> get snapshot => Map.of(data);
}

/// Structured allowlisted facts only: never pass a peer ID, invitation, raw
/// native error, clipboard text, device name or session credential to storage.
class ConnectionDiagnostics extends ChangeNotifier {
  ConnectionDiagnostics({required this.write, required this.platform,
      required this.appVersion, required this.build, this.upload, DateTime Function()? now})
      : now = now ?? DateTime.now;

  final Future<void> Function(String) write;
  final Future<bool> Function(Map<String, dynamic>)? upload;
  final String platform;
  final String appVersion;
  final String build;
  final DateTime Function() now;
  final List<DiagnosticAttempt> _attempts = [];
  final Map<String, int> _uploaded = {};
  Future<void> _writes = Future.value();
  bool _uploading = false;
  bool _flushAgain = false;
  bool uploadEnabled = true;
  bool storageAvailable = true;
  DateTime? _retryAfter;
  Timer? _retryTimer;
  bool _uploadActive = true;
  bool _disposed = false;
  static const maxAttempts = 100;
  static const retention = Duration(days: 7);

  List<Map<String, dynamic>> get records => _attempts.reversed.map((e) => e.snapshot).toList();
  ConnectionDiagnosticSummary get summary =>
      ConnectionDiagnosticSummary.fromRecords(records, now: now());
  Future<void> get saved => _writes;
  bool get uploadConfigured => upload != null;

  void restore(String raw) {
    try {
      if (raw.length > 131072) return;
      final saved = jsonDecode(raw);
      if (saved is! Map || saved['v'] != 1 || saved['attempts'] is! List) return;
      uploadEnabled = saved['uploadEnabled'] != false;
      for (final item in (saved['attempts'] as List).take(maxAttempts)) {
        final data = parseDiagnosticRecord(item);
        if (data == null) continue;
        if (data['outcome'] == 'pending') {
          data['outcome'] = 'interrupted';
          data['revision']++;
        }
        _attempts.add(DiagnosticAttempt._(data, () => data['elapsedMs'] as int));
      }
      _prune();
    } catch (_) { /* Corrupt diagnostics must never block assistance. */ }
  }

  DiagnosticAttempt begin({String kind = 'connection', String? callId, String role = 'helper'}) {
    final random = Random.secure();
    final id = base64Url.encode(List<int>.generate(16, (_) => random.nextInt(256))).replaceAll('=', '');
    final clock = Stopwatch()..start();
    final attempt = DiagnosticAttempt._({
      'v': 1, 'attemptId': id, 'kind': ['preparation', 'call'].contains(kind) ? kind : 'connection',
      'callId': callId != null && RegExp(r'^[A-Za-z0-9_-]{22}$').hasMatch(callId) ? callId : id,
      'role': role == 'elder' ? 'elder' : 'helper',
      'platform': platform, 'appVersion': appVersion, 'build': build,
      'startedAt': now().millisecondsSinceEpoch, 'elapsedMs': 0,
      'phase': 'starting', 'outcome': 'pending', 'error': 'none', 'path': 'unknown', 'revision': 0,
    }, () => clock.elapsedMilliseconds);
    _attempts.add(attempt);
    _changed();
    return attempt;
  }

  void advance(DiagnosticAttempt attempt, DiagnosticPhase phase, {bool? direct}) {
    if (!attempt.pending || !_attempts.contains(attempt)) return;
    final previous = DiagnosticPhase.values.byName(attempt.data['phase']);
    if (phase.index < previous.index) return;
    if (phase == previous && direct == null) return;
    attempt.data['phase'] = phase.name;
    if (direct != null) attempt.data['path'] = direct ? 'direct' : 'relay';
    if (phase == DiagnosticPhase.firstFrame) attempt.data['outcome'] = 'success';
    if (phase == DiagnosticPhase.serviceReady && attempt.data['kind'] == 'preparation') {
      attempt.data['outcome'] = 'ready';
    }
    _update(attempt);
  }

  void finish(DiagnosticAttempt attempt, DiagnosticOutcome outcome, {DiagnosticError error = DiagnosticError.none}) {
    if (!attempt.pending || !_attempts.contains(attempt) || outcome == DiagnosticOutcome.success ||
        outcome == DiagnosticOutcome.pending || outcome == DiagnosticOutcome.ready) return;
    attempt.data['outcome'] = outcome.name;
    attempt.data['error'] = error.name;
    _update(attempt);
  }

  void _update(DiagnosticAttempt attempt) {
    attempt.data['elapsedMs'] = attempt.elapsed().clamp(0, 600000);
    attempt.data['revision']++;
    _changed();
  }

  void setUploadEnabled(bool value) {
    uploadEnabled = value;
    if (!value) { _retryTimer?.cancel(); _retryTimer = null; }
    _changed();
  }

  void setUploadActive(bool value) {
    if (_disposed || _uploadActive == value) return;
    _uploadActive = value;
    if (!value) {
      _retryTimer?.cancel();
      _retryTimer = null;
    } else {
      // A resumed app may have changed networks. Replay without waiting for
      // another connection attempt or retaining a background cooldown.
      _retryAfter = null;
      unawaited(flush());
    }
  }

  void _scheduleFlush(Duration delay) {
    if (_disposed || !_uploadActive || !uploadEnabled || upload == null || _retryTimer != null) return;
    _retryTimer = Timer(delay, () {
      _retryTimer = null;
      unawaited(flush());
    });
  }

  @override
  void dispose() {
    _disposed = true;
    _retryTimer?.cancel();
    _retryTimer = null;
    super.dispose();
  }

  void _prune() {
    final cutoff = now().subtract(retention).millisecondsSinceEpoch;
    _attempts.removeWhere((e) => e.data['startedAt'] < cutoff);
    if (_attempts.length > maxAttempts) _attempts.removeRange(0, _attempts.length - maxAttempts);
    final ids = _attempts.map((e) => e.data['attemptId']).toSet();
    _uploaded.removeWhere((key, _) => !ids.contains(key));
  }

  String export() {
    _prune();
    return const JsonEncoder.withIndent('  ').convert({
      'v': 1, 'attempts': records, 'summary': summary.toJson(),
    });
  }

  void _changed() {
    if (_disposed) return;
    _prune();
    final raw = jsonEncode({'v': 1, 'uploadEnabled': uploadEnabled,
      'attempts': _attempts.map((e) => e.snapshot).toList()});
    _writes = _writes.then((_) => write(raw)).then((_) { storageAvailable = true; })
      .catchError((Object _) { storageAvailable = false; });
    notifyListeners();
    unawaited(flush());
  }

  Future<void> flush() async {
    if (_disposed || !_uploadActive || !uploadEnabled || upload == null) return;
    if (_uploading) { _flushAgain = true; return; }
    if (_retryAfter != null && now().isBefore(_retryAfter!)) {
      _scheduleFlush(_retryAfter!.difference(now()));
      return;
    }
    _retryTimer?.cancel();
    _retryTimer = null;
    _retryAfter = null;
    _uploading = true;
    try {
      _prune();
      // Bounded offline replay continues while the app is foreground, even
      // after the user stops retrying a failed connection.
      final pending = _attempts.reversed.where((attempt) =>
        _uploaded[attempt.data['attemptId']] != attempt.data['revision']).take(20).toList();
      for (final attempt in pending) {
        if (!uploadEnabled || !_uploadActive || _disposed) break;
        final record = attempt.snapshot;
        if (_uploaded[record['attemptId']] == record['revision']) continue;
        if (!await upload!(record)) {
          _retryAfter = now().add(const Duration(seconds: 60));
          break;
        }
        _uploaded[record['attemptId']] = record['revision'];
      }
    } catch (_) {
      _retryAfter = now().add(const Duration(seconds: 60));
    } finally {
      _uploading = false;
      if (_flushAgain) { _flushAgain = false; unawaited(flush()); }
      if (_attempts.any((attempt) => _uploaded[attempt.data['attemptId']] != attempt.data['revision'])) {
        final delay = _retryAfter?.difference(now()) ?? const Duration(seconds: 1);
        _scheduleFlush(delay.isNegative ? Duration.zero : delay);
      }
    }
  }
}

const _diagnosticKeys = {'v', 'attemptId', 'callId', 'role', 'kind', 'platform', 'appVersion', 'build',
  'startedAt', 'elapsedMs', 'phase', 'outcome', 'error', 'path', 'revision'};

Map<String, dynamic>? parseDiagnosticRecord(dynamic value) {
  if (value is! Map || value.length != _diagnosticKeys.length ||
      !value.keys.every(_diagnosticKeys.contains) || value['v'] != 1 ||
      value['attemptId'] is! String || !RegExp(r'^[A-Za-z0-9_-]{22}$').hasMatch(value['attemptId']) ||
      value['callId'] is! String || !RegExp(r'^[A-Za-z0-9_-]{22}$').hasMatch(value['callId']) ||
      !['elder', 'helper'].contains(value['role']) ||
      !['connection', 'preparation', 'call'].contains(value['kind']) ||
      !['ios', 'android'].contains(value['platform']) ||
      value['appVersion'] is! String || !RegExp(r'^\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.]+)?$').hasMatch(value['appVersion']) ||
      value['appVersion'].length > 40 || value['build'] is! String ||
      !RegExp(r'^\d{1,12}$').hasMatch(value['build']) ||
      value['startedAt'] is! int || value['startedAt'] <= 0 ||
      value['elapsedMs'] is! int || value['elapsedMs'] < 0 || value['elapsedMs'] > 600000 ||
      value['revision'] is! int || value['revision'] < 0 || value['revision'] > 64 ||
      !DiagnosticPhase.values.any((e) => e.name == value['phase']) ||
      !DiagnosticOutcome.values.any((e) => e.name == value['outcome']) ||
      !DiagnosticError.values.any((e) => e.name == value['error']) ||
      !['unknown', 'direct', 'relay'].contains(value['path']) ||
      (value['outcome'] == 'success' && value['phase'] != 'firstFrame') ||
      (value['outcome'] == 'ready' && (value['phase'] != 'serviceReady' || value['kind'] != 'preparation'))) return null;
  return Map<String, dynamic>.from(value);
}

/// Connection outcomes, not reasons for ending an already successful session.
/// A first frame fixes success even if the subsequent assistance disconnects.
class DiagnosticOutcomeCounts {
  DiagnosticOutcomeCounts._(Map<String, int> counts)
      : _counts = Map.unmodifiable(counts);

  final Map<String, int> _counts;
  int get success => _counts['success'] ?? 0;
  int get failure => _counts['failure'] ?? 0;
  int get cancelled => _counts['cancelled'] ?? 0;
  int get interrupted => _counts['interrupted'] ?? 0;
  int get pending => _counts['pending'] ?? 0;
  int get decided => success + failure;
  int get total => decided + cancelled + interrupted + pending;
  double? get successRate => decided == 0 ? null : success / decided;

  Map<String, dynamic> toJson() => {
    'total': total, 'decided': decided, 'success': success, 'failure': failure,
    'cancelled': cancelled, 'interrupted': interrupted, 'pending': pending,
    'successRate': successRate,
  };
}

class DiagnosticFirstFrameTiming {
  DiagnosticFirstFrameTiming._(List<int> samples, this.cappedCount)
      : _samples = List.unmodifiable(samples..sort());

  final List<int> _samples;
  final int cappedCount;
  int get sampleCount => _samples.length;
  double? get meanMs => _samples.isEmpty
      ? null : _samples.reduce((a, b) => a + b) / sampleCount;
  int? get p50Ms => _percentile(.5);
  int? get p95Ms => _percentile(.95);
  int? get maxMs => _samples.isEmpty ? null : _samples.last;
  int? _percentile(double fraction) => _samples.isEmpty
      ? null : _samples[(sampleCount * fraction).ceil() - 1];

  Map<String, dynamic> toJson() => {
    'sampleCount': sampleCount, 'cappedCount': cappedCount, 'meanMs': meanMs,
    'p50Ms': p50Ms, 'p95Ms': p95Ms, 'maxMs': maxMs,
    'cappedAtMs': 600000, 'percentileMethod': 'nearestRank',
  };
}

/// On-demand local aggregation of the retained helper connection attempts.
/// No new identifier or event is collected and nothing here invokes upload.
/// Phase groups are the last observed phase, never inferred funnel completion
/// or dwell time. Time to first frame includes authorization/network waiting.
class ConnectionDiagnosticSummary extends DiagnosticOutcomeCounts {
  ConnectionDiagnosticSummary._(super.counts, {
    required this.firstFrame,
    required this.byFinalPhase,
    required this.byPath,
    required this.failuresByError,
  }) : super._();

  final DiagnosticFirstFrameTiming firstFrame;
  final Map<String, DiagnosticOutcomeCounts> byFinalPhase;
  final Map<String, DiagnosticOutcomeCounts> byPath;
  final Map<String, int> failuresByError;

  factory ConnectionDiagnosticSummary.fromRecords(
      Iterable<Map<String, dynamic>> records, {required DateTime now}) {
    final cutoff = now.subtract(ConnectionDiagnostics.retention).millisecondsSinceEpoch;
    final end = now.millisecondsSinceEpoch;
    final unique = <String, Map<String, dynamic>>{};
    for (final item in records) {
      final record = parseDiagnosticRecord(item);
      if (record == null || record['kind'] != 'connection' ||
          record['role'] != 'helper' || record['startedAt'] < cutoff ||
          record['startedAt'] > end) continue;
      final id = record['attemptId'] as String;
      final previous = unique[id];
      if (previous == null || record['revision'] > previous['revision'] ||
          (record['revision'] == previous['revision'] &&
           previous['outcome'] == 'pending' && record['outcome'] != 'pending')) {
        unique[id] = record;
      }
    }
    final counts = <String, int>{};
    final phases = <String, Map<String, int>>{};
    final paths = <String, Map<String, int>>{};
    final failures = <String, int>{};
    final samples = <int>[];
    var capped = 0;
    void increment(Map<String, int> target, String key) {
      target.update(key, (count) => count + 1, ifAbsent: () => 1);
    }
    for (final record in unique.values) {
      final outcome = record['outcome'] as String;
      increment(counts, outcome);
      increment(phases.putIfAbsent(record['phase'] as String, () => {}), outcome);
      increment(paths.putIfAbsent(record['path'] as String, () => {}), outcome);
      if (outcome == 'failure') increment(failures, record['error'] as String);
      if (outcome == 'success') {
        final elapsed = record['elapsedMs'] as int;
        // The existing collector saturates at ten minutes. Do not report that
        // sentinel as an exact latency or silently bias the mean/percentiles.
        if (elapsed == 600000) { capped++; } else { samples.add(elapsed); }
      }
    }
    return ConnectionDiagnosticSummary._(counts,
      firstFrame: DiagnosticFirstFrameTiming._(samples, capped),
      byFinalPhase: Map.unmodifiable({
        for (final phase in DiagnosticPhase.values)
          if (phases.containsKey(phase.name))
            phase.name: DiagnosticOutcomeCounts._(phases[phase.name]!),
      }),
      byPath: Map.unmodifiable({
        for (final path in ['direct', 'relay', 'unknown'])
          if (paths.containsKey(path)) path: DiagnosticOutcomeCounts._(paths[path]!),
      }),
      failuresByError: Map.unmodifiable(failures),
    );
  }

  @override
  Map<String, dynamic> toJson() => {
    'v': 1, 'windowDays': ConnectionDiagnostics.retention.inDays,
    'kind': 'connection', 'role': 'helper', ...super.toJson(),
    'successRateDenominator': 'success+failure',
    'firstFrame': firstFrame.toJson(),
    'phaseBasis': 'lastRecorded',
    'byFinalPhase': byFinalPhase.map((key, value) => MapEntry(key, value.toJson())),
    'byPath': byPath.map((key, value) => MapEntry(key, value.toJson())),
    'failuresByError': Map<String, int>.of(failuresByError),
  };
}
