import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'connection_diagnostics.dart';
import 'remote_performance.dart';

class DiagnosticsPage extends StatelessWidget {
  const DiagnosticsPage(
      {super.key, required this.diagnostics, this.performance});
  final ConnectionDiagnostics diagnostics;
  final RemotePerformanceMetrics? performance;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('连接诊断')),
        body: AnimatedBuilder(
            animation: Listenable.merge([diagnostics, performance]),
            builder: (context, _) {
              final summary = diagnostics.summary;
              final rate = summary.successRate == null
                  ? '—'
                  : '${(summary.successRate! * 100).toStringAsFixed(0)}%';
              return ListView(padding: const EdgeInsets.all(24), children: [
                Text('最近 7 天 · 本机帮助端',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                Text('连接成功率 $rate',
                    key: const Key('diagnostic-success-rate'),
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                Text('看到画面 ${summary.success} 次 · 失败 ${summary.failure} 次\n'
                    '取消 ${summary.cancelled} 次 · 中途退出 ${summary.interrupted} 次\n'
                    '连接中 ${summary.pending} 次'),
                const SizedBox(height: 12),
                Text('成功率只计算已看到画面和明确失败的 ${summary.decided} 次连接。'
                    '看到画面不代表已完成协助。最多保留最近 100 条诊断。'),
                const SizedBox(height: 24),
                _FirstFrameSummary(timing: summary.firstFrame),
                const SizedBox(height: 20),
                if (diagnostics.uploadConfigured)
                  SwitchListTile(
                    title: const Text('发送连接诊断'),
                    subtitle: const Text('只发送连接阶段、结果、耗时和版本，不包含屏幕、邀请或密码。'),
                    value: diagnostics.uploadEnabled,
                    onChanged: diagnostics.setUploadEnabled,
                    contentPadding: EdgeInsets.zero,
                  )
                else
                  const Text('诊断保存在这台手机，云端统计尚未启用。'),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                    key: const Key('copy-diagnostics'),
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('复制诊断'),
                    onPressed: () async {
                      final report = performance == null
                          ? diagnostics.export()
                          : jsonEncode({
                              'connection': jsonDecode(diagnostics.export()),
                              'performance': jsonDecode(performance!.export()),
                            });
                      await Clipboard.setData(ClipboardData(text: report));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('诊断已复制')));
                      }
                    }),
                const SizedBox(height: 24),
                if (performance != null)
                  _PerformanceSummary(record: performance!.latest),
                if (summary.total > 0) _ConnectionBreakdown(summary: summary),
              ]);
            }),
      );
}

class _FirstFrameSummary extends StatelessWidget {
  const _FirstFrameSummary({required this.timing});
  final DiagnosticFirstFrameTiming timing;

  @override
  Widget build(BuildContext context) {
    String seconds(int? value) =>
        value == null ? '—' : '${(value / 1000).toStringAsFixed(1)} 秒';
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('连接到画面', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      if (timing.sampleCount == 0)
        const Text('还没有可计算耗时的成功连接。')
      else ...[
        Text('中位数 ${seconds(timing.p50Ms)} · P95 ${seconds(timing.p95Ms)}',
            key: const Key('diagnostic-first-frame-time')),
        Text('基于 ${timing.sampleCount} 次成功连接；P95 表示约 95% 的样本不超过此耗时。'),
      ],
      if (timing.cappedCount > 0)
        Text('另有 ${timing.cappedCount} 次达到 10 分钟记录上限，未计入耗时统计。'),
      const SizedBox(height: 8),
      const Text('从进入连接页到收到第一帧画面，包含授权和网络等待，不包含之前的呼叫响铃。'),
    ]);
  }
}

class _ConnectionBreakdown extends StatelessWidget {
  const _ConnectionBreakdown({required this.summary});
  final ConnectionDiagnosticSummary summary;

  @override
  Widget build(BuildContext context) {
    const phaseNames = {
      'starting': '发起连接',
      'serviceReady': '手机已就绪',
      'calling': '正在呼叫',
      'ringing': '等待接听',
      'signalingConnecting': '连接服务',
      'signalingHandshake': '服务验证',
      'peerLookup': '查找家人',
      'directConnecting': '尝试直连',
      'relayConnecting': '连接中继',
      'peerHandshake': '安全验证',
      'contacting': '连接家人',
      'waitingApproval': '等待允许',
      'authorized': '等待画面',
      'firstFrame': '显示画面',
    };
    const errorNames = {
      'none': '未分类',
      'offline': '对方未就绪',
      'network': '网络连接',
      'timeout': '等待超时',
      'rejected': '未获允许',
      'password': '邀请验证',
      'keyMismatch': '连接设置',
      'capture': '屏幕共享',
      'unknown': '其他',
      'dns': '地址解析',
      'refused': '连接被拒绝',
      'reset': '连接被重置',
      'unreachable': '网络不可达',
      'handshake': '安全验证',
      'relay': '中继连接',
      'signaling': '连接服务',
      'serviceRejected': '服务限制',
      'permission': '网络权限',
      'protocol': '协议响应',
    };
    const pathNames = {'direct': '直连', 'relay': '中继', 'unknown': '未确定'};
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: const Text('查看分组统计'),
      children: [
        Align(
            alignment: Alignment.centerLeft,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('最后记录阶段', style: Theme.of(context).textTheme.titleMedium),
                const Text('每次连接只计入一个阶段，不是各阶段的通过率。'),
                for (final entry in summary.byFinalPhase.entries)
                  Text('${phaseNames[entry.key]} · ${entry.value.total} 次'),
                const SizedBox(height: 16),
                Text('连接路径', style: Theme.of(context).textTheme.titleMedium),
                for (final entry in summary.byPath.entries)
                  Text(
                      '${pathNames[entry.key]} · 看到画面 ${entry.value.success} 次 · '
                      '失败 ${entry.value.failure} 次 · 共 ${entry.value.total} 次'),
                if (summary.failuresByError.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text('失败原因', style: Theme.of(context).textTheme.titleMedium),
                  for (final entry in summary.failuresByError.entries)
                    Text('${errorNames[entry.key]} · ${entry.value} 次'),
                ],
                const SizedBox(height: 16),
              ],
            )),
      ],
    );
  }
}

class _PerformanceSummary extends StatelessWidget {
  const _PerformanceSummary({required this.record});
  final Map<String, dynamic>? record;

  @override
  Widget build(BuildContext context) {
    final data = record;
    String number(String key, [int decimals = 1]) =>
        data?[key] is num ? (data![key] as num).toStringAsFixed(decimals) : '—';
    return Padding(
        padding: const EdgeInsets.only(bottom: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('最近一次画面表现', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            if (data == null)
              const Text('连接后每 5 秒记录一次，结束时保留最后一段。')
            else ...[
              Text(
                  '解码 ${number('nativeDecodeFps')} 帧/秒 · 交给界面 ${number('uiImageDeliveryFps')} 帧/秒',
                  key: const Key('performance-frame-rates')),
              Text(
                  '画面交付平均 ${number('rgbaDeliveryMeanMs')} 毫秒 · P95 ${number('rgbaDeliveryP95Ms')} 毫秒'),
              Text(
                  '网络往返 ${number('networkDelayMs', 0)} 毫秒 · ${(data['codec'] as String?)?.toUpperCase() ?? '—'}'),
              Text(
                  '${number('width', 0)} × ${number('height', 0)} · 目标码率 ${number('targetBitrateKbps', 0)} kbps'),
              Text(
                  '会话第 ${(data['windowStartMs'] / 1000).toStringAsFixed(1)} 秒起，统计 ${(data['durationMs'] / 1000).toStringAsFixed(1)} 秒'),
            ],
            const SizedBox(height: 8),
            const Text(
                '静止画面帧率低是正常现象。交给界面不等于屏幕实际刷新，网络往返也不等于点击响应。只在本机保留最近一次协助的最多 60 段，不上传。'),
          ],
        ));
  }
}
