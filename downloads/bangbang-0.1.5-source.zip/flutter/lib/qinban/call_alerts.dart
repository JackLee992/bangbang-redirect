import 'dart:async';
import 'package:flutter/services.dart';
import 'family_models.dart';
import 'background_push.dart';

/// Local ringing plus the native push registration/action bridge. System
/// delivery still requires a configured provider and notification permission.
class FamilyCallAlerts {
  FamilyCallAlerts({Future<dynamic> Function(String, dynamic)? invoke})
      : _invoke = invoke ?? ((method, args) => channel.invokeMethod(method, args));
  static const channel = MethodChannel('qinban/call-alerts');
  final Future<dynamic> Function(String, dynamic) _invoke;
  String? _shown;
  Future<void> _queue = Future.value();
  Future<void> get settled => _queue;

  void update(FamilyHelpRequest? request, FamilyRequestStatus status, {required bool helper}) {
    final next = helper && status == FamilyRequestStatus.received &&
        request != null && request.expiresAt.isAfter(DateTime.now()) ? request.requestId : null;
    if (_shown == next) return;
    _shown = next;
    final args = next == null ? null : {
      'requestId': next, 'name': request!.familyName,
      'expiresAt': request.expiresAt.millisecondsSinceEpoch,
    };
    _queue = _queue.then((_) async {
      try { await _invoke(next == null ? 'dismiss' : 'show', args); }
      catch (_) { /* A denied notification never prevents in-app answering. */ }
    });
  }

  Future<void> requestPermission() async {
    try { await _invoke('requestPermission', null); } catch (_) {}
  }

  Future<FamilyPushState> pushState() async {
    try { return FamilyPushState.parse(await _invoke('pushState', null)); }
    catch (_) { return const FamilyPushState('unavailable'); }
  }

  Future<Map?> takeAction() async {
    try {
      final value = await _invoke('takeAction', null);
      return value is Map ? value : null;
    } catch (_) { return null; }
  }

  void dispose() => update(null, FamilyRequestStatus.idle, helper: false);
}
