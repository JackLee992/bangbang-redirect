/// Keeps local revocation independent of an outstanding system consent dialog.
class SharingServiceLifecycle {
  SharingServiceLifecycle({
    required this.requestPermission,
    required this.startBackend,
    required this.stopPlatform,
    required this.stopBackend,
    required this.onChanged,
  });

  final Future<bool> Function() requestPermission;
  final Future<bool> Function() startBackend;
  final Future<void> Function() stopPlatform;
  final Future<void> Function() stopBackend;
  final void Function() onChanged;

  int _generation = 0;
  bool _started = false;
  bool _starting = false;
  Future<void>? _pendingStart;
  Future<void>? _pendingStop;
  Future<bool>? _backendStart;
  bool _hasLocalIntent = false;
  bool _nativeReady = false;

  bool get isStarted => _started;
  bool get isStarting => _starting;

  Future<void> nativeMediaStateChanged(bool ready) async {
    final wasReady = _nativeReady;
    _nativeReady = ready;
    // A pending permission dialog normally polls false. Only loss of consent
    // already obtained cancels an in-flight backend start.
    if (!ready && (_started || (_starting && wasReady))) await stop();
  }

  /// Restore a running native session when a new Flutter model first attaches.
  /// Local start/stop always takes precedence over later native snapshots.
  void restoreActive(bool active) {
    if (_hasLocalIntent || _started == active) return;
    _started = active;
    _nativeReady = active;
    onChanged();
  }

  Future<void> start() {
    if (_pendingStart != null) return _pendingStart!;
    if (_started) return Future.value();
    _hasLocalIntent = true;
    final generation = ++_generation;
    _starting = true;
    onChanged();
    final operation = _start(generation);
    _pendingStart = operation;
    return operation;
  }

  Future<void> _start(int generation) async {
    try {
      // A new attempt waits for teardown, never for the old permission request.
      if (_pendingStop != null) await _pendingStop;
      if (generation != _generation) return;
      final approved = await Future.sync(requestPermission);
      if (generation != _generation) return;
      if (!approved) return;
      _nativeReady = true;
      final backendStart = Future<bool>.sync(startBackend);
      _backendStart = backendStart;
      bool backendReady;
      try {
        backendReady = await backendStart;
      } finally {
        if (identical(_backendStart, backendStart)) _backendStart = null;
      }
      if (generation != _generation) return;
      if (!backendReady) {
        await stop();
        return;
      }
      _started = true;
    } finally {
      if (generation == _generation) {
        _starting = false;
        _pendingStart = null;
        onChanged();
      }
    }
  }

  Future<void> stop() {
    ++_generation;
    _hasLocalIntent = true;
    _started = false;
    _starting = false;
    _nativeReady = false;
    _pendingStart = null;
    onChanged();
    if (_pendingStop != null) return _pendingStop!;
    final operation = _stop();
    _pendingStop = operation;
    return operation;
  }

  Future<void> _stop() async {
    try {
      try {
        await Future<void>.sync(stopPlatform);
      } finally {
        // Revoke capture immediately, then stop the backend after any already
        // issued start completes. A later start waits for this teardown.
        try {
          if (_backendStart != null) await _backendStart;
        } finally {
          await Future<void>.sync(stopBackend);
        }
      }
    } finally {
      _pendingStop = null;
    }
  }
}
