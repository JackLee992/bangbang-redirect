import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/assist_model.dart';
import 'package:flutter_hbb/qinban/invitation.dart';

class PromptController extends AssistController {
  AssistState value = const AssistState(role: AssistRole.helper);
  @override
  AssistState get state => value;
  void explicitPrompt(String code) => resetInvitationPrompt(code);
  @override
  Future<void> selectRole(AssistRole? role) async {}
  @override
  Future<void> enableInput() async {}
  @override
  Future<void> startSharing() async {}
  @override
  Future<void> stopSharing() async {}
  @override
  Future<void> connectTo(String id) async {}
  @override
  void openSettings() {}
  @override
  void openSource() {}
  @override
  Future<void> openPrivacyPolicy() async {}
}

void main() {
  const first = QinbanInvitation('123456789');
  const second = QinbanInvitation('987654321');

  test('a complete copied invitation is retained before a controller attaches',
      () {
    final inbox = InvitationInbox();
    expect(inbox.offerClipboard(first.message), isTrue);
    expect(inbox.current?.deviceId, first.deviceId);
    expect(inbox.source, InvitationSource.clipboard);
    expect(inbox.revision, 1);
  });

  test('automatic reads do not repeat a pending or dismissed prompt', () {
    final inbox = InvitationInbox();
    inbox.offerClipboard(first.message);
    expect(inbox.offerClipboard(first.message), isFalse);
    expect(inbox.revision, 1);
    inbox.dismiss();
    expect(inbox.offerClipboard(first.message), isFalse);
    expect(inbox.current, isNull);
    expect(inbox.revision, 1);
  });

  test('explicit paste rearms a current or dismissed invitation', () {
    final inbox = InvitationInbox();
    inbox.offerClipboard(first.message);
    expect(inbox.offerClipboard(first.message, explicit: true), isTrue);
    expect(inbox.source, InvitationSource.paste);
    expect(inbox.revision, 2);
    inbox.dismiss();
    expect(inbox.offerClipboard(first.message, explicit: true), isTrue);
    expect(inbox.revision, 3);
    expect(inbox.current?.deviceId, first.deviceId);
  });

  test('changed invitation codes can prompt again without repeating resumes',
      () {
    final inbox = InvitationInbox();
    inbox.offerClipboard(first.message);
    inbox.dismiss();
    expect(inbox.offerClipboard(second.message), isTrue);
    expect(inbox.revision, 2);
    inbox.dismiss();
    expect(inbox.offerClipboard(first.message), isTrue);
    expect(inbox.revision, 3);
    expect(inbox.offerClipboard(first.message), isFalse);
  });

  test(
      'pending links take precedence and repeated link callbacks stay singular',
      () {
    final inbox = InvitationInbox();
    inbox.handleLink(first.url);
    expect(inbox.handleLink(first.url), isTrue);
    expect(inbox.revision, 1);
    expect(inbox.offerClipboard(second.message), isFalse);
    expect(inbox.current?.deviceId, first.deviceId);
    expect(inbox.offerClipboard(second.message, explicit: true), isTrue);
    expect(inbox.current?.deviceId, second.deviceId);
  });

  test('the latest busy invitation stays queued without claiming its prompt',
      () {
    final inbox = InvitationInbox();
    final controller = PromptController();
    addTearDown(controller.dispose);
    inbox.offerClipboard(first.message);
    inbox.offerClipboard(second.message);
    controller.value = AssistState(
        role: AssistRole.helper,
        invitationCode: inbox.current!.deviceId,
        invitationBlocked: true);
    expect(controller.claimInvitationPrompt(second.deviceId), isFalse);
    expect(inbox.current?.deviceId, second.deviceId);
    controller.value = AssistState(
        role: AssistRole.helper, invitationCode: inbox.current!.deviceId);
    expect(controller.claimInvitationPrompt(second.deviceId), isTrue);
    expect(controller.claimInvitationPrompt(second.deviceId), isFalse);
  });

  test(
      'prompt ownership survives home remounts but explicit paste can rearm it',
      () {
    final controller = PromptController();
    addTearDown(controller.dispose);
    controller.value =
        AssistState(role: AssistRole.helper, invitationCode: first.deviceId);
    expect(controller.claimInvitationPrompt(second.deviceId), isFalse);
    expect(controller.claimInvitationPrompt(first.deviceId), isTrue);
    controller.value = const AssistState(role: AssistRole.helper);
    expect(controller.claimInvitationPrompt(first.deviceId), isFalse);
    controller.value =
        AssistState(role: AssistRole.helper, invitationCode: first.deviceId);
    expect(controller.claimInvitationPrompt(first.deviceId), isFalse);
    controller.explicitPrompt(first.deviceId);
    expect(controller.claimInvitationPrompt(first.deviceId), isTrue);
  });

  test('helper-only startup never restores the elder role', () {
    expect(
        resolveInitialAssistRole('elder', helperOnly: true), AssistRole.helper);
    expect(resolveInitialAssistRole('', helperOnly: true), AssistRole.helper);
  });
}
