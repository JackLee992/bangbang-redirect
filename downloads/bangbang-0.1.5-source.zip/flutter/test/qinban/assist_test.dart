import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/assist_model.dart';
import 'package:flutter_hbb/qinban/assist_interface_router.dart';
import 'package:flutter_hbb/qinban/qinban_theme.dart';

class FakeController extends AssistController {
  FakeController(this.value, {this.supportsSharing = true});
  @override
  final bool supportsSharing;
  AssistState value;
  final calls = <String>[];
  bool fullPreference = false;
  @override
  AssistState get state => value;
  @override
  Future<void> selectRole(AssistRole? role) async {
    calls.add('role:${role?.name}');
    value = AssistState(role: role, online: true, deviceId: '123456789');
    notifyListeners();
  }
  @override
  Future<void> enableInput() async { calls.add('input'); }
  @override
  Future<void> startSharing() async { calls.add('start'); }
  @override
  Future<void> stopSharing() async { calls.add('stop'); }
  @override
  Future<void> connectTo(String id) async { calls.add('connect:$id'); }
  @override
  void openSettings() { calls.add('settings'); }
  @override
  void openSource() { calls.add('source'); }
  @override
  Future<void> openPrivacyPolicy() async { calls.add('privacy'); }
  @override
  Future<void> shareInvitation() async { calls.add('share-invitation'); }
  @override
  Future<void> copyInvitation() async { calls.add('copy-invitation'); }
  @override
  Future<void> shareInstall() async { calls.add('share-install'); }
  @override
  Future<void> pasteInvitation() async { calls.add('paste-invitation'); }
  @override
  void dismissInvitation() {
    calls.add('dismiss-invitation');
    value = const AssistState(role: AssistRole.helper);
    notifyListeners();
  }
  void receiveInvitation(String code, {bool explicit = false}) {
    if (explicit) resetInvitationPrompt(code);
    value = AssistState(role: AssistRole.helper, invitationCode: code);
    notifyListeners();
  }
  @override
  Future<void> setFullInterface(bool enabled) async {
    calls.add('interface:$enabled');
    fullPreference = enabled;
    value = AssistState(role: value.role, deviceId: value.deviceId,
      invitationCode: value.invitationCode, invitationBlocked: value.invitationBlocked,
      fullInterface: enabled);
    notifyListeners();
  }
}

class PendingSharingController extends FakeController {
  PendingSharingController({this.reportSharing = false}) : super(const AssistState(role: AssistRole.elder,
    deviceId: '123456789', inputReady: true));
  final bool reportSharing;
  final consent = Completer<void>();

  @override
  Future<void> startSharing() {
    calls.add('start');
    value = AssistState(role: AssistRole.elder,
      deviceId: '123456789', inputReady: true, preparing: true, sharing: reportSharing);
    notifyListeners();
    return consent.future;
  }

  @override
  Future<void> stopSharing() async {
    calls.add('stop');
    value = const AssistState(role: AssistRole.elder,
      deviceId: '123456789', inputReady: true);
    notifyListeners();
  }
}

class PendingClipboardController extends FakeController {
  PendingClipboardController() : super(const AssistState(role: AssistRole.helper));
  final clipboardResponse = Completer<void>();
  @override
  Future<void> pasteInvitation() async {
    calls.add('paste-invitation');
    receiveInvitation('987654321', explicit: true);
    await clipboardResponse.future;
  }
}

class InvitationProgressController extends FakeController {
  InvitationProgressController() : super(const AssistState(role: AssistRole.elder,
    deviceId: '123456789', inputReady: true));
  final serviceResponse = Completer<void>();
  final shareResponse = Completer<void>();

  void update({bool preparing = false, bool sharing = false, bool captureReady = false,
      bool online = false, String? error}) {
    value = AssistState(role: AssistRole.elder, deviceId: '123456789', inputReady: true,
      preparing: preparing, sharing: sharing, captureReady: captureReady, online: online,
      error: error);
    notifyListeners();
  }

  @override
  Future<void> startSharing() async {
    calls.add('start');
    update(preparing: true);
    await serviceResponse.future;
  }

  @override
  Future<void> shareInvitation() async {
    calls.add('share-invitation');
    await shareResponse.future;
  }
}

FamilyMember familyMember(String peerId, String name, FamilyDirection direction, {bool ready = true}) =>
  FamilyMember(peerId: peerId, name: name, direction: direction, directReady: ready,
    lastHelpAt: DateTime.utc(2026, 10, 1));

FamilyHelpRequest familyRequest({bool expired = false}) => FamilyHelpRequest(requestId: 'request-1',
  familyPeerId: '987654321', familyName: '妈妈', elderPeerId: '987654321',
  expiresAt: DateTime.now().add(Duration(minutes: expired ? -1 : 5)));

class FamilyController extends FakeController {
  FamilyController(super.value, {this.approveCapture = true, super.supportsSharing});
  final bool approveCapture;
  Completer<void>? captureResponse;
  Completer<void>? connectionResponse;
  bool revoked = false;

  void update({bool? inputReady, bool? captureReady, bool? sharing, bool? preparing,
      List<FamilyMember>? members, FamilyHelpRequest? pending, bool clearPending = false,
      FamilyRequestStatus? requestStatus}) {
    value = AssistState(role: value.role, deviceId: value.deviceId, online: true, inputReady: inputReady ?? value.inputReady,
      captureReady: captureReady ?? value.captureReady, sharing: sharing ?? value.sharing,
      preparing: preparing ?? value.preparing, fullInterface: value.fullInterface,
      invitationCode: value.invitationCode, invitationBlocked: value.invitationBlocked,
      familyMembers: members ?? value.familyMembers,
      pendingFamilyRequest: clearPending ? null : pending ?? value.pendingFamilyRequest,
      familyRequestStatus: requestStatus ?? (pending != null ? FamilyRequestStatus.received : value.familyRequestStatus));
    notifyListeners();
  }
  @override
  Future<void> startSharing() async {
    calls.add('start');
    update(preparing: true);
    if (captureResponse != null) await captureResponse!.future;
    update(preparing: false, sharing: approveCapture && !revoked, captureReady: approveCapture && !revoked);
  }
  @override
  Future<void> stopSharing() async {
    calls.add('stop');
    revoked = true;
    update(preparing: false, sharing: false, captureReady: false);
  }
  @override
  Future<void> connectTo(String id) async {
    calls.add('connect:$id');
    if (connectionResponse != null) await connectionResponse!.future;
  }
  @override
  Future<void> requestFamilyHelp(String peerId) async { calls.add('family-request:$peerId'); }
  @override
  Future<void> acceptFamilyRequest() async {
    calls.add('family-accept');
    update(clearPending: true);
  }
  @override
  Future<void> declineFamilyRequest() async {
    calls.add('family-decline');
    update(clearPending: true);
  }
  @override
  Future<void> renameFamilyMember(String peerId, String name) async {
    calls.add('family-rename:$peerId:$name');
    update(members: value.familyMembers.map((member) => member.peerId == peerId ?
      FamilyMember(peerId: member.peerId, name: name, direction: member.direction,
        directReady: member.directReady, lastHelpAt: member.lastHelpAt) : member).toList());
  }
  @override
  Future<void> forgetFamilyMember(String peerId) async {
    calls.add('family-forget:$peerId');
    update(members: value.familyMembers.where((member) => member.peerId != peerId).toList());
  }
}

Future<void> mount(WidgetTester tester, FakeController controller,
    {double width = 390, double height = 1000, double scale = 1,
      EdgeInsets padding = EdgeInsets.zero, Brightness brightness = Brightness.light,
      bool settle = true}) async {
  tester.view.physicalSize = Size(width, height);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  await tester.pumpWidget(MaterialApp(theme: ThemeData(brightness: brightness),
    home: MediaQuery(data: MediaQueryData(textScaler: TextScaler.linear(scale), padding: padding),
      child: AssistInterfaceRouter(controller: controller,
        fullInterfaceBuilder: (context, returnSimple) => Scaffold(
          appBar: AppBar(actions: [TextButton(key: const Key('simple-interface'),
            onPressed: returnSimple, child: const Text('切回简洁界面'))]),
          body: const Text('完整操作', key: Key('legacy-home')))))));
  if (settle) {
    await tester.pumpAndSettle();
  } else {
    await tester.pump();
  }
}

Future<void> openManualPeer(WidgetTester tester) async {
  await tester.ensureVisible(find.byKey(const Key('manual-peer')));
  await tester.tap(find.text('手动输入设备号码'));
  await tester.pumpAndSettle();
  await tester.ensureVisible(find.byKey(const Key('peer-id')));
}

Future<void> openTools(WidgetTester tester) async {
  await tester.tap(find.byKey(const Key('more-actions')));
  await tester.pumpAndSettle();
}

void main() {
  test('fresh role defaults to elder, helper preference and iOS remain helper', () {
    for (final saved in ['', 'elder', 'old-invalid-role']) {
      expect(resolveInitialAssistRole(saved), AssistRole.elder);
      expect(resolveInitialAssistRole(saved, helperOnly: true), AssistRole.helper);
    }
    expect(resolveInitialAssistRole('helper'), AssistRole.helper);
  });

  test('device numbers allow spoken grouping but reject malformed and self IDs', () {
    expect(validatePeerId(' 123 456 789 ', '999888777'), isNull);
    for (final input in ['', '12', 'abc123456', '123.456', '1' * 17]) {
      expect(validatePeerId(input, ''), isNotNull);
    }
    expect(validatePeerId('123 456 789', '123456789'), contains('本机'));
    expect(readableId('123456789'), '123 456 789');
    expect(readableId('1234567'), '123 456 7');
  });

  testWidgets('role selection opens the appropriate task', (tester) async {
    final controller = FakeController(const AssistState());
    await mount(tester, controller);
    await openTools(tester);
    await tester.tap(find.byKey(const Key('choose-helper')));
    await tester.pumpAndSettle();
    expect(controller.calls, contains('role:helper'));
    expect(find.byKey(const Key('helper-title')), findsOneWidget);
    expect(find.byKey(const Key('peer-id')), findsNothing);
    await openTools(tester);
    await tester.tap(find.byKey(const Key('choose-elder')));
    await tester.pumpAndSettle();
    expect(controller.state.role, AssistRole.elder);
    expect(find.byKey(const Key('elder-title')), findsOneWidget);
  });

  testWidgets('elder has large text and actions without reducing system scaling', (tester) async {
    final controller = FakeController(const AssistState(inputReady: true));
    await mount(tester, controller, scale: 1.8);
    expect(find.byKey(const Key('elder-title')), findsOneWidget);
    final context = tester.element(find.byKey(const Key('elder-title')));
    expect(MediaQuery.textScalerOf(context).scale(20), 36);
    expect(Theme.of(context).textTheme.bodyMedium!.fontSize, greaterThanOrEqualTo(20));
    expect(tester.widget<Text>(find.byKey(const Key('elder-title'))).style!.fontSize, greaterThanOrEqualTo(20));
    final actionContext = tester.element(find.byKey(const Key('share-invitation')));
    final style = Theme.of(actionContext).filledButtonTheme.style!;
    expect(style.minimumSize!.resolve({})!.height, greaterThanOrEqualTo(56));
    expect(style.textStyle!.resolve({})!.fontSize, greaterThanOrEqualTo(20));
    expect(find.byKey(const Key('full-interface')), findsNothing);
    expect(controller.calls, isEmpty);
  });

  testWidgets('idle elder heading yields visual emphasis to actions while live status stays prominent', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789'));
    await mount(tester, controller, width: 320, height: 640, scale: 1.8);
    final idle = tester.widget<Text>(find.byKey(const Key('elder-title'))).style!;
    final action = tester.widget<Text>(find.descendant(of: find.byKey(const Key('enable-input')),
      matching: find.byType(Text))).style!;
    final colors = Theme.of(tester.element(find.byKey(const Key('elder-title')))).colorScheme;
    expect(idle.fontSize, lessThanOrEqualTo(action.fontSize!));
    expect(idle.fontWeight!.value, lessThan(action.fontWeight!.value));
    expect(idle.color, colors.onSurfaceVariant);
    expect(action.color, colors.onPrimary);
    expect(find.byKey(const Key('enable-input')).hitTestable(), findsOneWidget);
    expect(find.byKey(const Key('share-invitation')).hitTestable(), findsOneWidget);
    controller.value = const AssistState(deviceId: '123456789', inputReady: true,
      sharing: true, online: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    final active = tester.widget<Text>(find.byKey(const Key('elder-title'))).style!;
    expect(find.text('等待家人'), findsOneWidget);
    expect(active.fontSize, greaterThan(idle.fontSize!));
    expect(active.fontWeight!.value, greaterThan(idle.fontWeight!.value));
    expect(active.color, isNull);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('compact elder main actions fit 320x640 at 180 percent without extra instructions', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789'));
    await mount(tester, controller, width: 320, height: 640, scale: 1.8,
      padding: const EdgeInsets.symmetric(vertical: 24));
    expect(tester.takeException(), isNull);
    for (final key in ['enable-input', 'share-invitation', 'more-actions']) {
      expect(find.byKey(Key(key)).hitTestable(), findsOneWidget, reason: key);
    }
    final mainSize = tester.getSize(find.byKey(const Key('enable-input')));
    final lockedSize = tester.getSize(find.byKey(const Key('share-invitation')));
    expect(mainSize.width, mainSize.height);
    expect(lockedSize.width, lockedSize.height);
    expect(lockedSize.width / mainSize.width, closeTo(.5, .01));
    expect(tester.getBottomRight(find.byKey(const Key('share-invitation'))).dy,
      lessThan(616));
    expect(tester.getBottomRight(find.byKey(const Key('more-actions'))).dx,
      lessThanOrEqualTo(304));
    expect(find.byKey(const Key('local-device-id')), findsNothing);
    expect(find.byKey(const Key('copy-invitation')), findsNothing);
    expect(find.byKey(const Key('share-install')), findsNothing);
    expect(find.byKey(const Key('stranger-warning')), findsNothing);
    expect(find.text('允许家人点击屏幕'), findsNothing);
    expect(find.text('连接服务已就绪'), findsNothing);
    expect(find.text('距离远一点，陪伴近一点'), findsNothing);
    final context = tester.element(find.byKey(const Key('elder-title')));
    expect(Theme.of(context).colorScheme.primary, qinbanOrange);
    expect(Theme.of(context).scaffoldBackgroundColor, const Color(0xFFF8F7F5));
    expect(controller.calls, isEmpty);
    controller.value = const AssistState(deviceId: '123456789', inputReady: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('enable-input')).hitTestable(), findsOneWidget);
    expect(find.text('已开'), findsNothing);
    expect(find.text('已开启'), findsNothing);
    expect(tester.getSize(find.byKey(const Key('permission-success-check'))).width, greaterThanOrEqualTo(48));
    expect(find.byWidgetPredicate((widget) => widget is Semantics && widget.properties.label == '已开启'), findsOneWidget);
    expect(tester.widget<InkWell>(find.byKey(const Key('enable-input'))).onTap, isNull);
    expect(find.byKey(const Key('start-sharing')), findsNothing);
    expect(find.byKey(const Key('share-invitation')).hitTestable(), findsOneWidget);
    expect(tester.getSize(find.byKey(const Key('enable-input'))), lockedSize);
    expect(tester.getSize(find.byKey(const Key('share-invitation'))), mainSize);
    expect(tester.getBottomRight(find.byKey(const Key('share-invitation'))).dy,
      lessThan(616));
    expect(tester.takeException(), isNull);
    expect(controller.calls, isEmpty);
  });

  testWidgets('tools keep device ID and help reachable then release listeners on exit', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789', sharing: true, online: true));
    await mount(tester, controller);
    await openTools(tester);
    expect(find.byKey(const Key('choose-helper')), findsNothing);
    await tester.tap(find.byKey(const Key('show-device-id')));
    await tester.pumpAndSettle();
    expect(find.text('123 456 789'), findsOneWidget);
    await tester.ensureVisible(find.byKey(const Key('use-help')));
    await tester.tap(find.byKey(const Key('use-help')));
    await tester.pumpAndSettle();
    expect(find.text('家人怎么连接'), findsOneWidget);
    await tester.pageBack();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['stop']);
    await tester.pumpWidget(const MaterialApp(home: SizedBox()));
    controller.notifyListeners();
    await tester.pump();
    expect(tester.takeException(), isNull);
  });

  testWidgets('helper toggles ordinary and full interfaces without starting sharing', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper));
    await mount(tester, controller, scale: 1.4);
    final context = tester.element(find.byKey(const Key('helper-title')));
    expect(Theme.of(context).textTheme.bodyMedium!.fontSize, lessThan(20));
    expect(MediaQuery.textScalerOf(context).scale(20), 28);
    await openTools(tester);
    await tester.ensureVisible(find.byKey(const Key('full-interface')));
    await tester.tap(find.byKey(const Key('full-interface')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('legacy-home')), findsOneWidget);
    expect(controller.fullPreference, isTrue);
    await tester.tap(find.byKey(const Key('simple-interface')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('helper-title')), findsOneWidget);
    expect(controller.fullPreference, isFalse);
    expect(controller.calls, ['interface:true', 'interface:false']);
  });

  testWidgets('saved full helper interface opens directly but elder never opens it', (tester) async {
    final helper = FakeController(const AssistState(role: AssistRole.helper, fullInterface: true));
    await mount(tester, helper);
    expect(find.byKey(const Key('legacy-home')), findsOneWidget);
    expect(helper.calls, isEmpty);
    final elder = FakeController(const AssistState(fullInterface: true));
    await mount(tester, elder);
    expect(find.byKey(const Key('elder-title')), findsOneWidget);
    expect(find.byKey(const Key('legacy-home')), findsNothing);
    expect(elder.calls, isEmpty);
  });

  testWidgets('incoming invitation takes precedence over full-interface preference', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      fullInterface: true, invitationCode: '987654321'));
    await mount(tester, controller);
    expect(find.byKey(const Key('legacy-home')), findsNothing);
    expect(find.byKey(const Key('invitation-prompt-connect')).hitTestable(), findsOneWidget);
    expect(find.byKey(const Key('peer-id')), findsNothing);
    expect(controller.calls, isEmpty);
    await tester.tap(find.byKey(const Key('invitation-prompt-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['connect:987654321']);
  });

  testWidgets('invalid or local ID never initiates a remote connection', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      deviceId: '123456789', online: true));
    await mount(tester, controller);
    await openManualPeer(tester);
    await tester.enterText(find.byKey(const Key('peer-id')), '123456789');
    await tester.ensureVisible(find.byKey(const Key('connect-peer')));
    await tester.tap(find.byKey(const Key('connect-peer')));
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    expect(find.textContaining('这是本机号码'), findsOneWidget);
    await tester.enterText(find.byKey(const Key('peer-id')), '987 654 321');
    await tester.ensureVisible(find.byKey(const Key('connect-peer')));
    await tester.tap(find.byKey(const Key('connect-peer')));
    await tester.pumpAndSettle();
    expect(controller.calls, contains('connect:987654321'));
  });

  testWidgets('sharing remains disabled without input permission', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.elder,
      deviceId: '123456789', online: true));
    await mount(tester, controller);
    final button = tester.widget<InkWell>(find.byKey(const Key('share-invitation')));
    expect(button.onTap, isNull);
    await tester.tap(find.byKey(const Key('enable-input')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['input']);
  });

  testWidgets('permission is confirmed before inviting and its success is not another action', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789'));
    await mount(tester, controller);
    final invite = find.byKey(const Key('share-invitation'));
    final permission = find.byKey(const Key('enable-input'));
    expect(tester.widget<InkWell>(invite).onTap, isNull);
    final mainSize = tester.getSize(permission);
    final secondarySize = tester.getSize(invite);
    expect(mainSize.width, mainSize.height);
    expect(mainSize.width, inInclusiveRange(180, 200));
    expect(secondarySize.width, secondarySize.height);
    expect(secondarySize.width, inInclusiveRange(85, 105));
    expect(secondarySize.width * secondarySize.height / (mainSize.width * mainSize.height), closeTo(.25, .01));
    expect(find.descendant(of: invite, matching: find.byIcon(Icons.lock_rounded)), findsOneWidget);
    final locked = tester.widget<Material>(find.ancestor(of: invite, matching: find.byType(Material)).first);
    expect(locked.color, const Color(0xFFD1D1D6));
    await tester.tap(invite);
    expect(controller.calls, isEmpty);
    await tester.tap(permission);
    await tester.pumpAndSettle();
    expect(controller.calls, ['input']);
    // Returning from settings alone does not grant the capability.
    expect(tester.widget<InkWell>(invite).onTap, isNull);
    controller.value = const AssistState(deviceId: '123456789', inputReady: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.text('已开启'), findsOneWidget);
    expect(tester.widget<InkWell>(permission).onTap, isNull);
    expect(tester.widget<InkWell>(invite).onTap, isNotNull);
    expect(tester.getSize(permission), secondarySize);
    expect(tester.getSize(invite), mainSize);
    final active = tester.widget<Material>(find.ancestor(of: invite, matching: find.byType(Material)).first);
    expect(active.color, qinbanOrange);
    expect(find.descendant(of: invite, matching: find.byIcon(Icons.lock_rounded)), findsNothing);
    await tester.tap(permission);
    await tester.tap(invite);
    await tester.pumpAndSettle();
    expect(controller.calls, ['input']);
    expect(find.text('允许家人帮忙'), findsOneWidget);
    expect(controller.state.captureReady, isFalse);
    expect(controller.state.sharing, isFalse);
  });

  for (final scale in [1.0, 1.8]) {
    testWidgets('permission and invitation keep independent accessible nodes: scale=$scale', (tester) async {
      final semantics = tester.ensureSemantics();
      try {
      final controller = FakeController(const AssistState(deviceId: '123456789'));
      await mount(tester, controller, width: 320, height: 640, scale: scale);
      final locked = tester.getSemantics(find.bySemanticsLabel('邀请家人'));
      expect(locked.getSemanticsData().hasFlag(SemanticsFlag.isEnabled), isFalse);
      expect(locked.getSemanticsData().hasAction(SemanticsAction.tap), isFalse);
      controller.value = const AssistState(deviceId: '123456789', inputReady: true);
      controller.notifyListeners();
      await tester.pumpAndSettle();
      expect(find.bySemanticsLabel('已开启'), findsOneWidget);
      expect(find.bySemanticsLabel('邀请家人'), findsOneWidget);
      final success = tester.getSemantics(find.bySemanticsLabel('已开启'));
      final invitation = tester.getSemantics(find.bySemanticsLabel('邀请家人'));
      expect(success.id, isNot(invitation.id));
      expect(success.getSemanticsData().hasFlag(SemanticsFlag.isButton), isFalse);
      expect(success.getSemanticsData().hasAction(SemanticsAction.tap), isFalse);
      expect(invitation.getSemanticsData().hasFlag(SemanticsFlag.isButton), isTrue);
      expect(invitation.getSemanticsData().hasFlag(SemanticsFlag.isEnabled), isTrue);
      expect(invitation.getSemanticsData().hasAction(SemanticsAction.tap), isTrue);
      // Perform the accessibility action, as TalkBack does, rather than key-tapping.
      tester.binding.pipelineOwner.semanticsOwner!.performAction(invitation.id, SemanticsAction.tap);
      await tester.pumpAndSettle();
      expect(controller.calls, isEmpty);
      expect(find.text('允许家人帮忙'), findsOneWidget);
      } finally {
        semantics.dispose();
      }
    });
  }

  testWidgets('copy invitation shares the permission gate while installation sharing stays available', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789'));
    await mount(tester, controller);
    await openTools(tester);
    final copy = find.byKey(const Key('copy-invitation'));
    expect(tester.widget<ListTile>(copy).enabled, isFalse);
    expect(tester.widget<ListTile>(copy).onTap, isNull);
    await tester.tap(copy);
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    await tester.ensureVisible(find.byKey(const Key('share-install')));
    await tester.tap(find.byKey(const Key('share-install')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['share-install']);
    controller.value = const AssistState(deviceId: '123456789', inputReady: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    await openTools(tester);
    expect(tester.widget<ListTile>(copy).enabled, isTrue);
    await tester.tap(copy);
    await tester.pumpAndSettle();
    expect(controller.calls, ['share-install']);
    expect(find.text('允许家人帮忙'), findsOneWidget);
  });

  testWidgets('screen consent and service restoration never substitute for input permission', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789',
      inputReady: true, captureReady: true, sharing: true));
    await mount(tester, controller, settle: false);
    expect(find.text('已开启'), findsOneWidget);
    expect(tester.widget<InkWell>(find.byKey(const Key('share-invitation'))).onTap, isNotNull);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    // Cancelling/ending projection retains accessibility, including after restore.
    controller.value = const AssistState(deviceId: '123456789', inputReady: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.text('已开启'), findsOneWidget);
    expect(tester.widget<InkWell>(find.byKey(const Key('share-invitation'))).onTap, isNotNull);
    expect(find.byKey(const Key('start-sharing')), findsNothing);
    // Conversely a capture grant cannot keep the invitation unlocked after input is revoked.
    controller.value = const AssistState(deviceId: '123456789', captureReady: true, sharing: true, online: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.text('已开启'), findsNothing);
    expect(find.text('开启权限'), findsOneWidget);
    expect(tester.widget<InkWell>(find.byKey(const Key('share-invitation'))).onTap, isNull);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['stop']);
  });

  testWidgets('helper pasting and connecting do not require its own input permission', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper), supportsSharing: false);
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('paste-invitation')));
    await tester.pumpAndSettle();
    controller.receiveInvitation('987654321');
    await tester.pumpAndSettle();
    expect(controller.state.inputReady, isFalse);
    await tester.tap(find.byKey(const Key('invitation-prompt-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['paste-invitation', 'connect:987654321']);
  });

  testWidgets('cancelling disclosure never starts capture', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.elder,
      deviceId: '123456789', online: true, inputReady: true));
    await mount(tester, controller);
    await tester.ensureVisible(find.byKey(const Key('share-invitation')));
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('暂不开启'));
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    expect(find.text('已开启'), findsOneWidget);
    expect(tester.widget<InkWell>(find.byKey(const Key('share-invitation'))).onTap, isNotNull);
  });

  testWidgets('stop is immediate and does not require another dialog', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.elder,
      deviceId: '123456789', online: true, inputReady: true,
      sharing: true, captureReady: true, connections: 1));
    await mount(tester, controller);
    expect(find.text('切换身份'), findsNothing);
    await tester.ensureVisible(find.byKey(const Key('stop-sharing')));
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['stop']);
    expect(find.byType(AlertDialog), findsNothing);
  });

  testWidgets('sharing shows connection progress until the service is actually online', (tester) async {
    final controller = FakeController(const AssistState(deviceId: '123456789',
      inputReady: true, sharing: true));
    await mount(tester, controller, settle: false);
    expect(find.text('正在连接'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')), findsOneWidget);
    expect(tester.widget<CircularProgressIndicator>(find.byKey(const Key('sharing-progress'))).value, isNull);
    expect(find.text('等待家人'), findsNothing);
    controller.value = const AssistState(deviceId: '123456789', inputReady: true,
      sharing: true, online: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.text('等待家人'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    controller.value = const AssistState(deviceId: '123456789', inputReady: true,
      sharing: true, online: true, connections: 1);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.text('家人在协助'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    expect(controller.calls, isEmpty);
  });

  testWidgets('stop remains executable while system consent is pending', (tester) async {
    final controller = PendingSharingController();
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('我知道了，继续'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('等待家人连接'), findsNothing);
    expect(find.text('取消准备'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')), findsOneWidget);
    expect(find.text('切换身份'), findsNothing);
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pump();
    expect(controller.calls, ['start', 'stop']);
    expect(controller.consent.isCompleted, isFalse);
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    controller.consent.complete();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('share-invitation')), findsOneWidget);
  });

  testWidgets('stop bypasses the busy guard when sharing is reported during start', (tester) async {
    final controller = PendingSharingController(reportSharing: true);
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('我知道了，继续'));
    await tester.pump(const Duration(milliseconds: 500));
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pump();
    expect(controller.calls, ['start', 'stop']);
    expect(controller.consent.isCompleted, isFalse);
    controller.consent.complete();
    await tester.pumpAndSettle();
  });

  testWidgets('received invitation fills the peer and waits for explicit connect', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller, width: 320, height: 640, scale: 1.8);
    expect(find.byKey(const Key('invitation-prompt')), findsOneWidget);
    expect(controller.calls, isEmpty);
    expect(find.byKey(const Key('peer-id')), findsNothing);
    // The confirmation is immediately reachable without scrolling or typing.
    expect(find.byKey(const Key('invitation-prompt-connect')).hitTestable(), findsOneWidget);
    await tester.tap(find.byKey(const Key('invitation-prompt-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['connect:987654321']);
  });

  testWidgets('later keeps the invitation card and does not repeat after rebuild or remote return', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('invitation-prompt-later')));
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    expect(find.byKey(const Key('invite-connect')).hitTestable(), findsOneWidget);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    await tester.pumpWidget(const MaterialApp(home: SizedBox()));
    await tester.pumpAndSettle();
    await mount(tester, controller);
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    final navigator = tester.state<NavigatorState>(find.byType(Navigator));
    navigator.push(MaterialPageRoute<void>(builder: (_) => const Scaffold(body: Text('远程会话'))));
    controller.value = const AssistState(role: AssistRole.helper,
      invitationCode: '987654321', invitationBlocked: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    navigator.pop();
    controller.receiveInvitation('987654321');
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    await tester.tap(find.byKey(const Key('invite-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['connect:987654321']);
  });

  testWidgets('explicit paste can prompt the same invitation again after later', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('invitation-prompt-later')));
    await tester.pumpAndSettle();
    controller.receiveInvitation('987654321', explicit: true);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsOneWidget);
    expect(controller.calls, isEmpty);
    await tester.tap(find.byKey(const Key('invitation-prompt-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['connect:987654321']);
  });

  testWidgets('clipboard confirmation waits for a busy operation to finish', (tester) async {
    final controller = PendingClipboardController();
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('paste-invitation')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    expect(controller.calls, ['paste-invitation']);
    controller.clipboardResponse.complete();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt-connect')).hitTestable(), findsOneWidget);
    expect(controller.calls, ['paste-invitation']);
  });

  testWidgets('an invitation waits behind another overlay until the main page is current', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper));
    await mount(tester, controller);
    await openTools(tester);
    controller.receiveInvitation('987654321');
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    final navigator = tester.state<NavigatorState>(find.byType(Navigator));
    navigator.pop();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt-connect')).hitTestable(), findsOneWidget);
    expect(controller.calls, isEmpty);
  });

  for (final conflict in ['sharing', 'preparing', 'remote', 'connection', 'family']) {
    testWidgets('invitation confirmation waits until $conflict is idle', (tester) async {
      final controller = FakeController(AssistState(role: AssistRole.helper,
        invitationCode: '987654321', sharing: conflict == 'sharing',
        preparing: conflict == 'preparing', invitationBlocked: conflict == 'remote',
        connections: conflict == 'connection' ? 1 : 0,
        pendingFamilyRequest: conflict == 'family' ? familyRequest() : null));
      await mount(tester, controller);
      expect(find.byKey(const Key('invitation-prompt')), findsNothing);
      expect(controller.calls, isEmpty);
      controller.receiveInvitation('987654321');
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('invitation-prompt')), findsOneWidget);
      expect(controller.calls, isEmpty);
    });
  }

  testWidgets('replacement invitation cannot connect a stale dialog target', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller);
    final staleAction = tester.widget<FilledButton>(find.byKey(const Key('invitation-prompt-connect'))).onPressed!;
    controller.receiveInvitation('456789123');
    staleAction();
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    expect(find.byKey(const Key('invitation-prompt')), findsOneWidget);
    await tester.tap(find.byKey(const Key('invitation-prompt-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['connect:456789123']);
  });

  testWidgets('a family request arriving during an invitation cannot be bypassed by the dialog', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller);
    final staleAction = tester.widget<FilledButton>(find.byKey(const Key('invitation-prompt-connect'))).onPressed!;
    controller.value = AssistState(role: AssistRole.helper, invitationCode: '987654321',
      pendingFamilyRequest: familyRequest());
    controller.notifyListeners();
    staleAction();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    expect(tester.widget<FilledButton>(find.byKey(const Key('invite-connect'))).onPressed, isNull);
    expect(controller.calls, isEmpty);
    controller.receiveInvitation('987654321');
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    expect(find.byKey(const Key('invite-connect')).hitTestable(), findsOneWidget);
  });

  testWidgets('an open invitation closes safely on sharing and widget disposal', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller);
    controller.value = const AssistState(role: AssistRole.helper, invitationCode: '987654321',
      sharing: true, invitationBlocked: true);
    controller.notifyListeners();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    expect(controller.calls, isEmpty);
    controller.receiveInvitation('456789123');
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt')), findsOneWidget);
    await tester.pumpWidget(const MaterialApp(home: SizedBox()));
    await tester.pumpAndSettle();
    controller.notifyListeners();
    await tester.pump();
    expect(tester.takeException(), isNull);
    await mount(tester, controller);
    expect(find.byKey(const Key('invitation-prompt')), findsNothing);
    expect(find.byKey(const Key('invite-connect')).hitTestable(), findsOneWidget);
  });

  testWidgets('an invitation during sharing remains pending with the stop action available', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.elder,
      sharing: true, inputReady: true, invitationCode: '987654321', invitationBlocked: true));
    await mount(tester, controller);
    expect(find.text('先结束当前协助'), findsOneWidget);
    expect(find.byKey(const Key('peer-id')), findsNothing);
    expect(tester.widget<FilledButton>(find.byKey(const Key('invite-connect'))).onPressed, isNull);
    expect(controller.calls, isEmpty);
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['stop']);
  });

  for (final preparing in [false, true]) {
    testWidgets('helper active service keeps a fixed stop action with a blocked invitation: preparing=$preparing', (tester) async {
      final controller = FakeController(AssistState(role: AssistRole.helper,
        sharing: !preparing, preparing: preparing, fullInterface: true,
        invitationCode: '987654321', invitationBlocked: true));
      await mount(tester, controller, height: 640);
      expect(find.byKey(const Key('legacy-home')), findsNothing);
      expect(tester.widget<FilledButton>(find.byKey(const Key('invite-connect'))).onPressed, isNull);
      expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
      expect(find.byKey(const Key('start-sharing')), findsNothing);
      await tester.tap(find.byKey(const Key('stop-sharing')));
      await tester.pumpAndSettle();
      expect(controller.calls, ['stop']);
      expect(find.byType(AlertDialog), findsNothing);
    });
  }

  testWidgets('ready elder can share and copy without preparing again', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.elder,
      deviceId: '123456789', inputReady: true, captureReady: true, sharing: true, online: true));
    await mount(tester, controller);
    await tester.ensureVisible(find.byKey(const Key('share-invitation')));
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await openTools(tester);
    await tester.ensureVisible(find.byKey(const Key('copy-invitation')));
    await tester.tap(find.byKey(const Key('copy-invitation')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['share-invitation', 'copy-invitation']);
  });

  testWidgets('first invitation prepares screen sharing before opening system share', (tester) async {
    final controller = FamilyController(const AssistState(role: AssistRole.elder,
      deviceId: '123456789', inputReady: true, online: true));
    controller.captureResponse = Completer<void>();
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty, reason: 'An invitation must not leave an unprepared phone');
    expect(find.text('允许家人帮忙'), findsOneWidget);
    await tester.tap(find.text('我知道了，继续'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(controller.calls, ['start']);
    controller.captureResponse!.complete();
    await tester.pumpAndSettle();
    expect(controller.calls, ['start', 'share-invitation']);
  });

  testWidgets('invitation progress follows consent, service and share at 320dp / 180% text', (tester) async {
    final controller = InvitationProgressController();
    await mount(tester, controller, width: 320, height: 640, scale: 1.8,
      padding: const EdgeInsets.symmetric(vertical: 24));
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    await tester.tap(find.text('我知道了，继续'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('等待确认'), findsOneWidget);
    expect(find.text('请完成屏幕共享授权'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')).hitTestable(), findsOneWidget);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    expect(tester.takeException(), isNull);

    controller.update(preparing: true, sharing: true, captureReady: true);
    await tester.pump();
    expect(find.text('正在连接'), findsOneWidget);
    expect(find.text('连接好后会打开分享'), findsOneWidget);
    expect(controller.calls, ['start'], reason: 'Share waits for real service readiness');
    expect(tester.widget<CircularProgressIndicator>(find.byKey(const Key('sharing-progress'))).value, isNull);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    final hint = tester.widget<Text>(find.byKey(const Key('sharing-progress-hint')));
    expect(hint.style!.fontSize, greaterThanOrEqualTo(20));
    expect(tester.takeException(), isNull);

    controller.update(sharing: true, captureReady: true, online: true);
    controller.serviceResponse.complete();
    await tester.pump();
    expect(controller.calls, ['start', 'share-invitation']);
    expect(find.text('正在打开分享'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress-hint')), findsNothing);
    expect(tester.takeException(), isNull);

    controller.shareResponse.complete();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    expect(find.text('等待家人'), findsOneWidget);
    expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('service error clears progress and prevents sharing even before preparation unwinds', (tester) async {
    final controller = InvitationProgressController();
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('我知道了，继续'));
    await tester.pump(const Duration(milliseconds: 500));
    controller.update(preparing: true, sharing: true, captureReady: true);
    await tester.pump();
    expect(find.byKey(const Key('sharing-progress')), findsOneWidget);

    controller.update(preparing: true, error: '暂时连不上连接服务，请重试。');
    await tester.pumpAndSettle();
    expect(controller.serviceResponse.isCompleted, isFalse);
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    expect(find.byKey(const Key('sharing-progress-hint')), findsNothing);
    expect(find.text('暂时连不上连接服务，请重试。'), findsOneWidget);
    controller.serviceResponse.complete();
    await tester.pumpAndSettle();
    expect(controller.calls, ['start']);
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
  });

  testWidgets('a failed share call clears progress after service readiness', (tester) async {
    final controller = InvitationProgressController();
    controller.update(sharing: true, captureReady: true, online: true);
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pump();
    expect(find.text('正在打开分享'), findsOneWidget);
    expect(find.byKey(const Key('sharing-progress')), findsOneWidget);

    controller.shareResponse.completeError(StateError('share unavailable'));
    await tester.pumpAndSettle();
    expect(controller.calls, ['share-invitation']);
    expect(find.byKey(const Key('sharing-progress')), findsNothing);
    expect(find.text('操作暂未完成，请重试'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('saved elder families replace sharing with a directional sheet and retain add-family sharing', (tester) async {
    final controller = FamilyController(AssistState(deviceId: '123456789', inputReady: true,
      familyMembers: [familyMember('987654321', '女儿', FamilyDirection.incomingHelper),
        familyMember('456789123', '妈妈', FamilyDirection.outgoingElder)]));
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    expect(find.text('女儿'), findsOneWidget);
    expect(find.text('妈妈'), findsNothing);
    expect(find.text('找TA帮忙'), findsOneWidget);
    expect(controller.calls, isEmpty);
    await tester.ensureVisible(find.byKey(const Key('family-add')));
    await tester.tap(find.byKey(const Key('family-add')));
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    await tester.tap(find.text('我知道了，继续'));
    await tester.pumpAndSettle();
    expect(controller.calls, ['start', 'share-invitation']);
  });

  testWidgets('family management can rename and remove without leaving disposed listeners', (tester) async {
    final controller = FamilyController(AssistState(deviceId: '123456789', inputReady: true,
      familyMembers: [familyMember('987654321', '女儿', FamilyDirection.incomingHelper, ready: false)]));
    await mount(tester, controller, width: 320, height: 640, scale: 1.8);
    await openTools(tester);
    await tester.tap(find.byKey(const Key('manage-family')));
    await tester.pumpAndSettle();
    expect(find.text('尚未完成配对'), findsOneWidget);
    expect(tester.widget<FilledButton>(find.byKey(const Key('family-action-987654321'))).onPressed, isNull);
    await tester.tap(find.byKey(const Key('family-menu-987654321')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('改名'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('family-rename-input')), '小李');
    await tester.tap(find.byKey(const Key('family-rename-save')));
    await tester.pumpAndSettle();
    expect(find.text('小李'), findsOneWidget);
    expect(controller.calls, ['family-rename:987654321:小李']);
    await tester.tap(find.byKey(const Key('family-menu-987654321')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('移除'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('family-forget-confirm')));
    await tester.pumpAndSettle();
    expect(find.text('还没有家人'), findsOneWidget);
    expect(controller.calls.last, 'family-forget:987654321');
    await tester.pumpWidget(const MaterialApp(home: SizedBox()));
    controller.notifyListeners();
    await tester.pump();
    expect(tester.takeException(), isNull);
  });

  for (final approved in [false, true]) {
    testWidgets('requesting family waits for actual capture consent: approved=$approved', (tester) async {
      final controller = FamilyController(AssistState(deviceId: '123456789', inputReady: true,
        familyMembers: [familyMember('987654321', '女儿', FamilyDirection.incomingHelper)]), approveCapture: approved);
      controller.captureResponse = Completer<void>();
      await mount(tester, controller);
      await tester.tap(find.byKey(const Key('share-invitation')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('family-action-987654321')));
      await tester.pumpAndSettle();
      expect(find.text('允许家人帮忙'), findsOneWidget);
      expect(controller.calls, isEmpty);
      await tester.tap(find.text('我知道了，继续'));
      await tester.pump(const Duration(milliseconds: 500));
      expect(controller.calls, ['start']);
      expect(find.byKey(const Key('stop-sharing')).hitTestable(), findsOneWidget);
      controller.captureResponse!.complete();
      await tester.pumpAndSettle();
      expect(controller.calls, approved ? ['start', 'family-request:987654321'] : ['start']);
      expect(find.text('已开启'), findsOneWidget);
    });
  }

  testWidgets('stopping pending family preparation prevents a late consent from sending a request', (tester) async {
    final controller = FamilyController(AssistState(deviceId: '123456789', inputReady: true,
      familyMembers: [familyMember('987654321', '女儿', FamilyDirection.incomingHelper)]));
    controller.captureResponse = Completer<void>();
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('family-action-987654321')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('我知道了，继续'));
    await tester.pump(const Duration(milliseconds: 500));
    await tester.tap(find.byKey(const Key('stop-sharing')));
    await tester.pump();
    controller.captureResponse!.complete();
    await tester.pumpAndSettle();
    expect(controller.calls, ['start', 'stop']);
    expect(controller.state.sharing, isFalse);
  });

  testWidgets('cancelling family disclosure does not start sharing or send a request', (tester) async {
    final controller = FamilyController(AssistState(deviceId: '123456789', inputReady: true,
      familyMembers: [familyMember('987654321', '女儿', FamilyDirection.incomingHelper)]));
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('share-invitation')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('family-action-987654321')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('暂不开启'));
    await tester.pumpAndSettle();
    expect(controller.calls, isEmpty);
    expect(find.text('已开启'), findsOneWidget);
    expect(controller.state.captureReady, isFalse);
  });

  testWidgets('saved families cannot bypass the missing accessibility gate from More', (tester) async {
    final controller = FamilyController(AssistState(deviceId: '123456789',
      familyMembers: [familyMember('987654321', '女儿', FamilyDirection.incomingHelper)]));
    await mount(tester, controller);
    await openTools(tester);
    await tester.tap(find.byKey(const Key('manage-family')));
    await tester.pumpAndSettle();
    expect(tester.widget<FilledButton>(find.byKey(const Key('family-action-987654321'))).onPressed, isNull);
    expect(tester.widget<OutlinedButton>(find.byKey(const Key('family-add'))).onPressed, isNull);
    expect(controller.calls, isEmpty);
  });

  testWidgets('helper saved history connects in the correct direction without local input permission', (tester) async {
    final controller = FamilyController(AssistState(role: AssistRole.helper,
      familyMembers: [familyMember('987654321', '妈妈', FamilyDirection.outgoingElder, ready: false),
        familyMember('456789123', '女儿', FamilyDirection.incomingHelper)]));
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('family-shortcut')));
    await tester.pumpAndSettle();
    expect(find.text('妈妈'), findsOneWidget);
    expect(find.text('女儿'), findsNothing);
    await tester.tap(find.byKey(const Key('family-action-987654321')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['connect:987654321']);
  });

  for (final accept in [false, true]) {
    testWidgets('incoming family request requires an explicit response: accept=$accept', (tester) async {
      final controller = FamilyController(AssistState(role: AssistRole.helper,
        familyRequestStatus: FamilyRequestStatus.received, pendingFamilyRequest: familyRequest()));
      await mount(tester, controller, width: 320, height: 640, scale: 1.8);
      expect(find.text('妈妈需要帮忙'), findsOneWidget);
      expect(find.byKey(const Key('family-request-accept')).hitTestable(), findsOneWidget);
      expect(controller.calls, isEmpty);
      await tester.tap(find.byKey(Key(accept ? 'family-request-accept' : 'family-request-decline')));
      await tester.pumpAndSettle();
      expect(controller.calls, [accept ? 'family-accept' : 'family-decline']);
      expect(find.byKey(const Key('family-request-title')), findsNothing);
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('a family request overrides full interface only when the helper is available', (tester) async {
    final controller = FamilyController(AssistState(role: AssistRole.helper, fullInterface: true,
      familyRequestStatus: FamilyRequestStatus.received,
      pendingFamilyRequest: familyRequest(), sharing: true, captureReady: true));
    await mount(tester, controller);
    expect(find.byKey(const Key('legacy-home')), findsOneWidget);
    expect(find.byKey(const Key('family-request-accept')), findsNothing);
    controller.update(sharing: false, captureReady: false);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('legacy-home')), findsNothing);
    expect(find.byKey(const Key('family-request-accept')).hitTestable(), findsOneWidget);
    expect(controller.calls, isEmpty);
  });

  testWidgets('incoming requests stay pending while busy and disappear after expiry or withdrawal', (tester) async {
    final controller = FamilyController(AssistState(role: AssistRole.helper,
      familyMembers: [familyMember('987654321', '妈妈', FamilyDirection.outgoingElder)]));
    controller.connectionResponse = Completer<void>();
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('family-shortcut')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('family-action-987654321')));
    await tester.pump();
    controller.update(pending: familyRequest());
    await tester.pump();
    expect(find.byKey(const Key('family-request-title')), findsNothing);
    expect(controller.state.pendingFamilyRequest, isNotNull);
    expect(controller.calls, ['connect:987654321']);
    controller.connectionResponse!.complete();
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('family-request-title')), findsOneWidget);
    expect(controller.calls, ['connect:987654321']);
    controller.update(clearPending: true);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('family-request-title')), findsNothing);
    controller.update(pending: familyRequest(expired: true));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('family-request-title')), findsNothing);
    expect(controller.calls, ['connect:987654321']);
  });

  testWidgets('reopening a dismissed invitation replaces a manually edited peer', (tester) async {
    final controller = FakeController(const AssistState(role: AssistRole.helper,
      invitationCode: '987654321'));
    await mount(tester, controller);
    await tester.tap(find.byKey(const Key('invitation-prompt-later')));
    await tester.pumpAndSettle();
    await openTools(tester);
    await tester.tap(find.byKey(const Key('dismiss-invitation')));
    await tester.pumpAndSettle();
    await openManualPeer(tester);
    await tester.enterText(find.byKey(const Key('peer-id')), '123456789');
    controller.receiveInvitation('987654321');
    await tester.pumpAndSettle();
    await openManualPeer(tester);
    expect(tester.widget<TextField>(find.byKey(const Key('peer-id'))).controller!.text, '987654321');
    expect(controller.calls, ['dismiss-invitation']);
  });

  for (final role in [null, AssistRole.elder, AssistRole.helper]) {
    for (final brightness in Brightness.values) {
      testWidgets('320dp / 180% text fits: $role $brightness', (tester) async {
        final controller = FakeController(AssistState(role: role,
          deviceId: '123456789', online: true, inputReady: true));
        await mount(tester, controller, width: 320, scale: 1.8, brightness: brightness);
        expect(tester.takeException(), isNull);
        await tester.drag(find.byType(ListView).first, const Offset(0, -900));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      });
    }
  }

  for (final brightness in Brightness.values) {
    testWidgets('iOS controller has no sharing or role controls: $brightness', (tester) async {
      final controller = FakeController(const AssistState(role: AssistRole.helper), supportsSharing: false);
      await mount(tester, controller, width: 320, scale: 1.8, brightness: brightness);
      expect(tester.takeException(), isNull);
      expect(find.byKey(const Key('stranger-warning')), findsNothing);
      await openManualPeer(tester);
      await tester.enterText(find.byKey(const Key('peer-id')), '987 654 321');
      await tester.ensureVisible(find.byKey(const Key('connect-peer')));
      await tester.tap(find.byKey(const Key('connect-peer')));
      await tester.pumpAndSettle();
      expect(controller.calls, ['connect:987654321']);
      expect(find.text('切换身份'), findsNothing);
      expect(find.byKey(const Key('start-sharing')), findsNothing);
      expect(find.byKey(const Key('enable-input')), findsNothing);
      await openTools(tester);
      for (final key in ['share-install', 'copy-invitation', 'show-device-id', 'local-device-id',
          'choose-elder', 'choose-helper']) {
        expect(find.byKey(Key(key)), findsNothing);
      }
      expect(find.byKey(const Key('full-interface')), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('iOS family adding uses paste and then an explicit connection prompt', (tester) async {
    final controller = FamilyController(AssistState(role: AssistRole.helper, deviceId: '123456789',
      inputReady: true, familyMembers: [familyMember('987654321', '妈妈', FamilyDirection.outgoingElder)]),
      supportsSharing: false);
    await mount(tester, controller, width: 320, height: 640, scale: 1.8);
    final helperContext = tester.element(find.byKey(const Key('helper-title')));
    expect(Theme.of(helperContext).textTheme.bodyMedium!.fontSize, lessThan(20));
    expect(find.byKey(const Key('share-invitation')), findsNothing);
    await tester.tap(find.byKey(const Key('family-shortcut')));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('family-add')));
    expect(find.descendant(of: find.byKey(const Key('family-add')), matching: find.text('粘贴邀请')), findsOneWidget);
    expect(find.text('添加家人'), findsNothing);
    await tester.tap(find.byKey(const Key('family-add')));
    await tester.pumpAndSettle();
    controller.receiveInvitation('456789123', explicit: true);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('invitation-prompt-connect')).hitTestable(), findsOneWidget);
    expect(controller.calls, ['paste-invitation']);
    await tester.tap(find.byKey(const Key('invitation-prompt-connect')));
    await tester.pumpAndSettle();
    expect(controller.calls, ['paste-invitation', 'connect:456789123']);
    expect(tester.takeException(), isNull);
  });
}
