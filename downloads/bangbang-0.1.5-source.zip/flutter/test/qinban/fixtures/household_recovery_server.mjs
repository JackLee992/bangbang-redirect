// Local test process only: real household service and SQLite transactions, with
// controlled identity verification and a dropped reply after a committed write.
import { createInterface } from 'node:readline';
import { randomBytes } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { HouseholdStore } from '../../../../site/server/household-store.mjs';
import { createHouseholdService } from '../../../../site/server/household-service.mjs';

const directory = mkdtempSync(join(tmpdir(), 'household-client-recovery-'));
const store = new HouseholdStore(join(directory, 'state.sqlite'));
const owner = { installationId: randomBytes(16).toString('base64url'), authSecret: randomBytes(32).toString('base64url') };
const guardian = { installationId: randomBytes(16).toString('base64url'), authSecret: randomBytes(32).toString('base64url') };
const pairId = randomBytes(16).toString('base64url');
const service = createHouseholdService({ store, verifyIdentity: async request => {
  const installationId = request.headers.get('authorization').split(' ')[1].split('.')[0];
  const peer = installationId === owner.installationId ? guardian :
    installationId === guardian.installationId ? owner : null;
  return { installationId, peerId: '123456789', serverScope: 'test:recovery',
    pairs: peer ? [{ pairId,
      role: 'helper', peerInstallationId: peer.installationId, peerId: '987654321' }] : [] };
} });

async function dispatch(identity, body) {
  const response = await service(new Request('https://test.invalid/v1/household', {
    method: 'POST', headers: { 'content-type': 'application/json',
      authorization: `Bearer ${identity.installationId}.${identity.authSecret}` },
    body: JSON.stringify({ v: 1, ...body }),
  }));
  return { status: response.status, body: await response.json() };
}

try {
  for await (const line of createInterface({ input: process.stdin })) {
    const command = JSON.parse(line);
    let result;
    if (command.seed) {
      let created;
      if (command.emptyFamily) {
        // Use actual membership APIs: a member receives a card then leaves.
        // Its stable identity and recovery proof still exist with no family.
        await dispatch(owner, { op: 'household.list' });
        const home = await dispatch(guardian, { op: 'household.create' });
        const invite = await dispatch(guardian, { op: 'member.invite',
          familyId: home.body.household.familyId,
          expectedRevision: home.body.household.revision,
          targetInstallationId: owner.installationId });
        created = await dispatch(owner, { op: 'invite.confirm',
          inviteCode: invite.body.inviteCode, confirmed: true });
        if (created.status !== 200) throw new Error('fixture member setup failed');
        const left = await dispatch(owner, { op: 'member.leave',
          familyId: created.body.household.familyId,
          expectedRevision: created.body.household.revision });
        if (left.status !== 200) throw new Error('fixture leave failed');
      } else {
        created = await dispatch(owner, { op: 'household.create' });
      }
      const listed = await dispatch(owner, { op: 'household.list' });
      result = { owner, card: created.body.recoveryCode, userId: listed.body.userId,
        familyId: created.body.household?.familyId ?? null };
    } else {
      result = await dispatch(command.identity ?? owner, command.body);
      if (command.drop && result.status === 200) result = { dropped: true };
    }
    process.stdout.write(JSON.stringify(result) + '\n');
  }
} finally {
  store.close();
  rmSync(directory, { recursive: true, force: true });
}
