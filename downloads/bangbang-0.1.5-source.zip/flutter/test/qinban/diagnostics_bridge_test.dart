import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';
import 'package:flutter_hbb/qinban/diagnostics_bridge.dart';

void main() {
  test('native stages and nested failures reach persisted diagnostics without private details', () async {
    var persisted = '';
    final store = ConnectionDiagnostics(platform: 'ios', appVersion: '0.1.4', build: '22',
        write: (raw) async { persisted = raw; });
    DiagnosticsBridge.service = store;
    addTearDown(() { DiagnosticsBridge.close('test-session'); DiagnosticsBridge.service = null; store.dispose(); });
    DiagnosticsBridge.start('test-session');
    DiagnosticsBridge.event('test-session', 'connection_progress', {'phase': 'signalingConnecting'});
    expect(store.records.single['phase'], 'signalingConnecting');
    DiagnosticsBridge.event('test-session', 'connection_progress', {'phase': 'peerLookup'});
    // Racing connection paths cannot move the recorded progress backwards.
    DiagnosticsBridge.event('test-session', 'connection_progress', {'phase': 'signalingConnecting'});
    DiagnosticsBridge.event('test-session', 'connection_progress', {'phase': 'firstFrame', 'peerId': '123456789'});
    expect(store.records.single['phase'], 'peerLookup');
    expect(store.records.single['outcome'], 'pending');
    DiagnosticsBridge.event('test-session', 'msgbox', {
      'title': 'Connection Error', 'type': 'error',
      'text': 'Failed to connect to 192.0.2.1:21116: TCP connect failed: Connection refused (os error 61)',
    });
    DiagnosticsBridge.firstFrame('test-session');
    await store.saved;
    final retained = (jsonDecode(persisted)['attempts'] as List).single;
    expect(retained['phase'], 'peerLookup');
    expect(retained['error'], 'refused');
    expect(retained['outcome'], 'failure');
    expect(persisted, isNot(contains('192.0.2.1')));
    expect(persisted, isNot(contains('123456789')));
    expect(persisted, isNot(contains('TCP connect failed')));
  });
}
