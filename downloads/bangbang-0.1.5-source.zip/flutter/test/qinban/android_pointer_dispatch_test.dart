import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/common/widgets/gestures.dart';
import 'package:flutter_hbb/main.dart' show buildAndroidAppContent;

void main() {
  Future<void> mount(WidgetTester tester, Widget child) => tester.pumpWidget(
        MaterialApp(
          builder: buildAndroidAppContent,
          home: Scaffold(body: child),
        ),
      );

  void down(WidgetTester tester, int pointer, Offset position, double size) {
    tester.binding.handlePointerEvent(
      PointerAddedEvent(pointer: pointer, position: position),
    );
    tester.binding.handlePointerEvent(
      PointerDownEvent(pointer: pointer, position: position, size: size),
    );
  }

  void end(WidgetTester tester, int pointer, Offset position, double size,
      {bool cancel = false}) {
    tester.binding.handlePointerEvent(cancel
        ? PointerCancelEvent(pointer: pointer, position: position, size: size)
        : PointerUpEvent(pointer: pointer, position: position, size: size));
    tester.binding.handlePointerEvent(
      PointerRemovedEvent(pointer: pointer, position: position),
    );
  }

  Future<void> swipe(WidgetTester tester, int pointer, double size) async {
    down(tester, pointer, const Offset(200, 400), size);
    await tester.pump();
    for (var i = 1; i <= 9; i++) {
      tester.binding.handlePointerEvent(PointerMoveEvent(
        pointer: pointer,
        size: size,
        timeStamp: Duration(milliseconds: 50 * i),
        position: Offset(200, 400 - 25.0 * i),
        delta: const Offset(0, -25),
      ));
      await tester.pump(const Duration(milliseconds: 50));
    }
    end(tester, pointer, const Offset(200, 175), size);
    await tester.pump(const Duration(milliseconds: 300));
  }

  Widget remoteCanvas(List<int> pointers, List<String> branches) => Listener(
        onPointerDown: (event) => pointers.add(event.pointer),
        child: RawGestureDetector(
          gestures: <Type, GestureRecognizerFactory>{
            CustomTouchGestureRecognizer: GestureRecognizerFactoryWithHandlers<
                CustomTouchGestureRecognizer>(
              () => CustomTouchGestureRecognizer(),
              (recognizer) => recognizer
                ..onOneFingerPanStart = ((_) => branches.add('one'))
                ..onTwoFingerScaleStart = ((_) => branches.add('two')),
            ),
          },
          child: const SizedBox.expand(
            child: ColoredBox(color: Colors.white),
          ),
        ),
      );

  for (final size in [0.1, 1.0]) {
    testWidgets('Android app keeps a single remote swipe single, size=$size',
        (tester) async {
      final pointers = <int>[];
      final branches = <String>[];
      await mount(tester, remoteCanvas(pointers, branches));

      await swipe(tester, 17, size);

      expect(pointers, [17]);
      expect(branches, ['one']);
    });
  }

  testWidgets('two physical pointers still start remote scaling',
      (tester) async {
    final pointers = <int>[];
    final branches = <String>[];
    await mount(tester, remoteCanvas(pointers, branches));

    down(tester, 17, const Offset(200, 300), 1);
    down(tester, 23, const Offset(300, 300), 1);
    await tester.pump();
    tester.binding.handlePointerEvent(const PointerMoveEvent(
      pointer: 23,
      size: 1,
      position: Offset(360, 300),
      delta: Offset(60, 0),
    ));
    await tester.pump();
    end(tester, 23, const Offset(360, 300), 1);
    end(tester, 17, const Offset(200, 300), 1);
    await tester.pump(const Duration(milliseconds: 300));

    expect(pointers, [17, 23]);
    expect(branches, ['two']);
  });

  // Android AccessibilityService gestures arrive with size=1. They must pass
  // through normally, including when the helped user is inside this app.
  testWidgets('size-one input taps an elder button once', (tester) async {
    var taps = 0;
    await mount(
        tester,
        Center(
            child: ElevatedButton(
          onPressed: () => taps++,
          child: const Text('邀请家人'),
        )));
    final position = tester.getCenter(find.byType(ElevatedButton));

    down(tester, 17, position, 1);
    await tester.pump(const Duration(milliseconds: 50));
    end(tester, 17, position, 1);
    await tester.pump();

    expect(taps, 1);
  });

  testWidgets('size-one input scrolls elder content', (tester) async {
    final controller = ScrollController();
    addTearDown(controller.dispose);
    await mount(
        tester,
        ListView.builder(
          controller: controller,
          itemExtent: 80,
          itemCount: 30,
          itemBuilder: (_, index) => Text('家人 $index'),
        ));

    await swipe(tester, 17, 1);

    expect(controller.offset, greaterThan(100));
  });

  testWidgets('cancelled size-one input leaves no synthetic pointer behind',
      (tester) async {
    final events = <String>[];
    final pointers = <int>[];
    final branches = <String>[];
    await mount(
        tester,
        Listener(
          onPointerDown: (event) => events.add('down:${event.pointer}'),
          onPointerCancel: (event) => events.add('cancel:${event.pointer}'),
          child: remoteCanvas(pointers, branches),
        ));

    down(tester, 17, const Offset(200, 400), 1);
    await tester.pump();
    end(tester, 17, const Offset(200, 400), 1, cancel: true);
    await tester.pump(const Duration(milliseconds: 300));
    await swipe(tester, 23, 1);

    expect(events, ['down:17', 'cancel:17', 'down:23']);
    expect(pointers, [17, 23]);
    expect(branches, ['one']);
  });
}
