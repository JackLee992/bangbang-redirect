import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/invitation.dart';

void main() {
  const golden = 'BB1-MTIzNDU2Nzg5';
  const base = 'https://bangbang-download.s419505080.chatgpt.site/invite.html';
  const legacyBase = 'https://bangbang-jacklee992.netlify.app/invite';

  test('cross-language BB1 golden vectors preserve all device digits', () {
    final vectors = {
      '123456789': golden,
      '000001': 'BB1-MDAwMDAx',
      '000123': 'BB1-MDAwMTIz',
      '1234567890123456': 'BB1-MTIzNDU2Nzg5MDEyMzQ1Ng',
    };
    for (final entry in vectors.entries) {
      expect(encodePairingCode(entry.key), entry.value);
      expect(decodePairingCode(entry.value), entry.key);
    }
  });

  test('decoding rejects padding, altered unused bits, unknown versions and invalid digits', () {
    for (final token in [
      '', '123456789', 'BB2-MTIzNDU2Nzg5', '$golden=', 'BB1-%%%%',
      'BB1-MTIzNDU2Nzg5MDEyMzQ1Nh', // same decoded bytes, noncanonical trailing bits
      'BB1-MTIzNDU2Nx',
      'BB1-MTIzNDU', 'BB1-MTIzNDU2Nzg5MDEyMzQ1Njc',
      'BB1-YWJjZGVm', 'BB1-77-977-977-977-977-977-9',
    ]) {
      expect(decodePairingCode(token), isNull, reason: token);
    }
    expect(() => encodePairingCode('12 3456'), throwsFormatException);
  });

  test('canonical website and custom scheme invitations decode the same peer', () {
    expect(parseInvitationUrl('$base?code=$golden')?.deviceId, '123456789');
    expect(parseInvitationUrl('$legacyBase?code=$golden')?.deviceId, '123456789');
    expect(parseInvitationUrl('bangbang://invite?code=$golden')?.deviceId, '123456789');
    expect(QinbanInvitation('123456789').url, '$base?code=$golden');
  });

  test('brand domain links and marked messages preserve all older invite hosts', () {
    const brandBase = 'https://bangbang.yilin.fun/invite.html';
    expect(parseInvitationUrl('$brandBase?code=$golden')?.deviceId, '123456789');
    expect(parseInvitationClipboard('$brandBase?code=$golden')?.deviceId, '123456789');
    for (final invitationUrl in [base, legacyBase, brandBase]) {
      for (final installUrl in [qinbanWebsite,
          'https://$qinbanLegacyInviteHost/', 'https://$qinbanBrandInviteHost/']) {
        final message = QinbanInvitation('123456789').message
            .replaceAll('$base?code=$golden', '$invitationUrl?code=$golden')
            .replaceFirst('装：\n$qinbanWebsite', '装：\n$installUrl');
        expect(parseInvitationClipboard(message)?.deviceId, '123456789',
            reason: '$invitationUrl with $installUrl');
      }
    }
    expect(QinbanInvitation('123456789').url, '$base?code=$golden');
  });

  test('brand domain rejects changed paths, authorities and extra parameters', () {
    const brandBase = 'https://bangbang.yilin.fun/invite.html';
    for (final invalid in [
      'http://bangbang.yilin.fun/invite.html?code=$golden',
      'https://bangbang.yilin.fun:443/invite.html?code=$golden',
      'https://bangbang.yilin.fun:8443/invite.html?code=$golden',
      'https://user@bangbang.yilin.fun/invite.html?code=$golden',
      'https://bangbang.yilin.fun.evil.example/invite.html?code=$golden',
      'https://api.bangbang.yilin.fun/invite.html?code=$golden',
      'https://downloads.bangbang.yilin.fun/invite.html?code=$golden',
      'https://bangbang.yilin.fun/invite?code=$golden',
      '$brandBase/?code=$golden', '$brandBase?Code=$golden',
      '$brandBase?code=123456789', '$brandBase?code=$golden&code=$golden',
      '$brandBase?code=$golden&server=evil', '$brandBase?code=$golden#fragment',
    ]) {
      expect(parseInvitationUrl(invalid), isNull, reason: invalid);
      expect(parseInvitationClipboard(invalid), isNull, reason: invalid);
    }
    final inbox = InvitationInbox();
    expect(inbox.handleLink('$brandBase?code=$golden&server=evil'), isTrue);
    expect(inbox.current, isNull);
    final message = QinbanInvitation('123456789').message;
    expect(parseInvitationClipboard('$message\n$brandBase?code=$golden&server=evil'), isNull);
    expect(parseInvitationClipboard('$message\nhttps://bangbang.yilin.fun/?server=evil'), isNull);
  });

  test('only one code parameter and the exact origin/path are accepted', () {
    for (final raw in [
      '$base?code=$golden&code=$golden', '$base?code=$golden&password=secret',
      '$base?code=$golden&server=evil', '$base?Code=$golden', '$base?code=123456789',
      '$base?code=$golden#config', '$base/?code=$golden',
      'http://bangbang-jacklee992.netlify.app/invite?code=$golden',
      'https://evil.example/invite?code=$golden',
      'https://user@bangbang-jacklee992.netlify.app/invite?code=$golden',
      'https://bangbang-jacklee992.netlify.app:443/invite?code=$golden',
      'https://bangbang-download.s419505080.chatgpt.site:443/invite.html?code=$golden',
      'https://user@bangbang-download.s419505080.chatgpt.site/invite.html?code=$golden',
      'https://bangbang-download.s419505080.chatgpt.site.evil.example/invite.html?code=$golden',
      'https://bangbang-services.s419505080.chatgpt.site/invite.html?code=$golden',
      'bangbang://config?code=$golden', 'bangbang://invite/?code=$golden',
    ]) {
      expect(parseInvitationUrl(raw), isNull, reason: raw);
    }
  });

  test('share text contains the pairing token and complete copy/open steps', () {
    final invitation = QinbanInvitation('123456789');
    expect(invitation.message, contains('我这手机有个地方弄不明白，你有空帮我看看。'));
    expect(invitation.message, contains('把这条消息整个复制下来，再打开「帮帮」'));
    expect(invitation.message, contains('配对口令：$golden'));
    expect(invitation.message, isNot(contains('123456789')));
    expect(invitation.message.endsWith(qinbanWebsite), isTrue);
    expect(parseInvitationClipboard(invitation.message)?.deviceId, '123456789');
  });

  test('older Netlify share messages remain valid without changing API configuration', () {
    final message = QinbanInvitation('123456789').message
        .replaceAll('$base?code=$golden', '$legacyBase?code=$golden')
        .replaceAll(qinbanWebsite, 'https://$qinbanLegacyInviteHost/');
    expect(parseInvitationClipboard(message)?.deviceId, '123456789');
    expect(isQinbanInvitationLink('$base?server=evil'), isTrue);
    expect(parseInvitationClipboard('$message\n$base?code=$golden&api=https://evil.example'), isNull);
  });

  test('clipboard accepts only our invitation or a standalone versioned token', () {
    expect(parseInvitationClipboard(golden)?.deviceId, '123456789');
    expect(parseInvitationClipboard('$base?code=$golden')?.deviceId, '123456789');
    for (final text in ['123456789', '号码 123456789', '普通聊天内容', 'https://example.com/123456789']) {
      expect(parseInvitationClipboard(text), isNull);
    }
  });

  test('a message with conflicting tokens or a dangerous owned URL is rejected', () {
    final message = QinbanInvitation('123456789').message;
    expect(parseInvitationClipboard('$message\n配对口令：BB1-MDAwMDAx'), isNull);
    expect(parseInvitationClipboard('$message\n$base?code=$golden&password=secret'), isNull);
    expect(parseInvitationClipboard('$message\nBB2-MTIzNDU2Nzg5'), isNull);
    expect(parseInvitationClipboard('$message\n${QinbanInvitation('000001').url}'), isNull);
  });

  test('cold-start invitations are retained before any UI listener exists', () {
    final inbox = InvitationInbox();
    expect(inbox.handleLink('$base?code=$golden'), isTrue);
    expect(inbox.current?.deviceId, '123456789');
    expect(inbox.source, InvitationSource.link);
  });

  test('owned invalid URLs are consumed instead of reaching generic configuration', () {
    final inbox = InvitationInbox();
    expect(inbox.handleLink('bangbang://config?password=secret'), isTrue);
    expect(inbox.handleLink('$base?code=$golden&server=evil'), isTrue);
    expect(inbox.current, isNull);
    expect(inbox.handleLink('rustdesk://123456789'), isFalse);
  });

  test('link events take precedence over a different clipboard invitation', () {
    final inbox = InvitationInbox();
    inbox.offerClipboard('BB1-MDAwMDAx');
    inbox.handleLink('$base?code=$golden');
    expect(inbox.current?.deviceId, '123456789');
    expect(inbox.offerClipboard('BB1-MDAwMDAx'), isFalse);
    expect(inbox.current?.deviceId, '123456789');
  });

  test('cancelled and repeated invitations do not reappear on each resume', () {
    final inbox = InvitationInbox();
    final message = QinbanInvitation('123456789').message;
    expect(inbox.offerClipboard(message), isTrue);
    inbox.dismiss();
    expect(inbox.offerClipboard(message), isFalse);
    expect(inbox.current, isNull);
    expect(inbox.offerClipboard(message, explicit: true), isTrue);
    expect(inbox.current?.deviceId, '123456789');
  });

  test('an explicit link can reopen after dismissal without duplicate pending events', () async {
    final inbox = InvitationInbox();
    int events = 0;
    final subscription = inbox.changes.listen((_) { events++; });
    inbox.handleLink('$base?code=$golden');
    inbox.handleLink('$base?code=$golden');
    expect(events, 1);
    inbox.dismiss();
    expect(inbox.current, isNull);
    inbox.handleLink('$base?code=$golden');
    expect(inbox.current?.deviceId, '123456789');
    expect(events, 3);
    await subscription.cancel();
  });
}
