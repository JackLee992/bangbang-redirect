import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/household_service.dart';

class DrippingClient extends http.BaseClient {
  final chunks = StreamController<List<int>>();
  bool closed = false;
  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async =>
      http.StreamedResponse(chunks.stream, 200);
  @override
  void close() {
    closed = true;
    chunks.close();
  }
}

void main() {
  testWidgets(
      'continuous response chunks cannot extend the total request deadline',
      (tester) async {
    final client = DrippingClient();
    final service = HouseholdService(
        store: FamilyStore('', (_) async {}),
        ensureRegistered: () async {},
        contacts: () => [],
        prepareRecovery: (scope) async {},
        endpoint: Uri.parse('https://family.example/v1/household'),
        clientFactory: () => client);
    Object? failure;
    service.call('household.list').catchError((Object error) {
      failure = error;
      return <String, dynamic>{};
    });
    await tester.pump();
    for (var i = 0; i < 9; i++) {
      client.chunks.add([32]);
      await tester.pump(Duration(seconds: 1));
    }
    expect(client.closed, false);
    expect(failure, isNull);
    client.chunks.add([32]);
    await tester.pump(Duration(seconds: 1));
    expect(client.closed, true);
    expect(failure, isA<HouseholdException>());
    expect(failure.toString(), 'HouseholdException');
  });
  test('endpoint accepts only fixed HTTPS or debug loopback business route',
      () {
    expect(householdEndpoint('', debug: true), isNull);
    expect(
        householdEndpoint('https://family.example/v1/household', debug: false),
        isNotNull);
    for (final value in [
      'http://family.example/v1/household',
      'https://user:secret@family.example/v1/household',
      'https://family.example/other',
      'https://family.example/v1/household?code=secret',
      'https://family.example/v1/household#secret'
    ]) {
      expect(householdEndpoint(value, debug: true), isNull);
    }
    for (final host in ['localhost', '10.0.2.2', '127.0.0.1']) {
      expect(householdEndpoint('http://$host:8787/v1/household', debug: true),
          isNotNull);
      expect(householdEndpoint('http://$host:8787/v1/household', debug: false),
          isNull);
    }
  });

  test('unconfigured service never registers or starts networking', () async {
    var calls = 0;
    final service = HouseholdService(
        store: FamilyStore('', (_) async {}),
        ensureRegistered: () async {
          calls++;
        },
        contacts: () => [],
        prepareRecovery: (scope) async {
          calls++;
        });
    expect(service.available, isFalse);
    await expectLater(
        service.call('household.list'), throwsA(isA<HouseholdException>()));
    await expectLater(
        service.prepareNewDevice(), throwsA(isA<HouseholdException>()));
    expect(calls, 0);
  });

  test('registration precedes credentials and redirects cannot forward them',
      () async {
    final store = FamilyStore('', (_) async {})
      ..identity = FamilyIdentity('old-device', 'old-secret');
    var requests = 0;
    final service = HouseholdService(
        store: store,
        ensureRegistered: () async {
          store.identity = FamilyIdentity('new-device', 'new-secret');
        },
        contacts: () => [],
        prepareRecovery: (scope) async {},
        endpoint: Uri.parse('https://family.example/v1/household'),
        clientFactory: () => MockClient((request) async {
              requests++;
              expect(request.method, 'POST');
              expect(request.url.query, isEmpty);
              expect(request.followRedirects, isFalse);
              expect(request.maxRedirects, 0);
              expect(request.headers['Authorization'],
                  'Bearer new-device.new-secret');
              expect(
                  jsonDecode(request.body), {'v': 1, 'op': 'household.list'});
              return http.Response('', 307,
                  headers: {'location': 'https://untrusted.example/steal'});
            }));
    await expectLater(
        service.call('household.list'), throwsA(isA<HouseholdException>()));
    expect(requests, 1);
  });

  test('failed registration sends no household credential', () async {
    var requests = 0;
    final service = HouseholdService(
        store: FamilyStore('', (_) async {}),
        ensureRegistered: () async {
          throw StateError('private-installation.private-secret');
        },
        contacts: () => [],
        prepareRecovery: (scope) async {},
        endpoint: Uri.parse('https://family.example/v1/household'),
        clientFactory: () {
          requests++;
          return MockClient((_) async => http.Response('{}', 200));
        });
    try {
      await service.call('household.list');
      fail('must fail');
    } catch (error) {
      expect(error.toString(), 'HouseholdException');
      expect((error as HouseholdException).message, isNot(contains('private')));
    }
    expect(requests, 0);
  });

  test('unknown backend diagnostics and oversized responses stay redacted',
      () async {
    for (final response in [
      http.Response(
          jsonEncode({
            'v': 1,
            'ok': false,
            'error': 'installation.secret.BHR1.private'
          }),
          500),
      http.Response('x' * 65537, 200)
    ]) {
      final service = HouseholdService(
          store: FamilyStore('', (_) async {}),
          ensureRegistered: () async {},
          contacts: () => [],
          prepareRecovery: (scope) async {},
          endpoint: Uri.parse('https://family.example/v1/household'),
          clientFactory: () => MockClient((_) async => response));
      try {
        await service.call('household.list');
        fail('must fail');
      } catch (error) {
        expect(error.toString(), 'HouseholdException');
        expect(
            (error as HouseholdException).message, isNot(contains('private')));
      }
    }
  });

  test('new-device calls need atomic identity preparation, shared by retries',
      () async {
    var preparations = 0;
    var requests = 0;
    final store = FamilyStore('', (_) async {});
    final gate = Completer<void>();
    final service = HouseholdService(
        store: store,
        ensureRegistered: () async {},
        contacts: () => [],
        prepareRecovery: (scope) async {
          preparations++;
          await gate.future;
          await store.replaceIdentity(householdScope: scope);
        },
        endpoint: Uri.parse('https://family.example/v1/household'),
        clientFactory: () => MockClient((request) async {
              requests++;
              expect(request.headers['Authorization'],
                  'Bearer ${store.identity!.installationId}.${store.identity!.authSecret}');
              final op = jsonDecode(request.body)['op'];
              return http.Response(jsonEncode({'v': 1, 'ok': true,
                if (op == 'household.list') ...{
                  'userId': 'fresh-user', 'currentInstallationId': store.identity!.installationId,
                  'households': []},
                if (op == 'device.transfer.begin') ...{
                  'transferCode': 'BHT1.challenge', 'expiresAt': 1999999999999},
              }), 200);
            }));
    await expectLater(
        service.call('recovery.redeem', {'recoveryCode': 'BHR1.private'}),
        throwsA(isA<HouseholdException>()));
    final first = service.prepareNewDevice();
    final second = service.prepareNewDevice();
    expect(preparations, 1);
    expect(requests, 0);
    gate.complete();
    await Future.wait([first, second]);
    await service.call('device.transfer.begin');
    await service.prepareNewDevice();
    expect(preparations, 1);
    await service.recoveryCompleted();
    await service.prepareNewDevice();
    expect(preparations, 2);
    expect(requests, 2);
  });

  test('failed completion write retains pending identity until acknowledged',
      () async {
    var durable = '';
    var failWrite = false;
    final store = FamilyStore('', (value) async {
      if (failWrite) throw StateError('controlled disk failure');
      durable = value;
    });
    const scope = 'https://family.example/v1/household';
    await store.replaceIdentity(householdScope: scope);
    final installation = store.identity!.installationId;
    final service = HouseholdService(
        store: store,
        ensureRegistered: () async {},
        contacts: () => [],
        prepareRecovery: (_) async => fail('must retain the current identity'),
        endpoint: Uri.parse(scope));
    addTearDown(service.dispose);
    failWrite = true;
    await expectLater(service.recoveryCompleted(), throwsStateError);
    expect(service.recoveryPending, isTrue);
    final restarted = FamilyStore(durable, (_) async {});
    expect(restarted.identity!.installationId, installation);
    expect(restarted.householdRecovery, isNotNull);
    await service.prepareNewDevice();
    expect(store.identity!.installationId, installation);
    failWrite = false;
    await service.recoveryCompleted();
    expect(service.recoveryPending, isFalse);
    expect(FamilyStore(durable, (_) async {}).householdRecovery, isNull);
  });

  test('expired restored transfer gets a new challenge on the same identity',
      () async {
    var durable = '';
    final original = FamilyStore('', (value) async { durable = value; });
    const scope = 'https://family.example/v1/household';
    await original.replaceIdentity(householdScope: scope);
    final installation = original.identity!.installationId;
    await original.saveHouseholdRecovery(HouseholdRecoveryState(
        installationId: installation,
        scope: scope,
        initialUserId: 'fresh-user',
        transferCode: 'BHT1.expired',
        transferExpires: 1));
    final store = FamilyStore(durable, (value) async { durable = value; });
    final operations = <String>[];
    final service = HouseholdService(
        store: store,
        ensureRegistered: () async {},
        contacts: () => [],
        prepareRecovery: (_) async => fail('must retain the restored identity'),
        endpoint: Uri.parse(scope),
        clientFactory: () => MockClient((request) async {
          final body = jsonDecode(request.body) as Map<String, dynamic>;
          final op = body['op'] as String;
          operations.add(op);
          expect(request.headers['Authorization'],
              'Bearer $installation.${store.identity!.authSecret}');
          expect(['household.list', 'device.transfer.begin'], contains(op));
          return http.Response(jsonEncode({'v': 1, 'ok': true,
            if (op == 'household.list') ...{
              'userId': 'fresh-user', 'currentInstallationId': installation,
              'households': []},
            if (op == 'device.transfer.begin') ...{
              'transferCode': 'BHT1.fresh', 'expiresAt': 1999999999999},
          }), 200);
        }));
    addTearDown(service.dispose);
    await service.prepareNewDevice();
    final result = await service.call('device.transfer.begin');
    expect(result['transferCode'], 'BHT1.fresh');
    expect(operations, ['household.list', 'device.transfer.begin']);
    expect(store.identity!.installationId, installation);
    expect(FamilyStore(durable, (_) async {}).householdRecovery!.transferCode,
        'BHT1.fresh');
    expect(durable, isNot(contains('BHT1.expired')));
  });

  test('failed local identity write cannot start recovery', () async {
    var requests = 0;
    final service = HouseholdService(
        store: FamilyStore('', (_) async {}),
        ensureRegistered: () async {},
        contacts: () => [],
        prepareRecovery: (scope) async {
          throw StateError('disk full');
        },
        endpoint: Uri.parse('https://family.example/v1/household'),
        clientFactory: () {
          requests++;
          return MockClient(
              (_) async => http.Response('{"v":1,"ok":true}', 200));
        });
    await expectLater(
        service.prepareNewDevice(), throwsA(isA<HouseholdException>()));
    await expectLater(service.call('device.transfer.begin'),
        throwsA(isA<HouseholdException>()));
    expect(requests, 0);
  });
}
