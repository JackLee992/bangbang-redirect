import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/family_models.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/family_bridge.dart';
import 'package:flutter_hbb/qinban/diagnostics_bridge.dart';
import 'package:flutter_hbb/qinban/remote_server_configuration.dart';
import 'package:flutter_hbb/qinban/rustdesk_assist_controller.dart';

const profileId = 'aliyun-ecs-v1';
const profileTuple = {
  'custom-rendezvous-server': '123.57.57.202:21116',
  'relay-server': '123.57.57.202:21117',
  'api-server': '',
  'key': 'lMADRklrhk4PQsqe1sy1VCqF6amA0WS6GImbUKnmbTo=',
};
const publicTuple = {
  'custom-rendezvous-server': '',
  'relay-server': '',
  'api-server': '',
  'key': '',
};
const oldTuple = {
  'custom-rendezvous-server': 'previous.controlled.test:21116',
  'relay-server': 'previous.controlled.test:21117',
  'api-server': '',
  'key': 'previous-public-key',
};

String managed(Map<String, String> applied,
        {String id = profileId, Map<String, String> original = publicTuple}) =>
    jsonEncode(
        {'v': 1, 'profile': id, 'applied': applied, 'original': original});

String recovery(Map<String, String> before, Map<String, String> after,
        {String beforeManaged = '', String? afterManaged}) =>
    jsonEncode({
      'v': 1,
      'before': before,
      'after': after,
      'beforeManaged': beforeManaged,
      'afterManaged': afterManaged ?? managed(after),
    });

class ConfigurationFixture {
  final options = <String, String>{
    'approve-mode': 'click',
    'enable-audio': 'N'
  };
  final local = <String, String>{
    'qinban-initialized': '1',
    'qinban-role': 'elder'
  };
  final events = <String>[];
  int optionWrites = 0;
  int restarts = 0;
  int failOptionWrite = 0;
  int ignoreOptionWrite = 0;
  bool partialWrite = false;
  bool failRollback = false;
  bool failRestart = false;
  String? failLocalKey;
  bool ignoreLocalWrite = false;

  Map<String, String> get tuple => {
        for (final key in publicTuple.keys) key: options[key] ?? '',
      };

  RemoteServerConfigurationManager manager([String profile = profileId]) =>
      RemoteServerConfigurationManager(
        configuredProfile: profile,
        readOptions: () {
          events.add('readOptions');
          return jsonEncode(options);
        },
        writeOptions: (raw) async {
          events.add('writeOptions');
          optionWrites++;
          if (optionWrites == ignoreOptionWrite) return;
          final next = Map<String, String>.from(jsonDecode(raw) as Map);
          if (optionWrites == failOptionWrite ||
              (failRollback && optionWrites > 1)) {
            if (partialWrite) {
              options['custom-rendezvous-server'] =
                  next['custom-rendezvous-server']!;
            }
            throw StateError('controlled failure with private config');
          }
          options
            ..clear()
            ..addAll(next);
        },
        readLocalOption: (key) {
          events.add('readLocal:$key');
          return local[key] ?? '';
        },
        writeLocalOption: (key, value) async {
          events.add('writeLocal:$key');
          if (key == failLocalKey) {
            failLocalKey = null;
            if (ignoreLocalWrite) return;
            throw StateError('controlled marker failure');
          }
          if (value.isEmpty) {
            local.remove(key);
          } else {
            local[key] = value;
          }
        },
        restartRegistration: (server) async {
          events.add('restart:$server');
          restarts++;
          if (failRestart) {
            failRestart = false;
            throw StateError('controlled restart failure');
          }
        },
      );

  RemoteServerConfigurationManager compiledManager() {
    final callbacks = manager();
    return RemoteServerConfigurationManager(
      readOptions: callbacks.readOptions,
      writeOptions: callbacks.writeOptions,
      readLocalOption: callbacks.readLocalOption,
      writeLocalOption: callbacks.writeLocalOption,
      restartRegistration: callbacks.restartRegistration,
    );
  }
}

Matcher failure(String code) => isA<RemoteServerConfigurationException>()
    .having((error) => error.code, 'safe error code', code);

void main() {
  test('the production selector defaults to the trusted service unless defined',
      () async {
    final f = ConfigurationFixture();
    const hasBuildOverride = bool.hasEnvironment('QINBAN_REMOTE_PROFILE');
    final selected = qinbanRemoteBuildProfile;
    if (!hasBuildOverride) {
      expect(selected, profileId);
    }
    final manager = f.compiledManager();
    expect(manager.configuredProfile, selected);
    if (selected.isEmpty) {
      f.options.addAll(oldTuple);
      f.local[qinbanRemoteRecoveryKey] = 'pending';
      final originalOptions = Map.of(f.options);
      final originalLocal = Map.of(f.local);
      expect(await manager.apply(), RemoteServerConfigurationResult.disabled);
      expect(f.events, isEmpty);
      expect(f.options, originalOptions);
      expect(f.local, originalLocal);
    } else if (selected == profileId) {
      expect(await manager.apply(), RemoteServerConfigurationResult.applied);
      expect(f.tuple, profileTuple);
      expect(f.restarts, 1);
    } else if (selected == 'restore-managed') {
      expect(await manager.apply(),
          RemoteServerConfigurationResult.preservedUserConfiguration);
      expect(f.optionWrites, 0);
      expect(f.restarts, 0);
    } else {
      await expectLater(
          manager.apply(), throwsA(failure('profile_not_trusted')));
      expect(f.events, isEmpty);
    }
  });

  test(
      'a rejected profile stops the real mobile initializer before FFI or family',
      () async {
    final f = ConfigurationFixture();
    expect(FamilyBridge.service, isNull);
    expect(DiagnosticsBridge.service, isNull);
    await expectLater(
        initializeQinban(remoteConfiguration: f.manager('unknown')),
        throwsA(failure('profile_not_trusted')));
    expect(f.events, isEmpty);
    expect(FamilyBridge.service, isNull);
    expect(DiagnosticsBridge.service, isNull);
  });

  test(
      'explicitly disabled builds do not read, recover, write or restart anything',
      () async {
    final f = ConfigurationFixture()
      ..options.addAll(oldTuple)
      ..local[qinbanRemoteRecoveryKey] = 'pending';
    final originalOptions = Map.of(f.options);
    final originalLocal = Map.of(f.local);
    expect(
        await f.manager('').apply(), RemoteServerConfigurationResult.disabled);
    expect(f.events, isEmpty);
    expect(f.options, originalOptions);
    expect(f.local, originalLocal);
  });

  test('unknown build settings reject before reading any configuration',
      () async {
    for (final profile in [
      'public',
      'ALIYUN-ECS-V1',
      'aliyun-ecs-v1 ',
      '123.57.57.202:21116',
      'https://evil.example'
    ]) {
      final f = ConfigurationFixture();
      await expectLater(
          f.manager(profile).apply(), throwsA(failure('profile_not_trusted')));
      expect(f.events, isEmpty);
    }
  });

  test('explicit fixed profile applies the entire tuple before one restart',
      () async {
    final f = ConfigurationFixture();
    final unrelated = Map.of(f.options);
    final identityAndRole = Map.of(f.local);
    expect(await f.manager().apply(), RemoteServerConfigurationResult.applied);
    expect(f.tuple, profileTuple);
    expect(f.optionWrites, 1);
    expect(f.restarts, 1);
    expect(f.options['allow-websocket'], isNull);
    expect(f.options['disable-udp'], isNull);
    for (final entry in unrelated.entries) {
      expect(f.options[entry.key], entry.value);
    }
    for (final entry in identityAndRole.entries) {
      expect(f.local[entry.key], entry.value);
    }
    final marker = jsonDecode(f.local[qinbanRemoteManagedKey]!) as Map;
    expect(marker['profile'], profileId);
    expect(marker['applied'], profileTuple);
    expect(marker['original'], publicTuple);
    expect(f.local[qinbanRemoteRecoveryKey], isNull);
    expect(f.events.indexOf('writeLocal:$qinbanRemoteRecoveryKey'),
        lessThan(f.events.indexOf('writeOptions')));
    expect(
        f.events.indexOf('writeOptions'),
        lessThan(f.events
            .indexOf('restart:${profileTuple['custom-rendezvous-server']}')));
  });

  test('repeat startup remains managed without writes or registration restarts',
      () async {
    final f = ConfigurationFixture();
    await f.manager().apply();
    f.events.clear();
    expect(await f.manager().apply(),
        RemoteServerConfigurationResult.alreadyApplied);
    expect(f.optionWrites, 1);
    expect(f.restarts, 1);
    expect(f.events.where((event) => event.startsWith('write')), isEmpty);
  });

  test('every partial tuple and user transport setting remains user-owned',
      () async {
    final settings = [
      oldTuple,
      for (final key in profileTuple.keys)
        {
          key: key == 'api-server' ? 'https://user.example' : profileTuple[key]!
        },
      {'custom-rendezvous-server': ' '},
      {'allow-websocket': 'Y'},
      {'disable-udp': 'Y'},
    ];
    for (final setting in settings) {
      final f = ConfigurationFixture()..options.addAll(setting);
      final before = Map.of(f.options);
      expect(await f.manager().apply(),
          RemoteServerConfigurationResult.preservedUserConfiguration,
          reason: setting.keys.toString());
      expect(f.options, before);
      expect(f.optionWrites, 0);
      expect(f.restarts, 0);
      expect(f.local[qinbanRemoteManagedKey], isNull);
    }
  });

  test('an unmarked identical profile is not claimed as app-owned', () async {
    final f = ConfigurationFixture()..options.addAll(profileTuple);
    expect(await f.manager().apply(),
        RemoteServerConfigurationResult.preservedUserConfiguration);
    expect(f.local[qinbanRemoteManagedKey], isNull);
    expect(f.optionWrites, 0);
  });

  test('only an exact old managed tuple migrates and retains its original',
      () async {
    final oldMarker = managed(oldTuple, id: 'aliyun-ecs-v0');
    final f = ConfigurationFixture()
      ..options.addAll(oldTuple)
      ..local[qinbanRemoteManagedKey] = oldMarker;
    expect(await f.manager().apply(), RemoteServerConfigurationResult.applied);
    expect(f.tuple, profileTuple);
    expect((jsonDecode(f.local[qinbanRemoteManagedKey]!) as Map)['original'],
        publicTuple);
    for (final changed in [
      'key',
      'relay-server',
      'api-server',
      'custom-rendezvous-server'
    ]) {
      final customized = ConfigurationFixture()
        ..options.addAll(oldTuple)
        ..options[changed] = 'user-choice'
        ..local[qinbanRemoteManagedKey] = oldMarker;
      final before = Map.of(customized.options);
      expect(await customized.manager().apply(),
          RemoteServerConfigurationResult.preservedUserConfiguration);
      expect(customized.options, before);
      expect(customized.local[qinbanRemoteManagedKey], oldMarker);
    }
  });

  test('an explicit user reset and malformed management marker stay unchanged',
      () async {
    for (final marker in [
      managed(oldTuple),
      '{broken',
      jsonEncode({'v': 2, 'profile': profileId})
    ]) {
      final f = ConfigurationFixture()..local[qinbanRemoteManagedKey] = marker;
      final before = Map.of(f.options);
      expect(await f.manager().apply(),
          RemoteServerConfigurationResult.preservedUserConfiguration);
      expect(f.options, before);
      expect(f.local[qinbanRemoteManagedKey], marker);
    }
  });

  test('existing family in another scope prevents even an explicit migration',
      () async {
    final f = ConfigurationFixture();
    final family = FamilyStore('', (raw) async {
      f.local['qinban-family-v1'] = raw;
    });
    family.remember('987654321', '家人', 'rustdesk-public-v1',
        FamilyDirection.outgoingElder, DateTime(2026, 10, 4));
    family.markCompleted(familyToken(16));
    await family.save();
    final beforeFamily = f.local['qinban-family-v1'];
    final beforeOptions = Map.of(f.options);
    expect(await f.manager().apply(),
        RemoteServerConfigurationResult.preservedFamilyHistory);
    expect(f.options, beforeOptions);
    expect(f.local['qinban-family-v1'], beforeFamily);
    expect(f.optionWrites, 0);
    expect(f.restarts, 0);
    expect(f.local[qinbanRemoteManagedKey], isNull);
  });

  test(
      'existing family in the trusted scope is kept unchanged when enabling it',
      () async {
    final f = ConfigurationFixture();
    final family = FamilyStore('', (raw) async {
      f.local['qinban-family-v1'] = raw;
    });
    final scope = familyServerScope(
        profileTuple['custom-rendezvous-server']!, profileTuple['key']!);
    family.remember('987654321', '家人', scope, FamilyDirection.outgoingElder,
        DateTime(2026, 10, 4));
    family.markCompleted(familyToken(16));
    await family.save();
    final beforeFamily = f.local['qinban-family-v1'];
    expect(await f.manager().apply(), RemoteServerConfigurationResult.applied);
    expect(f.tuple, profileTuple);
    expect(f.local['qinban-family-v1'], beforeFamily);
    expect(f.optionWrites, 1);
    expect(f.restarts, 1);
  });

  test(
      'unreadable family history is preserved instead of assuming a new install',
      () async {
    for (final raw in [
      '{broken',
      jsonEncode({'v': 2, 'members': []}),
      jsonEncode({
        'v': 1,
        'members': [
          {'serverScope': null}
        ]
      }),
      jsonEncode({
        'v': 1,
        'members': [],
        'householdRecovery': {'pending': true}
      })
    ]) {
      final f = ConfigurationFixture()..local['qinban-family-v1'] = raw;
      expect(await f.manager().apply(),
          RemoteServerConfigurationResult.preservedFamilyHistory);
      expect(f.local['qinban-family-v1'], raw);
      expect(f.optionWrites, 0);
    }
  });

  test(
      'an observable partially failed write restores the complete previous tuple',
      () async {
    final f = ConfigurationFixture()
      ..failOptionWrite = 1
      ..partialWrite = true;
    await expectLater(
        f.manager().apply(), throwsA(failure('profile_apply_failed')));
    expect(f.tuple, publicTuple);
    expect(f.options['approve-mode'], 'click');
    expect(f.local[qinbanRemoteManagedKey], isNull);
    expect(f.local[qinbanRemoteRecoveryKey], isNull);
    expect(f.events.last, 'readLocal:$qinbanRemoteRecoveryKey');
  });

  test('a silently ignored tuple write cannot mark the profile as applied',
      () async {
    final f = ConfigurationFixture()..ignoreOptionWrite = 1;
    await expectLater(
        f.manager().apply(), throwsA(failure('profile_apply_failed')));
    expect(f.tuple, publicTuple);
    expect(f.local[qinbanRemoteManagedKey], isNull);
    expect(f.local[qinbanRemoteRecoveryKey], isNull);
  });

  test(
      'a failed application stops mobile family and diagnostics initialization',
      () async {
    final f = ConfigurationFixture()
      ..failOptionWrite = 1
      ..partialWrite = true;
    await expectLater(initializeQinban(remoteConfiguration: f.manager()),
        throwsA(failure('profile_apply_failed')));
    expect(f.tuple, publicTuple);
    expect(FamilyBridge.service, isNull);
    expect(DiagnosticsBridge.service, isNull);
  });

  test('marker and registration failures restore the old managed record',
      () async {
    for (final atRestart in [false, true]) {
      final oldMarker = managed(oldTuple, id: 'aliyun-ecs-v0');
      final f = ConfigurationFixture()
        ..options.addAll(oldTuple)
        ..local[qinbanRemoteManagedKey] = oldMarker;
      if (atRestart) {
        f.failRestart = true;
      } else {
        f.failLocalKey = qinbanRemoteManagedKey;
      }
      await expectLater(
          f.manager().apply(), throwsA(failure('profile_apply_failed')));
      expect(f.tuple, oldTuple);
      expect(f.local[qinbanRemoteManagedKey], oldMarker);
      expect(f.local[qinbanRemoteRecoveryKey], isNull);
    }
  });

  test('an unverified recovery journal never permits the tuple write',
      () async {
    for (final ignored in [false, true]) {
      final f = ConfigurationFixture()
        ..failLocalKey = qinbanRemoteRecoveryKey
        ..ignoreLocalWrite = ignored;
      await expectLater(
          f.manager().apply(), throwsA(failure('profile_apply_failed')));
      expect(f.optionWrites, 0);
      expect(f.restarts, 0);
      expect(f.tuple, publicTuple);
    }
  });

  test(
      'failed rollback retains a journal and a fresh startup recovers before retry',
      () async {
    final f = ConfigurationFixture()
      ..failOptionWrite = 1
      ..partialWrite = true
      ..failRollback = true;
    await expectLater(
        f.manager().apply(), throwsA(failure('profile_recovery_failed')));
    expect(f.local[qinbanRemoteRecoveryKey], isNotNull);
    f.failRollback = false;
    f.partialWrite = false;
    await expectLater(
        f.manager().apply(), throwsA(failure('profile_transaction_recovered')));
    expect(f.tuple, publicTuple);
    expect(f.local[qinbanRemoteRecoveryKey], isNull);
    expect(f.local[qinbanRemoteManagedKey], isNull);
    expect(await f.manager().apply(), RemoteServerConfigurationResult.applied);
    expect(f.tuple, profileTuple);
  });

  test('interrupted applied state recovers without assuming it was committed',
      () async {
    final f = ConfigurationFixture()
      ..options.addAll(profileTuple)
      ..local[qinbanRemoteManagedKey] = managed(profileTuple)
      ..local[qinbanRemoteRecoveryKey] = recovery(publicTuple, profileTuple);
    await expectLater(
        f.manager().apply(), throwsA(failure('profile_transaction_recovered')));
    expect(f.tuple, publicTuple);
    expect(f.local[qinbanRemoteManagedKey], isNull);
  });

  test('pending recovery does not overwrite a later user configuration',
      () async {
    final f = ConfigurationFixture()
      ..options.addAll(oldTuple)
      ..local[qinbanRemoteRecoveryKey] = recovery(publicTuple, profileTuple);
    final originalOptions = Map.of(f.options);
    final originalLocal = Map.of(f.local);
    await expectLater(
        f.manager().apply(), throwsA(failure('profile_recovery_conflict')));
    expect(f.options, originalOptions);
    expect(f.local, originalLocal);
    expect(f.optionWrites, 0);
    expect(f.restarts, 0);
  });

  test('explicit restoration requires current managed ownership', () async {
    final f = ConfigurationFixture();
    await f.manager().apply();
    expect(await f.manager('restore-managed').apply(),
        RemoteServerConfigurationResult.restored);
    expect(f.tuple, publicTuple);
    expect(f.local[qinbanRemoteManagedKey], isNull);
    expect(f.local[qinbanRemoteRecoveryKey], isNull);
    expect(await f.manager('restore-managed').apply(),
        RemoteServerConfigurationResult.preservedUserConfiguration);
    final customized = ConfigurationFixture()
      ..options.addAll(oldTuple)
      ..local[qinbanRemoteManagedKey] = managed(profileTuple);
    expect(await customized.manager('restore-managed').apply(),
        RemoteServerConfigurationResult.preservedUserConfiguration);
    expect(customized.tuple, oldTuple);
  });

  test(
      'errors contain fixed codes without the tuple, family or injected details',
      () async {
    final f = ConfigurationFixture()
      ..failOptionWrite = 1
      ..partialWrite = true;
    try {
      await f.manager().apply();
      fail('The failed configuration must prevent further initialization');
    } on RemoteServerConfigurationException catch (error) {
      expect(error.toString(), contains('profile_apply_failed'));
      expect(error.toString(), isNot(contains('private')));
      expect(error.toString(), isNot(contains(profileTuple['key']!)));
      expect(error.toString(), isNot(contains('123.57.57.202')));
    }
  });
}
