import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';
import 'package:flutter_hbb/qinban/diagnostics_page.dart';
import 'package:flutter_hbb/qinban/remote_performance.dart';

void main() {
  testWidgets(
      'performance updates and copies separately from first-frame success',
      (tester) async {
    var now = DateTime.utc(2026);
    final metrics = RemotePerformanceMetrics(now: () => now)
      ..start('private-peer');
    final diagnostics = ConnectionDiagnostics(
        write: (_) async {}, platform: 'ios', appVersion: '0.1.2', build: '12');
    final attempt = diagnostics.begin();
    diagnostics.advance(attempt, DiagnosticPhase.firstFrame);
    String? copied;
    tester.binding.defaultBinaryMessenger
        .setMockMethodCallHandler(SystemChannels.platform, (call) async {
      if (call.method == 'Clipboard.setData') copied = call.arguments['text'];
      return null;
    });
    addTearDown(() {
      tester.binding.defaultBinaryMessenger
          .setMockMethodCallHandler(SystemChannels.platform, null);
      metrics.dispose();
      diagnostics.dispose();
    });
    await tester.pumpWidget(MaterialApp(
        home: DiagnosticsPage(diagnostics: diagnostics, performance: metrics)));
    expect(find.text('连接成功率 100%'), findsOneWidget);
    metrics.quality('private-peer',
        {'fps': '{"0":30}', 'codec_format': 'VP8', 'delay': '22'});
    metrics.delivered('private-peer',
        width: 360, height: 800, elapsedMicros: 2000);
    now = now.add(const Duration(seconds: 5));
    metrics.quality('private-peer', {'fps': '{"0":25}'});
    await tester.pump();
    await tester.ensureVisible(find.byKey(const Key('copy-diagnostics')));
    await tester.tap(find.byKey(const Key('copy-diagnostics')));
    await tester.pumpAndSettle();
    expect(copied, isNot(contains('private-peer')));
    final report = jsonDecode(copied!);
    expect(report['performance']['latest']['nativeDecodeFps'], 30);
    expect(report['performance']['latest']['uiImageDeliveryFps'], .2);
    expect(report['connection']['attempts'].single['outcome'], 'success');
    expect(report['connection']['summary']['success'], 1);
    await tester.scrollUntilVisible(
        find.byKey(const Key('performance-frame-rates')), 250);
    expect(find.text('解码 30.0 帧/秒 · 交给界面 0.2 帧/秒'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('cancelled-only connections show no rate or invented latency',
      (tester) async {
    final diagnostics = ConnectionDiagnostics(
        write: (_) async {},
        platform: 'android',
        appVersion: '0.1.2',
        build: '14');
    addTearDown(diagnostics.dispose);
    diagnostics.finish(diagnostics.begin(), DiagnosticOutcome.cancelled);
    // Preparation on the elder's side must not inflate helper connection rate.
    final ready = diagnostics.begin(kind: 'preparation', role: 'elder');
    diagnostics.advance(ready, DiagnosticPhase.serviceReady);
    await tester.pumpWidget(
        MaterialApp(home: DiagnosticsPage(diagnostics: diagnostics)));
    expect(find.text('连接成功率 —'), findsOneWidget);
    expect(find.textContaining('取消 1 次'), findsOneWidget);
    expect(find.textContaining('明确失败的 0 次'), findsOneWidget);
    expect(find.text('还没有可计算耗时的成功连接。'), findsOneWidget);
    expect(find.byKey(const Key('diagnostic-first-frame-time')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('summary remains readable on a narrow screen at double text size',
      (tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final diagnostics = ConnectionDiagnostics(
        write: (_) async {}, platform: 'ios', appVersion: '0.1.2', build: '14');
    addTearDown(diagnostics.dispose);
    diagnostics.advance(diagnostics.begin(), DiagnosticPhase.firstFrame);
    diagnostics.finish(diagnostics.begin(), DiagnosticOutcome.failure,
        error: DiagnosticError.timeout);
    await tester.pumpWidget(MaterialApp(
        builder: (context, child) => MediaQuery(
            data: MediaQuery.of(context)
                .copyWith(textScaler: const TextScaler.linear(2)),
            child: child!),
        home: DiagnosticsPage(diagnostics: diagnostics)));
    expect(find.text('连接成功率 50%'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('查看分组统计'), 250);
    await tester.drag(find.byType(ListView), const Offset(0, -200));
    await tester.pumpAndSettle();
    await tester.tap(find.text('查看分组统计'));
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(find.text('等待超时 · 1 次'), 250);
    expect(find.text('等待超时 · 1 次'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
