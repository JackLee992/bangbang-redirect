import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:flutter_hbb/common/widgets/remote_input.dart';
import 'package:flutter_hbb/models/input_model.dart';
import 'package:flutter_hbb/models/model.dart';

class RecordingInput implements InputModel {
  final events = <String>[];
  @override
  final relativeMouseMode = false.obs;
  @override
  bool shouldIgnoreTouchTap(ui.Offset position) => false;
  @override
  Future<void> tapDown(MouseButtons button) async { events.add('down'); }
  @override
  Future<void> tapUp(MouseButtons button) async { events.add('up'); }
  @override
  Future<void> tap(MouseButtons button) async {
    await tapDown(button);
    await tapUp(button);
  }
  @override
  Future<void> sendMouse(String type, MouseButtons button) async { events.add(type); }
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class MobilePeer implements FfiModel {
  @override
  bool get touchMode => true;
  @override
  bool get isPeerMobile => true;
  @override
  bool get isPeerAndroid => true;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class RecordingCursor implements CursorModel {
  RecordingCursor(this.firstMoveDelay);
  final Duration firstMoveDelay;
  int moves = 0;
  final positions = <Offset>[];
  @override
  Future<bool> move(double x, double y) async {
    if (moves++ == 0) await Future<void>.delayed(firstMoveDelay);
    positions.add(Offset(x, y));
    return true;
  }
  @override
  Future<void> updatePan(Offset delta, Offset position, bool touchMode) async {
    await move(position.dx, position.dy);
  }
  @override
  bool shouldBlock(double x, double y) => false;
  @override
  bool isInRemoteRect(Offset position) => true;
  @override
  bool get lastIsBlocked => false;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class GestureSession implements FFI {
  GestureSession(Duration delay) : cursorModel = RecordingCursor(delay);
  @override
  final RecordingInput inputModel = RecordingInput();
  @override
  final ffiModel = MobilePeer();
  @override
  final RecordingCursor cursorModel;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  Future<void> mount(WidgetTester tester, GestureSession session) async {
    await tester.pumpWidget(MaterialApp(home: Scaffold(body:
      RawTouchGestureDetectorRegion(ffi: session, child:
        const SizedBox.expand(child: ColoredBox(color: Colors.white))))));
  }

  Future<void> drain(WidgetTester tester) async {
    for (var i = 0; i < 12; i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(tester.takeException(), isNull);
  }

  for (final delay in [Duration.zero, const Duration(milliseconds: 400)]) {
    testWidgets('a short remote tap always ends released with bridge delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      await tester.tapAt(const Offset(200, 200));
      await drain(tester);
      expect(session.inputModel.events, ['down', 'up'],
        reason: 'A completed tap must not leave the Android accessibility gesture held: ${session.inputModel.events}');
    });

    testWidgets('a double tap sends exactly two pairs with delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      await tester.tapAt(const Offset(200, 200));
      await tester.pump(const Duration(milliseconds: 80));
      await tester.tapAt(const Offset(200, 200));
      await drain(tester);
      expect(session.inputModel.events, ['down', 'up', 'down', 'up']);
    });

    testWidgets('a long press stays held until release with delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      final gesture = await tester.startGesture(const Offset(200, 200));
      await drain(tester);
      expect(session.inputModel.events, ['down']);
      await gesture.moveTo(const Offset(250, 220));
      await gesture.up();
      await drain(tester);
      expect(session.inputModel.events, ['down', 'up']);
      expect(session.cursorModel.positions.last, const Offset(250, 220));
    });

    testWidgets('a swipe moves before releasing with delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      await tester.dragFrom(const Offset(200, 200), const Offset(120, 60));
      await drain(tester);
      expect(session.inputModel.events, ['down', 'up']);
      expect(session.cursorModel.positions.last.dx, greaterThan(250));
    });

    testWidgets('a cancelled pointer releases with delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      final gesture = await tester.startGesture(const Offset(200, 200));
      await gesture.cancel();
      await drain(tester);
      expect(session.inputModel.events, ['down', 'up']);
    });

    testWidgets('closing the remote view releases an active press with delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      await tester.startGesture(const Offset(200, 200));
      await drain(tester);
      expect(session.inputModel.events, ['down']);
      await tester.pumpWidget(const SizedBox());
      await drain(tester);
      expect(session.inputModel.events, ['down', 'up']);
    });

    testWidgets('closing while the first move is pending never leaves a press with delay $delay', (tester) async {
      final session = GestureSession(delay);
      await mount(tester, session);
      await tester.startGesture(const Offset(200, 200));
      await tester.pumpWidget(const SizedBox());
      await drain(tester);
      expect(session.inputModel.events, anyOf(isEmpty, ['down', 'up']));
    });
  }
}
