import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_hbb/qinban/family_models.dart';
import 'package:flutter_hbb/qinban/family_service.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/household_service.dart';
import 'family_identity_recovery_test.dart' show IdentityTransport;

class RecoveryBackend {
  RecoveryBackend(this.process)
      : replies = StreamIterator(process.stdout
            .transform(utf8.decoder)
            .transform(const LineSplitter())) {
    process.stderr.drain<void>();
  }
  final Process process;
  final StreamIterator<String> replies;
  Future<Map<String, dynamic>> send(Map<String, dynamic> data) async {
    process.stdin.writeln(jsonEncode(data));
    if (!await replies.moveNext()) throw StateError('fixture stopped');
    return jsonDecode(replies.current) as Map<String, dynamic>;
  }

  Future<void> close() async {
    await process.stdin.close();
    await process.exitCode;
    await replies.cancel();
  }
}

void main() {
  for (final scenario in ['recovery', 'transfer', 'empty-family-recovery']) {
    final mode = scenario == 'transfer' ? 'transfer' : 'recovery';
    final emptyFamily = scenario == 'empty-family-recovery';
    test(
        '$scenario retains committed identity across lost reply, restart and retry (real SQLite)',
        () async {
      final backend = RecoveryBackend(await Process.start(
          'node', ['test/qinban/fixtures/household_recovery_server.mjs']));
      addTearDown(backend.close);
      final seed = await backend.send({'seed': true, 'emptyFamily': emptyFamily});
      String durable = '';
      final operations = <String>[];
      var preparations = 0;
      var drop =
          mode == 'recovery' ? 'recovery.redeem' : 'device.transfer.complete';
      var failQuery = false;
      late FamilyStore store;
      late FamilyService family;
      late HouseholdService service;
      void restart() {
        store = FamilyStore(durable, (value) async {
          durable = value;
        });
        family = FamilyService(
            store: store,
            transport: IdentityTransport(store.identity!),
            freshTransport: IdentityTransport.new,
            context: () => FamilyContext('123456789', 'test:recovery'));
        service = HouseholdService(
            store: store,
            ensureRegistered: family.ensureRegistered,
            contacts: () => [],
            endpoint: Uri.parse('https://test.invalid/v1/household'),
            prepareRecovery: (scope) async {
              preparations++;
              await family.prepareHouseholdRecovery(
                  confirmed: true, householdScope: scope);
            },
            clientFactory: () => MockClient((request) async {
                  final body = jsonDecode(request.body) as Map<String, dynamic>;
                  operations.add(body['op']);
                  if (failQuery && body['op'] == 'household.list') {
                    throw http.ClientException('controlled offline');
                  }
                  final owner = store.identity!;
                  final result = await backend.send({
                    'identity': {
                      'installationId': owner.installationId,
                      'authSecret': owner.authSecret
                    },
                    'body': body,
                    'drop': body['op'] == drop
                  });
                  if (result['dropped'] == true) {
                    drop = '';
                    throw http.ClientException(
                        'reply lost after SQLite commit');
                  }
                  return http.Response(
                      jsonEncode(result['body']), result['status']);
                }));
      }

      restart();
      final originalIdentity = store.identity!;
      final oldBinding = store.remember('987654321', '家人', 'test:recovery',
          FamilyDirection.outgoingElder, DateTime.now())
        ..pairId = familyToken(16)
        ..capability = familyToken(32)
        ..nonce = familyToken(16)
        ..remoteInstallationId = familyToken(16)
        ..ownPeerId = '123456789'
        ..confirmed = true;
      expect(oldBinding.view.directReady, isTrue);
      await service.prepareNewDevice();
      final retainedIdentity = store.identity!;
      expect(retainedIdentity.installationId,
          isNot(originalIdentity.installationId));
      expect(store.members, isEmpty);
      expect(durable, isNot(contains(seed['card'])));
      String? challenge;
      if (mode == 'transfer') {
        challenge =
            (await service.call('device.transfer.begin'))['transferCode'];
        final approved = await backend.send({
          'body': {
            'op': 'device.transfer.approve',
            'transferCode': challenge,
            'confirmed': true
          }
        });
        expect(approved['status'], 200);
      }
      final op =
          mode == 'recovery' ? 'recovery.redeem' : 'device.transfer.complete';
      final fields = {
        'confirmed': true,
        if (mode == 'recovery')
          'recoveryCode': seed['card']
        else
          'transferCode': challenge
      };
      await expectLater(
          service.call(op, fields), throwsA(isA<HouseholdException>()));
      expect(service.recoveryPending, isTrue);
      // The real transaction has already revoked the old phone.
      final oldPhone = await backend.send({
        'body': {'op': 'household.list'}
      });
      expect(oldPhone['body']['error'], 'device_revoked');
      service.dispose();
      family.dispose();
      restart();
      expect(store.identity!.installationId, retainedIdentity.installationId);
      expect(store.identity!.authSecret, retainedIdentity.authSecret);
      expect(service.transferCode, challenge);
      expect(store.members, isEmpty);
      // An inconclusive status check must preserve the same identity too.
      failQuery = true;
      await service.prepareNewDevice();
      await expectLater(
          service.call(op, fields), throwsA(isA<HouseholdException>()));
      expect(preparations, 1);
      expect(store.identity!.installationId, retainedIdentity.installationId);
      failQuery = false;
      final recovered = await service.call(op, fields);
      expect(recovered['userId'], seed['userId']);
      if (emptyFamily) {
        expect(recovered['households'], isEmpty);
      } else {
        expect((recovered['households'] as List).single['familyId'],
            seed['familyId']);
      }
      expect(validHouseholdCode(recovered['recoveryCode'], 'BHR1'), isTrue);
      expect(recovered['recoveryCode'], isNot(seed['card']));
      expect(operations.where((item) => item == op), hasLength(1));
      expect(operations, contains('recovery.rotate'));
      expect(preparations, 1);
      expect(store.members, isEmpty);
      expect(family.pendingRequest, isNull);
      expect(family.requestStatus, FamilyRequestStatus.idle);
      // Keep the checkpoint until the UI acknowledges saving the new card.
      expect(service.recoveryPending, isTrue);
      expect(durable, isNot(contains(recovered['recoveryCode'])));
      await service.recoveryCompleted();
      expect(FamilyStore(durable, (_) async {}).householdRecovery, isNull);
      expect(durable, isNot(contains('BHT1.')));
      service.dispose();
      family.dispose();
    });
  }

  test('another endpoint cannot reuse or replace a pending recovery identity',
      () async {
    String durable = '';
    var store = FamilyStore('', (value) async {
      durable = value;
    });
    final fresh = await store.replaceIdentity(
        householdScope: 'https://one.invalid/v1/household');
    store = FamilyStore(durable, (_) async {});
    final service = HouseholdService(
        store: store,
        ensureRegistered: () async {},
        contacts: () => [],
        prepareRecovery: (_) async =>
            fail('must not rotate an unresolved identity'),
        endpoint: Uri.parse('https://two.invalid/v1/household'),
        clientFactory: () =>
            throw StateError('must not send credentials to the other service'));
    await expectLater(
        service.prepareNewDevice(), throwsA(isA<HouseholdException>()));
    await expectLater(
        service.resumeRecovery(), throwsA(isA<HouseholdException>()));
    expect(store.identity!.installationId, fresh.installationId);
    service.dispose();
  });
}
