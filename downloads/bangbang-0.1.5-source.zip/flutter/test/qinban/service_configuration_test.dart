import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_hbb/qinban/family_models.dart';
import 'package:flutter_hbb/qinban/family_service.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/family_transport.dart';
import 'package:flutter_hbb/qinban/service_configuration.dart';

class RegistrationTransport
    implements FamilyTransport, FamilyRegistrationScope {
  RegistrationTransport(this.registrationScope);
  @override
  String registrationScope;
  int registrations = 0;
  Completer<Map<String, dynamic>>? reply;
  @override
  Future<Map<String, dynamic>> call(
      String op, Map<String, dynamic> data) async {
    expect(op, 'register');
    registrations++;
    return reply?.future ?? Future.value({'v': 1, 'ok': true});
  }

  @override
  void dispose() {}
  @override
  void resume() {}
  @override
  void suspend() {}
}

void main() {
  test('Sites is the single default family and diagnostics authority', () {
    expect(familyServiceEndpoint().toString(), qinbanFamilyServiceUrl);
    expect(NetlifyFamilyTransport.endpoint.toString(), qinbanFamilyServiceUrl);
    expect(diagnosticsServiceEndpoint('')?.toString(),
        qinbanDiagnosticsServiceUrl);
    expect(familyServiceEndpoint(configured: qinbanFamilyServiceUrl).toString(),
        qinbanFamilyServiceUrl);
  });

  test(
      'untrusted build settings cannot disclose installation credentials or select a second database',
      () {
    for (final configured in [
      'https://bangbang-jacklee992.netlify.app/.netlify/functions/family',
      'https://evil.example/.netlify/functions/family',
      '$qinbanFamilyServiceUrl?api=evil',
      '$qinbanFamilyServiceUrl#config',
      qinbanFamilyServiceUrl.replaceFirst('https://', 'https://name:secret@'),
      qinbanFamilyServiceUrl.replaceFirst('.site/', '.site:443/'),
      '$qinbanFamilyServiceUrl\n',
      qinbanFamilyServiceUrl.replaceFirst('https:', 'http:'),
    ]) {
      expect(familyServiceEndpoint(configured: configured).toString(),
          qinbanFamilyServiceUrl);
    }
    for (final configured in [
      'https://evil.example/v1/attempts',
      '$qinbanDiagnosticsServiceUrl?token=secret',
      qinbanDiagnosticsServiceUrl.replaceFirst(
          'https://', 'https://name:secret@'),
      qinbanDiagnosticsServiceUrl.replaceFirst('.site/', '.site:443/'),
      'https://bangbang-jacklee992.netlify.app/v1/attempts',
    ]) {
      expect(diagnosticsServiceEndpoint(configured), isNull);
    }
  });

  test('only debug builds can use the explicit loopback family fixture', () {
    for (final host in ['localhost', '127.0.0.1', '10.0.2.2']) {
      final fixture = 'http://$host:43210/family';
      expect(
          familyServiceEndpoint(localFixture: fixture, debug: true).toString(),
          fixture);
      expect(
          familyServiceEndpoint(localFixture: fixture, debug: false).toString(),
          qinbanFamilyServiceUrl);
    }
    for (final fixture in [
      'http://evil.example/family',
      'http://localhost:123/family?secret=value',
      'http://user:secret@localhost:123/family'
    ]) {
      expect(
          familyServiceEndpoint(localFixture: fixture, debug: true).toString(),
          qinbanFamilyServiceUrl);
    }
  });

  test(
      'HTTP family calls use the installation bearer and never follow redirects',
      () async {
    final identity = FamilyIdentity.create();
    int status = 200;
    final transport = NetlifyFamilyTransport(identity,
        clientFactory: () => MockClient((request) async {
              expect(request.url.toString(), qinbanFamilyServiceUrl);
              expect(request.followRedirects, isFalse);
              expect(request.headers['Authorization'],
                  'Bearer ${identity.installationId}.${identity.authSecret}');
              expect(jsonDecode(request.body),
                  {'v': 1, 'op': 'register', 'peerId': '123456789'});
              return http.Response('{"v":1,"ok":true}', status,
                  headers: {'location': 'https://evil.example/'});
            }));
    expect(await transport.call('register', {'peerId': '123456789'}),
        {'v': 1, 'ok': true});
    status = 302;
    await expectLater(transport.call('register', {'peerId': '123456789'}),
        throwsA(isA<FamilyNetworkException>()));
    transport.dispose();
  });

  test(
      'an API configuration change invalidates registration while retaining identity and remote server scope',
      () async {
    final store = FamilyStore('', (_) async {});
    final identity = store.identity;
    store.remember('987654321', '家人', 'rustdesk-public-v1',
        FamilyDirection.outgoingElder, DateTime.now());
    final transport = RegistrationTransport('https://first.example/family');
    final family = FamilyService(
        store: store,
        transport: transport,
        context: () => const FamilyContext('123456789', 'rustdesk-public-v1'));
    await family.ensureRegistered();
    await family.ensureRegistered();
    expect(transport.registrations, 1);
    transport.registrationScope = qinbanFamilyServiceUrl;
    await family.ensureRegistered();
    expect(transport.registrations, 2);
    expect(store.identity, same(identity));
    expect(store.members.single.serverScope, 'rustdesk-public-v1');
    expect(family.members.single.peerId, '987654321');
    family.dispose();
  });

  test(
      'a late response from an obsolete API cannot populate the current registration cache',
      () async {
    final store = FamilyStore('', (_) async {});
    final transport = RegistrationTransport('https://first.example/family')
      ..reply = Completer();
    final family = FamilyService(
        store: store,
        transport: transport,
        context: () => const FamilyContext('123456789', 'rustdesk-public-v1'));
    final registering = expectLater(
        family.ensureRegistered(), throwsA(isA<FamilyNetworkException>()));
    await Future<void>.delayed(Duration.zero);
    transport.registrationScope = qinbanFamilyServiceUrl;
    transport.reply!.complete({'v': 1, 'ok': true});
    await registering;
    transport.reply = null;
    await family.ensureRegistered();
    expect(transport.registrations, 2);
    family.dispose();
  });
}
