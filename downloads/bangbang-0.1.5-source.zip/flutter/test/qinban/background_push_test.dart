import 'dart:async';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/background_push.dart';
import 'package:flutter_hbb/qinban/family_service.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/family_transport.dart';

FamilyPushState ready([String suffix = 'a']) => FamilyPushState.parse({
  'provider': 'fcm', 'token': 'test-provider-push-token-$suffix', 'enabled': true, 'status': 'ready',
  'clientConfig': {'appId': 'io.github.jacklee992.qinban', 'projectId': 'bangbang-test'},
});

class PushTransport implements FamilyTransport {
  final calls = <String>[];
  bool supported = true;
  bool actionable = true;
  bool configured = true;
  bool configurationSupported = true;
  String? configurationStatus = 'matched';
  final arguments = <Map<String, dynamic>>[];
  @override
  Future<Map<String, dynamic>> call(String op, Map<String, dynamic> data) async {
    calls.add(op);
    arguments.add(data);
    if (op == 'register') return {'backgroundPush': supported ? 1 : 0, if (configurationSupported) 'pushConfiguration': 1};
    if (op == 'push.resolve') return {...data, 'actionable': actionable};
    return {'push': {'registered': op == 'push.register', 'deliveryConfigured': configured, 'configurationStatus': configurationStatus}};
  }
  @override
  void suspend() {}
  @override
  void resume() {}
  @override
  void dispose() {}
}

void main() {
  test('a native token or ready label without verified configuration is not readiness', () async {
    for (final value in [
      {'provider': 'fcm', 'token': 'test-provider-push-token-a', 'enabled': true, 'status': 'ready'},
      {'provider': 'fcm', 'enabled': true, 'status': 'ready'},
      {'provider': 'apns', 'token': 'ab' * 32, 'enabled': true, 'status': 'ready',
        'clientConfig': {'appId': 'com.example.app', 'environment': 'development'}},
    ]) {
      final registration = FamilyPushRegistration(readState: () async => FamilyPushState.parse(value),
        publish: (_, __, ___, ____) async => fail('Unknown configuration must not register'));
      await registration.sync(helper: true);
      expect(registration.status, isNot('configured'));
    }
    expect(FamilyPushState.parse({'status': 'denied'}).status, 'denied');
  });

  test('configuration changes invalidate the stable-token cache and preserve mismatch status', () async {
    var state = ready();
    final writes = <String>[];
    final registration = FamilyPushRegistration(readState: () async => state,
      publish: (_, __, ___, config) async {
        writes.add(config!['projectId']!);
        return writes.length == 1 ? 'matched' : 'mismatch';
      });
    await registration.sync(helper: true);
    expect(registration.status, 'configured');
    state = FamilyPushState('ready', provider: state.provider, token: state.token, enabled: true,
      clientConfig: {'appId': 'io.github.jacklee992.qinban', 'projectId': 'another-project'});
    await registration.sync(helper: true);
    expect(writes, ['bangbang-test', 'another-project']);
    expect(registration.status, 'configurationMismatch');
    await registration.sync(helper: true);
    expect(registration.status, 'configurationMismatch');
  });

  test('old servers and deliveryConfigured alone cannot establish a configuration match', () async {
    for (final configurationSupported in [false, true]) {
      final transport = PushTransport()..configurationSupported = configurationSupported
        ..configurationStatus = null;
      final family = FamilyService(store: FamilyStore('', (_) async {}), transport: transport,
        context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
      expect(await family.configurePush('fcm', ready().token!, true, ready().clientConfig), 'unverified');
      expect(transport.calls, configurationSupported ? ['register', 'push.register'] : ['register']);
      if (configurationSupported) expect(transport.arguments.last['clientConfig'], ready().clientConfig);
      // Existing registrations can still be removed on an older endpoint.
      expect(await family.configurePush('fcm', ready().token!, false, null), 'disabled');
      expect(transport.arguments.last.keys, ['provider', 'token']);
      family.dispose();
    }
  });

  test('an unconfirmed unregister retries until the server confirms removal', () async {
    var state = ready();
    final writes = <bool>[];
    final registration = FamilyPushRegistration(readState: () async => state,
      publish: (_, __, enabled, ___) async {
        writes.add(enabled);
        return enabled ? 'matched' : writes.length == 2 ? 'unavailable' : 'disabled';
      });
    await registration.sync(helper: true);
    state = FamilyPushState('denied', provider: state.provider, token: state.token);
    await registration.sync(helper: true);
    expect(registration.status, 'serverUnavailable');
    await registration.sync(helper: true);
    expect(writes, [true, false, false]);
    expect(registration.status, 'denied');
    await registration.sync(helper: true);
    expect(writes.length, 3);
  });

  test('unsupported and malformed addresses never register', () async {
    for (final value in [null, {'provider': 'sms', 'token': 'test-push-token-a'},
      {'provider': 'apns', 'token': 'not-a-hex-token', 'enabled': true},
      {'provider': 'fcm', 'token': 'contains whitespace ', 'enabled': true}]) {
      final registration = FamilyPushRegistration(readState: () async => FamilyPushState.parse(value),
          publish: (_, __, ___, ____) async => fail('Invalid address must not be sent'));
      await registration.sync(helper: true);
    }
  });

  test('stable token deduplicates; rotation and permission revocation are published', () async {
    var state = ready();
    final writes = <String>[];
    final registration = FamilyPushRegistration(readState: () async => state,
      publish: (provider, token, enabled, config) async { writes.add('$token/$enabled'); return enabled ? 'matched' : 'disabled'; });
    await registration.sync(helper: true);
    await registration.sync(helper: true);
    state = ready('b');
    await registration.sync(helper: true);
    state = FamilyPushState('denied', provider: state.provider, token: state.token);
    await registration.sync(helper: true);
    expect(writes, ['test-provider-push-token-a/true', 'test-provider-push-token-b/true', 'test-provider-push-token-b/false']);
    expect(registration.status, 'denied');
  });

  test('stable token renews within a bounded interval after server invalidation', () async {
    var now = DateTime.utc(2026, 10, 2);
    var writes = 0;
    var serverRegistered = false;
    final registration = FamilyPushRegistration(readState: () async => ready(), now: () => now,
      publish: (_, __, enabled, config) async { writes++; serverRegistered = enabled; return 'matched'; });
    await registration.sync(helper: true);
    serverRegistered = false; // Provider invalidated the saved server address.
    for (var i = 0; i < 29; i++) {
      now = now.add(const Duration(seconds: 30));
      await registration.sync(helper: true);
    }
    expect(writes, 1); // Ordinary 30-second polling must not churn registrations.
    expect(serverRegistered, isFalse);
    now = now.add(const Duration(seconds: 30));
    await registration.sync(helper: true);
    expect(writes, 2);
    expect(serverRegistered, isTrue);
    expect(registration.status, 'configured');
  });

  test('an expired cached registration cannot hide a failed authoritative refresh', () async {
    var now = DateTime.utc(2026, 10, 2);
    var writes = 0;
    final registration = FamilyPushRegistration(readState: () async => ready(), now: () => now,
      publish: (_, __, ___, ____) async {
        writes++;
        if (writes == 2) throw const FamilyNetworkException();
        return 'matched';
      });
    await registration.sync(helper: true);
    now = now.add(const Duration(minutes: 15));
    await registration.sync(helper: true);
    expect(registration.status, 'serverUnavailable');
    await registration.sync(helper: true);
    expect(writes, 3);
    expect(registration.status, 'configured');
  });

  test('temporary native refresh failure preserves the token without claiming ready', () async {
    var state = ready();
    var now = DateTime.utc(2026, 10, 2);
    final writes = <bool>[];
    final registration = FamilyPushRegistration(readState: () async => state, now: () => now,
      publish: (_, __, enabled, config) async { writes.add(enabled); return enabled ? 'matched' : 'disabled'; });
    await registration.sync(helper: true);
    state = FamilyPushState('unavailable', provider: state.provider, token: state.token, enabled: true, clientConfig: state.clientConfig);
    await registration.sync(helper: true);
    expect(writes, [true]);
    expect(registration.status, 'unavailable');
    now = now.add(const Duration(minutes: 15));
    await registration.sync(helper: true);
    expect(writes, [true, true]);
    expect(registration.status, 'unavailable');
    state = ready(); // A successful native callback confirms recovery of the same token.
    await registration.sync(helper: true);
    expect(registration.status, 'configured');
    state = FamilyPushState('denied', provider: state.provider, token: state.token);
    await registration.sync(helper: true);
    expect(writes, [true, true, false]);
    expect(registration.status, 'denied');
  });

  test('an ambiguous native failure cannot unregister, but switching role still can', () async {
    var state = ready();
    final writes = <bool>[];
    final registration = FamilyPushRegistration(readState: () async => state,
      publish: (_, __, enabled, config) async { writes.add(enabled); return enabled ? 'matched' : 'disabled'; });
    await registration.sync(helper: true);
    state = FamilyPushState('unavailable', provider: state.provider, token: state.token);
    await registration.sync(helper: true);
    expect(writes, [true]);
    expect(registration.status, 'unavailable');
    await registration.sync(helper: false);
    expect(writes, [true, false]);
    expect(registration.status, 'disabled');
  });

  test('clock rollback does not make a cached registration permanent', () async {
    var now = DateTime.utc(2026, 10, 2);
    var writes = 0;
    final registration = FamilyPushRegistration(readState: () async => ready(), now: () => now,
      publish: (_, __, ___, ____) async { writes++; return 'matched'; });
    await registration.sync(helper: true);
    now = now.subtract(const Duration(days: 1));
    await registration.sync(helper: true);
    expect(writes, 2);
  });

  test('switching to elder while registering finishes with unregistration', () async {
    final pending = Completer<String>();
    final writes = <bool>[];
    final registration = FamilyPushRegistration(readState: () async => ready(),
      publish: (_, __, enabled, config) async {
        writes.add(enabled);
        if (enabled) return await pending.future;
        return 'disabled';
      });
    final first = registration.sync(helper: true);
    await Future<void>.delayed(Duration.zero);
    final second = registration.sync(helper: false);
    pending.complete('matched');
    await Future.wait([first, second]);
    expect(writes, [true, false]);
    expect(registration.status, 'disabled');
  });

  test('network failure and missing provider config retry without claiming ready', () async {
    var count = 0;
    final registration = FamilyPushRegistration(readState: () async => ready(),
      publish: (_, __, ___, ____) async {
        count++;
        if (count == 1) throw const FamilyNetworkException();
        return count > 2 ? 'matched' : 'unconfigured';
      });
    await registration.sync(helper: true);
    expect(registration.status, 'serverUnavailable');
    await registration.sync(helper: true);
    expect(registration.status, 'serverUnavailable');
    await registration.sync(helper: true);
    expect(registration.status, 'configured');
    expect(count, 3);
  });

  test('disposed coordinator does not register a late native response', () async {
    final pending = Completer<FamilyPushState>();
    final registration = FamilyPushRegistration(readState: () => pending.future,
      publish: (_, __, ___, ____) async => fail('disposed'));
    final sync = registration.sync(helper: true);
    registration.dispose();
    pending.complete(ready());
    await sync;
  });

  test('identity change does not reuse the old registration or its late acknowledgement', () async {
    final pending = Completer<String>();
    var count = 0;
    final registration = FamilyPushRegistration(readState: () async => ready(),
      publish: (_, __, ___, ____) async {
        count++;
        if (count == 1) return await pending.future;
        return 'matched';
      });
    final sync = registration.sync(helper: true);
    await Future<void>.delayed(Duration.zero);
    registration.invalidateIdentity();
    pending.complete('matched');
    await sync;
    expect(count, 2);
    registration.invalidateIdentity();
    await registration.sync(helper: true);
    expect(count, 3);
  });

  test('legacy family servers do not receive unsupported push operations', () async {
    final transport = PushTransport()..supported = false;
    final family = FamilyService(store: FamilyStore('', (_) async {}), transport: transport,
      context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
    expect(await family.configurePush('fcm', 'test-push-token-a', true, ready().clientConfig), 'unavailable');
    expect(await family.resolvePush(familyToken(16), familyToken(16)), isFalse);
    expect(transport.calls, ['register']);
    family.dispose();
  });

  test('notification resolution never accepts a call or trusts expired references', () async {
    final transport = PushTransport();
    final family = FamilyService(store: FamilyStore('', (_) async {}), transport: transport,
      context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
    final pair = familyToken(16), request = familyToken(16);
    expect(await family.resolvePush('bad', request), isFalse);
    expect(transport.calls, isEmpty);
    expect(await family.resolvePush(pair, request), isTrue);
    transport.actionable = false;
    expect(await family.resolvePush(pair, request), isFalse);
    expect(transport.calls, ['register', 'push.resolve', 'push.resolve']);
    expect(family.pendingRequest, isNull);
    family.dispose();
  });
}
