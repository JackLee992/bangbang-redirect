import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/frame_delivery.dart';

class TestFrame {
  var disposals = 0;
  void dispose() => disposals++;
}

void main() {
  test(
      'a delayed frame is not delivered until construction and preparation finish',
      () async {
    final decodeGate = Completer<TestFrame?>();
    final prepareGate = Completer<void>();
    final prepared = Completer<void>();
    final events = <String>[];
    final frame = TestFrame();
    final delivery = deliverDecodedFrame<TestFrame>(
      decode: () => decodeGate.future,
      prepare: (_) {
        events.add('prepare');
        prepared.complete();
        return prepareGate.future;
      },
      isCurrent: () => true,
      install: (_) => events.add('install'),
      dispose: (frame) => frame.dispose(),
      onDelivered: (delivered, elapsedMicros) {
        expect(delivered, same(frame));
        expect(elapsedMicros, greaterThanOrEqualTo(0));
        events.add('delivered');
      },
    );
    expect(events, isEmpty);
    decodeGate.complete(frame);
    await prepared.future;
    expect(events, ['prepare']);
    prepareGate.complete();
    expect(await delivery, isTrue);
    expect(events, ['prepare', 'install', 'delivered']);
    expect(frame.disposals, 0);
  });

  test(
      'a failed construction never reports a frame or replaces the displayed image',
      () async {
    var installs = 0;
    var deliveries = 0;
    expect(
        await deliverDecodedFrame<TestFrame>(
          decode: () async => null,
          prepare: (_) async => fail('must not prepare a null frame'),
          isCurrent: () => true,
          install: (_) => installs++,
          dispose: (_) => fail('there is no frame to dispose'),
          onDelivered: (_, __) => deliveries++,
        ),
        isFalse);
    expect(installs, 0);
    expect(deliveries, 0);
  });

  test('a frame completed after close is released without delivery', () async {
    final decodeGate = Completer<TestFrame?>();
    var open = true;
    final frame = TestFrame();
    final delivery = deliverDecodedFrame<TestFrame>(
      decode: () => decodeGate.future,
      prepare: (_) async => fail('closed sessions cannot prepare frames'),
      isCurrent: () => open,
      install: (_) => fail('closed sessions cannot install frames'),
      dispose: (frame) => frame.dispose(),
      onDelivered: (_, __) => fail('closed sessions cannot report success'),
    );
    open = false;
    decodeGate.complete(frame);
    expect(await delivery, isFalse);
    expect(frame.disposals, 1);
  });

  test('reopening the same peer rejects a frame from the earlier session',
      () async {
    final decodeGate = Completer<TestFrame?>();
    final oldFrame = TestFrame();
    final currentFrame = TestFrame();
    var generation = 1;
    final previousGeneration = generation;
    var deliveries = 0;
    final previous = deliverDecodedFrame<TestFrame>(
      decode: () => decodeGate.future,
      prepare: (_) async {},
      isCurrent: () => generation == previousGeneration,
      install: (_) => fail('old frame must not overwrite a new session'),
      dispose: (frame) => frame.dispose(),
      onDelivered: (_, __) =>
          fail('old frame must not mark the new session successful'),
    );
    generation++;
    expect(
        await deliverDecodedFrame<TestFrame>(
          decode: () async => currentFrame,
          prepare: (_) async {},
          isCurrent: () => true,
          install: (_) {},
          dispose: (frame) => frame.dispose(),
          onDelivered: (_, __) => deliveries++,
        ),
        isTrue);
    decodeGate.complete(oldFrame);
    expect(await previous, isFalse);
    expect(deliveries, 1);
    expect(oldFrame.disposals, 1);
    expect(currentFrame.disposals, 0);
  });

  test('closing during asynchronous canvas preparation also releases the frame',
      () async {
    final preparation = Completer<void>();
    final started = Completer<void>();
    var open = true;
    final frame = TestFrame();
    final delivery = deliverDecodedFrame<TestFrame>(
      decode: () async => frame,
      prepare: (_) {
        started.complete();
        return preparation.future;
      },
      isCurrent: () => open,
      install: (_) => fail('must recheck after preparation'),
      dispose: (frame) => frame.dispose(),
      onDelivered: (_, __) => fail('must not report success after close'),
    );
    await started.future;
    open = false;
    preparation.complete();
    expect(await delivery, isFalse);
    expect(frame.disposals, 1);
  });

  test('preparation failure releases the constructed frame exactly once',
      () async {
    final frame = TestFrame();
    await expectLater(
        deliverDecodedFrame<TestFrame>(
          decode: () async => frame,
          prepare: (_) async => throw StateError('canvas unavailable'),
          isCurrent: () => true,
          install: (_) => fail('failed preparation cannot install'),
          dispose: (frame) => frame.dispose(),
          onDelivered: (_, __) =>
              fail('failed preparation cannot report success'),
        ),
        throwsStateError);
    expect(frame.disposals, 1);
  });

  test('a session already closed does not start constructing a frame',
      () async {
    expect(
        await deliverDecodedFrame<TestFrame>(
          decode: () async => fail('do not access a closed session buffer'),
          prepare: (_) async => fail('closed'),
          isCurrent: () => false,
          install: (_) => fail('closed'),
          dispose: (_) => fail('no constructed frame'),
          onDelivered: (_, __) => fail('closed'),
        ),
        isFalse);
  });

  test('a callback failure cannot dispose an image already owned by the view',
      () async {
    final frame = TestFrame();
    TestFrame? displayed;
    await expectLater(
      deliverDecodedFrame<TestFrame>(
        decode: () async => frame,
        prepare: (_) async {},
        isCurrent: () => true,
        install: (image) => displayed = image,
        dispose: (image) => image.dispose(),
        onDelivered: (_, __) => throw StateError('notification failure'),
      ),
      throwsStateError,
    );
    expect(displayed, same(frame));
    expect(frame.disposals, 0);
    displayed!.dispose();
    expect(frame.disposals, 1);
  });

  test('construction errors propagate without preparing or reporting a frame',
      () async {
    await expectLater(
      deliverDecodedFrame<TestFrame>(
        decode: () async => throw StateError('construction failed'),
        prepare: (_) async => fail('no valid frame to prepare'),
        isCurrent: () => true,
        install: (_) => fail('no valid frame to install'),
        dispose: (_) => fail('no constructed image to dispose'),
        onDelivered: (_, __) =>
            fail('failed construction cannot report success'),
      ),
      throwsStateError,
    );
  });
}
