import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_hbb/qinban/performance_report.dart';
import 'package:flutter_hbb/qinban/performance_queue.dart';
import 'package:flutter_hbb/qinban/performance_transport.dart';
import 'package:flutter_hbb/qinban/remote_performance.dart';
import 'package:flutter_hbb/qinban/diagnostics_bridge.dart';
import 'package:flutter_hbb/qinban/diagnostics_transport.dart';
import 'package:flutter_hbb/qinban/family_bridge.dart';
import 'package:flutter_hbb/qinban/family_service.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/family_transport.dart';
import 'package:flutter_hbb/qinban/service_configuration.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';

Map<String, dynamic> window([Map<String, dynamic> changes = const {}]) => {
      'v': 1,
      'windowStartMs': 0,
      'durationMs': 5000,
      'nativeDecodeFps': 8,
      'nativeSamples': 5,
      'uiImageDeliveryFps': 8.0,
      'deliveredFrames': 40,
      'rgbaDeliveryMeanMs': 2,
      'rgbaDeliveryMaxMs': 4,
      'rgbaDeliveryP95Ms': 3,
      'latencySamples': 40,
      'codec': 'vp9',
      'networkDelayMs': 49,
      'targetBitrateKbps': 1763,
      'receiveBytesPerSecond': 120000,
      'width': 540,
      'height': 1170,
      ...changes,
    };
Map<String, dynamic> report([Map<String, dynamic> changes = const {}]) => {
      'v': 1,
      'attemptId': 'A' * 22,
      'platform': 'ios',
      'appVersion': '0.1.4',
      'build': '24',
      'startedAt': DateTime.now().millisecondsSinceEpoch,
      'durationMs': 5000,
      'path': 'relay',
      'windows': [window()],
      ...changes,
    };

class RegistrationTransport implements FamilyTransport {
  int calls = 0;
  @override
  Future<Map<String, dynamic>> call(
      String op, Map<String, dynamic> data) async {
    expect(op, 'register');
    expect(data['peerId'], '123456789');
    calls++;
    return {'v': 1, 'ok': true};
  }

  @override
  void dispose() {}
  @override
  void suspend() {}
  @override
  void resume() {}
}

void main() {
  test(
      'upload parser rejects private fields, impossible metrics and windows outside the final minute',
      () {
    expect(parsePerformanceReport(report()), isNotNull);
    for (final extra in ['peerId', 'callId', 'pixels', 'event', 'token']) {
      expect(parsePerformanceReport(report({extra: 'private'})), isNull);
    }
    expect(
        parsePerformanceReport(report({'windows': List.filled(13, window())})),
        isNull);
    expect(parsePerformanceReport(report({'durationMs': 65000})), isNull);
    expect(parsePerformanceWindow(window({'uiImageDeliveryFps': 30})), isNull);
    expect(parsePerformanceWindow(window({'rgbaDeliveryP95Ms': 5})), isNull);
    expect(parsePerformanceWindow(window({'nativeSamples': 0})), isNull);
  });
  test('close emits once and callbacks contain only copied recent measurements',
      () {
    var clock = DateTime.now();
    var closed = 0;
    final emitted = <Map<String, dynamic>>[];
    final metrics = RemotePerformanceMetrics(
        now: () => clock,
        onClose: (session, windows, duration) {
          closed++;
          expect(session, 'private-session');
          expect(duration, 350000);
          emitted.addAll(windows
              .where((item) => item['windowStartMs'] >= duration - 60000)
              .toList()
              .reversed
              .take(12)
              .toList()
              .reversed);
          windows.first['codec'] = 'private';
        });
    addTearDown(metrics.dispose);
    metrics.start('private-session');
    for (var i = 0; i < 70; i++) {
      metrics.delivered('private-session',
          width: 540, height: 1170, elapsedMicros: 2000);
      clock = clock.add(const Duration(seconds: 5));
    }
    metrics.close('private-session');
    metrics.close('private-session');
    expect(closed, 1);
    expect(emitted.length, 12);
    expect(emitted.first['windowStartMs'], 290000);
    expect(metrics.export(), isNot(contains('private')));
  });
  test(
      'queue is separate, persistent, capped at ten/128KiB and expires at seven days',
      () async {
    var clock = DateTime.now(), persisted = '';
    final queue = RemotePerformanceQueue(
        now: () => clock,
        write: (raw) async {
          persisted = raw;
        },
        upload: (_) async => false);
    addTearDown(queue.dispose);
    queue.setForeground(false);
    for (var i = 0; i < 15; i++) {
      await queue.enqueue(report({
        'attemptId': base64Url.encode(List.filled(16, i)).replaceAll('=', ''),
        'startedAt': clock.millisecondsSinceEpoch
      }));
    }
    expect(queue.pending, 10);
    expect(utf8.encode(persisted).length, lessThanOrEqualTo(131072));
    final restored = RemotePerformanceQueue(
        now: () => clock, write: (_) async {}, upload: (_) async => false);
    addTearDown(restored.dispose);
    restored.setForeground(false);
    restored.restore(persisted);
    expect(restored.pending, 10);
    clock = clock.add(const Duration(days: 8));
    restored.restore(persisted);
    expect(restored.pending, 0);
  });
  test(
      'disabled preference clears durable queue and prevents enqueue/retry; background cancels only active upload',
      () async {
    var writes = '', sends = 0, cancelled = 0;
    final gate = Completer<bool>();
    final queue = RemotePerformanceQueue(write: (raw) async {
      writes = raw;
    }, upload: (_) {
      sends++;
      return gate.future;
    }, cancelUpload: () {
      cancelled++;
    });
    addTearDown(queue.dispose);
    await queue.enqueue(report());
    await Future<void>.delayed(Duration.zero);
    expect(sends, 1);
    queue.setForeground(false);
    expect(cancelled, 1);
    expect(queue.pending, 1);
    gate.complete(true);
    await Future<void>.delayed(Duration.zero);
    expect(queue.pending, 1);
    await queue.setEnabled(false);
    expect(queue.pending, 0);
    expect(jsonDecode(writes)['records'], isEmpty);
    await queue.enqueue(report());
    queue.setForeground(true);
    await queue.flush();
    expect(sends, 1);
  });
  test(
      'failed foreground attempt retains one immutable report and explicit foreground retry sends it',
      () async {
    var success = false, sends = 0;
    final queue = RemotePerformanceQueue(
        write: (_) async {},
        upload: (value) async {
          sends++;
          expect(value.length, 9);
          return success;
        });
    addTearDown(queue.dispose);
    queue.setForeground(false);
    await queue.enqueue(report());
    await queue.enqueue(report());
    expect(queue.pending, 1);
    queue.setForeground(true);
    await Future<void>.delayed(Duration.zero);
    expect(queue.pending, 1);
    expect(sends, 1);
    success = true;
    await queue.flush();
    expect(queue.pending, 0);
    expect(sends, 2);
  });
  test(
      'performance uses fixed native endpoint, bounded body and installation auth with no redirects',
      () async {
    final identity = FamilyIdentity.create();
    var requests = 0;
    final transport = AuthenticatedPerformanceTransport(
        authorize: () async => identity,
        allowed: () => true,
        clientFactory: () => MockClient((request) async {
              requests++;
              expect(request.url.toString(),
                  '$qinbanServiceOrigin/v1/performance');
              expect(request.followRedirects, false);
              expect(request.headers['Authorization'],
                  'Bearer ${identity.installationId}.${identity.authSecret}');
              expect(
                  parsePerformanceReport(jsonDecode(request.body)), isNotNull);
              expect(
                  utf8.encode(request.body).length, lessThanOrEqualTo(16384));
              return http.Response('{"v":1,"ok":true}', 202);
            }));
    expect(await transport.upload(report()), true);
    expect(requests, 1);
  });
  test(
      'untrusted endpoints, malformed facts, background cancellation and late auth cannot create HTTP clients',
      () async {
    var enabled = true, clients = 0;
    final gate = Completer<FamilyIdentity?>();
    http.Client factory() {
      clients++;
      return MockClient((_) async => http.Response('{"v":1,"ok":true}', 202));
    }

    final transport = AuthenticatedPerformanceTransport(
        authorize: () => gate.future,
        allowed: () => enabled,
        clientFactory: factory);
    final pending = transport.upload(report());
    transport.cancel();
    enabled = false;
    gate.complete(FamilyIdentity.create());
    expect(await pending, false);
    expect(clients, 0);
    final bad = AuthenticatedPerformanceTransport(
        configuredEndpoint: 'https://evil.example/v1/performance',
        authorize: () async => FamilyIdentity.create(),
        allowed: () => true,
        clientFactory: factory);
    expect(await bad.upload(report()), false);
    expect(await transport.upload(report({'ip': '192.0.2.1'})), false);
    expect(clients, 0);
  });
  test(
      'redirect, rejected, oversized and unstructured responses are never acknowledged',
      () async {
    for (final response in [
      http.Response('{"v":1,"ok":true}', 307),
      http.Response('{"v":1,"ok":false}', 401),
      http.Response(' ' * 4097, 202),
      http.Response('<html>login</html>', 200),
      http.Response('{"ok":true}', 202)
    ]) {
      final transport = AuthenticatedPerformanceTransport(
          authorize: () async => FamilyIdentity.create(),
          allowed: () => true,
          clientFactory: () => MockClient((_) async => response));
      expect(await transport.upload(report()), false);
    }
  });
  test(
      'existing installation can authorize v1 and performance when iOS own peer is not ready; new valid context still registers',
      () async {
    final store = FamilyStore('', (_) async {}),
        registering = RegistrationTransport();
    var context = const FamilyContext('', 'public');
    final family = FamilyService(
        store: store, transport: registering, context: () => context);
    FamilyBridge.service = family;
    addTearDown(() {
      FamilyBridge.service = null;
      family.dispose();
    });
    final identity = await DiagnosticsBridge.authorizeInstallation();
    expect(identity, same(store.identity));
    expect(registering.calls, 0);
    var received = 0;
    final performance = AuthenticatedPerformanceTransport(
        authorize: DiagnosticsBridge.authorizeInstallation,
        allowed: () => true,
        clientFactory: () => MockClient((request) async {
              received++;
              expect(request.headers['Authorization'],
                  'Bearer ${identity!.installationId}.${identity.authSecret}');
              return http.Response('{"v":1,"ok":true}', 202);
            }));
    expect(await performance.upload(report()), true);
    final v1 = AuthenticatedDiagnosticsTransport(
        authorize: DiagnosticsBridge.authorizeInstallation,
        allowed: () => true,
        clientFactory: () => MockClient((request) async {
              expect((jsonDecode(request.body) as Map).length, 15);
              return http.Response('{"v":1,"ok":true}', 202);
            }));
    expect(
        await v1.upload({
          'v': 1,
          'attemptId': 'A' * 22,
          'callId': 'B' * 22,
          'role': 'helper',
          'kind': 'connection',
          'platform': 'ios',
          'appVersion': '0.1.4',
          'build': '24',
          'startedAt': DateTime.now().millisecondsSinceEpoch,
          'elapsedMs': 10739,
          'phase': 'firstFrame',
          'outcome': 'success',
          'error': 'none',
          'path': 'relay',
          'revision': 3
        }),
        true);
    context = const FamilyContext('123456789', 'public');
    expect(await performance.upload(report()), true);
    expect(received, 2);
    expect(registering.calls, 1);
  });
  test(
      'bridge enqueues only on close with the same random connection attempt, never the private session',
      () async {
    final diagnostics = ConnectionDiagnostics(
        platform: 'ios', appVersion: '0.1.4', build: '24', write: (_) async {});
    final queue =
        RemotePerformanceQueue(write: (_) async {}, upload: (_) async => false)
          ..setForeground(false);
    DiagnosticsBridge.service = diagnostics;
    DiagnosticsBridge.performanceUploads = queue;
    addTearDown(() {
      DiagnosticsBridge.close('private-remote-session');
      DiagnosticsBridge.service = null;
      DiagnosticsBridge.performanceUploads = null;
      diagnostics.dispose();
      queue.dispose();
    });
    DiagnosticsBridge.start('private-remote-session');
    DiagnosticsBridge.event(
        'private-remote-session', 'connection_ready', {'direct': 'false'});
    DiagnosticsBridge.firstFrame('private-remote-session');
    DiagnosticsBridge.frameDelivered('private-remote-session',
        width: 540, height: 1170, elapsedMicros: 2200);
    expect(queue.pending, 0);
    await Future<void>.delayed(const Duration(milliseconds: 20));
    DiagnosticsBridge.close('private-remote-session');
    await Future<void>.delayed(Duration.zero);
    expect(queue.pending, 1);
    final value = (jsonDecode(queue.export())['records'] as List).single;
    expect(value['attemptId'], diagnostics.records.single['attemptId']);
    expect(value['path'], 'relay');
    expect(value['windows'].length, 1);
    expect(value['windows'].single['deliveredFrames'], 1);
    expect(queue.export(), isNot(contains('private-remote-session')));
    DiagnosticsBridge.close('private-remote-session');
    expect(queue.pending, 1);
  });
  test(
      'unknown-length oversized response stream is cancelled at the byte limit',
      () async {
    var cancelled = false;
    final stream = StreamController<List<int>>(onCancel: () {
      cancelled = true;
    });
    stream.add(List.filled(4097, 32));
    final transport = AuthenticatedPerformanceTransport(
        authorize: () async => FamilyIdentity.create(),
        allowed: () => true,
        clientFactory: () => MockClient.streaming(
            (_, __) async => http.StreamedResponse(stream.stream, 202)));
    expect(await transport.upload(report()), false);
    expect(cancelled, true);
    await stream.close();
  });
  testWidgets(
      'total deadline prevents a late registration callback from creating HTTP after timeout',
      (tester) async {
    final gate = Completer<FamilyIdentity?>();
    var clients = 0;
    final transport = AuthenticatedPerformanceTransport(
        authorize: () => gate.future,
        allowed: () => true,
        clientFactory: () {
          clients++;
          return MockClient(
              (_) async => http.Response('{"v":1,"ok":true}', 202));
        });
    final pending = transport.upload(report());
    await tester.pump(const Duration(seconds: 5));
    expect(await pending, false);
    gate.complete(FamilyIdentity.create());
    await tester.pump();
    expect(clients, 0);
  });
}
