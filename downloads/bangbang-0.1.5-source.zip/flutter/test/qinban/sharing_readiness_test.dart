import 'package:fake_async/fake_async.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/sharing_readiness.dart';

void main() {
  test('screen capture alone cannot make an offline host ready', () {
    fakeAsync((clock) {
      final changes = ChangeNotifier();
      var online = false;
      SharingReadinessResult? result;
      SharingReadiness(changes: changes, isActive: () => true,
        isOnline: () => online).result.then((value) => result = value);
      clock.elapse(const Duration(seconds: 10));
      expect(result, isNull);
      online = true;
      changes.notifyListeners();
      clock.flushMicrotasks();
      expect(result, SharingReadinessResult.ready);
      expect(changes.hasListeners, isFalse);
    });
  });

  test('offline wait is bounded and a late online event cannot revive it', () {
    fakeAsync((clock) {
      final changes = ChangeNotifier();
      var online = false;
      SharingReadinessResult? result;
      SharingReadiness(changes: changes, isActive: () => true,
        isOnline: () => online).result.then((value) => result = value);
      clock.elapse(const Duration(seconds: 20));
      expect(result, SharingReadinessResult.timedOut);
      online = true;
      changes.notifyListeners();
      expect(result, SharingReadinessResult.timedOut);
      expect(changes.hasListeners, isFalse);
    });
  });

  test('stop wins even when the next event says the network is online', () {
    fakeAsync((clock) {
      final changes = ChangeNotifier();
      var active = true;
      var online = false;
      SharingReadinessResult? result;
      final wait = SharingReadiness(changes: changes, isActive: () => active,
        isOnline: () => online);
      wait.result.then((value) => result = value);
      active = false;
      online = true;
      changes.notifyListeners();
      wait.cancel();
      clock.flushMicrotasks();
      expect(result, SharingReadinessResult.stopped);
      expect(changes.hasListeners, isFalse);
      expect(clock.nonPeriodicTimerCount, 0);
    });
  });
}
