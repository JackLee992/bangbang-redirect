import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/mobile_session_lifecycle.dart';

void main() {
  test('a new connection waits for every previous asynchronous teardown', () async {
    final old = MobileSessionLifecycle.beginClose();
    final other = MobileSessionLifecycle.beginClose();
    var started = false;
    final next = MobileSessionLifecycle.waitForIdle().then((_) => started = true);
    await Future<void>.delayed(Duration.zero);
    expect(started, false);
    old.complete();
    await Future<void>.delayed(Duration.zero);
    expect(started, false);
    other.complete();
    await next;
    expect(started, true);
  });
}
