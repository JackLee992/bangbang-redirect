import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/remote_quality_control.dart';
import 'package:flutter_hbb/qinban/remote_quality_settings.dart';

// Models the native contract, including the critical difference between saving
// "custom" and sending custom option messages (src/client.rs:save_image_quality).
class NativeQuality {
  String? mode = 'balanced';
  int savedQuality = 80;
  int savedFps = 60;
  int remoteQuality = 80;
  int remoteFps = 60;
  bool current = true;
  bool failPreset = false;
  bool failFps = false;
  bool ignorePreset = false;
  Completer<void>? presetGate;
  Future<String?> Function()? readOverride;
  void Function()? afterCustomQuality;
  final writes = <String>[];

  RemoteQualityAccess get access => RemoteQualityAccess(
        isCurrent: () => current,
        readQuality: () => readOverride?.call() ?? Future.value(mode),
        readCustomQuality: () async => [savedQuality],
        readCustomFps: () async => '$savedFps',
        writeQuality: (value) async {
          writes.add('mode:$value');
          if (failPreset) throw StateError('unavailable');
          if (presetGate != null) await presetGate!.future;
          if (ignorePreset) return;
          mode = value;
          if (value != 'custom') {
            remoteQuality = value == 'low' ? 30 : 50;
            remoteFps = 30;
          }
          // Setting the custom string does NOT send savedQuality or savedFps.
        },
        writeCustomQuality: (value) async {
          writes.add('quality:$value');
          mode = 'custom';
          savedQuality = value;
          remoteQuality = value;
          afterCustomQuality?.call();
        },
        writeCustomFps: (value) async {
          writes.add('fps:$value');
          if (failFps) throw StateError('FPS write failed');
          savedFps = value;
          remoteFps = value;
        },
      );
}

void main() {
  Future<void> show(WidgetTester tester, NativeQuality native) async {
    await tester.pumpWidget(MaterialApp(
        home: Scaffold(
      body: RemoteQualityControl(access: native.access),
    )));
    await tester.pumpAndSettle();
  }

  Future<void> tap(WidgetTester tester) async {
    await tester.tap(find.byKey(const Key('remote-smooth-quality')));
    await tester.pumpAndSettle();
  }

  testWidgets('restoring custom resends both values, not just the mode string',
      (tester) async {
    final native = NativeQuality()..mode = 'custom';
    await show(tester, native);
    expect(native.writes, isEmpty);
    await tap(tester);
    expect(native.remoteQuality, 30);
    expect(native.remoteFps, 30);
    expect(native.savedFps, 60);
    expect(find.text('流畅已开'), findsOneWidget);
    await tap(tester);
    expect(native.writes, ['mode:low', 'quality:80', 'fps:60']);
    expect(native.remoteQuality, 80);
    expect(native.remoteFps, 60);
    expect(native.mode, 'custom');
    expect(find.text('流畅优先'), findsOneWidget);
  });

  testWidgets('reads advanced changes again and prevents duplicate writes',
      (tester) async {
    final native = NativeQuality();
    await show(tester, native);
    native.mode = 'best';
    native.presetGate = Completer<void>();
    final button = find.byKey(const Key('remote-smooth-quality'));
    await tester.tap(button);
    await tester.pump();
    await tester.tap(button);
    expect(native.writes, ['mode:low']);
    native.presetGate!.complete();
    await tester.pumpAndSettle();
    await tap(tester);
    expect(native.writes, ['mode:low', 'mode:best']);
  });

  testWidgets(
      'failed switch does not claim success and retries the same intent',
      (tester) async {
    final native = NativeQuality()..failPreset = true;
    await show(tester, native);
    await tap(tester);
    expect(find.text('流畅已开'), findsNothing);
    expect(find.text('暂时没能切换画质，再试一次'), findsOneWidget);
    native.failPreset = false;
    await tap(tester);
    expect(native.writes, ['mode:low', 'mode:low']);
    expect(find.text('流畅已开'), findsOneWidget);
  });

  testWidgets('closed page ignores a pending read without writing',
      (tester) async {
    final native = NativeQuality();
    await show(tester, native);
    final pending = Completer<String?>();
    native.readOverride = () => pending.future;
    await tester.tap(find.byKey(const Key('remote-smooth-quality')));
    await tester.pump();
    await tester.pumpWidget(const SizedBox());
    pending.complete('balanced');
    await tester.pump();
    expect(native.writes, isEmpty);
    expect(tester.takeException(), isNull);
  });

  testWidgets('null means no native session and never authorizes a write',
      (tester) async {
    final native = NativeQuality()..mode = null;
    await show(tester, native);
    await tap(tester);
    expect(native.writes, isEmpty);
    expect(find.text('流畅已开'), findsNothing);
  });

  testWidgets('a silently ignored native write fails readback confirmation',
      (tester) async {
    final native = NativeQuality()..ignorePreset = true;
    await show(tester, native);
    await tap(tester);
    expect(native.writes, ['mode:low']);
    expect(find.text('流畅已开'), findsNothing);
    expect(find.text('暂时没能切换画质，再试一次'), findsOneWidget);
  });

  testWidgets(
      'partial custom restore retries the original FPS instead of toggling low',
      (tester) async {
    final native = NativeQuality()..mode = 'custom';
    await show(tester, native);
    await tap(tester);
    native.failFps = true;
    await tap(tester);
    expect(native.mode, 'custom');
    expect(native.remoteFps, 30);
    native.failFps = false;
    await tap(tester);
    expect(native.remoteFps, 60);
    expect(native.writes,
        ['mode:low', 'quality:80', 'fps:60', 'quality:80', 'fps:60']);
  });

  test('a changed session stops a multi-step restore before the next write',
      () async {
    final native = NativeQuality()
      ..mode = 'low'
      ..remoteFps = 30;
    native.afterCustomQuality = () => native.current = false;
    await expectLater(
        native.access.apply(const RemoteQualitySettings('custom',
            customQuality: 80, customFps: 60)),
        throwsStateError);
    expect(native.writes, ['quality:80']);
    expect(native.remoteFps, 30);
  });

  testWidgets('invalid saved custom parameters fail before changing quality',
      (tester) async {
    final native = NativeQuality()
      ..mode = 'custom'
      ..savedFps = 5000;
    await show(tester, native);
    await tap(tester);
    expect(native.writes, isEmpty);
    expect(find.text('流畅已开'), findsNothing);
  });
}
