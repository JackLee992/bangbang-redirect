import 'dart:convert';
import 'dart:async';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';

void main() {
  ConnectionDiagnostics create({Future<void> Function(String)? write,
      Future<bool> Function(Map<String, dynamic>)? upload, DateTime Function()? now}) {
    final store = ConnectionDiagnostics(write: write ?? (_) async {}, platform: 'ios',
      appVersion: '0.1.1', build: '11', upload: upload, now: now);
    addTearDown(store.dispose);
    return store;
  }

  testWidgets('failed uploads retry while idle without another connection event', (tester) async {
    var now = DateTime.utc(2026, 10, 4);
    var requests = 0;
    final store = create(now: () => now, upload: (_) async => ++requests > 1);
    store.begin();
    await tester.pump();
    expect(requests, 1);
    now = now.add(const Duration(seconds: 60));
    await tester.pump(const Duration(seconds: 60));
    expect(requests, 2);
    await tester.pump(const Duration(minutes: 2));
    expect(requests, 2);
  });

  testWidgets('backgrounding and disabling uploads cancel retry; resume replays once', (tester) async {
    var now = DateTime.utc(2026, 10, 4);
    var requests = 0;
    final store = create(now: () => now, upload: (_) async => ++requests > 1);
    store.begin();
    await tester.pump();
    store.setUploadActive(false);
    now = now.add(const Duration(minutes: 2));
    await tester.pump(const Duration(minutes: 2));
    expect(requests, 1);
    store.setUploadActive(true);
    await tester.pump();
    expect(requests, 2);
    store.setUploadEnabled(false);
    store.begin();
    await tester.pump(const Duration(minutes: 2));
    expect(requests, 2);
  });

  testWidgets('successful bounded replay drains older records while idle', (tester) async {
    final uploaded = <String>{};
    final store = create(upload: (record) async {
      uploaded.add(record['attemptId'] as String);
      return true;
    })..uploadEnabled = false;
    for (var i = 0; i < 30; i++) { store.begin(); }
    store.setUploadEnabled(true);
    await tester.pump();
    expect(uploaded.length, 20);
    await tester.pump(const Duration(seconds: 1));
    expect(uploaded.length, 30);
  });

  testWidgets('disposing diagnostics cancels a scheduled retry', (tester) async {
    var requests = 0;
    final store = ConnectionDiagnostics(write: (_) async {}, platform: 'ios',
        appVersion: '0.1.4', build: '22', upload: (_) async { requests++; return false; });
    store.begin();
    await tester.pump();
    expect(requests, 1);
    store.dispose();
    await tester.pump(const Duration(minutes: 2));
    expect(requests, 1);
  });

  test('the final revision is uploaded even when an earlier upload is in flight', () async {
    final gate = Completer<bool>();
    final uploaded = <Map<String, dynamic>>[];
    final store = create(upload: (record) async {
      uploaded.add(record);
      if (uploaded.length == 1) return await gate.future;
      return true;
    });
    final attempt = store.begin();
    store.advance(attempt, DiagnosticPhase.firstFrame);
    gate.complete(true);
    for (var i = 0; i < 5; i++) { await Future<void>.delayed(Duration.zero); }
    expect(uploaded.last['outcome'], 'success');
  });

  test('later flushes drain older offline records beyond the first batch', () async {
    final uploaded = <String>{};
    final store = create(upload: (record) async {
      uploaded.add(record['attemptId'] as String);
      return true;
    })..uploadEnabled = false;
    for (var i = 0; i < 30; i++) { store.begin(); }
    store.uploadEnabled = true;
    await store.flush();
    expect(uploaded.length, 20);
    await store.flush();
    expect(uploaded.length, 30);
    await store.saved;
  });

  test('transport ready and authorization are not first-frame success', () async {
    final store = create();
    final attempt = store.begin();
    store.advance(attempt, DiagnosticPhase.contacting, direct: false);
    store.advance(attempt, DiagnosticPhase.authorized);
    expect(store.records.single['outcome'], 'pending');
    store.advance(attempt, DiagnosticPhase.firstFrame);
    store.finish(attempt, DiagnosticOutcome.failure, error: DiagnosticError.network);
    expect(store.records.single['outcome'], 'success');
    expect(store.records.single['path'], 'relay');
    await store.saved;
  });
  test('cancel and late events cannot inflate success or failure counts', () {
    final store = create();
    final attempt = store.begin();
    store.finish(attempt, DiagnosticOutcome.cancelled);
    store.advance(attempt, DiagnosticPhase.firstFrame);
    expect(store.records.single['outcome'], 'cancelled');
  });
  test('persisted unfinished connections restore as interrupted, not failure', () async {
    var saved = '';
    final store = create(write: (raw) async { saved = raw; });
    store.begin();
    await store.saved;
    final restored = create()..restore(saved);
    expect(restored.records.single['outcome'], 'interrupted');
  });
  test('raw identifiers and error details never enter exported diagnostics', () {
    final store = create();
    final attempt = store.begin();
    store.finish(attempt, DiagnosticOutcome.failure,
      error: classifyConnectionError('Connection reset for 123456789 at 192.0.2.1:21116 BB1-secret'));
    final exported = store.export();
    expect(exported, isNot(contains('123456789')));
    expect(exported, isNot(contains('192.0.2.1')));
    expect(exported, isNot(contains('BB1-secret')));
    expect(store.records.single['error'], 'reset');
    final poisoned = {...store.records.single, 'peerId': '123456789'};
    expect(parseDiagnosticRecord(poisoned), isNull);
    final restored = create()..restore(jsonEncode({'v': 1, 'attempts': [poisoned]}));
    expect(restored.records, isEmpty);
  });
  test('native failure chains retain actionable categories without raw messages', () {
    final failures = {
      'Failed to connect: DNS resolution failed: nodename nor servname provided': 'dns',
      'Failed to connect to rendezvous server: Connection refused (os error 61)': 'refused',
      'Failed to connect: Network is unreachable (os error 51)': 'unreachable',
      'Failed to connect via relay server: Connection reset by peer': 'reset',
      'Failed to connect: Permission denied (os error 13)': 'permission',
      'Failed to secure tcp: decryption error': 'handshake',
      'Failed to connect via relay server: deadline has elapsed': 'timeout',
      'Failed to connect via relay server': 'relay',
      'Failed to connect via rendezvous server': 'signaling',
      'Key overuse': 'serviceRejected',
      'Access to mobile devices is restricted in your country.': 'serviceRejected',
      'other punch hole failure': 'protocol',
      'WebSocket connection failed (HTTP error: 301 Moved Permanently). The server may not support WebSocket.': 'protocol',
      'WebSocket error: HTTP error: 404 Not Found': 'protocol',
      'WebSocket error: HTTP error: 403 Forbidden': 'serviceRejected',
      'TCP fallback failed after WebSocket upgrade rejection: HTTP error: 301: Connection refused': 'refused',
      'Remote desktop is offline': 'offline',
      'Key mismatch': 'keyMismatch',
      'Rejected by the remote user': 'rejected',
    };
    for (final entry in failures.entries) {
      expect(classifyConnectionError(entry.key).name, entry.value, reason: entry.key);
    }
  });
  test('service rejection is retained without the server message or peer details', () {
    final store = create();
    final attempt = store.begin();
    store.advance(attempt, DiagnosticPhase.peerLookup);
    store.finish(attempt, DiagnosticOutcome.failure,
        error: classifyConnectionError(
            'Access to mobile devices is restricted in your country. 123456789'));
    expect(store.records.single['error'], 'serviceRejected');
    expect(store.export(), isNot(contains('restricted')));
    expect(store.export(), isNot(contains('123456789')));
  });
  test('failed storage or uploads never prevent a connection from progressing', () async {
    final store = create(write: (_) async { throw StateError('disk'); },
      upload: (_) async { throw StateError('network'); });
    final attempt = store.begin();
    store.advance(attempt, DiagnosticPhase.firstFrame);
    await store.saved;
    await store.flush();
    expect(store.records.single['outcome'], 'success');
    expect(store.storageAvailable, isFalse);
  });
  test('retention and queue are bounded and disable stops new uploads', () async {
    var now = DateTime.utc(2026, 10, 2);
    var uploaded = 0;
    final store = create(now: () => now, upload: (_) async { uploaded++; return true; });
    store.setUploadEnabled(false);
    for (var i = 0; i < 105; i++) { store.begin(); }
    expect(store.records.length, 100);
    await store.flush();
    expect(uploaded, 0);
    now = now.add(const Duration(days: 8));
    store.begin();
    expect(store.records.length, 1);
    await store.saved;
  });
}
