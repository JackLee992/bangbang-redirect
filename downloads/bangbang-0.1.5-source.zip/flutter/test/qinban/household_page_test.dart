import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/household_page.dart';
import 'package:flutter_hbb/qinban/household_service.dart';
import 'package:flutter_hbb/qinban/assist_home.dart';
import 'package:flutter_hbb/qinban/assist_model.dart';
import 'assist_test.dart' show FakeController;

class HouseholdHomeController extends FakeController {
  HouseholdHomeController(this.householdService, {bool ios = false})
      : super(AssistState(role: ios ? AssistRole.helper : AssistRole.elder),
            supportsSharing: !ios);
  @override
  final HouseholdService householdService;
}

class Fixture {
  final store = FamilyStore('', (_) async {});
  FamilyIdentity get owner => store.identity!;
  final calls = <Map<String, dynamic>>[];
  final order = <String>[];
  final copied = <String>[];
  bool joined = false;
  bool removed = false;
  bool withMember = false;
  bool withDevices = false;
  int prepared = 0;
  Completer<void>? createGate;
  String? failOp;
  Map<String, dynamic> get home => {
        'familyId': 'home-one',
        'revision': 7,
        'members': [
          {
            'userId': 'user-me',
            'role': 'owner',
            'displayName': '家庭管理者',
            'joinedAt': 1
          },
          if (withMember && !removed)
            {
              'userId': 'user-other',
              'role': 'member',
              'displayName': '爸爸',
              'joinedAt': 2
            }
        ],
        'invites': []
      };

  late final service = HouseholdService(
      store: store,
      ensureRegistered: () async {
        order.add('register');
      },
      contacts: () => [HouseholdContact('paired-installation', '爸爸')],
      prepareRecovery: (scope) async {
        order.add('prepare');
        prepared++;
        await store.replaceIdentity(householdScope: scope);
        joined = false;
      },
      endpoint: Uri.parse('https://family.example/v1/household'),
      clientFactory: () => MockClient((request) async {
            final data = jsonDecode(request.body) as Map<String, dynamic>;
            calls.add(data);
            final op = data['op'];
            order.add(op);
            if (failOp == op) {
              return http.Response(
                  '{"v":1,"ok":false,"error":"revision_conflict"}', 409);
            }
            Map<String, dynamic> result = {};
            switch (op) {
              case 'household.list':
                result = {
                  'userId': joined ? 'user-me' : 'fresh-user',
                  'currentInstallationId': owner.installationId,
                  'households': joined
                      ? [
                          {
                            'familyId': 'home-one',
                            'revision': 7,
                            'role': 'owner',
                            'memberCount': 1
                          }
                        ]
                      : []
                };
              case 'household.get':
                result = {'household': home};
              case 'household.create':
                await createGate?.future;
                joined = true;
                result = {
                  'household': home,
                  'recoveryCode': 'BHR1.privateRecoveryToken'
                };
              case 'invite.confirm':
                joined = true;
                result = {
                  'household': home,
                  'recoveryCode': 'BHR1.firstJoinRecovery'
                };
              case 'member.invite':
                result = {'household': home, 'inviteCode': 'BH1.privateInvite'};
              case 'member.remove':
                removed = true;
                result = {'household': home};
              case 'recovery.redeem':
              case 'device.transfer.complete':
                joined = true;
                expect(request.headers['Authorization'],
                    'Bearer ${owner.installationId}.${owner.authSecret}');
                result = {
                  'userId': 'user-me',
                  'households': [],
                  'recoveryCode': 'BHR1.newRecoveryToken'
                };
              case 'device.transfer.begin':
                result = {
                  'transferCode': 'BHT1.transferToken',
                  'expiresAt': 1791000000000
                };
              case 'device.transfer.approve':
                result = {'approved': true, 'expiresAt': 1791000000000};
              case 'recovery.rotate':
                result = {'recoveryCode': 'BHR1.replacedRecoveryToken'};
              case 'device.list':
                result = {
                  'userId': joined ? 'user-me' : 'fresh-user',
                  'devices': [
                    {
                      'installationId': owner.installationId,
                      'status': 'active',
                      'createdAt': 1,
                      'familyCredentialRevocation': 'not_required'
                    },
                    if (withDevices)
                      {
                        'installationId': 'old-device',
                        'status': 'revoked',
                        'createdAt': 1,
                        'familyCredentialRevocation': 'pending'
                      }
                  ]
                };
            }
            return http.Response(
                jsonEncode({'v': 1, 'ok': true, ...result}), 200,
                headers: {'content-type': 'application/json; charset=utf-8'});
          }));
}

Future<void> launch(WidgetTester tester, Fixture fixture,
    {bool elder = false, double scale = 1}) async {
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
      .setMockMethodCallHandler(SystemChannels.platform, (call) async {
    if (call.method == 'Clipboard.setData') {
      fixture.copied.add(call.arguments['text']);
    }
    return null;
  });
  await tester.pumpWidget(MaterialApp(
      home: MediaQuery(
          data: MediaQueryData(textScaler: TextScaler.linear(scale)),
          child: HouseholdPage(service: fixture.service, elder: elder))));
  await tester.pump();
  expect(
      fixture.calls.map((c) => c['op']).toList(),
      fixture.joined
          ? ['household.list', 'household.get']
          : ['household.list']);
  expect(find.byKey(Key('household-busy')), findsNothing);
  await tester.pumpAndSettle();
}

Future<void> tapPage(WidgetTester tester, String key) async {
  final finder = find.byKey(Key(key));
  await tester.scrollUntilVisible(finder, 180,
      scrollable: find.byType(Scrollable).first);
  await Scrollable.ensureVisible(tester.element(finder), alignment: .5);
  await tester.pumpAndSettle();
  await tester.tap(finder);
  await tester.pumpAndSettle();
}

Future<void> finishSecret(WidgetTester tester) async {
  await tester.ensureVisible(find.byKey(Key('household-secret-saved')));
  await tester.tap(find.byKey(Key('household-secret-saved')));
  await tester.pump();
  await tester.ensureVisible(find.byKey(Key('household-secret-done')));
  await tester.tap(find.byKey(Key('household-secret-done')));
  await tester.pumpAndSettle();
}

void main() {
  tearDown(() => TestDefaultBinaryMessengerBinding
      .instance.defaultBinaryMessenger
      .setMockMethodCallHandler(SystemChannels.platform, null));

  testWidgets(
      'household entry is only in More and never changes iOS controller-only role',
      (tester) async {
    final fixture = Fixture();
    final controller = HouseholdHomeController(fixture.service, ios: true);
    await tester
        .pumpWidget(MaterialApp(home: AssistHome(controller: controller)));
    await tester.pumpAndSettle();
    expect(find.text('我的家庭'), findsNothing);
    expect(fixture.calls, isEmpty);
    await tester.tap(find.byKey(Key('more-actions')));
    await tester.pumpAndSettle();
    expect(find.byKey(Key('manage-household')), findsOneWidget);
    expect(find.byKey(Key('choose-elder')), findsNothing);
    await tester.tap(find.byKey(Key('manage-household')));
    await tester.pumpAndSettle();
    expect(find.byType(HouseholdPage), findsOneWidget);
    expect(controller.calls, isEmpty);
    await tester.pumpWidget(SizedBox());
    controller.dispose();
  });

  testWidgets(
      'one-time recovery card remains saveable on a narrow large-text display',
      (tester) async {
    await tester.binding.setSurfaceSize(Size(320, 640));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final fixture = Fixture();
    await launch(tester, fixture, scale: 1.8);
    await tapPage(tester, 'household-create');
    await tester.tap(find.widgetWithText(FilledButton, '创建'));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await finishSecret(tester);
    expect(tester.takeException(), isNull);
    expect(find.byKey(Key('household-secret')), findsNothing);
    expect(fixture.copied, isEmpty);
  });

  testWidgets('unconfigured page stops at an honest unavailable state',
      (tester) async {
    var calls = 0;
    final service = HouseholdService(
        store: FamilyStore('', (_) async {}),
        contacts: () => [],
        ensureRegistered: () async {
          calls++;
        },
        prepareRecovery: (scope) async {
          calls++;
        });
    await tester.pumpWidget(MaterialApp(home: HouseholdPage(service: service)));
    await tester.pumpAndSettle();
    expect(find.byKey(Key('household-unavailable')), findsOneWidget);
    expect(find.byKey(Key('household-busy')), findsNothing);
    expect(find.byKey(Key('household-create')), findsNothing);
    expect(calls, 0);
  });

  testWidgets(
      'create is explicit and single-flight, recovery card requires deliberate save',
      (tester) async {
    final fixture = Fixture()..createGate = Completer<void>();
    await launch(tester, fixture);
    await tapPage(tester, 'household-create');
    expect(fixture.calls.where((c) => c['op'] == 'household.create'), isEmpty);
    await tester.tap(find.widgetWithText(FilledButton, '创建'));
    await tester.pump();
    expect(fixture.calls.where((c) => c['op'] == 'household.create'),
        hasLength(1));
    expect(
        tester
            .widget<OutlinedButton>(find.byKey(Key('household-create')))
            .onPressed,
        isNull);
    fixture.createGate!.complete();
    await tester.pumpAndSettle();
    expect(fixture.copied, isEmpty);
    expect(find.byKey(Key('household-secret')), findsOneWidget);
    expect(
        tester
            .widget<FilledButton>(find.byKey(Key('household-secret-done')))
            .onPressed,
        isNull);
    await tester.tap(find.byKey(Key('household-secret-copy')));
    await tester.pump();
    expect(fixture.copied, ['BHR1.privateRecoveryToken']);
    await finishSecret(tester);
    expect(find.byKey(Key('household-secret')), findsNothing);
    expect(find.text('家庭管理者（我）'), findsOneWidget);
  });

  testWidgets(
      'pasted invitation needs confirmation and never prepares or connects',
      (tester) async {
    final fixture = Fixture();
    await launch(tester, fixture, elder: true);
    await tapPage(tester, 'household-join');
    await tester.enterText(
        find.byKey(Key('household-code-input')), 'BH1.privateInvite');
    await tester.pump();
    expect(fixture.calls.map((c) => c['op']), ['household.list']);
    await tester.tap(find.byKey(Key('household-code-confirm')));
    await tester.pumpAndSettle();
    expect(find.byKey(Key('household-code-input')), findsNothing);
    expect(
        fixture.calls
            .singleWhere((c) => c['op'] == 'invite.confirm')['confirmed'],
        true);
    expect(fixture.prepared, 0);
    expect(fixture.copied, isEmpty);
    expect(find.byKey(Key('household-secret')), findsNothing);
    expect(find.text('已加入家庭'), findsOneWidget);
    expect(
        fixture.calls.every((c) => [
              'household.list',
              'household.get',
              'invite.confirm'
            ].contains(c['op'])),
        true);
  });

  testWidgets(
      'new-device recovery changes credentials only after explicit confirmation',
      (tester) async {
    final fixture = Fixture();
    await launch(tester, fixture);
    await tapPage(tester, 'household-recover');
    await tester.enterText(
        find.byKey(Key('household-code-input')), 'BHR1.oldRecovery');
    expect(fixture.prepared, 0);
    expect(find.textContaining('清除本机原有家人配对'), findsOneWidget);
    await tester.tap(find.byKey(Key('household-code-confirm')));
    await tester.pumpAndSettle();
    expect(fixture.prepared, 1);
    expect(fixture.order.indexOf('prepare'),
        lessThan(fixture.order.indexOf('recovery.redeem')));
    expect(fixture.copied, isEmpty);
    await finishSecret(tester);
    expect(find.text('家庭已找回，请重新与家人配对。'), findsOneWidget);
    expect(fixture.calls.map((c) => c['op']), [
      'household.list',
      'household.list',
      'recovery.redeem',
      'household.list',
      'household.get'
    ]);
  });

  testWidgets('reopening a committed recovery offers a replacement card before clearing pending', (tester) async {
    final fixture = Fixture();
    await fixture.service.prepareNewDevice();
    await fixture.service.resumeRecovery();
    fixture.joined = true;
    fixture.calls.clear();
    await tester.pumpWidget(MaterialApp(home: HouseholdPage(service: fixture.service)));
    await tester.pumpAndSettle();
    expect(find.text('保存恢复卡'), findsOneWidget);
    expect(find.text('BHR1.replacedRecoveryToken'), findsOneWidget);
    expect(fixture.service.recoveryPending, isTrue);
    expect(fixture.prepared, 1);
    expect(fixture.calls.map((item) => item['op']),
        ['household.list', 'device.list', 'recovery.rotate']);
    await finishSecret(tester);
    expect(fixture.service.recoveryPending, isFalse);
    expect(find.text('家庭已找回，请重新与家人配对。'), findsOneWidget);
    expect(find.text('家庭管理者（我）'), findsOneWidget);
  });

  for (final flow in ['recovery', 'transfer']) {
    testWidgets('$flow reset clears old household and devices when API fails', (tester) async {
      final fixture = Fixture()..joined = true..withMember = true..withDevices = true;
      await launch(tester, fixture);
      await tapPage(tester, 'household-devices');
      expect(find.text('爸爸'), findsOneWidget);
      expect(find.byKey(Key('household-device-1')), findsOneWidget);
      fixture.failOp = 'household.list';
      if (flow == 'recovery') {
        await tapPage(tester, 'household-recover');
        await tester.enterText(find.byKey(Key('household-code-input')), 'BHR1.savedCard');
        await tester.tap(find.byKey(Key('household-code-confirm')));
      } else {
        await tapPage(tester, 'household-transfer-begin');
        await tester.tap(find.widgetWithText(FilledButton, '开始换机'));
      }
      await tester.pumpAndSettle();
      expect(fixture.prepared, 1);
      expect(find.text('爸爸'), findsNothing);
      expect(find.text('家庭管理者（我）'), findsNothing);
      expect(find.byKey(Key('household-invite-home-one')), findsNothing);
      expect(find.byKey(Key('household-device-1')), findsNothing);
      expect(find.text('本机 · 有效'), findsNothing);
      expect(find.byKey(Key('household-error')), findsOneWidget);
      expect(fixture.service.recoveryPending, isTrue);
    });
  }

  testWidgets(
      'old-device approval preserves identity; new-device completes only on tap',
      (tester) async {
    final fixture = Fixture();
    await launch(tester, fixture);
    await tapPage(tester, 'household-transfer-approve');
    await tester.enterText(
        find.byKey(Key('household-code-input')), 'BHT1.transferToken');
    await tester.tap(find.byKey(Key('household-code-confirm')));
    await tester.pumpAndSettle();
    expect(fixture.prepared, 0);
    await tapPage(tester, 'household-transfer-begin');
    await tester.tap(find.widgetWithText(FilledButton, '开始换机'));
    await tester.pumpAndSettle();
    expect(fixture.prepared, 1);
    expect(fixture.calls.where((c) => c['op'] == 'device.transfer.complete'),
        isEmpty);
    expect(fixture.copied, isEmpty);
    await tapPage(tester, 'household-transfer-complete');
    await finishSecret(tester);
    expect(fixture.prepared, 1);
    expect(fixture.calls.where((c) => c['op'] == 'device.transfer.complete'),
        hasLength(1));
  });

  testWidgets(
      'invitations select a paired device, errors retain safe refresh action',
      (tester) async {
    final fixture = Fixture()
      ..joined = true
      ..withMember = true;
    await launch(tester, fixture);
    await tapPage(tester, 'household-invite-home-one');
    await tester.tap(find.widgetWithText(SimpleDialogOption, '爸爸'));
    await tester.pumpAndSettle();
    final call = fixture.calls.singleWhere((c) => c['op'] == 'member.invite');
    expect(call['targetInstallationId'], 'paired-installation');
    expect(call['expectedRevision'], 7);
    expect(fixture.copied, isEmpty);
    await tester.tap(find.byKey(Key('household-secret-done')));
    await tester.pumpAndSettle();
    fixture.failOp = 'member.remove';
    await tapPage(tester, 'household-remove-user-other');
    await tester.tap(find.widgetWithText(FilledButton, '确认'));
    await tester.pumpAndSettle();
    expect(find.text('家庭成员已变化，请刷新后再操作。'), findsOneWidget);
    expect(find.text('爸爸'), findsOneWidget);
    expect(
        tester
            .widget<OutlinedButton>(find.byKey(Key('household-refresh')))
            .onPressed,
        isNotNull);
  });

  testWidgets(
      'device list distinguishes pending revocation and cannot revoke current phone',
      (tester) async {
    final fixture = Fixture()..withDevices = true;
    await launch(tester, fixture);
    await tapPage(tester, 'household-devices');
    await tester.scrollUntilVisible(find.text('协助凭据撤销尚未确认'), 160,
        scrollable: find.byType(Scrollable).first);
    expect(find.byKey(Key('household-device-0')), findsNothing);
    await tapPage(tester, 'household-device-1');
    await tester.tap(find.widgetWithText(FilledButton, '确认'));
    await tester.pumpAndSettle();
    expect(
        fixture.calls
            .singleWhere((c) => c['op'] == 'device.revoke')['installationId'],
        'old-device');
  });

  testWidgets(
      '320px elder page and input dialog remain usable at 180 percent text',
      (tester) async {
    await tester.binding.setSurfaceSize(Size(320, 640));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final fixture = Fixture()
      ..joined = true
      ..withMember = true;
    await launch(tester, fixture, elder: true, scale: 1.8);
    expect(tester.takeException(), isNull);
    await tapPage(tester, 'household-join');
    expect(tester.takeException(), isNull);
    await tester.enterText(
        find.byKey(Key('household-code-input')), 'BH1.privateInvite');
    await tester.ensureVisible(find.byKey(Key('household-code-confirm')));
    await tester.tap(find.byKey(Key('household-code-confirm')));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    expect(
        fixture.calls.where((c) => c['op'] == 'invite.confirm'), hasLength(1));
  });
}
