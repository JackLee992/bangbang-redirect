import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/invitation.dart';
import 'package:flutter_hbb/qinban/invitation_sharing.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('qinban/share');
  final messenger = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;

  tearDown(() {
    messenger.setMockMethodCallHandler(channel, null);
    messenger.setMockMethodCallHandler(SystemChannels.platform, null);
  });

  test('native share receives the complete invitation without writing the clipboard', () async {
    final message = QinbanInvitation('123456789').message;
    messenger.setMockMethodCallHandler(channel, (call) async {
      expect(call.method, 'share_text');
      expect(call.arguments, message);
      return true;
    });
    messenger.setMockMethodCallHandler(SystemChannels.platform, (call) async {
      fail('Successful native sharing should not change the clipboard');
    });
    expect(await shareInvitationText(message), isTrue);
  });

  test('unavailable sharing copies the whole message for WeChat or another chat', () async {
    final message = QinbanInvitation('123456789').message;
    String? copied;
    messenger.setMockMethodCallHandler(channel, (_) async => false);
    messenger.setMockMethodCallHandler(SystemChannels.platform, (call) async {
      expect(call.method, 'Clipboard.setData');
      copied = (call.arguments as Map)['text'];
      return null;
    });
    expect(await shareInvitationText(message), isFalse);
    expect(copied, message);
    expect(parseInvitationClipboard(copied!)?.deviceId, '123456789');
  });
}
