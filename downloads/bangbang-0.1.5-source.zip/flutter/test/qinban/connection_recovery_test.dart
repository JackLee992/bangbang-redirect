import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';
import 'package:flutter_hbb/qinban/connection_recovery.dart';
import 'package:flutter_hbb/qinban/qinban_theme.dart';

void main() {
  test('rejected or stale invitations never invite blind retry', () {
    for (final error in [
      DiagnosticError.offline,
      DiagnosticError.rejected,
      DiagnosticError.password,
      DiagnosticError.keyMismatch,
      DiagnosticError.capture,
    ]) {
      final plan = ConnectionRecoveryPlan(
          error: error, sawFrame: false, familyCall: false);
      expect(plan.canRetry, isFalse, reason: error.name);
    }
  });

  test('only transient invitation failures offer manual retry', () {
    for (final error in [
      DiagnosticError.network,
      DiagnosticError.timeout,
      DiagnosticError.unknown,
    ]) {
      expect(
          ConnectionRecoveryPlan(
                  error: error, sawFrame: false, familyCall: false)
              .canRetry,
          isTrue);
    }
  });

  test('a service policy rejection does not suggest blind retry or imply bad connectivity', () {
    final plan = ConnectionRecoveryPlan(
        error: DiagnosticError.serviceRejected, sawFrame: false, familyCall: false);
    expect(plan.canRetry, isFalse);
    expect(plan.title, '连接服务拒绝了请求');
    expect(plan.nextStep, contains('连接服务'));
    expect(plan.nextStep, isNot(contains('网络')));
    expect(connectionProblemText(DiagnosticError.serviceRejected), contains('拒绝'));
  });

  test('ended saved-family calls cannot reuse their released request', () {
    for (final error in DiagnosticError.values) {
      expect(
          ConnectionRecoveryPlan(
                  error: error, sawFrame: false, familyCall: true)
              .canRetry,
          isFalse);
    }
    final plan = ConnectionRecoveryPlan(
        error: DiagnosticError.network, sawFrame: false, familyCall: true);
    expect(plan.nextStep, contains('重新呼叫'));
  });

  test('a closed session stays closed regardless of old invitation details',
      () {
    for (final familyCall in [true, false]) {
      final plan = ConnectionRecoveryPlan(
          error: DiagnosticError.password,
          sawFrame: true,
          familyCall: familyCall);
      expect(plan.canRetry, isFalse);
      expect(plan.title, '协助已结束');
      expect(plan.nextStep, isNot(contains('复制')));
    }
  });

  testWidgets('next action stays readable at large text on a narrow screen',
      (tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final plan = ConnectionRecoveryPlan(
        error: DiagnosticError.timeout, sawFrame: false, familyCall: true);
    await tester.pumpWidget(MaterialApp(
        theme: qinbanTheme(Brightness.light),
        home: MediaQuery(
            data: const MediaQueryData(textScaler: TextScaler.linear(2)),
            child: Scaffold(
                body: AlertDialog(
                    scrollable: true,
                    title: Text(plan.title),
                    content: ConnectionRecoveryContent(plan: plan),
                    actions: [
                  TextButton(onPressed: () {}, child: const Text('返回'))
                ])))));
    expect(find.text(plan.title), findsOneWidget);
    expect(find.text(plan.nextStep), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
