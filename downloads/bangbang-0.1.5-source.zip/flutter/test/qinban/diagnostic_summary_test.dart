import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';

void main() {
  var now = DateTime.utc(2026, 10, 2, 12);
  var sequence = 0;
  setUp(() {
    now = DateTime.utc(2026, 10, 2, 12);
    sequence = 0;
  });

  Map<String, dynamic> record({
    String kind = 'connection',
    String role = 'helper',
    String outcome = 'success',
    String phase = 'firstFrame',
    int elapsedMs = 1000,
    String error = 'none',
    String path = 'unknown',
    DateTime? startedAt,
  }) {
    final id = (++sequence).toString().padLeft(22, 'a');
    return {
      'v': 1,
      'attemptId': id,
      'callId': id,
      'kind': kind,
      'role': role,
      'platform': 'ios',
      'appVersion': '0.1.2',
      'build': '14',
      'startedAt': (startedAt ?? now).millisecondsSinceEpoch,
      'elapsedMs': elapsedMs,
      'phase': phase,
      'outcome': outcome,
      'error': error,
      'path': path,
      'revision': 2,
    };
  }

  ConnectionDiagnostics create(List<Map<String, dynamic>> records,
      {Future<bool> Function(Map<String, dynamic>)? upload}) {
    return ConnectionDiagnostics(
      write: (_) async {},
      platform: 'ios',
      appVersion: '0.1.2',
      build: '14',
      now: () => now,
      upload: upload,
    )..restore(jsonEncode({'v': 1, 'attempts': records}));
  }

  test('denominator includes only decided helper connections', () {
    final store = create([
      record(path: 'direct'),
      record(
          outcome: 'failure',
          phase: 'contacting',
          error: 'timeout',
          path: 'relay'),
      record(outcome: 'cancelled', phase: 'waitingApproval'),
      record(outcome: 'interrupted', phase: 'authorized'),
      record(
          kind: 'preparation',
          role: 'elder',
          outcome: 'ready',
          phase: 'serviceReady'),
      record(kind: 'call'),
      record(role: 'elder'),
    ]);
    store.begin();
    final summary = store.summary;
    expect(summary.total, 5);
    expect(summary.decided, 2);
    expect(summary.successRate, .5);
    expect(summary.success, 1);
    expect(summary.failure, 1);
    expect(summary.cancelled, 1);
    expect(summary.interrupted, 1);
    expect(summary.pending, 1);
    expect(summary.byFinalPhase['contacting']!.failure, 1);
    expect(summary.byFinalPhase['starting']!.pending, 1);
    expect(summary.byFinalPhase.containsKey('ringing'), isFalse);
    expect(summary.byPath['direct']!.success, 1);
    expect(summary.byPath['relay']!.failure, 1);
    expect(summary.failuresByError, {'timeout': 1});
  });

  test(
      'first-frame latency uses successful samples and nearest-rank percentiles',
      () {
    final summary = create([
      for (final ms in [1200, 100, 400, 200, 600000]) record(elapsedMs: ms),
      record(
          outcome: 'failure',
          phase: 'authorized',
          elapsedMs: 10000,
          error: 'network'),
    ]).summary;
    expect(summary.success, 5);
    expect(summary.firstFrame.sampleCount, 4);
    expect(summary.firstFrame.cappedCount, 1);
    expect(summary.firstFrame.meanMs, 475);
    expect(summary.firstFrame.p50Ms, 200);
    expect(summary.firstFrame.p95Ms, 1200);
    expect(summary.firstFrame.maxMs, 1200);
  });

  test('empty and censored samples never become a zero success rate or latency',
      () {
    final empty = create([]).summary;
    expect(empty.total, 0);
    expect(empty.successRate, isNull);
    expect(empty.firstFrame.p50Ms, isNull);
    final censored = create([record(elapsedMs: 600000)]).summary;
    expect(censored.firstFrame.sampleCount, 0);
    expect(censored.firstFrame.cappedCount, 1);
    expect(censored.firstFrame.meanMs, isNull);
  });

  test('idle summaries exclude expired and future records at read time', () {
    final store = create([
      record(startedAt: now.subtract(const Duration(days: 7))),
      record(startedAt: now.add(const Duration(seconds: 1))),
    ]);
    expect(store.summary.total, 1);
    now = now.add(const Duration(days: 8));
    expect(store.records.length, 2);
    expect(store.summary.total, 0);
    expect(store.summary.firstFrame.sampleCount, 0);
  });

  test('duplicate records are counted once using the latest revision', () {
    final latest = record();
    final old = {
      ...latest,
      'outcome': 'failure',
      'phase': 'contacting',
      'revision': 1
    };
    for (final records in [
      [old, latest, latest],
      [latest, old]
    ]) {
      final summary = create(records).summary;
      expect(summary.total, 1);
      expect(summary.success, 1);
      expect(summary.failure, 0);
    }
  });

  test(
      'summary export has no record identifiers or timestamps and is immutable',
      () {
    final data = record(error: 'none');
    final summary = create([data]).summary;
    final raw = jsonEncode(summary.toJson());
    expect(raw, isNot(contains(data['attemptId'] as String)));
    expect(raw, isNot(contains('attemptId')));
    expect(raw, isNot(contains('callId')));
    expect(raw, isNot(contains('startedAt')));
    expect(() => summary.byFinalPhase.clear(), throwsUnsupportedError);
    expect(() => summary.failuresByError.clear(), throwsUnsupportedError);
  });

  test(
      'adding export summary preserves v1 restoration and upload record schema',
      () async {
    final uploaded = <Map<String, dynamic>>[];
    final store = create([record()], upload: (data) async {
      uploaded.add(data);
      return true;
    });
    final exported = jsonDecode(store.export()) as Map<String, dynamic>;
    expect(exported['v'], 1);
    expect(exported['summary']['success'], 1);
    expect(parseDiagnosticRecord((exported['attempts'] as List).single),
        isNotNull);
    final restored = create([])..restore(jsonEncode(exported));
    expect(restored.summary.toJson(), store.summary.toJson());
    await store.flush();
    expect(uploaded, hasLength(1));
    expect(uploaded.single.containsKey('summary'), isFalse);
    expect(parseDiagnosticRecord(uploaded.single), isNotNull);
  });

  test(
      'late errors after first frame retain success without claiming normal hangup',
      () {
    final store = create([]);
    final attempt = store.begin();
    store.advance(attempt, DiagnosticPhase.firstFrame);
    store.finish(attempt, DiagnosticOutcome.failure,
        error: DiagnosticError.network);
    expect(store.summary.success, 1);
    expect(store.summary.failure, 0);
    expect(store.summary.toJson().containsKey('normalHangup'), isFalse);
  });

  test('reading or exporting a summary does not trigger configured uploads',
      () async {
    var uploaded = 0;
    final store = create([record()], upload: (_) async {
      uploaded++;
      return true;
    });
    expect(store.summary.success, 1);
    store.export();
    await Future<void>.delayed(Duration.zero);
    expect(uploaded, 0);
  });

  test(
      'malformed and identifier-bearing records cannot enter public aggregation',
      () {
    final valid = record();
    final summary = ConnectionDiagnosticSummary.fromRecords([
      valid,
      {...record(), 'peerId': 'private-device-id'},
      {...record(), 'elapsedMs': -1},
    ], now: now);
    expect(summary.total, 1);
    expect(jsonEncode(summary.toJson()), isNot(contains('private-device-id')));
  });
}
