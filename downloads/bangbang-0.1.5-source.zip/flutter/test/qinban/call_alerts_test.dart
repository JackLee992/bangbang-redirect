import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/call_alerts.dart';
import 'package:flutter_hbb/qinban/family_models.dart';

void main() {
  test('a request rings once and answering cancels the same alert', () async {
    final calls = <String>[];
    final alerts = FamilyCallAlerts(invoke: (method, args) async { calls.add(method); });
    final request = FamilyHelpRequest(requestId: 'aaaaaaaaaaaaaaaaaaaaaa', familyPeerId: '123456789',
      familyName: '家人', elderPeerId: '123456789', expiresAt: DateTime.now().add(Duration(seconds: 60)));
    alerts.update(request, FamilyRequestStatus.received, helper: true);
    alerts.update(request, FamilyRequestStatus.received, helper: true);
    alerts.update(request, FamilyRequestStatus.connecting, helper: true);
    await alerts.settled;
    expect(calls, ['show', 'dismiss']);
    alerts.dispose();
    await alerts.settled;
    expect(calls, ['show', 'dismiss']);
  });
  test('expired, elder-side and failed requests never ring', () async {
    final calls = <String>[];
    final alerts = FamilyCallAlerts(invoke: (method, args) async { calls.add(method); });
    final request = FamilyHelpRequest(requestId: 'aaaaaaaaaaaaaaaaaaaaaa', familyPeerId: '123456789',
      familyName: '家人', elderPeerId: '123456789', expiresAt: DateTime.now().subtract(Duration(seconds: 1)));
    alerts.update(request, FamilyRequestStatus.received, helper: true);
    alerts.update(request, FamilyRequestStatus.received, helper: false);
    alerts.update(request, FamilyRequestStatus.failed, helper: true);
    await alerts.settled;
    expect(calls, isEmpty);
  });
}
