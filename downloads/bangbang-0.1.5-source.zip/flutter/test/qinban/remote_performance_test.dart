import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/remote_performance.dart';

void main() {
  late DateTime clock;
  late RemotePerformanceMetrics metrics;
  late List<Map<String, dynamic>> emitted;
  late int notifications;

  void advance(int milliseconds) {
    clock = clock.add(Duration(milliseconds: milliseconds));
  }

  void frame([String session = 'session-a', int micros = 2000]) {
    metrics.delivered(session, width: 720, height: 1280, elapsedMicros: micros);
  }

  Map<String, dynamic> quality({String fps = '{"0":30}'}) => {
        'fps': fps,
        'speed': '12.50kB/s',
        'delay': '48',
        'target_bitrate': '1500',
        'codec_format': 'H264',
      };

  setUp(() {
    clock = DateTime.utc(2026, 10, 2);
    emitted = [];
    notifications = 0;
    metrics =
        RemotePerformanceMetrics(now: () => clock, onSnapshot: emitted.add)
          ..addListener(() => notifications++)
          ..start('session-a');
  });
  tearDown(() => metrics.dispose());

  test('separates native decoded FPS from image delivery with verified units',
      () {
    metrics.quality('session-a', quality());
    frame('session-a', 2000);
    advance(1000);
    metrics.quality('session-a', quality(fps: '{"0":20}'));
    frame('session-a', 4000);
    advance(4000);
    metrics.quality('session-a', quality());
    final snapshot = metrics.latest!;
    expect(snapshot['nativeDecodeFps'], 25);
    expect(snapshot['uiImageDeliveryFps'], .4);
    expect(snapshot['deliveredFrames'], 2);
    expect(snapshot['rgbaDeliveryMeanMs'], 3);
    expect(snapshot['rgbaDeliveryMaxMs'], 4);
    expect(snapshot['rgbaDeliveryP95Ms'], 4);
    expect(snapshot['receiveBytesPerSecond'], 12800);
    expect(snapshot['networkDelayMs'], 48);
    expect(snapshot['targetBitrateKbps'], 1500);
    expect(snapshot['codec'], 'h264');
    expect(snapshot['width'], 720);
    expect(snapshot['height'], 1280);
    expect(snapshot['durationMs'], 5000);
    expect(emitted, hasLength(1));
    expect(notifications, 1);
  });

  test('per-frame accounting emits only once per five seconds and on close',
      () {
    for (var i = 0; i < 200; i++) {
      frame();
      advance(20);
    }
    expect(emitted, isEmpty);
    advance(1000);
    frame();
    expect(emitted, hasLength(1));
    expect(metrics.latest!['deliveredFrames'], 200);
    advance(700);
    metrics.close('session-a');
    expect(emitted, hasLength(2));
    expect(metrics.latest!['durationMs'], 700);
    expect(metrics.latest!['deliveredFrames'], 1);
    metrics.close('session-a');
    frame();
    expect(emitted, hasLength(2));
  });

  test('a static screen records zero delivery without classifying a stall', () {
    metrics.quality('session-a', quality(fps: '{"0":0}'));
    advance(5000);
    metrics.quality('session-a', quality(fps: '{"0":0}'));
    expect(metrics.latest!['uiImageDeliveryFps'], 0);
    expect(metrics.latest!['rgbaDeliveryMeanMs'], isNull);
    expect(metrics.latest!.keys.where((k) => k.contains('stall')), isEmpty);
  });

  test('session switch clears aggregates and ignores old asynchronous events',
      () {
    frame();
    advance(5000);
    frame();
    metrics.start('session-b');
    expect(metrics.latest, isNull);
    expect((jsonDecode(metrics.export()) as Map)['windows'], isEmpty);
    metrics.quality('session-a', quality());
    frame('session-a');
    metrics.close('session-a');
    frame('session-b', 6000);
    advance(5000);
    frame('session-b');
    expect(metrics.latest!['deliveredFrames'], 1);
    expect(metrics.latest!['rgbaDeliveryMeanMs'], 6);
    expect(metrics.latest!['nativeDecodeFps'], isNull);
    expect(metrics.latest!['codec'], isNull);
  });

  test('same active session start is idempotent and late close cannot reset it',
      () {
    frame();
    metrics.start('session-a');
    advance(5000);
    frame();
    expect(metrics.latest!['deliveredFrames'], 1);
  });

  test('unknown fields, malformed metrics and raw identifiers never survive',
      () {
    metrics.quality('session-a', {
      'peerId': '123456789',
      'sessionId': 'secret-session',
      'fps': '{"0":"NaN"}',
      'delay': double.infinity,
      'target_bitrate': '-1',
      'speed': 'secret@example.com',
      'codec_format': 'h264 secret-token',
      'pixels': [1, 2, 3],
    });
    metrics.delivered('session-a', width: -1, height: 1280, elapsedMicros: 5);
    metrics.delivered('session-a',
        width: 720, height: 999999, elapsedMicros: 5);
    frame('session-a', -1);
    frame('session-a', 10000001);
    advance(5000);
    metrics.close('session-a');
    final raw = metrics.export();
    for (final forbidden in [
      '123456789',
      'secret',
      'pixels',
      'peerId',
      'sessionId',
      'NaN',
      'Infinity'
    ]) {
      expect(raw, isNot(contains(forbidden)));
    }
    expect(metrics.latest!['deliveredFrames'], 0);
    expect(metrics.latest!['nativeDecodeFps'], isNull);
    expect(metrics.latest!['networkDelayMs'], isNull);
    expect(metrics.latest!['codec'], isNull);
  });

  test('multi-display, oversized JSON and unsupported speed units are dropped',
      () {
    metrics.quality('session-a', {'fps': '{"0":30,"1":20}', 'speed': '12Mb/s'});
    metrics.quality('session-a', {'fps': '{"secret":"${'x' * 2000}"}'});
    advance(1000);
    metrics.close('session-a');
    expect(metrics.latest!['nativeDecodeFps'], isNull);
    expect(metrics.latest!['receiveBytesPerSecond'], isNull);
  });

  test(
      'delivery percentile is explicitly bounded while mean and max use all frames',
      () {
    for (var i = 1; i <= 300; i++) {
      frame('session-a', i * 1000);
    }
    advance(5000);
    metrics.close('session-a');
    expect(metrics.latest!['deliveredFrames'], 300);
    expect(metrics.latest!['latencySamples'], 128);
    expect(metrics.latest!['rgbaDeliveryMeanMs'], 150.5);
    expect(metrics.latest!['rgbaDeliveryMaxMs'], 300);
    expect(metrics.latest!['rgbaDeliveryP95Ms'], 294);
  });

  test(
      'only the most recent sixty fixed windows are retained, gaps are not invented',
      () {
    for (var i = 0; i < 70; i++) {
      frame();
      advance(5000);
    }
    metrics.close('session-a');
    var data = jsonDecode(metrics.export()) as Map;
    expect(data['windows'], hasLength(60));
    expect(data['windows'].first['windowStartMs'], 50000);
    metrics.start('session-b');
    frame('session-b');
    advance(600000);
    frame('session-b');
    data = jsonDecode(metrics.export()) as Map;
    expect(data['windows'], hasLength(1));
    expect(data['latest']['durationMs'], 5000);
  });

  test(
      'backwards wall clock cannot create negative durations or rapid publications',
      () {
    frame();
    advance(4000);
    frame();
    advance(-10000);
    frame();
    expect(emitted, isEmpty);
    advance(11000);
    frame();
    expect(emitted, hasLength(1));
    expect(metrics.latest!['durationMs'], 5000);
    expect(metrics.latest!['deliveredFrames'], 3);
  });

  test('snapshot getters and callbacks cannot mutate retained records', () {
    frame();
    advance(5000);
    frame();
    metrics.latest!['codec'] = 'secret';
    emitted.single['width'] = -1;
    expect(metrics.latest!['codec'], isNull);
    expect(metrics.latest!['width'], 720);
  });

  test(
      'strict restore derives latest from bounded valid windows and accepts no injected fields',
      () {
    frame();
    advance(5000);
    metrics.close('session-a');
    final clean = metrics.latest!;
    final raw = jsonEncode({
      'v': 1,
      'windows': [
        ...List.generate(65, (i) => {...clean, 'windowStartMs': i * 5000}),
        {...clean, 'peerId': 'secret'},
        {...clean, 'codec': 'secret'},
        {...clean, 'durationMs': -2},
        {...clean, 'nativeDecodeFps': '30'},
      ],
      'latest': {'secret': 'not-trusted'},
    });
    metrics.restore(raw);
    final restored = jsonDecode(metrics.export()) as Map;
    expect(restored['windows'], hasLength(60));
    expect(restored['windows'].first['windowStartMs'], 25000);
    expect(restored['latest']['windowStartMs'], 320000);
    expect(metrics.export(), isNot(contains('secret')));
    metrics.start('session-b');
    expect(metrics.latest, isNull);
  });

  test(
      'corrupt and unsupported restore do not replace a valid snapshot or active call',
      () {
    frame();
    advance(5000);
    metrics.close('session-a');
    final original = metrics.export();
    for (final raw in [
      'broken',
      '{"v":2,"windows":[]}',
      '{"v":1,"windows":"x"}'
    ]) {
      metrics.restore(raw);
      expect(metrics.export(), original);
    }
    metrics.start('session-b');
    frame('session-b');
    metrics.restore(original);
    expect(metrics.latest, isNull);
    advance(5000);
    metrics.close('session-b');
    expect(metrics.latest!['deliveredFrames'], 1);
  });

  test('a delayed image completion from an old session cannot alter a new call',
      () async {
    final gate = Completer<void>();
    final pendingImage = gate.future.then((_) => frame('session-a', 9000000));
    metrics.start('session-b');
    frame('session-b', 3000);
    advance(5000);
    gate.complete();
    await pendingImage;
    metrics.close('session-b');
    expect(metrics.latest!['deliveredFrames'], 1);
    expect(metrics.latest!['rgbaDeliveryMaxMs'], 3);
    expect(emitted, hasLength(1));
  });

  test('a failed snapshot sink cannot interrupt frame delivery or notification',
      () {
    final local = RemotePerformanceMetrics(
        now: () => clock,
        onSnapshot: (_) => throw StateError('disk unavailable'));
    addTearDown(local.dispose);
    var count = 0;
    local.addListener(() => count++);
    local.start('session-local');
    local.delivered('session-local',
        width: 720, height: 1280, elapsedMicros: 2000);
    advance(5000);
    expect(() => local.close('session-local'), returnsNormally);
    expect(count, 1);
    expect(local.latest!['deliveredFrames'], 1);
  });

  test('restore rejects overflowing JSON numbers and oversized documents', () {
    frame();
    advance(5000);
    metrics.close('session-a');
    final clean = metrics.export();
    metrics.restore(
        clean.replaceAll('"nativeDecodeFps":null', '"nativeDecodeFps":1e999'));
    expect(metrics.latest, isNull);
    metrics.restore(clean);
    final original = metrics.export();
    metrics.restore(' ' * 102401);
    expect(metrics.export(), original);
  });
}
