import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/family_models.dart';
import 'package:flutter_hbb/qinban/family_service.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/family_transport.dart';

String token(int bytes, int value) =>
    base64Url.encode(List.filled(bytes, value)).replaceAll('=', '');

class Backend {
  final pairs = <String, Map<String, dynamic>>{};
  final requests = <String, Map<String, dynamic>>{};
  final registered = <String, Map<String, dynamic>>{};
  DateTime now = DateTime(2026, 10, 1);
  Completer<void>? pollResponseDelay;
  Completer<void>? createDelay;
  Completer<void>? respondDelay;
  Completer<void>? respondResponseDelay;
  Completer<void>? progressResponseDelay;
  Map<String, dynamic> Function(Map<String, dynamic>)? createResponse;
  bool activeLeaseRecovery = true;
  bool failCreate = false;
  bool failCancel = false;
}

class FakeTransport implements FamilyTransport {
  FakeTransport(this.backend, this.owner);
  final Backend backend;
  final FamilyIdentity owner;
  final calls = <Map<String, dynamic>>[];
  bool paused = false;
  @override
  Future<Map<String, dynamic>> call(
      String op, Map<String, dynamic> data) async {
    if (paused) throw const FamilyNetworkException();
    calls.add({'op': op, ...data});
    if (op == 'register') {
      backend.registered[owner.installationId] = {...data};
      return {'v': 1, 'ok': true, if (backend.activeLeaseRecovery) 'activeLeaseRecovery': 1};
    } else if (op == 'pair.offer') {
      expect(data['helperInstallationId'], owner.installationId);
      expect(
          backend.registered.containsKey(data['elderInstallationId']), isTrue);
      backend.pairs
          .putIfAbsent(data['pairId'], () => {...data, 'status': 'pending'});
    } else if (op == 'pair.confirm') {
      final pair = backend.pairs[data['pairId']]!;
      if (data['capability'] != pair['capability'] ||
          data['nonce'] != pair['nonce'] ||
          owner.installationId != pair['elderInstallationId']) {
        throw const FamilyNetworkException();
      }
      pair['status'] = 'confirmed';
    } else if (op == 'poll') {
      final pairs = backend.pairs.values
          .where((p) =>
              p['elderInstallationId'] == owner.installationId ||
              p['helperInstallationId'] == owner.installationId)
          .toList();
      final pairIds = pairs.map((p) => p['pairId']).toSet();
      final requests = backend.requests.values
          .where((r) => pairIds.contains(r['pairId']))
          .toList();
      for (final request in requests) {
        final pair = backend.pairs[request['pairId']]!;
        if (request['status'] == 'queued' &&
            pair['helperInstallationId'] == owner.installationId) {
          request['status'] = 'observed';
        }
      }
      final response = {
        'ok': true,
        'v': 1,
        'pairs': pairs.map((p) => {...p}).toList(),
        'requests': requests.map((r) => {
          ...r,
          if (['queued', 'observed', 'accepted', 'active'].contains(r['status']) &&
              r['expiresAt'] <= backend.now.millisecondsSinceEpoch)
            'status': r['status'] == 'active' && r['leaseMode'] == 'native-v1' ? 'interrupted' : 'expired',
        }).toList()
      };
      if (backend.pollResponseDelay != null) await backend.pollResponseDelay!.future;
      return response;
    } else if (op == 'request.create') {
      if (backend.createDelay != null) await backend.createDelay!.future;
      if (backend.failCreate) throw const FamilyNetworkException();
      final pair = backend.pairs[data['pairId']]!;
      if (owner.installationId != pair['elderInstallationId'] ||
          pair['status'] != 'confirmed') {
        throw const FamilyNetworkException();
      }
      final request = backend.requests.putIfAbsent(
          data['requestId'],
          () => {
                ...data,
                'elderPeerId': pair['elderPeerId'],
                'helperPeerId': pair['helperPeerId'],
                'createdAt': backend.now.millisecondsSinceEpoch,
                'expiresAt': backend.now
                    .add(const Duration(seconds: 120))
                    .millisecondsSinceEpoch,
                'status': 'queued'
              });
      return {
        'ok': true,
        'v': 1,
        'request': backend.createResponse?.call({...request}) ?? {...request}
      };
    } else if (op == 'request.cancel') {
      if (backend.failCancel) throw const FamilyNetworkException();
      backend.requests[data['requestId']]?['status'] = 'cancelled';
    } else if (op == 'request.progress') {
      final request = backend.requests[data['requestId']]!;
      if (data.containsKey('leaseMode') && !backend.activeLeaseRecovery) throw const FamilyNetworkException();
      if (!['accepted', 'active'].contains(request['status'])) throw const FamilyNetworkException();
      if (request['expiresAt'] <= backend.now.millisecondsSinceEpoch &&
          !(request['status'] == 'active' && request['leaseMode'] == 'native-v1' &&
            data['leaseMode'] == 'native-v1')) throw const FamilyNetworkException();
      if (data['leaseMode'] == 'native-v1') {
        request['leaseMode'] = 'native-v1';
        request['leaseUpdatedAt'] = backend.now.millisecondsSinceEpoch;
      }
      request['status'] = 'active';
      request['connectedAt'] ??= backend.now.millisecondsSinceEpoch;
      request['expiresAt'] = backend.now.add(const Duration(seconds: 60)).millisecondsSinceEpoch;
      final response = {'v': 1, 'ok': true, 'request': {...request}};
      if (backend.progressResponseDelay != null) await backend.progressResponseDelay!.future;
      return response;
    } else if (op == 'request.end') {
      backend.requests[data['requestId']]?['status'] = data['reason'];
    } else if (op == 'request.respond') {
      if (backend.respondDelay != null) await backend.respondDelay!.future;
      final request = backend.requests[data['requestId']];
      if (request == null ||
          !['queued', 'observed'].contains(request['status'])) {
        throw const FamilyNetworkException();
      }
      request['status'] =
          data['decision'] == 'accept' ? 'accepted' : 'declined';
      final response = {
        'ok': true,
        'v': 1,
        'request': {...request}
      };
      if (backend.respondResponseDelay != null) await backend.respondResponseDelay!.future;
      return response;
    } else if (op == 'pair.forget') {
      backend.pairs[data['pairId']]?['status'] = 'revoked';
    }
    return {'ok': true, 'v': 1};
  }

  @override
  void suspend() {
    paused = true;
  }

  @override
  void resume() {
    paused = false;
  }

  @override
  void dispose() {
    paused = true;
  }
}

class Device {
  Device(this.backend, this.peerId) {
    store = FamilyStore('', (raw) async {
      if (saveDelay != null) await saveDelay!.future;
      saved = raw;
    });
    transport = FakeTransport(backend, store.identity!);
    service = FamilyService(
        store: store,
        transport: transport,
        context: () => FamilyContext(peerId, scope),
        now: () => backend.now);
  }
  final Backend backend;
  final String peerId;
  String scope = 'rustdesk-public-v1';
  String saved = '';
  Completer<void>? saveDelay;
  bool active = true;
  late final FamilyStore store;
  late final FakeTransport transport;
  late final FamilyService service;
}

class PairHarness {
  PairHarness() {
    elder = Device(backend, '123456789');
    helper = Device(backend, '987654321');
  }
  final backend = Backend();
  late final Device elder;
  late final Device helper;
  final elderFrames = <String>[];
  final helperFrames = <String>[];
  bool elderSupportsNative = true;
  bool helperSupportsNative = true;
  bool deliverNative = true;
  Completer<void>? nativeDeliveryGate;
  bool nativeFrame(String text) =>
      (jsonDecode(text.substring(familyChatPrefix.length))['type'] as String).startsWith('call.');
  void connect({bool helperEncrypted = true, bool elderApproved = true}) {
    elder.active = elderApproved;
    helper.active = true;
    elder.service.connected(FamilyChannel(
        id: 'in:1',
        peerId: helper.peerId,
        name: 'Android-Android SDK built for arm64',
        direction: FamilyDirection.incomingHelper,
        encrypted: false,
        isActive: () => elder.active,
        send: (text) async {
          elderFrames.add(text);
          if (nativeFrame(text) && nativeDeliveryGate != null) await nativeDeliveryGate!.future;
          if (!nativeFrame(text) || (deliverNative && helperSupportsNative)) helper.service.consumeChat('out:1', text);
        }));
    helper.service.connected(FamilyChannel(
        id: 'out:1',
        peerId: elder.peerId,
        name: '妈妈',
        direction: FamilyDirection.outgoingElder,
        encrypted: helperEncrypted,
        isActive: () => helper.active,
        send: (text) async {
          helperFrames.add(text);
          if (nativeFrame(text) && nativeDeliveryGate != null) await nativeDeliveryGate!.future;
          if (!nativeFrame(text) || (deliverNative && elderSupportsNative)) elder.service.consumeChat('in:1', text);
        }));
  }

  Future<void> flush() async {
    for (var i = 0; i < 15; i++) {
      await Future<void>.delayed(Duration.zero);
    }
  }

  Future<void> pair() async {
    connect();
    await flush();
    await elder.service.poll();
    await helper.service.poll();
    expect(elder.service.members.single.directReady, isTrue,
        reason:
            'pair statuses: ${backend.pairs.values.map((p) => p["status"]).toList()}, '
            'elder ops: ${elder.transport.calls.map((c) => c["op"]).toList()}, '
            'helper ops: ${helper.transport.calls.map((c) => c["op"]).toList()}, '
            'frames: ${[
          ...elderFrames,
          ...helperFrames
        ].map((f) => (jsonDecode(f.substring(familyChatPrefix.length)) as Map)["type"]).toList()}');
    expect(helper.service.members.single.directReady, isTrue);
  }

  Future<void> startCall() async {
    await pair();
    await elder.service.requestHelp(helper.peerId, () => true);
    await helper.service.poll();
    expect(await helper.service.accept(() => true), elder.peerId);
    await helper.service.firstFrame(elder.peerId, channelId: 'out:1');
    await elder.service.poll();
    await flush();
  }

  Future<void> waitForActiveLease() async {
    const timeout = Duration(seconds: 15);
    final waiting = Stopwatch()..start();
    bool synced(Device device, Map<String, dynamic> request) =>
        device.service.requestStatus == FamilyRequestStatus.active &&
        device.service.pendingRequest?.requestId == request['requestId'] &&
        device.service.pendingRequest?.expiresAt.millisecondsSinceEpoch ==
            request['expiresAt'];
    void timedOut() => fail('Both clients must receive the active lease before '
        'testing expiry: server=${backend.requests.values.single['status']}/'
        '${backend.requests.values.single['expiresAt']}, '
        'elder=${elder.service.requestStatus}/'
        '${elder.service.pendingRequest?.expiresAt.millisecondsSinceEpoch}, '
        'helper=${helper.service.requestStatus}/'
        '${helper.service.pendingRequest?.expiresAt.millisecondsSinceEpoch}');
    while (waiting.elapsed < timeout) {
      final request = backend.requests.values.single;
      if (request['status'] == 'active' && synced(elder, request) &&
          synced(helper, request)) return;
      // poll() skips a concurrent poll. A completed firstFrame and a fixed
      // number of event turns do not prove an earlier accepted snapshot has
      // finished, nor that both clients have received the active delivery lease.
      await Future.wait([
        if (!synced(elder, request)) elder.service.poll(),
        if (!synced(helper, request)) helper.service.poll(),
      ]).then<void>((_) {}).timeout(timeout - waiting.elapsed, onTimeout: timedOut);
      await Future<void>.delayed(const Duration(milliseconds: 10));
    }
    timedOut();
  }

  void dispose() {
    elder.service.dispose();
    helper.service.dispose();
  }
}

void main() {
  test('healthy native session survives a 65 second family HTTPS outage', () async {
    final h = PairHarness(); addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    await h.helper.service.accept(() => true);
    await h.helper.service.firstFrame(h.elder.peerId);
    await h.elder.service.poll();
    final id = h.helper.service.pendingRequest!.requestId;
    h.helper.transport.paused = true;
    h.elder.transport.paused = true;
    h.backend.now = h.backend.now.add(const Duration(seconds: 65));
    await h.helper.service.poll();
    await h.flush();
    await h.elder.service.poll();
    expect(h.helper.service.pendingRequest?.requestId, id);
    expect(h.elder.service.pendingRequest?.requestId, id);
    expect(h.helper.service.lastEnd, isNull);
    expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
  });

  group('native lease recovery', () {
    for (final seconds in [20, 65, 90, 3660]) {
      for (final background in [false, true]) {
        test('$seconds seconds HTTPS loss, background=$background, no more frames', () async {
          final h = PairHarness(); addTearDown(h.dispose);
          await h.startCall();
          final id = h.helper.service.pendingRequest!.requestId;
          expect(h.backend.requests[id]!['leaseMode'], 'native-v1');
          final createCount = h.elder.transport.calls.where((c) => c['op'] == 'request.create').length;
          h.helper.transport.paused = true;
          h.elder.transport.paused = true;
          if (background) {
            h.helper.service.setForeground(false);
            h.elder.service.setForeground(false);
          }
          h.backend.now = h.backend.now.add(Duration(seconds: seconds));
          if (background) {
            h.helper.service.expire();
            expect(h.helper.service.pendingRequest?.requestId, id);
            h.helper.service.setForeground(true);
            h.elder.service.setForeground(true);
            h.helper.transport.paused = true;
            h.elder.transport.paused = true;
            await h.flush();
          }
          await h.helper.service.poll();
          await h.elder.service.poll();
          expect(h.helper.service.lastEnd, isNull);
          expect(h.elder.service.lastEnd, isNull);
          h.helper.transport.paused = false;
          h.elder.transport.paused = false;
          // No second firstFrame event is supplied: a static image is healthy.
          h.backend.now = h.backend.now.add(const Duration(seconds: 30));
          await h.helper.service.poll();
          await h.elder.service.poll();
          expect(h.helper.service.pendingRequest?.requestId, id);
          expect(h.elder.service.pendingRequest?.requestId, id);
          expect(h.backend.requests[id]!['status'], 'active');
          expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
          expect(h.elder.transport.calls.where((c) => c['op'] == 'request.create').length, createCount);
          expect(h.helper.transport.calls.where((c) => c['op'] == 'request.respond'), hasLength(1));
        });
      }
    }

    test('fresh native health suppresses misleading HTTP retry copy during assistance', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.startCall();
      h.elder.service.requestError = '暂时无法更新求助状态，回到应用后可重试。';
      h.elder.transport.paused = true;
      h.backend.now = h.backend.now.add(const Duration(seconds: 11));
      await h.elder.service.poll();
      expect(h.elder.service.requestStatus, FamilyRequestStatus.active);
      expect(h.elder.service.pendingRequest, isNotNull);
      expect(h.elder.service.requestError, isNull);
    });

    test('HTTP failure without native health retains the retry explanation', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      h.elder.transport.paused = true;
      await h.elder.service.poll();
      expect(h.elder.service.requestStatus, FamilyRequestStatus.waiting);
      expect(h.elder.service.requestError, contains('暂时无法更新求助状态'));
    });

    test('the first progress waits for an asynchronous native challenge round trip', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      await h.helper.service.accept(() => true);
      h.nativeDeliveryGate = Completer<void>();
      final first = h.helper.service.firstFrame(h.elder.peerId, channelId: 'out:1');
      await h.flush();
      expect(h.helper.transport.calls.where((c) => c['op'] == 'request.progress'), isEmpty);
      h.nativeDeliveryGate!.complete();
      await first;
      expect(h.helper.transport.calls.where((c) => c['op'] == 'request.progress').single['leaseMode'], 'native-v1');
    });

    test('new clients preserve a healthy native call with an old family service', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      h.backend.activeLeaseRecovery = false;
      await h.startCall();
      final id = h.helper.service.pendingRequest!.requestId;
      expect(h.backend.requests[id]!['leaseMode'], isNull);
      h.backend.now = h.backend.now.add(const Duration(seconds: 90));
      await h.helper.service.poll();
      await h.elder.service.poll();
      expect(h.helper.service.pendingRequest?.requestId, id);
      expect(h.elder.service.pendingRequest?.requestId, id);
      expect(h.helper.transport.calls.where((c) => c['op'] == 'request.progress').every((c) => !c.containsKey('leaseMode')), isTrue);
      // Explicit termination over the native channel wins even while legacy
      // HTTP considers its delivery lease already expired.
      await h.elder.service.endCall();
      await h.flush();
      expect(h.helper.service.pendingRequest, isNull);
      expect(h.helper.service.lastEnd?.reason, 'ended');
    });

    for (final oldSide in ['elder', 'helper']) {
      test('one old $oldSide endpoint never enables native-v1', () async {
        final h = PairHarness(); addTearDown(h.dispose);
        h.elderSupportsNative = oldSide != 'elder';
        h.helperSupportsNative = oldSide != 'helper';
        await h.startCall();
        await h.waitForActiveLease();
        expect(h.backend.requests.values.single['leaseMode'], isNull);
        h.helper.active = false;
        h.elder.active = false;
        h.backend.now = h.backend.now.add(const Duration(seconds: 61));
        h.helper.service.expire();
        h.elder.service.expire();
        expect(h.helper.service.pendingRequest, isNull);
        expect(h.elder.service.pendingRequest, isNull);
      });
    }

    test('old endpoint expiry waits for an earlier accepted poll to finish', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      h.helperSupportsNative = false;
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      expect(await h.helper.service.accept(() => true), h.elder.peerId);
      final acceptedExpiry = h.elder.service.pendingRequest!.expiresAt;
      final gate = Completer<void>();
      addTearDown(() { if (!gate.isCompleted) gate.complete(); });
      h.backend.pollResponseDelay = gate;
      final earlierPoll = h.elder.service.poll();
      await h.flush();
      h.backend.pollResponseDelay = null;
      await h.helper.service.firstFrame(h.elder.peerId, channelId: 'out:1');
      expect(h.backend.requests.values.single['status'], 'active');
      expect(h.backend.requests.values.single['leaseMode'], isNull);
      expect(h.elder.service.pendingRequest!.expiresAt, acceptedExpiry);
      expect(h.helper.service.pendingRequest!.expiresAt,
          h.backend.now.add(const Duration(seconds: 60)));
      var synced = false;
      final synchronization = h.waitForActiveLease().then((_) { synced = true; });
      await h.flush();
      expect(synced, isFalse);
      gate.complete();
      await earlierPoll;
      await synchronization;
      expect(h.backend.requests.values.single['leaseMode'], isNull);
      h.helper.active = false;
      h.elder.active = false;
      h.backend.now = h.backend.now.add(const Duration(seconds: 61));
      h.helper.service.expire();
      h.elder.service.expire();
      expect(h.helper.service.pendingRequest, isNull);
      expect(h.elder.service.pendingRequest, isNull);
    });

    test('wrong pair, request, owner, challenge and channel cannot keep a dead native call alive', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.startCall();
      h.deliverNative = false;
      h.backend.now = h.backend.now.add(const Duration(seconds: 65));
      final polling = h.helper.service.poll();
      await h.flush();
      final ping = Map<String, dynamic>.from(jsonDecode(h.helperFrames.last.substring(familyChatPrefix.length)));
      expect(ping['type'], 'call.ping');
      final pong = {...ping, 'type': 'call.pong', 'installationId': h.elder.store.identity!.installationId,
        'peerId': h.elder.peerId, 'firstFrame': false};
      for (final change in [
        {'pairId': token(16, 40)}, {'requestId': token(16, 41)},
        {'installationId': token(16, 42)}, {'challenge': token(16, 43)},
      ]) {
        h.helper.service.consumeChat('out:1', '$familyChatPrefix${jsonEncode({...pong, ...change})}');
      }
      h.helper.service.connected(FamilyChannel(id: 'out:wrong', peerId: h.elder.peerId,
        name: 'old', direction: FamilyDirection.outgoingElder, encrypted: true,
        isActive: () => true, send: (_) async {}));
      h.helper.service.consumeChat('out:wrong', '$familyChatPrefix${jsonEncode(pong)}');
      // The 5 second probe expires despite cached isActive=true and no HTTP error.
      await polling;
      expect(h.helper.service.pendingRequest, isNull);
      expect(h.helper.service.lastEnd?.reason, 'expired');
      final progressCount = h.helper.transport.calls.where((c) => c['op'] == 'request.progress').length;
      h.helper.service.consumeChat('out:1', '$familyChatPrefix${jsonEncode(pong)}');
      await h.helper.service.poll();
      expect(h.helper.service.pendingRequest, isNull);
      expect(h.helper.transport.calls.where((c) => c['op'] == 'request.progress').length, progressCount);
    });

    test('foreground resume rejects a pre-suspension pong and probes a static dead channel once', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.startCall();
      h.deliverNative = false;
      h.backend.now = h.backend.now.add(const Duration(seconds: 65));
      final polling = h.helper.service.poll();
      await h.flush();
      final oldPing = Map<String, dynamic>.from(jsonDecode(h.helperFrames.last.substring(familyChatPrefix.length)));
      h.helper.service.setForeground(false);
      await polling;
      expect(h.helper.service.pendingRequest, isNotNull);
      h.backend.now = h.backend.now.add(const Duration(seconds: 90));
      h.helper.service.expire();
      expect(h.helper.service.pendingRequest, isNotNull);
      h.helper.service.setForeground(true);
      await h.flush();
      final newPing = Map<String, dynamic>.from(jsonDecode(h.helperFrames.last.substring(familyChatPrefix.length)));
      expect(newPing['challenge'], isNot(oldPing['challenge']));
      h.helper.service.consumeChat('out:1', '$familyChatPrefix${jsonEncode({
        ...oldPing, 'type': 'call.pong', 'installationId': h.elder.store.identity!.installationId,
        'peerId': h.elder.peerId, 'firstFrame': false,
      })}');
      await Future<void>.delayed(familyNativeProbeTimeout + const Duration(milliseconds: 50));
      expect(h.helper.service.pendingRequest, isNull);
      expect(h.helper.service.lastEnd?.reason, 'expired');
    });

    test('a first frame arriving after the unanswered lease cannot enable native recovery', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      await h.helper.service.accept(() => true);
      h.backend.now = h.backend.now.add(const Duration(seconds: 121));
      await h.helper.service.firstFrame(h.elder.peerId, channelId: 'out:1');
      expect(h.helper.service.pendingRequest, isNull);
      expect(h.helper.service.lastEnd?.reason, 'expired');
      expect(h.helper.transport.calls.where((c) => c['op'] == 'request.progress'), isEmpty);
    });

    test('an interrupted history cannot create an authorized session on a restarted client', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.startCall();
      h.backend.now = h.backend.now.add(const Duration(seconds: 65));
      final store = FamilyStore(h.elder.saved, (_) async {});
      final service = FamilyService(store: store, transport: FakeTransport(h.backend, store.identity!),
        context: () => FamilyContext(h.elder.peerId, h.elder.scope), now: () => h.backend.now);
      addTearDown(service.dispose);
      await service.poll();
      expect(service.pendingRequest, isNull);
      expect(service.requestStatus, FamilyRequestStatus.idle);
    });

    test('a replacement request ends only the old call and still needs a fresh answer', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.startCall();
      final old = h.backend.requests.values.single;
      final replacement = token(16, 60);
      h.backend.requests.clear();
      h.backend.requests[replacement] = {...old, 'requestId': replacement, 'status': 'queued'}
        ..remove('leaseMode')..remove('leaseUpdatedAt')..remove('connectedAt');
      await h.helper.service.poll();
      expect(h.helper.service.lastEnd?.reason, 'superseded');
      expect(h.helper.service.pendingRequest?.requestId, replacement);
      expect(h.helper.service.requestStatus, FamilyRequestStatus.received);
      expect(h.helper.transport.calls.where((c) => c['op'] == 'request.respond'), hasLength(1));
    });

    test('a delayed poll history snapshot cannot supersede a newly started local call', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      final pair = h.backend.pairs.values.single;
      final historical = token(16, 70);
      final created = h.backend.now.subtract(const Duration(seconds: 121)).millisecondsSinceEpoch;
      h.backend.requests[historical] = {
        'requestId': historical, 'pairId': pair['pairId'],
        'elderPeerId': h.elder.peerId, 'helperPeerId': h.helper.peerId,
        'status': 'active', 'createdAt': created, 'connectedAt': created + 1,
        'expiresAt': created + 60001, 'leaseMode': 'native-v1', 'leaseUpdatedAt': created + 1,
      };
      final gate = Completer<void>();
      h.backend.pollResponseDelay = gate;
      final oldPoll = h.elder.service.poll();
      await h.flush();
      h.backend.pollResponseDelay = null;
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      final newId = h.elder.service.pendingRequest!.requestId;
      await h.helper.service.poll();
      await h.helper.service.accept(() => true);
      await h.helper.service.firstFrame(h.elder.peerId, channelId: 'out:1');
      expect(h.elder.service.requestStatus, FamilyRequestStatus.active);
      gate.complete();
      await oldPoll;
      expect(h.elder.service.pendingRequest?.requestId, newId);
      expect(h.elder.service.lastEnd, isNull);
    });

    test('stale channel close, dispose and error cannot end a newer same-peer call', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      await h.helper.service.accept(() => true);
      h.helper.service.attachOutgoingCall(h.elder.peerId, 'out:new');
      h.helper.service.disconnected('out:1');
      h.helper.service.connectionFinished(channelId: 'out:1');
      await h.helper.service.endCall(reason: 'failed', channelId: 'out:1');
      await h.helper.service.firstFrame(h.elder.peerId, channelId: 'out:1');
      expect(h.helper.service.ownsOutgoingChannel('out:new'), isTrue);
      expect(h.helper.service.requestStatus, FamilyRequestStatus.connecting);
      // The matching pre-authorization failure does clean up immediately.
      h.helper.service.disconnected('out:new');
      expect(h.helper.service.pendingRequest, isNull);
    });

    test('revocation closes a healthy native session and late pongs cannot restore it', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.startCall();
      FamilyCallEnd? ended;
      h.helper.service.onRemoteEnd = (event) => ended = event;
      h.backend.pairs.values.single['status'] = 'revoked';
      await h.helper.service.poll();
      expect(ended?.reason, 'revoked');
      expect(h.helper.service.pendingRequest, isNull);
      for (final frame in h.elderFrames.where((f) => h.nativeFrame(f))) {
        h.helper.service.consumeChat('out:1', frame);
      }
      await h.flush();
      expect(h.helper.service.pendingRequest, isNull);
    });
  });

  group('call cleanup', () {
    Future<void> activeCall(PairHarness h) async {
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      expect(await h.helper.service.accept(() => true), h.elder.peerId);
      await h.helper.service.firstFrame(h.elder.peerId);
      await h.elder.service.poll();
      expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
    }

    Future<void> answerNextCall(PairHarness h) async {
      h.helper.service.disconnected('out:1');
      h.elder.service.disconnected('in:1');
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      final id = h.elder.service.pendingRequest!.requestId;
      await h.helper.service.poll();
      expect(h.helper.service.requestStatus, FamilyRequestStatus.received);
      expect(await h.helper.service.accept(() => true), h.elder.peerId);
      expect(h.helper.transport.calls.where((call) =>
          call['op'] == 'request.respond' && call['requestId'] == id &&
          call['decision'] == 'accept'), hasLength(1));
      h.connect();
      await h.flush();
      // An authorized channel must not inherit the preceding call's frame.
      expect(h.helper.service.requestStatus, FamilyRequestStatus.connecting);
      expect(h.backend.requests[id]!['status'], 'accepted');
      await h.helper.service.firstFrame(h.elder.peerId);
      expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
      expect(h.backend.requests[id]!['status'], 'active');
    }

    test('an expired active call can be answered again after page teardown', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await activeCall(h);
      h.helper.active = false;
      h.elder.active = false;
      h.backend.now = h.backend.now.add(const Duration(seconds: 61));
      h.helper.service.expire();
      expect(h.helper.service.lastEnd?.reason, 'expired');
      h.helper.service.connectionFinished();
      h.elder.service.expire();
      await answerNextCall(h);
    });

    for (final terminal in ['ended', 'cancelled', 'expired', 'failed', 'declined']) {
      test('remote $terminal permits a new explicitly answered call', () async {
        final h = PairHarness(); addTearDown(h.dispose);
        await activeCall(h);
        h.backend.requests.values.single['status'] = terminal;
        await h.helper.service.poll();
        expect(h.helper.service.lastEnd?.reason, terminal);
        h.helper.service.connectionFinished();
        await h.elder.service.poll();
        await answerNextCall(h);
      });
    }

    for (final termination in ['scope changed', 'unconfirmed', 'forgotten']) {
      test('relation $termination clears state before a new call', () async {
        final h = PairHarness(); addTearDown(h.dispose);
        await activeCall(h);
        if (termination == 'scope changed') {
          h.helper.scope = 'another-server';
          h.helper.service.expire();
          h.helper.scope = 'rustdesk-public-v1';
          await h.elder.service.endCall();
        } else if (termination == 'unconfirmed') {
          h.backend.pairs.values.single['status'] = 'pending';
          await h.helper.service.poll();
          await h.elder.service.poll();
          h.backend.pairs.values.single['status'] = 'confirmed';
          await h.helper.service.poll();
          await h.elder.service.poll();
        } else {
          await h.helper.service.forget(h.elder.peerId);
          await h.elder.service.forget(h.helper.peerId);
          await h.pair();
        }
        expect(h.helper.service.pendingRequest, isNull);
        await answerNextCall(h);
      });
    }

    for (final response in ['success', 'failure', 'expired']) {
      test('a late $response acceptance cannot overwrite the next request', () async {
        final h = PairHarness(); addTearDown(h.dispose);
        await h.pair();
        await h.elder.service.requestHelp(h.helper.peerId, () => true);
        await h.helper.service.poll();
        final delay = Completer<void>();
        if (response == 'success') {
          h.backend.respondResponseDelay = delay;
        } else {
          h.backend.respondDelay = delay;
        }
        final accepting = h.helper.service.accept(() => true);
        await h.flush();
        if (response == 'expired') {
          h.backend.now = h.backend.now.add(const Duration(seconds: 121));
          h.helper.service.expire();
          h.elder.service.expire();
        } else {
          h.backend.requests.values.single['status'] = 'cancelled';
          await h.helper.service.poll();
          await h.elder.service.poll();
        }
        h.helper.service.connectionFinished();
        await h.elder.service.requestHelp(h.helper.peerId, () => true);
        final nextId = h.elder.service.pendingRequest!.requestId;
        await h.helper.service.poll();
        expect(h.helper.service.requestStatus, FamilyRequestStatus.received);
        // Cleanup must not release a lock still held by an in-flight response.
        expect(await h.helper.service.accept(() => true), isNull);
        expect(h.helper.transport.calls.where((call) =>
            call['op'] == 'request.respond'), hasLength(1));
        delay.complete();
        expect(await accepting, isNull);
        expect(h.helper.service.pendingRequest!.requestId, nextId);
        expect(h.helper.service.requestStatus, FamilyRequestStatus.received);
        expect(h.helper.service.requestError, isNull);
        expect(await h.helper.service.accept(() => true), h.elder.peerId);
        expect(h.backend.requests[nextId]!['status'], 'accepted');
      });
    }

    test('acceptance finishing persistence after expiry cannot connect the next request', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      h.helper.saveDelay = Completer<void>();
      final accepting = h.helper.service.accept(() => true);
      await h.flush();
      h.backend.now = h.backend.now.add(const Duration(seconds: 121));
      h.helper.service.expire();
      h.elder.service.expire();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      final nextId = h.elder.service.pendingRequest!.requestId;
      final polling = h.helper.service.poll();
      await h.flush();
      expect(h.helper.service.pendingRequest!.requestId, nextId);
      h.helper.saveDelay!.complete();
      expect(await accepting, isNull);
      await polling;
      expect(h.helper.service.requestStatus, FamilyRequestStatus.received);
      expect(await h.helper.service.accept(() => true), h.elder.peerId);
    });

    test('a late progress response cannot swallow the next calls only first frame', () async {
      final h = PairHarness(); addTearDown(h.dispose);
      await h.pair();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      await h.helper.service.accept(() => true);
      h.backend.progressResponseDelay = Completer<void>();
      final progress = h.helper.service.firstFrame(h.elder.peerId);
      await h.flush();
      await h.helper.service.endCall();
      await h.elder.service.poll();
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      await h.helper.service.poll();
      expect(await h.helper.service.accept(() => true), h.elder.peerId);
      final oldResponse = h.backend.progressResponseDelay!;
      h.backend.progressResponseDelay = null;
      h.backend.now = h.backend.now.add(const Duration(seconds: 10));
      await h.helper.service.firstFrame(h.elder.peerId);
      final nextRequest = h.helper.service.pendingRequest!;
      expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
      expect(h.helper.transport.calls.where((call) =>
          call['op'] == 'request.progress'), hasLength(2));
      oldResponse.complete();
      await progress;
      expect(h.helper.service.pendingRequest!.requestId, nextRequest.requestId);
      expect(h.helper.service.pendingRequest!.expiresAt, nextRequest.expiresAt);
      expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
    });
  });

  test('an early first frame waits for the matching authorized channel', () async {
    final h = PairHarness(); addTearDown(h.dispose);
    await h.pair();
    h.helper.service.disconnected('out:1');
    h.elder.service.disconnected('in:1');
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    await h.helper.service.accept(() => true);
    await h.helper.service.firstFrame(h.elder.peerId);
    expect(h.helper.service.requestStatus, FamilyRequestStatus.connecting);
    h.connect(); await h.flush();
    expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
  });

  test('answer to first frame to hangup stays one call on both devices', () async {
    final h = PairHarness(); addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    final id = h.elder.service.pendingRequest!.requestId;
    await h.helper.service.poll();
    await h.elder.service.poll();
    expect(h.elder.service.requestStatus, FamilyRequestStatus.ringing);
    await h.helper.service.accept(() => true);
    await h.elder.service.poll();
    expect(h.elder.service.requestStatus, FamilyRequestStatus.connecting);
    expect(h.helper.service.pendingRequest!.requestId, id);
    await h.helper.service.firstFrame(h.elder.peerId);
    await h.elder.service.poll();
    expect(h.elder.service.requestStatus, FamilyRequestStatus.active);
    expect(h.helper.service.requestStatus, FamilyRequestStatus.active);
    h.backend.now = h.backend.now.add(const Duration(seconds: 30));
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest!.requestId, id);
    FamilyCallEnd? end;
    h.elder.service.onRemoteEnd = (event) => end = event;
    await h.helper.service.endCall();
    await h.elder.service.poll();
    expect(h.elder.service.pendingRequest, isNull);
    expect(end?.requestId, id);
    expect(end?.reason, 'ended');
  });

  test('cancellation while accepted closes the matching helper call only', () async {
    final h = PairHarness(); addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    await h.helper.service.accept(() => true);
    FamilyCallEnd? end;
    h.helper.service.onRemoteEnd = (event) => end = event;
    await h.elder.service.cancelOutgoing();
    await h.helper.service.poll();
    expect(end?.peerId, h.elder.peerId);
    expect(end?.incoming, isTrue);
    expect(h.helper.service.pendingRequest, isNull);
    await h.helper.service.firstFrame(h.elder.peerId);
    expect(h.backend.requests.values.single['status'], 'cancelled');
  });

  test('custom server scope hashes normalized host and case-sensitive key', () {
    const expected = 'rustdesk-custom-v1:'
        '801d3726231a286417ce91067e49b8d1131be120c526dab1c86c68ee09487aac';
    expect(familyServerScope(' RD.Example.Com:21116 ', ' Ab+/C== '), expected);
    expect(familyServerScope('rd.example.com:21116', 'Ab+/C=='), expected);
    expect(validFamilyScope(expected), isTrue);
    expect(
        familyServerScope('rd.example.com:21117', 'Ab+/C=='), isNot(expected));
    expect(
        familyServerScope('rd.example.com:21116', 'ab+/C=='), isNot(expected));
    expect(familyServerScope(' ', 'Ab+/C=='), 'rustdesk-public-v1');
    expect(validFamilyScope(familyServerScope('x' * 250, 'key')), isTrue);
  });

  test('server scope uses the backend ASCII character and length rules', () {
    for (final scope in ['rustdesk-public-v1', 'AZaz09._:/+=-', 'x' * 200]) {
      expect(validFamilyScope(scope), isTrue);
    }
    for (final scope in [
      null,
      1,
      '',
      'x' * 201,
      'host%3A21116',
      'key%3D',
      'scope with space',
      'scope\n',
      'scope\t',
      '范围',
      'scope?'
    ]) {
      expect(validFamilyScope(scope), isFalse);
    }
  });

  test('custom server with a port and base64 public key can finish pairing',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    h.elder.scope = familyServerScope(' RD.Example.Com:21116 ', 'Ab+/C==');
    h.helper.scope = familyServerScope('rd.example.com:21116', ' Ab+/C== ');
    await h.pair();
    expect(h.backend.pairs.values.single['serverScope'], h.elder.scope);
    expect(
        h.backend.registered.values
            .every((device) => device['serverScope'] == h.elder.scope),
        isTrue);
  });

  test(
      'changing a custom server port or public key blocks the old relationship',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    h.elder.scope =
        h.helper.scope = familyServerScope('rd.example.com:21116', 'Ab+/C==');
    await h.pair();
    for (final changed in [
      familyServerScope('rd.example.com:21117', 'Ab+/C=='),
      familyServerScope('rd.example.com:21116', 'ChangedKey=='),
      familyServerScope('another.example.com:21116', 'Ab+/C==')
    ]) {
      h.elder.scope = changed;
      expect(h.elder.service.members, isEmpty);
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      expect(h.elder.service.requestStatus, FamilyRequestStatus.failed);
      expect(h.backend.requests, isEmpty);
    }
  });

  test(
      'corrupt archives cannot create trusted family; tokens are canonical random credentials',
      () async {
    for (final raw in [
      '',
      '{',
      '{"v":99}',
      '{"v":1,"owner":{},"members":[]}'
    ]) {
      final store = FamilyStore(raw, (_) async {});
      expect(store.members, isEmpty);
      expect(validFamilyToken(store.identity!.installationId, 16), isTrue);
      expect(validFamilyToken(store.identity!.authSecret, 32), isTrue);
    }
    expect(validFamilyToken('${token(16, 1)}=', 16), isFalse);
    expect(validFamilyToken(token(32, 1), 16), isFalse);
  });

  test('history is capped at twenty and names are editable, short and safe',
      () async {
    String saved = '';
    final store = FamilyStore('', (value) async {
      saved = value;
    });
    for (var i = 0; i < 25; i++) {
      store.remember('${100000 + i}', 'iPhone18,3', 'public',
          FamilyDirection.incomingHelper, DateTime.now());
    }
    expect(store.members, hasLength(20));
    expect(
        store.members.every(
            (m) => !m.name.contains('iPhone') && !m.name.contains(m.peerId)),
        isTrue);
    store.members.first.name =
        familyDisplayName('  小明\n  ', store.members.first.peerId);
    await store.save();
    final restored = FamilyStore(saved, (_) async {});
    expect(restored.members.first.name, '小明');
    expect(restored.members.every((m) => !m.confirmed), isTrue);
  });

  test('failed/unapproved incoming sessions never create a family record',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    h.connect(elderApproved: false);
    await h.flush();
    expect(h.elder.service.members, isEmpty);
    expect(h.backend.pairs, isEmpty);
  });

  test(
      'a successful but insecure outgoing session is history only, with no capability sent',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    h.connect(helperEncrypted: false);
    await h.flush();
    expect(h.helper.service.members.single.directReady, isFalse);
    expect(h.backend.pairs, isEmpty);
    expect(h.helperFrames, isEmpty);
  });

  test(
      'authorized encrypted handshake binds both IDs, scopes and separate family capability',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    expect(h.elder.service.members.single.name, '家人');
    expect(h.helper.service.members.single.name, '妈妈');
    final elderBinding = h.elder.store.members.single;
    final helperBinding = h.helper.store.members.single;
    expect(elderBinding.pairId, helperBinding.pairId);
    expect(elderBinding.capability, helperBinding.capability);
    expect(h.elderFrames.any((f) => f.contains('capability')), isFalse);
    expect(
        [...h.elderFrames, ...h.helperFrames]
            .any((f) => f.contains('authSecret')),
        isFalse);
    expect(h.elder.service.consumeChat('in:1', '普通聊天'), isFalse);
  });

  test(
      'malformed, unauthorized, ID mismatch and scope mismatch internal frames stay hidden and rejected',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    h.connect();
    await h.flush();
    final good =
        jsonDecode(h.elderFrames.first.substring(familyChatPrefix.length))
            as Map<String, dynamic>;
    final before =
        h.helper.transport.calls.where((c) => c['op'] == 'pair.offer').length;
    expect(
        h.helper.service.consumeChat('unknown', '$familyChatPrefix{}'), isTrue);
    expect(h.helper.service.consumeChat('out:1', '${familyChatPrefix}invalid'),
        isTrue);
    for (final altered in [
      {...good, 'peerId': '111111111'},
      {...good, 'serverScope': 'evil'},
      {...good, 'installationId': 'bad'},
      {...good, 'v': 2},
      {...good, 'extra': 'unexpected'},
      {...good, 'nonce': token(16, 3)},
    ]) {
      expect(
          h.helper.service
              .consumeChat('out:1', '$familyChatPrefix${jsonEncode(altered)}'),
          isTrue);
    }
    await h.flush();
    expect(
        h.helper.transport.calls.where((c) => c['op'] == 'pair.offer').length,
        before);
  });

  test('elder cannot request before actual sharing/input/capture readiness',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => false);
    expect(h.backend.requests, isEmpty);
    expect(h.elder.service.requestStatus, FamilyRequestStatus.failed);
    expect(h.elder.service.requestError, contains('屏幕共享'));
  });

  test(
      'explicit helper acceptance returns elder ID and never auto-connects or auto-authorizes',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    expect(h.backend.requests.values.single['status'], 'queued');
    expect(h.helper.service.pendingRequest, isNull);
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest!.elderPeerId, h.elder.peerId);
    expect(h.helper.service.requestStatus, FamilyRequestStatus.received);
    expect(await h.helper.service.accept(() => false), isNull);
    expect(h.backend.requests.values.single['status'], 'observed');
    expect(await h.helper.service.accept(() => true), h.elder.peerId);
    expect(h.backend.requests.values.single['status'], 'accepted');
    expect(h.helper.service.pendingRequest, isNotNull);
    expect(h.helper.service.requestStatus, FamilyRequestStatus.connecting);
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest, isNotNull);
  });

  test(
      'foreground pause cancels transport, resume polls; request expiry removes the confirmation card',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    h.helper.service.setForeground(false);
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest, isNull);
    h.helper.service.setForeground(true);
    await h.flush();
    expect(h.helper.service.pendingRequest, isNotNull);
    h.backend.now = h.backend.now.add(const Duration(seconds: 121));
    h.helper.service.expire();
    expect(h.helper.service.pendingRequest, isNull);
    expect(h.helper.service.requestError, contains('超时'));
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest, isNull);
  });

  test('stopping sharing withdraws requests and removes the helper card',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest, isNotNull);
    await h.elder.service.cancelOutgoing();
    await h.helper.service.poll();
    expect(h.helper.service.pendingRequest, isNull);
    expect(h.backend.requests.values.single['status'], 'cancelled');
  });

  test(
      'stop during a delayed create cancels even when the request is written after the first cancel',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    h.backend.createDelay = Completer<void>();
    var sharing = true;
    final sending = h.elder.service.requestHelp(h.helper.peerId, () => sharing);
    await h.flush();
    sharing = false;
    await h.elder.service.cancelOutgoing();
    h.backend.createDelay!.complete();
    await sending;
    expect(h.elder.service.pendingRequest, isNull);
    expect(h.backend.requests.values.single['status'], 'cancelled');
  });

  test('failed send retry uses the same request ID rather than extending TTL',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    h.backend.failCreate = true;
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    final requestId = h.elder.service.pendingRequest!.requestId;
    h.backend.failCreate = false;
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    expect(h.backend.requests.keys.single, requestId);
    expect(
        h.elder.transport.calls
            .where((c) => c['op'] == 'request.create')
            .map((c) => c['requestId'])
            .toSet(),
        {requestId});
  });

  test(
      'terminal pair states clear old capabilities and only a new approved session repairs pairing',
      () async {
    for (final terminal in ['revoked', 'expired', 'stale']) {
      final h = PairHarness();
      try {
        await h.pair();
        final oldPair = h.helper.store.members.single.pairId;
        h.backend.pairs[oldPair]!['status'] = terminal;
        await h.helper.service.poll();
        await h.elder.service.poll();
        expect(h.helper.store.members.single.hasCapability, isFalse);
        expect(h.elder.store.members.single.hasCapability, isFalse);
        final calls = h.helper.transport.calls
            .where((c) => c['op'] == 'pair.offer')
            .length;
        h.helper.service.setForeground(false);
        h.helper.service.setForeground(true);
        await h.flush();
        expect(
            h.helper.transport.calls
                .where((c) => c['op'] == 'pair.offer')
                .length,
            calls);
        h.elder.service.disconnected('in:1');
        h.helper.service.disconnected('out:1');
        h.connect();
        await h.flush();
        await h.elder.service.poll();
        await h.helper.service.poll();
        expect(h.helper.service.members.single.directReady, isTrue);
        expect(h.elder.service.members.single.directReady, isTrue);
        expect(h.helper.store.members.single.pairId, isNot(oldPair));
      } finally {
        h.dispose();
      }
    }
  });

  test(
      'invalid create acknowledgments never report waiting and retry keeps its request ID',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    for (final mutate in <Map<String, dynamic> Function(Map<String, dynamic>)>[
      (r) => {},
      (r) => {...r, 'requestId': token(16, 5)},
      (r) => {...r, 'pairId': token(16, 6)},
      (r) => {...r, 'elderPeerId': '111111111'},
      (r) => {...r, 'helperPeerId': '222222222'},
      (r) => {...r, 'status': 'cancelled'},
      (r) => {...r, 'expiresAt': h.backend.now.millisecondsSinceEpoch},
      (r) => {...r, 'expiresAt': r['createdAt'] + 120001},
    ]) {
      h.backend.createResponse = mutate;
      await h.elder.service.requestHelp(h.helper.peerId, () => true);
      expect(h.elder.service.requestStatus, FamilyRequestStatus.failed);
      expect(h.elder.service.requestError, isNotNull);
    }
    final requestId = h.elder.service.pendingRequest!.requestId;
    h.backend.createResponse = null;
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    expect(h.elder.service.pendingRequest!.requestId, requestId);
    expect(h.elder.service.requestStatus, FamilyRequestStatus.waiting);
  });

  test(
      'context change while creating a request withdraws the late acknowledgment',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    h.backend.createDelay = Completer<void>();
    final sending = h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.flush();
    h.elder.scope = 'another-server';
    h.backend.createDelay!.complete();
    await sending;
    expect(h.elder.service.pendingRequest, isNull);
    expect(h.elder.service.requestStatus, FamilyRequestStatus.idle);
    expect(h.backend.requests.values.single['status'], 'cancelled');
  });

  test(
      'forget during request creation cannot revive the contact or pending request',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    h.backend.createDelay = Completer<void>();
    final sending = h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.flush();
    await h.elder.service.forget(h.helper.peerId);
    h.backend.createDelay!.complete();
    await sending;
    expect(h.elder.service.members, isEmpty);
    expect(h.elder.service.pendingRequest, isNull);
    expect(h.elder.service.requestStatus, FamilyRequestStatus.idle);
  });

  test(
      'foreground pause during acceptance never starts a connection from a late acknowledgment',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    h.backend.respondDelay = Completer<void>();
    final accepting = h.helper.service.accept(() => true);
    await h.flush();
    expect(await h.helper.service.accept(() => true), isNull);
    h.helper.service.setForeground(false);
    h.backend.respondDelay!.complete();
    expect(await accepting, isNull);
    h.helper.service.setForeground(true);
    await h.flush();
    expect(h.helper.service.pendingRequest, isNull);
  });

  test(
      'revoke, rename, forget and server-scope changes cannot revive a trusted relation',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.rename(h.helper.peerId, ' 小明 ');
    expect(h.elder.service.members.single.name, '小明');
    h.elder.scope = 'another-server';
    expect(h.elder.service.members, isEmpty);
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    expect(h.backend.requests, isEmpty);
    h.elder.scope = 'rustdesk-public-v1';
    await h.elder.service.forget(h.helper.peerId);
    expect(h.elder.service.members, isEmpty);
    await h.helper.service.poll();
    expect(h.helper.service.members.single.directReady, isFalse);
    final restored = FamilyStore(h.elder.saved, (_) async {});
    expect(restored.members, isEmpty);
  });

  test(
      'accepted requests stay retractable and expire unless an actual incoming session succeeds',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    await h.helper.service.poll();
    expect(await h.helper.service.accept(() => true), h.elder.peerId);
    await h.elder.service.poll();
    expect(h.elder.service.pendingRequest, isNotNull);
    expect(h.elder.service.requestStatus, FamilyRequestStatus.connecting);
    await h.elder.service.cancelOutgoing();
    expect(h.backend.requests.values.single['status'], 'cancelled');
    expect(h.elder.service.pendingRequest, isNull);
  });

  test(
      'a failed retract is retried while foreground without resurrecting its card',
      () async {
    final h = PairHarness();
    addTearDown(h.dispose);
    await h.pair();
    await h.elder.service.requestHelp(h.helper.peerId, () => true);
    h.backend.failCancel = true;
    await h.elder.service.cancelOutgoing();
    expect(h.elder.service.pendingRequest, isNull);
    expect(h.elder.service.requestError, contains('未确认撤回'));
    h.backend.failCancel = false;
    await h.elder.service.poll();
    expect(h.backend.requests.values.single['status'], 'cancelled');
    expect(h.elder.service.pendingRequest, isNull);
  });
}
