import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/qinban/family_models.dart';
import 'package:flutter_hbb/qinban/family_service.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/family_transport.dart';

class IdentityTransport implements FamilyTransport {
  IdentityTransport(this.identity);
  final FamilyIdentity identity;
  Completer<Map<String, dynamic>>? registerReply;
  Completer<Map<String, dynamic>>? pollReply;
  bool paused = false;
  bool closed = false;
  final calls = <String>[];
  @override
  Future<Map<String, dynamic>> call(String op, Map<String, dynamic> data) async {
    if (paused || closed) throw const FamilyNetworkException();
    calls.add(op);
    if (op == 'register' && registerReply != null) return registerReply!.future;
    if (op == 'poll' && pollReply != null) return pollReply!.future;
    return {'v': 1, 'ok': true, 'pairs': [], 'requests': []};
  }
  @override
  void suspend() { paused = true; }
  @override
  void resume() { if (!closed) paused = false; }
  @override
  void dispose() { closed = true; paused = true; }
}

void remember(FamilyStore store) {
  store.remember('987654321', '家人', 'rustdesk-public-v1', FamilyDirection.outgoingElder, DateTime.now());
  store.markCompleted(familyToken(16));
}

void main() {
  test('identity replacement commits after earlier saves and exposes no partial new owner', () async {
    final firstWrite = Completer<void>();
    final writes = <Map>[];
    final store = FamilyStore('', (encoded) async {
      writes.add(jsonDecode(encoded) as Map);
      if (writes.length == 1) await firstWrite.future;
    });
    remember(store);
    final oldIdentity = store.identity!;
    final saving = store.save();
    await Future<void>.delayed(Duration.zero);
    final replacing = store.replaceIdentity(householdScope: 'https://family.example/v1/household');
    expect(store.identity, same(oldIdentity));
    expect(store.householdRecovery, isNull);
    expect(store.members, hasLength(1));
    await expectLater(store.save(), throwsStateError);
    firstWrite.complete();
    await saving;
    final replacement = await replacing;
    expect(replacement.installationId, isNot(oldIdentity.installationId));
    expect(writes.last['owner']['installationId'], replacement.installationId);
    expect(writes.last['members'], isEmpty);
    expect(writes.last['householdRecovery']['installationId'], replacement.installationId);
    expect(writes.last['householdRecovery']['scope'], 'https://family.example/v1/household');
    expect(store.householdRecovery!.installationId, replacement.installationId);
    expect(store.members, isEmpty);
    expect(store.completed, isEmpty);
    await store.save();
    expect(writes.last['owner']['installationId'], replacement.installationId);
  });

  test('failed durable identity write retains the old identity and transport', () async {
    final store = FamilyStore('', (_) async => throw StateError('controlled storage failure'));
    remember(store);
    final original = store.identity!;
    final oldTransport = IdentityTransport(original);
    final family = FamilyService(store: store, transport: oldTransport,
      freshTransport: (_) => fail('Must not construct replacement before persistence'),
      context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
    await expectLater(family.prepareHouseholdRecovery(confirmed: true, householdScope: 'https://family.example/v1/household'), throwsStateError);
    expect(store.identity, same(original));
    expect(store.members, hasLength(1));
    expect(oldTransport.closed, isFalse);
    expect(oldTransport.paused, isFalse);
    family.dispose();
  });

  test('explicit recovery changes auth, invalidates a late registration and never connects', () async {
    final store = FamilyStore('', (_) async {});
    final oldIdentity = store.identity!;
    final oldTransport = IdentityTransport(oldIdentity)..registerReply = Completer();
    late IdentityTransport fresh;
    final family = FamilyService(store: store, transport: oldTransport,
      freshTransport: (identity) => fresh = IdentityTransport(identity),
      context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
    final lateRegister = expectLater(family.ensureRegistered(), throwsA(isA<FamilyNetworkException>()));
    await Future<void>.delayed(Duration.zero);
    final identity = await family.prepareHouseholdRecovery(confirmed: true, householdScope: 'https://family.example/v1/household');
    expect(fresh.identity, same(identity));
    expect(oldTransport.closed, isTrue);
    await family.ensureRegistered();
    oldTransport.registerReply!.complete({'v': 1, 'ok': true});
    await lateRegister;
    expect(fresh.calls, ['register']);
    expect(family.pendingRequest, isNull);
    expect(family.requestStatus, FamilyRequestStatus.idle);
    family.dispose();
  });

  test('unconfirmed recovery and active native assistance cannot clear family history', () async {
    final store = FamilyStore('', (_) async {});
    final family = FamilyService(store: store, transport: IdentityTransport(store.identity!),
      context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
    await expectLater(family.prepareHouseholdRecovery(confirmed: false, householdScope: 'https://family.example/v1/household'), throwsStateError);
    family.connected(FamilyChannel(id: 'active-channel', peerId: '987654321', name: '家人',
      direction: FamilyDirection.incomingHelper, encrypted: false, isActive: () => true, send: (_) async {}));
    final identity = store.identity;
    await expectLater(family.prepareHouseholdRecovery(confirmed: true, householdScope: 'https://family.example/v1/household'), throwsStateError);
    expect(store.identity, same(identity));
    expect(store.members, hasLength(1));
    family.dispose();
  });

  test('late old poll cannot restore cleared pairings after recovery preparation', () async {
    final store = FamilyStore('', (_) async {});
    remember(store);
    final oldTransport = IdentityTransport(store.identity!)..pollReply = Completer();
    final family = FamilyService(store: store, transport: oldTransport,
      freshTransport: IdentityTransport.new,
      context: () => FamilyContext('123456789', 'rustdesk-public-v1'));
    final polling = family.poll();
    await Future<void>.delayed(Duration.zero);
    expect(oldTransport.calls, contains('poll'));
    await family.prepareHouseholdRecovery(confirmed: true, householdScope: 'https://family.example/v1/household');
    oldTransport.pollReply!.complete({'v': 1, 'ok': true, 'pairs': [], 'requests': []});
    await polling;
    expect(store.members, isEmpty);
    expect(store.completed, isEmpty);
    expect(family.pendingRequest, isNull);
    family.dispose();
  });
}
