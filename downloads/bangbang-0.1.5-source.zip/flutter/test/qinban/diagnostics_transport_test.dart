import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_hbb/qinban/connection_diagnostics.dart';
import 'package:flutter_hbb/qinban/diagnostics_transport.dart';
import 'package:flutter_hbb/qinban/family_store.dart';
import 'package:flutter_hbb/qinban/service_configuration.dart';

Map<String, dynamic> record() => {
      'v': 1,
      'attemptId': 'A' * 22,
      'callId': 'B' * 22,
      'role': 'helper',
      'kind': 'connection',
      'platform': 'ios',
      'appVersion': '0.1.2',
      'build': '18',
      'startedAt': DateTime.now().millisecondsSinceEpoch,
      'elapsedMs': 1234,
      'phase': 'firstFrame',
      'outcome': 'success',
      'error': 'none',
      'path': 'relay',
      'revision': 2,
    };

void main() {
  test(
      'structured diagnostics use the current installation bearer and a fixed nonredirecting API',
      () async {
    var identity = FamilyIdentity.create();
    int requests = 0;
    final transport = AuthenticatedDiagnosticsTransport(
      authorize: () async => identity,
      allowed: () => true,
      clientFactory: () => MockClient((request) async {
        requests++;
        expect(request.url.toString(), qinbanDiagnosticsServiceUrl);
        expect(request.followRedirects, isFalse);
        expect(request.headers['Authorization'],
            'Bearer ${identity.installationId}.${identity.authSecret}');
        expect(parseDiagnosticRecord(jsonDecode(request.body)), isNotNull);
        expect(utf8.encode(request.body).length, lessThanOrEqualTo(2048));
        return http.Response('{"v":1,"ok":true}', 202);
      }),
    );
    expect(await transport.upload(record()), isTrue);
    identity = FamilyIdentity.create();
    expect(await transport.upload(record()), isTrue);
    expect(requests, 2);
  });

  test(
      'private extra fields, untrusted hosts and missing authorization never create an HTTP client',
      () async {
    int clients = 0;
    http.Client factory() {
      clients++;
      return MockClient((_) async => http.Response('{"v":1,"ok":true}', 202));
    }
    final identity = FamilyIdentity.create();
    final normal = AuthenticatedDiagnosticsTransport(
        authorize: () async => identity,
        allowed: () => true,
        clientFactory: factory);
    expect(await normal.upload({...record(), 'peerId': '123456789'}), isFalse);
    final untrusted = AuthenticatedDiagnosticsTransport(
        authorize: () async => identity,
        allowed: () => true,
        configuredEndpoint: 'https://evil.example/v1/attempts',
        clientFactory: factory);
    expect(await untrusted.upload(record()), isFalse);
    final missing = AuthenticatedDiagnosticsTransport(
        authorize: () async => null,
        allowed: () => true,
        clientFactory: factory);
    expect(await missing.upload(record()), isFalse);
    expect(clients, 0);
  });

  test(
      'disabling diagnostic sharing cancels a request still waiting for registration',
      () async {
    bool enabled = true;
    final authorization = Completer<FamilyIdentity?>();
    final transport = AuthenticatedDiagnosticsTransport(
        authorize: () => authorization.future,
        allowed: () => enabled,
        clientFactory: () => throw StateError('must not send'));
    final uploading = transport.upload(record());
    enabled = false;
    authorization.complete(FamilyIdentity.create());
    expect(await uploading, isFalse);
    expect(await transport.upload(record()), isFalse);
  });

  test(
      'unauthorized, quota, unavailable, redirect and HTML responses retain local records',
      () async {
    final identity = FamilyIdentity.create();
    for (final response in [
      http.Response('{"v":1,"ok":false}', 401),
      http.Response('{"v":1,"ok":false}', 403),
      http.Response('{"v":1,"ok":false}', 429),
      http.Response('{"v":1,"ok":false}', 503),
      http.Response('{"v":1,"ok":true}', 302),
      http.Response('<html>login page</html>', 200),
      http.Response('{"ok":true}', 202),
      http.Response('{"v":1,"ok":false}', 202),
    ]) {
      final transport = AuthenticatedDiagnosticsTransport(
          authorize: () async => identity,
          allowed: () => true,
          clientFactory: () => MockClient((_) async => response));
      expect(await transport.upload(record()), isFalse);
    }
  });
}
