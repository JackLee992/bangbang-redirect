import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/common.dart';
import 'package:flutter_hbb/desktop/widgets/tabbar_widget.dart';
import 'package:flutter_hbb/qinban/qinban_theme.dart';

void main() {
  for (final brightness in Brightness.values) {
    for (final elderMode in [false, true]) {
      final scenario = '${brightness.name}, elderMode=$elderMode';

      testWidgets('upstream tab control builds and responds under $scenario',
          (tester) async {
        var taps = 0;
        await tester.pumpWidget(MaterialApp(
          theme: qinbanTheme(brightness, elderMode: elderMode),
          home: Scaffold(
            body: Center(
              child: ActionIcon(
                icon: Icons.fullscreen,
                onTap: () => taps++,
              ),
            ),
          ),
        ));

        expect(tester.takeException(), isNull);
        final context = tester.element(find.byType(ActionIcon));
        final upstream = brightness == Brightness.dark
            ? MyTheme.darkTheme
            : MyTheme.lightTheme;
        expect(
            MyTheme.tabbar(context), same(upstream.extension<TabbarTheme>()));
        await tester.tap(find.byType(ActionIcon));
        await tester.pump();
        expect(taps, 1);
        expect(tester.takeException(), isNull);
      });

      testWidgets('upstream shared color lookup builds under $scenario',
          (tester) async {
        ColorThemeExtension? colors;
        await tester.pumpWidget(MaterialApp(
          theme: qinbanTheme(brightness, elderMode: elderMode),
          home: Builder(builder: (context) {
            colors = MyTheme.color(context);
            return ColoredBox(color: colors!.highlight!);
          }),
        ));

        expect(tester.takeException(), isNull);
        final upstream = brightness == Brightness.dark
            ? MyTheme.darkTheme
            : MyTheme.lightTheme;
        expect(colors, same(upstream.extension<ColorThemeExtension>()));
        expect(find.byType(ColoredBox), findsOneWidget);
      });
    }
  }
}
