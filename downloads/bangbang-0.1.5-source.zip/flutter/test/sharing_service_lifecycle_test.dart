import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_hbb/models/sharing_service_lifecycle.dart';

class Harness {
  Harness() {
    lifecycle = SharingServiceLifecycle(
      requestPermission: () {
        calls.add('permission');
        final request = Completer<bool>();
        permissions.add(request);
        return request.future;
      },
      startBackend: () async {
        calls.add('start');
        if (backendStart != null) await backendStart!.future;
        return backendReady;
      },
      stopPlatform: () async {
        calls.add('stop-platform');
        if (platformStop != null) await platformStop!.future;
      },
      stopBackend: () async { calls.add('stop-backend'); },
      onChanged: () { changes++; },
    );
  }

  late final SharingServiceLifecycle lifecycle;
  final calls = <String>[];
  final permissions = <Completer<bool>>[];
  Completer<void>? backendStart;
  Completer<void>? platformStop;
  int changes = 0;
  bool backendReady = true;
}

Future<void> flush() => Future<void>.delayed(Duration.zero);

void main() {
  test('sharing is pending until consent and backend readiness both complete', () async {
    final h = Harness()..backendStart = Completer<void>();
    final start = h.lifecycle.start();
    expect(h.lifecycle.isStarting, isTrue);
    expect(h.lifecycle.isStarted, isFalse);
    h.permissions.single.complete(true);
    await flush();
    expect(h.calls, ['permission', 'start']);
    expect(h.lifecycle.isStarted, isFalse);
    h.backendStart!.complete();
    await start;
    expect(h.lifecycle.isStarted, isTrue);
    expect(h.lifecycle.isStarting, isFalse);
  });

  test('denial never starts the backend', () async {
    final h = Harness();
    final start = h.lifecycle.start();
    h.permissions.single.complete(false);
    await start;
    expect(h.calls, ['permission']);
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.lifecycle.isStarting, isFalse);
  });

  test('stop finishes without waiting for consent and ignores late approval', () async {
    final h = Harness();
    final start = h.lifecycle.start();
    await h.lifecycle.stop();
    expect(h.calls, ['permission', 'stop-platform', 'stop-backend']);
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.lifecycle.isStarting, isFalse);
    h.permissions.single.complete(true);
    await start;
    expect(h.calls, isNot(contains('start')));
    expect(h.lifecycle.isStarted, isFalse);
  });

  test('duplicate starts share one outstanding consent request', () async {
    final h = Harness();
    final first = h.lifecycle.start();
    final second = h.lifecycle.start();
    expect(identical(first, second), isTrue);
    expect(h.permissions, hasLength(1));
    h.permissions.single.complete(true);
    await first;
    await h.lifecycle.start();
    expect(h.calls, ['permission', 'start']);
  });

  test('an old result cannot affect a new request after stop', () async {
    final h = Harness();
    final old = h.lifecycle.start();
    await h.lifecycle.stop();
    final current = h.lifecycle.start();
    h.permissions.first.complete(false);
    await old;
    expect(h.lifecycle.isStarting, isTrue);
    h.permissions.last.complete(true);
    await current;
    expect(h.calls.where((call) => call == 'start'), hasLength(1));
    expect(h.lifecycle.isStarted, isTrue);
  });

  test('a new start waits for teardown while old consent remains pending', () async {
    final h = Harness()..platformStop = Completer<void>();
    final old = h.lifecycle.start();
    final stop = h.lifecycle.stop();
    final next = h.lifecycle.start();
    expect(h.permissions, hasLength(1));
    h.platformStop!.complete();
    await stop;
    await flush();
    expect(h.permissions, hasLength(2));
    h.permissions.first.complete(true);
    await old;
    expect(h.calls, isNot(contains('start')));
    h.permissions.last.complete(true);
    await next;
    expect(h.lifecycle.isStarted, isTrue);
  });

  test('stop revokes capture immediately and wins an in-flight backend start', () async {
    final h = Harness()..backendStart = Completer<void>();
    final start = h.lifecycle.start();
    h.permissions.single.complete(true);
    await flush();
    final stop = h.lifecycle.stop();
    expect(h.calls.last, 'stop-platform');
    expect(h.lifecycle.isStarted, isFalse);
    await flush();
    expect(h.calls, isNot(contains('stop-backend')));
    h.backendStart!.complete();
    await start;
    await stop;
    expect(h.calls.last, 'stop-backend');
    expect(h.lifecycle.isStarted, isFalse);
  });

  test('failed platform stop still stops the backend', () async {
    final calls = <String>[];
    final lifecycle = SharingServiceLifecycle(
      requestPermission: () async => true,
      startBackend: () async => true,
      stopPlatform: () { throw StateError('platform unavailable'); },
      stopBackend: () async { calls.add('stop-backend'); },
      onChanged: () {},
    );
    await expectLater(lifecycle.stop(), throwsStateError);
    expect(calls, ['stop-backend']);
    expect(lifecycle.isStarted, isFalse);
  });

  test('a recreated model restores the active native session without another start', () {
    final h = Harness();
    h.lifecycle.restoreActive(true);
    expect(h.lifecycle.isStarted, isTrue);
    expect(h.lifecycle.isStarting, isFalse);
    expect(h.calls, isEmpty);
    h.lifecycle.restoreActive(false);
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.calls, isEmpty);
  });

  test('a delayed active snapshot cannot restore a locally stopped session', () async {
    final h = Harness();
    h.lifecycle.restoreActive(true);
    await h.lifecycle.stop();
    h.lifecycle.restoreActive(true);
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.calls, ['stop-platform', 'stop-backend']);
  });

  test('native snapshots cannot bypass outstanding consent or a denied local start', () async {
    final h = Harness();
    final start = h.lifecycle.start();
    h.lifecycle.restoreActive(true);
    expect(h.lifecycle.isStarted, isFalse);
    h.permissions.single.complete(false);
    await start;
    h.lifecycle.restoreActive(true);
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.calls, ['permission']);
  });

  test('revocation before the native startup acknowledgement tears down the backend', () async {
    final h = Harness()..backendReady = false;
    final start = h.lifecycle.start();
    h.permissions.single.complete(true);
    await start;
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.lifecycle.isStarting, isFalse);
    expect(h.calls, ['permission', 'start', 'stop-platform', 'stop-backend']);
  });

  test('unapproved media polls do not cancel the outstanding consent dialog', () async {
    final h = Harness();
    final start = h.lifecycle.start();
    await h.lifecycle.nativeMediaStateChanged(false);
    expect(h.lifecycle.isStarting, isTrue);
    expect(h.calls, ['permission']);
    h.permissions.single.complete(true);
    await start;
    expect(h.lifecycle.isStarted, isTrue);
  });

  test('loss of approved media revokes an in-flight backend startup', () async {
    final h = Harness()..backendStart = Completer<void>();
    final start = h.lifecycle.start();
    h.permissions.single.complete(true);
    await flush();
    final stopped = h.lifecycle.nativeMediaStateChanged(false);
    expect(h.calls.last, 'stop-platform');
    expect(h.lifecycle.isStarting, isFalse);
    h.backendStart!.complete();
    await start;
    await stopped;
    expect(h.lifecycle.isStarted, isFalse);
    expect(h.calls.last, 'stop-backend');
  });
}
