# 帮帮图标

最终设计：暖橙背景、奶白色相扣的两个简洁矩形环，表现家人两端连接。前后层次、柔和接触阴影和细腻边缘高光保持小尺寸辨识度。

- `bangbang-icon-v4.png`：imagegen 内置工具生成、按用户意见增加材质层次的完整方形原图。
- `bangbang-icon-1024.png`：用于 App 图标导出的 1024×1024 不透明 PNG。
- 不预切外轮廓圆角；iOS 和 Android 系统负责图标遮罩。
- Android 26+ 使用 adaptive icon，旧系统保留完整方形位图。
- Android 自适应前景通过 `bangbang_launcher_foreground.xml` 四边内缩14%，保留原图，不预切圆角；原连接标记最远约43dp，内缩后约31dp，落在官方66dp直径安全圆内。背景层继续满幅，外轮廓由桌面遮罩处理。以后替换原图需要重新检查安全区，不能默认沿用这一比例。
- iOS 导出各尺寸 AppIcon，所有图片不透明。

参考：https://developer.apple.com/design/human-interface-guidelines/app-icons

最终编辑提示词见 `prompt.txt`。蓝色手机爱心与扁平橙色草案未采用。
