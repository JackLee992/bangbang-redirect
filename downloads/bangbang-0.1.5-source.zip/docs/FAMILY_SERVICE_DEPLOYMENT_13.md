# 家人呼叫服务发布记录 13

2026-10-02：现有 Netlify 站点已发布支持 `request.progress` / `request.end` 的家人呼叫服务。正式发布及生产 HTTP 验证完成；首页和所有公开下载仍为原有 0.1.1，不代表 0.1.2(13) 安装包或 iOS TestFlight 已发布。

## 发布对象与来源

| 项目 | 结果 |
| --- | --- |
| 正式站点 | <https://bangbang-jacklee992.netlify.app/> |
| Site ID | `3e8053ab-2226-4cd7-a6ec-37bb1cb9e768` |
| 新生产 Deploy ID | `6abf6974be775941f0aaaf81` |
| API 核验状态 | `ready`，且已成为该站点 `published_deploy` |
| 发布时间 | 2026-10-02 16:21:10（Asia/Shanghai） |
| 发布前生产版本 / 回滚候选 | `6abeee9cb4651b458ae0c918`，本轮通过 API 实时确认 |
| 家人服务源码快照 | `37da688df38e83831a1008b9c0f0f054d2018c6d` |
| 保留公开应用版本 | 0.1.1，原 Android APK 与对应源码 ZIP |

[新发布详情](https://app.netlify.com/projects/bangbang-jacklee992/deploys/6abf6974be775941f0aaaf81)。本次只上传独立允许清单目录中的静态 `public/` 和已构建的 `family` 函数，没有上传工作仓库、debug APK、家庭成员/权益模块、测试身份或本地环境文件。

部署前已核对允许清单内 28 个文件的 SHA-256；其中两份服务源码与 Git 快照逐字节一致。关键输入：

| 输入 | SHA-256 |
| --- | --- |
| `site/server/family-service.mjs` | `9d8607895549bb31e5ee89ca5afbd184971164627cb57d1a06b08ad213680059` |
| `site/netlify/functions/family.mjs` | `ec8772b62c016ae921808c89d03e830ddd07d60a30822b936a91b5bdc80a5ad3` |
| 已构建 `family.zip` | `379de3b4f403941d469628d432c027caef914577d5638ffe25f76d849b0c1e2b` |

离线生产构建已准备完成，正式步骤使用既有登录的 Netlify CLI，对原 site 执行 `deploy --prod --no-build --dir public --functions .netlify/functions`。没有更改全站访问保护；草稿部署曾因保护返回 HTML 401，该结果未作为函数测试成功。本记录以下结果均来自正式站点真实 HTTPS / Netlify Blobs。

## 生产验证结果

只创建一组随机专用 QA 身份和关系，不读取或修改既有家庭。共 27 项接口响应检查通过，另包含状态、租期、身份角色及 `no-store` 等断言：

| 阶段 | 数量 | 完成时间（北京时间） | 已验证结果 |
| --- | ---: | --- | --- |
| 旧生产基线 `init` | 12 | 16:19:53 | 注册、错误凭据拒绝、邀请/确认、角色限制、发起/观察/接听/取消 |
| 新发布 `verify` | 2 | 16:21:23 | 双方仍能读到发布前的 confirmed 配对及 cancelled 请求；跨发布存储保留 |
| 新生命周期 `lifecycle` | 10 | 16:22:33 | 新请求被接听，控制方 progress 进入 active；错误角色被拒；双方可见 active；再次 progress 延长 expiresAt 且 connectedAt 不变；结束可见；迟到 end 不覆写终态，迟到 progress 返回 `request_ended` |
| 清理 `cleanup` | 3 | 16:22:55 | QA 关系已撤销，另一端读到 revoked，再次发起返回 `pair_revoked` |

清理使用正常 `pair.forget` 接口，服务端仍可保留已撤销测试记录；不是声称物理删除全部 QA 数据。测试私有身份文件权限为 `0600`，仅存在被 Git 忽略的本地发布目录，未提交、未上传或记录到本文。

本次证明 API 协议与持久化路径工作正常，不代表原生采屏、视频中继、iPhone→Android 真机连接成功率、弱网体验、后台来电通知或长时租约已经验收。续租测试检查实际到期时间延长，没有将短时接口测试当作一小时会话耐久结果。仍需用最终候选包补真实双机、旧新客户端组合及跨网络验收。

## 公开页面与下载保持一致

发布前后分别从正式域名获取内容并计算 SHA-256。以下 6 项全部字节一致，且除 Netlify 处理后的 HTML 外均严格匹配本地允许清单：

| 线上资源 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `/index.html` | 3783 | `b38010ab101caafcaf610600e4963c63eaba488947c1275de858a6f08c09fd42` |
| `/release.json` | 688 | `3f11b99aee7559af25842d5da6401fe4519908305291823c9aa884802ff9a165` |
| `/downloads/build-info.json` | 1457 | `2d6da03e9029c2f6d584b019c1a0f404617e4f23decaba9898d981d5f7ad850c` |
| `/downloads/SHA256SUMS` | 263 | `6a575b0cf5469e3b693a147929f49a675daafcbf404973a5049d6a5e9b8e15f9` |
| `/downloads/bangbang-0.1.1-arm.apk` | 49333720 | `23131085a2529fc54ed94c3ca8e09c60410579496b65f650b6a3264b70be5828` |
| `/downloads/bangbang-0.1.1-source.zip` | 13356207 | `56a1aee8682e62342c1852d01e98f1120dd936983a3acbae8d92ffbffc938051` |

首页本地原始文件 hash 与线上不同，差异已逐项检查为 Netlify 注入托管注释及将 `/help.html` 链接处理为 `/help`；没有以此忽略页面检查，而是将发布前线上 HTML 原始响应作为发布后基准。`release.json` 保持 `version: 0.1.1`、iOS `pending` 和空 App Store URL。

## 证据与回滚

本地忽略目录 `artifacts/netlify-call-service-13/` 保留 `source-manifest.json`、`production-deploy.json`、`published-before.json`、`published-after.json`、`assets-before.json`、`assets-after.json`、`qa-production/*-result.json` 及汇总 `deployment-qa-summary.json`。这些本地产物及凭据均不进入 Git；本次只提交这份脱敏说明。

若后续发现该发布引入的服务回归，应停止候选分发，定位后在原站点恢复已记录的旧 Deploy。Netlify `restoreSiteDeploy` 的参数为 `site_id` 与 `deploy_id`；本轮只核对其 API 契约，**没有执行回滚**。恢复后需再次核验 published ID、公开资产、旧协议配对，并记录新版 progress/end 将重新不可用的影响。

代码部署回滚不会回滚或删除生产 Blobs 业务数据。禁止为回滚方便而清空存储或切换到空 namespace；本轮已实际证明同一生产 namespace 的配对可以跨发布保留。

## 增量发布：可访问的隐私说明

2026-10-02 16:29:25（Asia/Shanghai），在同一站点新增独立的隐私说明页面，供 iOS 测试与审核引用。当前生产 Deploy 为 `6abf6b6368465d21732bebf9`，API 已确认 `ready` 且成为 `published_deploy`；即时回滚候选为本记录上次家人服务发布 `6abf6974be775941f0aaaf81`。[本次发布详情](https://app.netlify.com/projects/bangbang-jacklee992/deploys/6abf6b6368465d21732bebf9)。

本次唯一新增的静态文件是 `public/privacy.html`，来源为 `6fd45df146b2cffdd1b08abc0c73d3ae91d0b618` 的 `site/public/privacy.html`，源码 SHA-256 为 `7ecc998e4b36d9ba62d6ee9019cc60d2cd7205d6f6dabbe31a7356e552da6212`。原允许清单的 28 个文件和 `family.zip` 逐字节保持，服务源码仍为 `37da688`；没有重新生成首页、更新下载或添加 TestFlight 按钮。

已从正式域名验证以下结果：

- [隐私说明](https://bangbang-jacklee992.netlify.app/privacy) 与 [privacy.html](https://bangbang-jacklee992.netlify.app/privacy.html) 均返回 HTTP 200 / HTML，内容与批准源码一致，仅有 Netlify 托管注释及空白处理；两份响应均为 3802 字节，SHA-256 为 `70d9fb917a6c3c2413785eff339cc42265232d8a7ae73cd24413c07c9da48ee9`。
- 首页、`release.json`、构建元数据、校验和、0.1.1 APK 与源码 ZIP 共 6 项在本次发布前后完全相同，hash 与上表一致。iOS 发布状态仍为 `pending`。
- 发布前后分别使用先前专用 QA 双方身份查询，共 4 次响应通过；原关系始终为 `revoked`。没有创建新关系、重新发送邀请或恢复已撤销关系。

页面准确区分本机诊断保留期与服务端防重放记录，并披露本机性能记录不自动上传。上线隐私 URL 不代表 Apple 已通过审核或 TestFlight 已可公开安装。

增量证据保存在原忽略目录下的 `privacy-update/`：发布前后部署元数据、输入清单、六资源校验、隐私页面响应、已撤销关系检查和 `summary.json`。继续遵循本记录的凭据、业务数据与回滚边界；若只回滚本次页面新增到即时候选，家人服务的 progress/end 仍保留。

## 增量发布：按用户要求移除可见源码入口

在上述 API 和隐私页面发布完成后，用户明确要求网站不再展示源码入口。2026-10-02 16:33:49（Asia/Shanghai）发布了独立功能分支 `feat/testflight-download-link` 的页面简化，源码提交为 `7f0a593663cb3e06701bcf96fe840a8813f1d4be`。当前生产 Deploy 为 `6abf6c6a93e2cd3c249b7376`，已核验 `ready` 和 `published_deploy`；即时回滚候选为 `6abf6b6368465d21732bebf9`。[本次发布详情](https://app.netlify.com/projects/bangbang-jacklee992/deploys/6abf6c6a93e2cd3c249b7376)。

仅替换允许清单中的 `index.html`、`help.html`、`privacy.html`：前两页移除源码下载链接，隐私页移除仓库源码入口并将“联系与源码”改为“联系”。项目反馈联系方式保留，其余隐私披露未变。其余 26 个清单文件和 `family.zip` 保持原字节，源码 ZIP、AGPL 许可证及其原网址仍可访问。首页本次 hash **按用户新要求发生变化**，不能与前两次“首页保持不变”的发布证据混为同一次操作。

正式站点页面响应已与本次发布前响应逐字节比较，除了上述准确移除的内容没有其他变化：

| 页面 | 字节数 | 最新 SHA-256 |
| --- | ---: | --- |
| `/index.html` | 3717 | `3c39617292d427075f52919cdf6d52d0057108eb9275ff75b9d2f699422180d8` |
| `/help.html` | 2247 | `842be2226b9b284cf355addfd1ed83d2e771c94a7a65b6427aee8d04198a2f72` |
| `/privacy.html` | 3693 | `243f159b2b5cc3f26d9ea9f3ff7662358e744ce2d73dbe35ce3257b1312667e5` |

另验证首页 `/`、`/help`、`/privacy` 均为 200 且与各 HTML 版本一致；`release.json`、构建元数据、校验和、0.1.1 APK、源码 ZIP、AGPL 许可证共 6 个资源均为 200 且 hash 未变。原 QA 双方查询仍为 `revoked`。

同一功能分支还准备了 `ios.status: testflight` 的构建支持，邀请地址仅接受官方 `https://testflight.apple.com/join/` 后接 8 位 ASCII 字母数字，不接受用户信息、端口、查询、片段、其他域名或可被 URL 规范化隐藏的额外内容；安装文案明确标注 TestFlight 公测。新增测试先失败、实现后通过，专项 8 项及全站 75 项测试通过。独立工作区初次全站测试缺少 `@netlify/blobs`，按原锁文件离线安装依赖后全套通过，没有改依赖版本。

本次实际构建和线上 `release.json` 始终保持 0.1.1 / iOS `pending`，没有设置真实 TestFlight 邀请、没有展示公测按钮，也没有把未获 Apple 审核的候选包发布为可安装版本。完整构建已验证原下载校验和；本次上线仅选取上述三份已构建 HTML，未上传独立工作区或重新打包家人函数。

本地证据位于原忽略目录的 `source-link-update/`，包含当前生产元数据、前后输入清单、三页前后响应、12 项公开资源/路由检查、QA 撤销状态以及汇总。凭据仍只保存在原 `0600` 私有 QA 文件中；本文及功能提交均不含私有身份或发布产物。
