# 帮帮技术方案

文档版本：0.2 · 审核稿\
基线日期：2026-10-02\
适用范围：当前仓库实现、未发布的呼叫候选、下一阶段需审核的扩展。\
配套：[产品需求](PRD-bangbang.md) · [审核清单](REVIEW-bangbang.md) · [完整呼叫验证](CALL_FLOW_VERIFICATION.md)

2026-10-04 补充：本文保留早期整体技术审核基线，其 Netlify/未部署等描述不代表当前服务。最新服务端架构、实现与迁移边界见 [服务端技术方案](TECHNICAL_DESIGN-bangbang-server.md)，需求与验收见 [服务端产品需求](PRD-bangbang-server.md)；最新移动发布见 [0.1.4](releases/0.1.4.md)。

## 1. 实现基线与设计原则

工作分支为 `feat/family-invites-elder-mode`，移动候选源码冻结于 `37da688`，呼叫、通知、诊断、性能和再次接听改动已经本地提交；后续家庭领域模块独立合并。对外 Android 0.1.1 对应源码为 `32a8e2402b0edfcb581ed406f2053750aed524a8`。不能把两者混为同一发布版本。

| 层次 | 当前选择 | 状态 |
| --- | --- | --- |
| 界面与业务 | Flutter 3.24.5，适老/家人角色与共用状态服务 | 已实现，候选已测试 |
| 安卓宿主 | Kotlin，MediaProjection、无障碍输入、系统分享、通知 | 原生基础已发布，新呼叫通知在候选 |
| iOS 宿主 | Swift，控制端、URL Scheme、剪贴板确认、UserNotifications | 新候选构建通过，真实协助待测 |
| 远控 | 固定 RustDesk 1.4.9 原生引擎，发现、穿透、加密连接、必要时中继 | 使用真实引擎，不自行仿造视频或控制协议 |
| 家人信令 | Netlify Functions + Blobs，HTTPS JSON，安装身份鉴权 | progress/end已在原Netlify站发布，27项真实HTTP检查通过；真机链路另验 |
| 诊断 | 应用私有本地文件；可选 Cloudflare Worker + D1 | 本地可用，云端代码未部署 |
| 自建连接服务 | Oracle/Linux VM 上 hbbs + hbbr 1.1.16 | 仅模板及本机原生服务验证，未部署云主机 |

安卓当前从校验过的官方 1.4.9 包取得**未修改的原生库**，重编 Flutter 和宿主；改动 Rust 或 FFI 时必须重建原生库。iOS 构建使用本地原生源码与 Xcode。具体依赖和构建入口见 [构建说明](QINBAN_BUILD.md)。安卓工程声明 minSdk 24、targetSdk 33，iOS原工程声明最低13.0，但本轮核实部分原生依赖实际minOS26.5；公开测试构建已隔离重建依赖并统一到iOS15.0，原生对象与签名归档核验通过，已上传Apple，外部审核/链接未完成。声明不是完整兼容性矩阵或商店可发布性证明。

设计原则：原生事件决定画面与控制状态；信令管理一次求助；通知只是送达后的呈现；诊断失败不阻止协助。保存家人不授予永久控制权限。对用户隐藏安装身份与能力凭据。当前免登录；后续账号/家庭订阅按 [专项方案](ACCOUNT_SUBSCRIPTION_PLAN.md) 推进，家庭身份不授予永久远控权。

## 2. 系统结构与数据流

```mermaid
flowchart LR
  E[安卓长辈端] <-->|原生加密视频和操作| H[安卓或 iOS 家人端]
  E <-->|设备发现和必要中继| R[RustDesk 发现与中继]
  H <-->|设备发现和必要中继| R
  E <-->|HTTPS 家人关系和求助状态| F[Netlify Functions]
  H <-->|HTTPS 家人关系和求助状态| F
  F <--> B[Netlify Blobs]
  W[Netlify 下载与邀请网页] -->|下载或编码邀请| E
  W -->|邀请或复制说明| H
  E -.可选诊断 未部署.-> D[Cloudflare Worker 与 D1]
  H -.可选诊断 未部署.-> D
  F -.未来推送 待实现.-> P[APNs 与安卓推送服务]
  P -.短期请求提醒.-> H
```

- 实线是已有架构，不代表所有候选改动已上线；虚线是尚未启用的外部能力。
- 视频、远程点击和输入通过 RustDesk 会话传输，不经过 Netlify 或统计服务。
- 目前正式客户端仍使用公共发现/中继配置；Oracle 模板不会自动改变已安装应用的连接服务。
- 网站有宣发下载页和功能性的邀请落地页。页面不承担手机视频中转，也不展示诊断后台。

### 2.1 主要代码职责

| 模块 | 责任与边界 |
| --- | --- |
| [assist_home.dart](../flutter/lib/qinban/assist_home.dart)、[qinban_theme.dart](../flutter/lib/qinban/qinban_theme.dart) | 角色页面、大小方块、邀请和来电展示；不自行决定连接成功 |
| [rustdesk_assist_controller.dart](../flutter/lib/qinban/rustdesk_assist_controller.dart) | 共享准备、原生状态与业务衔接、前后台、通知动作及停止清理 |
| [sharing_readiness.dart](../flutter/lib/qinban/sharing_readiness.dart) | 等待真实共享与在线条件；支持取消和准备超时 |
| [invitation.dart](../flutter/lib/qinban/invitation.dart)、[invitation_sharing.dart](../flutter/lib/qinban/invitation_sharing.dart) | 统一邀请编码、严格解析、收件箱去重与系统分享 |
| [family_service.dart](../flutter/lib/qinban/family_service.dart) | 配对握手、请求状态、轮询、终态和过期，不承担视频传输 |
| [family_bridge.dart](../flutter/lib/qinban/family_bridge.dart) | 将真实原生连接、已授权客户端和加密 Chat 接入家人服务 |
| [family_store.dart](../flutter/lib/qinban/family_store.dart)、[family_transport.dart](../flutter/lib/qinban/family_transport.dart) | 本地身份/关系、顺序保存、HTTPS 鉴权与网络生命周期 |
| [call_alerts.dart](../flutter/lib/qinban/call_alerts.dart) 与原生宿主 | 去重呈现、响铃/通知、动作回流；不因一个通知 Intent 就批准协助 |
| [diagnostics_bridge.dart](../flutter/lib/qinban/diagnostics_bridge.dart)、[connection_diagnostics.dart](../flutter/lib/qinban/connection_diagnostics.dart) | 原生事件转固定诊断分类、本地持久化和可选上传 |
| [mobile_session_lifecycle.dart](../flutter/lib/qinban/mobile_session_lifecycle.dart) | 新连接等旧会话异步清理完成，防止关闭到新会话 |
| [family-service.mjs](../site/server/family-service.mjs) | 关系、角色与请求的服务端权威状态，条件写入及鉴权 |

## 3. 邀请、连接与首次配对

### 3.1 邀请格式

格式：`BB1-` + 6–16 位 ASCII 设备号码的 UTF-8 base64url，去掉尾部 `=`。例如测试号码 `123456789` 编为 `BB1-MTIzNDU2Nzg5`。这是可逆编码，不是签名、加密凭据或一次性授权。

当前接收入口为：

- `https://bangbang-jacklee992.netlify.app/invite?code=<BB1口令>`。
- `bangbang://invite?code=<BB1口令>`。
- 完整带 `【帮帮邀请】` 标记的消息，或独立合法 BB1 口令。

解析只接受规范域名/路径、单一 code、规范编码和一致的设备号码；拒绝重复参数、冲突邀请、未知版本、用户信息或片段。剪贴板输入最多 8192 字符。网站与 App 共用测试样例验证模板一致性。

安卓声明 HTTPS App Links 并提供对应发布证书的 assetlinks；调试包显式拉起测试不证明它具备发布证书的域名验证。iOS 当前仅有 `bangbang` Scheme，没有 Associated Domains 权限/AASA，因此不能写为“Universal Links 已接入”。微信内唤起不作保证，主退路是复制整条消息→手动打开 App→确认。

读取剪贴板不自动连接；只在空闲界面确认，旧邀请去重，显式粘贴允许重新提示。没有实现应用安装后的自动恢复邀请；用户安装后仍需再打开链接或复制消息。

### 3.2 分享准备

适老入口将批准模式设为本机点击，并使用临时验证机制。顺序是操作权限就绪→共享说明→系统屏幕共享→原生采集可用→发现服务在线→发送分享/求助。

20 秒就绪超时从共享服务启动并返回、开始检查在线状态后计时，不是覆盖用户阅读和系统授权的总时限。使用 generation 标识取消，迟到授权和网络回调不再继续发送。停止先释放本机共享，再异步结束服务端请求。

安卓通过系统分享面板发纯文本，可选择系统提供的微信目标。没有微信 SDK，也没有微信发送、送达或阅读回执；“分享面板成功打开”不能作为送达埋点。

### 3.3 首次家人关系的建立

```mermaid
sequenceDiagram
  participant E as 安卓长辈端
  participant H as 家人控制端
  participant N as 原生远控会话
  participant F as 家人服务
  E->>E: 开启共享并等待就绪
  E-->>H: 系统分享或复制 BB1 消息
  H->>H: 识别邀请并明确确认
  H->>N: 发起原生连接
  N->>E: 请求本机允许协助
  E->>N: 允许本次协助
  N-->>H: 实际连接事件与画面
  E->>F: 注册本安装身份
  H->>F: 注册本安装身份
  H->>N: 在满足加密条件的会话内交换配对消息
  N-->>E: 传递与当前对端绑定的配对消息
  H->>F: pair.offer
  E->>F: pair.confirm
  F-->>E: confirmed
  F-->>H: confirmed
```

该图的注册与握手可异步交错，关键条件不能省略：控制端为普通远控连接，原生 `connection_ready.secure == true` 且实际 `peer_info` 已到达；被控端为真实授权且未断开的普通客户端。控制端创建能力凭据，通过该加密会话交换；对端号码、方向、双方 nonce、当前 serverScope 必须匹配。

被控端连接管理接口没有暴露加密标志，代码不会伪造 true 或由该端发出能力。不能将任何 Chat 消息都视为可信握手。内部配对帧由 bridge 消费，无效帧不弹普通聊天窗口。

配对完成与首帧统计是不同事实：关系可在满足真实授权/加密握手后确认，不要求“通话已正常结束”；连接成功统计必须等真实第一帧。首次 BB1 的准备与接入目前没有共同 callId。

## 4. 已配对呼叫的状态与一致性

| 服务端状态 | 含义 | 客户端行为 |
| --- | --- | --- |
| queued | 求助已保存，未证明对方已读取 | 显示等待，不报告送达保证 |
| observed | 家人端前台轮询读取了请求 | 展示来电卡片，尝试通知和响铃；不是 OS 通知显示回执 |
| accepted | 家人明确接听 | 保留该请求，开始原生连接；长辈仍需本机授权 |
| active | 控制端实际收到首帧并报告 | 显示协助中，续期本次呼叫 |
| ended | 正常结束 | 关闭会话/共享、停止提醒 |
| failed | 明确连接失败 | 结束本次请求，显示可行动的重试说明 |
| declined / cancelled | 拒接 / 撤回 | 清理本机状态，异步通知对方 |
| expired / revoked | 超时 / 关系撤销 | 不接受迟到接听或进度，不恢复旧会话 |

终态与请求 ID 绑定。旧请求不能被新连接的事件覆盖；服务端条件写保证同一关系的接受/撤回竞争不会复活终态。客户端只有明确、仍有效的接听才连接；前后台切换、对端变更和过期后拒绝迟到响应。

### 4.1 当前参数——实现默认值，待 D-03 审核

| 参数 | 值 | 实际范围 |
| --- | --- | --- |
| 前台家人轮询 | 2 秒 | 一次轮询未结束时不重入；inactive 通知栏仍运行，paused/hidden 暂停 |
| 家人 HTTP 超时 | 8 秒 | 取消或暂停会结束在途请求，不向用户泄漏 HTTP 内容 |
| 配对 offer | 10 分钟 | 只限制首次握手，confirmed 关系没有相同的十分钟寿命 |
| 未接通请求 | 120 秒 | 从创建时计时，接听不重置；留给阅读和授权的时间也在其中 |
| 发送间隔 | 同一关系至少 15 秒 | 同 requestId 幂等；用户下一次主动呼叫使用新 ID |
| 已接通租约 | 60 秒，每 25 秒续期 | 只有 helper 的有效 progress 更新；前台轮询驱动 |
| 单次最长 | 旧模式 createdAt 起 1 小时 | 包含响铃准备时间；已发布实现的限制，非已确认产品规则 |
| 关系容量 | 客户端 20 条，服务端身份索引 32 条 | 不应向产品宣称无限家人；容量与淘汰规则需统一 |

**新本地候选：**已发布旧模式的租约过期会结束协助，服务层已受控复现这一问题；仍不能据此认定为用户卡顿的全部根因。F-04 已通过请求与通道绑定的原生挑战区分健康协助和 HTTP 失联，新模式支持同一请求从 `interrupted` 恢复，明确终态仍不可恢复。10 秒探测、30 秒健康新鲜度与 5 秒探测等待是本轮实现策略，不是线上承诺；仅双方新客户端与新服务协商后取消原一小时截断。完整兼容、验证与发布边界见 [活动协助恢复](ACTIVE_CALL_RECOVERY.md)，生产仍是旧模式，D-03 的产品规则仍待审核。

### 4.2 关闭与重连

- 长辈停止不会等服务端答复才释放 MediaProjection；停止操作无需再确认一次。
- 家人主动挂断使用明显的红色按钮；正常远端结束可展示“协助已结束”后返回。
- 终态写入失败可在当前进程前台重试到旧请求过期；重试队列目前不是持久化 outbox，不承诺被杀进程后可靠补发。
- 原生第一帧若早于家人 bridge 就绪，会等待有效的匹配会话再上报；接听响应不能被当作连接结束。
- 移动新连接等待旧页面异步清理完成，避免旧全局 FFI 销毁新会话。普通断开和连接前失败分别提示，不自动重播已结束的求助。
- 当前产品按一对一主协助设计；底层多连接、多个家人同时求助和忙线回执未形成完整业务仲裁，见 D-07。

## 5. 身份、数据与家人接口

### 5.1 当前安装身份与未来用户账号

| 数据 | 生成与使用 | 留存边界 |
| --- | --- | --- |
| installationId / authSecret | 每安装本地生成 16 / 32 字节随机值；用于 HTTPS 鉴权 | 持久化先于首次注册；不出现在 UI、链接或统计 |
| pairId / capability / nonce | 16 / 32 / 16 字节随机值，绑定双方安装身份、设备号码和 serverScope | 通过已授权会话建立关系；移除请求撤销能力 |
| 家人称呼、方向、最近协助时间 | 本地历史与展示 | 当前保存最多 20 条；不是云端联系人同步或通话记录 |
| serverScope | 公共服务固定标识，或自建 host+key 的稳定摘要 | 更换 ID 服务/公钥或号码会影响关系有效性 |
| requestId | 每次求助 16 字节随机值 | 已配对流程同时作为统计关联 callId；不是授权密钥 |

随机值均使用无 padding 的 canonical base64url。16 字节为 22 字符，32 字节为 43 字符。BB1 中的设备 ID 与这些身份凭据完全不同。

本地关系通过 RustDesk local option `qinban-family-v1` 保存，串行写入避免旧值覆盖新移除。当前这一层没有单独实现 Keychain/Keystore 封装；备份、换机和本地凭据保护策略需核验，不能声称已有硬件安全存储或账号恢复能力。

服务端只存 authSecret、capability、nonce 的绑定摘要。confirmed 关系长期保留；短期请求 TTL 不是自动物理删除。防重放 claim 作为墓碑保留；服务端身份和关系的最终删除、保留策略尚需 D-08 审核，不能把所有后端数据概括为“7 天删除”。7 天仅适用于诊断。

### 5.2 当前协议

入口：`POST /.netlify/functions/family`。JSON 公共字段 `v=1` 和 `op`；头部 `Authorization: Bearer <installationId>.<authSecret>`。正文最多 8192 字节，未知字段被拒绝，返回不缓存；客户端拒绝非成功、非预期结构或超过 64 KiB 的响应。

| 操作 | 责任与鉴权 |
| --- | --- |
| register | 首次原子认领安装身份；后续只有原凭据可更新号码/scope |
| pair.offer / pair.confirm | 控制端提出、被帮助端确认；身份、号码、nonce、能力、scope 一致 |
| poll | 只读取该身份的关系及请求；控制端读 queued 才变 observed |
| request.create | 被帮助端发起，关系必须 confirmed 且当前绑定一致 |
| request.respond | 只有对应控制端可 accept/decline |
| request.progress | 只有控制端可将 accepted→active 或续期；终态不得恢复 |
| request.end | 双方绑定 owner 可 ended/failed/cancelled；终态幂等 |
| request.cancel | 兼容撤回操作；新客户端挂断已接通呼叫走 end |
| pair.forget | 任一关系 owner 可撤销后续求助关系 |

完整字段和错误码见 [家人协议](FAMILY_CONNECTION.md)。接口 v1 的 progress/end 是新增操作，旧线上函数尚不支持；版本号仍为 v1 不代表部署天然兼容。

### 5.3 持久化与异常

Netlify Blobs 使用 `ap-southeast-1`、强一致读取及 ETag 条件写；单关系状态为权威，最多重试 6 次冲突。适配层校验真实响应并强读回，避免把不能确认的写入报成成功。生产 store 与每次预览的 store 分离，未知部署上下文失败关闭。

客户端当前把大多数 HTTP 失败统一为 FamilyNetworkException，因此并未针对 401、409、429、503 实现精细的用户恢复路径；“协议有错误码”不等于 UI 已全部差异化处理。

移除家人先保存本机结果，再尝试服务端撤销。断网失败时显示“本机已移除、网络未确认”，但目前没有持久化撤销重试队列。不能在这种情况下承诺服务端能力已注销；重装、后台退出和移除并发应补测试（G-05）。

另外两处容量契约尚不一致：BB1/移动端只接受 6–16 位号码，服务端接受 6–20 位；客户端最近 20 条与服务端 32 段索引并非同一上限。建议固定移动产品契约，容量达到上限时显式处理，避免静默淘汰本地记录后遗留服务端关系。

## 6. 平台能力、权限与通知

### 6.1 当前已实现的通知呈现

| 平台 | 实现 | 已验证边界 |
| --- | --- | --- |
| Android | `FamilyCallNotifications.kt`，高优先级通知、接听/拒接 PendingIntent、请求期限内提示音；API 33+ 请求通知许可 | 双模拟器验证通知动作、撤回与拒接清理；不同厂商/锁屏音量策略待真机验证 |
| iOS | `AppDelegate.swift` 的 UserNotifications 分类与动作，前台周期提示音 | 代码及未签名设备构建通过；未完成真机提醒与控制链路验收 |
| 共用 Dart | `FamilyCallAlerts` 按 requestId 去重、串行呈现/清理；返回应用后重新拉取认证状态 | 不以原始通知参数直接连接；检查当前请求、过期、角色和空闲条件 |

通知被拒绝不应阻止前台来电卡片操作。Android 通知到期可由系统清理；iOS 暂停后本地计时器可能不执行，因此不能保证已显示通知在暂停期间即时消失，点击后必须重新验证状态。

权限分离：安卓无障碍用于触控；系统录屏授权用于画面；本机“允许协助”用于本次连接。通知许可独立于远控批准。上游 Android Manifest 仍含音频等能力声明，产品虽未启用独立语音电话，发布前仍需按实际依赖审计；不能据 UI 隐藏就宣称包中没有相关权限。

### 6.2 后台通知方案——尚未实现，待 D-01 / D-06 审核

优先候选是 iOS 普通 APNs 可操作通知、安卓厂商推送或聚合服务。它们要求开发者配置，不要求家庭成员注册账号。

拟增加的流程：

1. 安装端取得系统推送 token，用现有安装凭据注册 provider、环境、token 和更新时间。未来接口例如 `push.register/unregister` **不属于当前已实现 API**。
2. 请求先持久化为 queued；服务端核验家人关系后单播提醒。推送失败不能假报 delivered，也不能撤销已保存的前台请求。
3. 载荷只放短期 requestId 和必要类型/过期信息；不放设备密码、capability、authSecret 或剪贴板内容。
4. 收到提醒后拉取权威请求，检查是否仍可接听；通知点击只触发这个校验路径。过期、撤回或移除后的通知不能补响或恢复呼叫。
5. 处理 token 更新、失效、环境切换与撤销；服务端重试受请求 TTL 限制，重复消息按 requestId 去重。不要承诺系统必定投递或用户强制停止后仍可唤醒。

Apple 将 PushKit 的该路径用于 VoIP，并要求相应 CallKit 行为；当前产品没有独立 VoIP 通话服务，建议先用普通通知，不能把后台唤醒包装成已接入电话能力。[Apple PushKit 文档](https://developer.apple.com/documentation/pushkit/responding-to-voip-notifications-from-pushkit)

Android 提供 CallStyle 的接听、拒接、挂断模板，但当前实现是高优先级普通通知，不是 CallStyle/Telecom 或全屏电话。是否升级应在真实通话范围与厂商测试确定后单独设计。[Android CallStyle 文档](https://developer.android.com/develop/ui/compose/notifications/call-style)

## 7. 诊断、统计与第三方 SDK

### 7.1 当前数据模型

每条诊断是一次尝试的最新状态，不是每步事件流水。保留字段：

`v, attemptId, callId, role, kind, platform, appVersion, build, startedAt, elapsedMs, phase, outcome, error, path, revision`。

| 维度 | 当前值及用途 |
| --- | --- |
| kind | preparation：共享准备；call：已配对求助；connection：实际原生连接尝试 |
| phase | starting、serviceReady、calling、ringing、contacting、waitingApproval、authorized、firstFrame |
| outcome | pending、ready、success、failure、cancelled、interrupted |
| error | none、offline、network、timeout、rejected、password、keyMismatch、capture、unknown |
| path | unknown、direct、relay，来自真实原生事件 |

stage 变化更新同一条记录和 revision；第一帧把 outcome 置为 success，之后正常挂断或断线不回写成“连接失败”。因此当前日志**不覆盖首帧后的稳定时长、逐步耗时或完整通话质量**。如要统计这些指标，需要额外设计，不能倒用 elapsedMs。

本地在应用私有目录串行原子保存，最多 100 条、7 天；恢复时把未完成连接列 interrupted。没有远程地址时只保存在本机。配置 HTTPS `/v1/attempts` 后才可能上传；当前上传开关默认 true，设置页可关闭。正式启用前需审核告知/选择流程，而非声称现在已经有明确选择加入流程。

上传超时 4 秒；每批最多 20 条待上传版本，失败退避 60 秒；新变化或下次前台继续补报。已修复在途请求遗漏最终状态和旧记录无法越过首批的问题。上传状态索引在内存中，重启可能重复补报，服务端必须按 attemptId/revision 幂等处理。

### 7.2 统计口径

当前云端查询限定 `kind=connection AND role=helper`，最近 7 天：

**技术连接成功率 = 首帧成功次数 ÷（首帧成功次数 + 明确连接失败次数）。**

取消、进程中断、进行中单列；未接听或共享准备失败不进入这个分母。示例：8 次首帧、2 次连接失败、5 次取消，技术成功率是 80%，这不是“15 次求助中 80% 获得帮助”。

当前不足与建议：

- 已配对流程共用 requestId，可关联双方记录；首次邀请未共用，不能计算全入口完整漏斗。
- D1 查询按版本、平台、结果、错误及 direct/relay 分组，输出数量和平均 elapsedMs；没有现成可视化管理后台，也未实现 P95 报表。
- 上报为客户端事实声明，匿名入口可被伪造，不能当作授权或安全审计证据。
- 统计总数最多受本地 100 条、7 天保留与网络补报影响，需同时显示样本量、缺失/中断和采集覆盖范围。
- 下一阶段拟补“发起意图、准备、对方收到、接听、授权完成、首帧、结束原因”等事件以及同一呼叫关联；事件定义和邀请协议兼容方案先评审，不能直接宣称已采集。

### 7.3 Cloudflare 接口

| 接口/任务 | 规则 |
| --- | --- |
| POST `/v1/attempts` | 单条 JSON ≤2 KiB，固定字段校验，默认 INGEST_ENABLED=false；要求 Rate Limiter，30 次/IP/分钟 |
| GET `/v1/summary` | 管理 Bearer token 至少 32 字符，不能放客户端；返回最近 7 天聚合 |
| GET `/health` | 只表示 Worker 响应，不证明 D1、推送或手机连接健康 |
| 定时清理 | 删除超过 7 天诊断记录；与家人关系存储互不影响 |

D1 用 attempt_id 主键与 revision 更新，终态不被旧 pending 覆盖。IP 作为限流键，不写入 D1。公开入口的来源检查不能替代认证；当前只是限制滥用的诊断服务。免费额度和费用以实际账号为准。

### 7.4 国内 SDK 的取舍——未接入

| 候选 | 可解决的问题 | 对本产品的建议 |
| --- | --- | --- |
| [友盟 U-App](https://www.umeng.com/analytics) | 自定义事件、漏斗和版本对比；官方有免费标准版 | 与自建诊断统计存在部分重叠。先统一事件口径，再决定是否接入；不默认开启营销归因或广告标识采集 |
| [Bugly Flutter 插件](https://github.com/BuglyDevTeam/Bugly-Flutter-Plugin) | Dart/原生崩溃捕获与上报 | 可补崩溃定位；普通“连不上”不是崩溃，不能用崩溃率代替连接率 |
| [个推](https://docs.getui.com/getui/) | APNs/安卓推送聚合 | 后台提醒候选；需 AppKey、系统/厂商凭据、token 绑定和目标地区真机验收 |

建议先保留本地诊断与已准备的 Cloudflare 方案，第三方按用途逐个启用。免费资格、功能限制、Flutter/原生 SDK 兼容、自动采集项及隐私申报都要在选定版本时验证；本稿没有替项目创建账号、接入 SDK 或作付费承诺。

## 8. 基础设施与发布

### 8.1 服务分工

| 服务 | 工作 | 当前状态与限制 |
| --- | --- | --- |
| Netlify | 静态宣发下载、邀请页、家人 HTTPS API 与 Blobs | 已有站点；新 API 与隐私页待部署。不能用短生命周期 HTTP 函数代替当前需要 TCP/UDP 的原生中继进程 |
| Cloudflare Worker / D1 | 诊断接收、限流、聚合、7 天清理 | 代码和 dry-run 通过，无云端部署 |
| Oracle / Linux VM | hbbs 发现及 hbbr 中继 | Compose 模板，镜像固定 1.1.16；免费容量、地域和连通性须实际确认 |
| 国内替代 | CloudBase 等可评估家人 HTTP/日志；国内 VM 可跑相同原生服务 | 只是备选，没有完成迁移、性能或免费额度验收 |

详细部署文件见 [Cloudflare 说明](../backend/diagnostics/README.md) 和 [Oracle 说明](../deploy/oracle/README.md)。本稿不新增运营后台、网站复杂说明或要求长辈自行搭服务器。

### 8.2 连通、容量与迁移

原生 VM 模板开放 TCP 21115–21117、UDP 21116，客户端配置同一 ID 地址、relay 地址和生成的公钥；私钥只在服务端。源码本机编译成功不代表 Docker 镜像、Oracle 防火墙、真实中继与中国大陆网络已可用。

前台 2 秒轮询约为每台活跃设备每分钟 30 次 poll，另有主动操作；注册在当前 context 内有缓存。Functions 配置按 IP+域名 180 次/分钟，真实平台限流尚未验收；同一家庭/办公网络多台设备可能共享出口。每次请求还会产生多次 Blobs 操作。上线前以并发前台设备和关系数测量，不把免费服务器视为无限容量。

从公共服务切换自建 host/key 会改变 serverScope，现有关系可能失效；必须设计客户端默认配置、切换提示与重新配对/迁移策略。只部署服务器不会自动修好旧客户端的连接路径。不能悄悄把网络配置任务交给长辈。

### 8.3 建议发布顺序

1. 完成审核，确定平台能力、统计口径和当前差距的处理范围。
2. 验证原生发现与中继的目标网络，再确定是否更改客户端默认连接服务。
3. 先升级原 Netlify 项目的家人函数和独立隐私页；使用专用 QA 身份验收旧客户端操作、新 progress/end、状态不可复活及跨发布数据保留。
4. 准备正式签名 Android 和对应完整源码；iOS 使用 liyilin 的实际可用分发权限归档，不把开发 IPA 或未签名构建当分发包。
5. 用与拟分发文件一致的产物执行真机矩阵，校验版本、签名和 hash，再替换下载清单。
6. 单独开启诊断服务或推送服务；失败可关闭统计/回退通知呈现，但不能破坏本机停止与授权。正式上传配置不是已存在的远程开关，关闭方式需按实际客户端版本和服务端开关区分。

回滚保留 Blobs 身份/关系、原生公钥/私钥和数据目录；不要回退为不认识新客户端操作的家人函数，也不要将 revoked/终态记录删掉来“修复”重试。网站、客户端、家人 API 和原生服务需分别记录版本。

## 9. 质量与验收

已有证据：173 项 Flutter、40 项网站/家人服务、6 项 Worker/SQLite、22 项发布脚本测试；Android 最终候选双模拟器真实视频/操作和呼叫清理；iOS 未签名 0.1.2（11）构建成功。详见[证据与 hash](CALL_FLOW_VERIFICATION.md)。本次文档整理没有重新运行这些移动构建或把历史结果提升为真机证据。

| 层级 | 下一轮必须覆盖 |
| --- | --- |
| 状态/协议 | 取消与接受竞争、重复点击、过期通知、进程重启、撤销失败重试、容量边界、多请求忙线 |
| 安卓系统 | 各厂商权限、录屏拒绝/撤回、通知拒绝、系统放大、后台/省电、helper 挂断释放捕获 |
| iOS 真机 | 整条复制识别、Scheme、接听与拒接、通知动作、远控首帧/触控、切后台与返回 |
| 网络 | Wi-Fi/移动网络组合；强制中继实际 path=relay；断网和切网；只中断家人 HTTPS 但维持视频的情况 |
| 生产 | Functions/Blobs 真实写入与跨部署，下载证书和链接关联，云端诊断鉴权/清理/限流 |
| 用户体验 | 长辈独立完成第二次求助，记录每个 App 动作与系统动作；正常结束不误报失败 |

首次邀请与已配对呼叫分别统计。模拟器本机 direct 结果不作为真实 iPhone、跨运营商或所有家庭的成功率结论。

## 10. 差距登记与审核建议

以下仅登记现状和后续处理建议；本轮不修改业务代码。

| 编号 | 当前差距 | 影响 / 建议处理 | 关联审核 |
| --- | --- | --- | --- |
| G-01 | 真实 iPhone→安卓、跨网络和 relay 未验收 | 下一次公开可用性结论前补完整矩阵 | D-01、D-05 |
| G-02 | 后台远程投递及推送 token 服务缺失；iOS 无相关配置 | 不能承诺关闭 App 后来电；按普通推送路线推进 | D-01、D-06 |
| G-03 | 已发布 active 仍依赖信令租约；F-04 本地候选已修复 | 受控及模拟器证据见专项文档；真机与兼容发布待执行，产品时限仍待审核 | D-03 |
| G-04 | 首次邀请无共用 callId，缺少授权后计时；本轮新增本机首帧后质量采样，真机验证仍待完成 | 技术成功率不能代替全流程体验指标；采样说明见 [性能实施](REMOTE_PERFORMANCE.md) | D-04 |
| G-05 | 断网移除后没有持久化撤销重试；终态补发仅进程内 | 补可恢复的撤销/终态任务与明确提示，避免宣称服务端已撤销 | D-08 |
| G-06 | 本地能力凭据保护、系统备份、身份/关系删除策略未闭合 | 评估安全存储与备份规则；定义各类数据留存，7 天规则仅限诊断 | D-08 |
| G-07 | 多家人同时呼叫与忙线回执未完整设计 | 当前按单会话使用；明确第二来电策略，不让 UI 覆盖当前会话 | D-07 |
| G-08 | 号码长度、客户端/服务端关系容量契约不一致 | 固定移动产品边界与超限行为，补边界测试 | D-07、D-08 |
| G-09 | iOS Universal Links 未接入，微信与跨安装入口未完整真机验收 | 保留复制退路；如需 HTTPS 直达再补域名能力与证据 | D-01 |
| G-10 | 新API/隐私页已上线；iOS13已上传，外部审核及公开测试链接未完成 | 先兼容部署再发客户端，完成平台审核材料 | D-01 |

## 11. 需求到实现的追踪

| PRD 需求 | 主要实现 | 主要测试/证据 |
| --- | --- | --- |
| FR-01～03、FR-12 | assist_model、assist_home、qinban_theme、interface_router | assist_test、角色与系统字号截图 |
| FR-04 | sharing_readiness、rustdesk_assist_controller | sharing_readiness_test、emulator_family_call |
| FR-05～07 | invitation、invitation_sharing、平台宿主、site invite/share | invitation_test、invitation_prompt_test、invitation_sharing_test、site tests |
| FR-08～09 | family_store、family_bridge、family_service、family-service.mjs | family_test、family-service.test、真实加密会话模拟器记录 |
| FR-10～11 | call_alerts、Android/iOS 宿主、remote_page、mobile_session_lifecycle | call_alerts_test、mobile_session_lifecycle_test、系统通知接听/挂断记录 |
| FR-13 | diagnostics_bridge、connection_diagnostics、Worker/SQLite | connection_diagnostics_test、worker.test.mjs |
| FR-14 | site/public、release.json、build/release 脚本 | 网站构建测试、历史生产下载与 hash 记录 |

更早的研究、历史发布和上架步骤保留作参考；当其内容与本稿的现状冲突时，以本稿明确的代码基线和证据为准。产品目标和建议取舍仍需项目负责人审核。
