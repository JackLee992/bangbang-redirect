# 网站 Android 0.1.2 下载发布

现有网站已于 2026-10-02 17:14:05（Asia/Shanghai）切换到通过验证的 Android 0.1.2（14）公测安装包。[下载首页](https://bangbang-jacklee992.netlify.app/)保持极简，仅更新版本和安卓下载链接；没有新增可见源码入口。iOS 仍为 `pending`，没有 TestFlight 安装链接。

## 来源和发布范围

| 项目 | 固定来源 |
| --- | --- |
| Android / 对应源码 | `de34ddf9a7b9ac9dbd2c59c27e37f126aaa6b3d2`，[v0.1.2 公测发布](https://github.com/JackLee992/bangbang-android/releases/tag/v0.1.2) |
| 构建与双模拟器验收 | [Actions 36985273277](https://github.com/JackLee992/bangbang-android/actions/runs/36985273277)，通过 |
| 签名、版本、源码及发布守卫 | [Actions 36987564526](https://github.com/JackLee992/bangbang-android/actions/runs/36987564526)，通过 |
| 网站清单提交 | `1ed686888fb051a2e3709f0935a1befb34dc731d` |
| Netlify Site ID | `3e8053ab-2226-4cd7-a6ec-37bb1cb9e768`，原站点 |
| 当前生产 Deploy | `6abf75a879a9a47638321d3a`，API 确认 `ready` 且为 `published_deploy` |
| 发布前 / 回滚候选 | `6abf6c6a93e2cd3c249b7376`，发布前实时确认 |

[本次 Netlify 发布详情](https://app.netlify.com/projects/bangbang-jacklee992/deploys/6abf75a879a9a47638321d3a)。网站构建使用从已发布 GitHub Release 下载并再次核验的正式产物。`site/release.json` 的 `sourceCommit` 对应 APK 的构建源码，`deployment.json` 对应网站清单提交，两者用途不同。

独立发布目录以原允许清单为基线，只更新首页、帮助页中的版本/链接、当前下载清单与元数据，并加入新包和旧版归档。原 `family` 函数源码仍为 `37da688`；已构建 `family.zip` 的 SHA-256 始终为 `379de3b4f403941d469628d432c027caef914577d5638ffe25f76d849b0c1e2b`。本轮没有发布家庭成员/权益模块、账号/支付接口、debug APK、开发 IPA 或 QA 凭据。

## 下载资产

以下资源已从正式 Netlify 域名下载，长度和 SHA-256 与已验证 GitHub Release 相同：

| 资源 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `/downloads/bangbang-0.1.2-arm.apk` | 49,491,396 | `2149cf15cd56ba4d3f67f5c811b29e20bd116b3efb234442515cc08fb45c35ae` |
| `/downloads/bangbang-0.1.2-source.zip` | 13,516,555 | `8dc61b90b1c4d9be97183c22593d924160ce008871d8f72b94e4ff232d6a522a` |
| `/downloads/build-info.json` | 1,458 | `30065aad5793ff0098d1cbc7b4f6ab540948eb9d21169dd98c1e3a62b43bc17d` |
| `/downloads/SHA256SUMS` | 263 | `4dfc770b741ef0ae8a08b57c8debd64dbe2125c7673d8dcf9928ad4d9460163a` |

APK 的版本、构建号、包名、最低系统版本、ARMv7 / ARM64 架构与原签名证书均已检查。源码 ZIP 是同一发布快照，含固定版本的 `hbb_common`；原生包、对应源码与元数据的校验链没有使用本机 debug 产物替代。

旧版 `/downloads/bangbang-0.1.1-arm.apk` 与 `/downloads/bangbang-0.1.1-source.zip` 的原网址和字节保持不变；其 SHA-256 分别为 `23131085a2529fc54ed94c3ca8e09c60410579496b65f650b6a3264b70be5828` 和 `56a1aee8682e62342c1852d01e98f1120dd936983a3acbae8d92ffbffc938051`。另在 `/downloads/0.1.1/` 保存 APK、源码 ZIP、原 `build-info.json`、`SHA256SUMS`、AGPL 许可证和旧 `release.json`，这些归档也逐一完成线上哈希验证。公共根路径的构建元数据和校验文件有意切换为当前 0.1.2，旧元数据可从版本归档读取。

源码 ZIP 和 AGPL 许可证仍可直接下载；页面不再提供可见源码入口。GitHub v0.1.1 的发布、标签和原资产没有被覆盖。

## 本轮验证

- 网站及服务测试 75 项通过，完整网站构建通过；构建时校验正式 APK、源码和构建元数据。当前与旧版目录的校验清单均通过。
- 24 项正式域名检查通过：新旧下载及归档、发布/构建清单、Android App Links 关联文件、首页/帮助/隐私/邀请页面及其简短路由。
- 首页和帮助页响应与发布前逐字节比较，只替换了 `0.1.1` 为 `0.1.2`；隐私页和邀请页原样保持。页面无虚构 TestFlight 地址或可见源码入口。[隐私说明](https://bangbang-jacklee992.netlify.app/privacy)与 `/privacy.html` 均为 200。
- 发布前后各使用既有专用 QA 双方身份查询，共 4 次生产 API 响应通过；原关系一直为 `revoked`。没有读取或更改真实家庭，没有新建测试关系或恢复旧邀请。此次 API 检查验证正常认证查询及跨发布保存；完整 progress/end 生命周期的早先生产验证见 [家人服务发布记录](FAMILY_SERVICE_DEPLOYMENT_13.md)。
- 函数 ZIP 与已有版本逐字节一致，仍使用同一站点和生产 Blobs 空间，没有清库、迁移或更改全站保护。

Android 构建已有 222 项 Flutter 测试和同一 runner 上双 Android 35 x86_64 模拟器的远控验收；证据记录了一条 Quickstep 系统提示。不能据此宣称所有 Android 真机、iPhone → Android、不同运营商网络、长时协助或后台推送均已验收。

## 证据与回滚

被忽略的 `artifacts/netlify-release-0.1.2/` 保存 39 项输入文件的哈希清单、构建结果、发布前后 Deploy 元数据、页面原始响应、24 项线上校验、前后 QA 查询报告和 `deployment-summary.json`。私有 QA 身份仍仅保存在原权限 `0600` 的本地文件中，没有复制进发布目录或提交到 Git。

如需回滚本次网站，恢复已记录的上一 Deploy，并再次核验下载与 API。回滚会把网站下载入口恢复为 0.1.1；GitHub v0.1.2 公测发布仍保留。代码回滚不回滚或删除 Blobs 数据，家人函数在前后两次部署中相同。

本次正式部署使用上述包含历史资产的允许清单，而非将整个工作区上传。后续部署也应从该完整清单保留旧版目录；通用 `site/dist` 构建当前只生成所选版本，直接用它覆盖部署内容会丢失网站上的历史归档。若使用自动 `site-deploy` 分支，需要先把保留历史资产纳入该流程，不能把本次人工保留当作自动构建已具备该功能。
