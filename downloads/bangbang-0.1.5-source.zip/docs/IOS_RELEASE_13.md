# iOS 0.1.2（13）构建与公测记录

**后续校验结果：** Apple 随后针对构建 13 发来 ITMS-91061，指出 7 个 SDK 缺少隐私清单并要求上传新 binary。因此下文“正在等待审核”是当时页面记录，构建 13 不能继续视为只等批准或可公开安装。修复和替代构建见 [iOS 0.1.2（14）隐私清单修复](IOS_RELEASE_14.md)。

应用代码冻结在 `37da688df38e83831a1008b9c0f0f054d2018c6d`。本次将原生依赖重新编译为 **iOS 15 及以上**，完成签名归档，并经本机 Xcode 的既有团队云端分发证书上传。Xcode 已显示 `0.1.2 (13) uploaded`，App Store Connect 已列出处理后的构建 13。已按真实加密用途和“不在法国分发”的计划保存申报，外部组“帮帮公开测试”已加入构建 13 并提交审核。2026-10-02 页面状态为“正在等待审核”；公开邀请链接已创建、上限 1,000 人，但 Apple 明确提示审核通过前测试员不能加入。

本版本 iOS 仅作为家人控制端，不宣称已实现账号、订阅或应用内购买。公开测试使用邀请链接，不默认发送个人邮箱邀请。

## 为什么重新编译原生库

原归档声明支持 iOS 13，但静态库内 aom、opus、yuv 共 483 个对象实际要求 iOS 26.5，产生 413 条较新系统版本链接告警。只修改 App 的最低系统设置或 Mach-O 版本字段不能修复此问题。

原依赖构建没有明确设置部署版本；构建环境还可能继承桌面 `SDKROOT`。修复包含：

- 在 vcpkg triplet 中同时指定 `VCPKG_OSX_DEPLOYMENT_TARGET=15.0` 与 `VCPKG_OSX_SYSROOT=iphoneos`。
- 构建前清除继承的 `SDKROOT`，明确选择 Xcode。vcpkg 只由目标 triplet 设置 iOS 版本，避免全局 iPhone 环境使 macOS 宿主工具无法运行；Cargo 和 Xcode 阶段再设置 `IPHONEOS_DEPLOYMENT_TARGET=15.0`。
- 使用新的 vcpkg installed、buildtrees、packages 和 Cargo target 目录，保留旧包证据。
- Cargo 同时设置 `VCPKG_ROOT` 和 `VCPKG_INSTALLED_ROOT`。仅设置后者不够，opus/hwcodec 的构建脚本仍读取 `VCPKG_ROOT/installed`。
- 核验每一个静态库成员的 Mach-O 平台与最低系统版本，再核验最终 App 及嵌入 Framework。

采用 iOS 15 与当前使用的 Xcode 部署支持范围一致：[Apple Xcode 系统要求](https://developer.apple.com/xcode/system-requirements)。这不是 iOS 15 真机运行验证；后续仍需覆盖最低系统版本和 iPhone 控制 Android 的真实设备流程。

## 可重复的构建入口

新增脚本不安装工具链、不自动生成源快照、不默认签名或上传。它要求提供已经准备好的 Flutter、Pods、生成桥接代码和原生源树，以及经过审核的 SHA-256 清单。未加 `--execute` 时仅验证输入并输出构建计划；缺参数、源码漂移、输出目录已存在或输出目录不在仓库忽略范围内都会停止。

从仓库根目录执行，路径可按本机已准备的工具链调整：

```sh
python3 scripts/qinban/build_ios_distribution.py \
  --repository "$PWD" \
  --candidate 37da688df38e83831a1008b9c0f0f054d2018c6d \
  --prepared-source artifacts/ios-local/current-source \
  --manifest artifacts/ios-local/remote-performance-source-snapshot-13.json \
  --native-manifest artifacts/ios-local/native-source-manifest.json \
  --vcpkg-root artifacts/ios-local/toolchains/vcpkg \
  --cargo-home artifacts/ios-local/toolchains/cargo \
  --rustup-home artifacts/ios-local/toolchains/rustup \
  --binary-cache artifacts/ios-local/vcpkg-cache \
  --output artifacts/ios-local/reproduce-ios15-build13 \
  --version 0.1.2 --build 13
```

检查计划后，加 `--execute` 才会构建。如需使用本机已有开发签名归档，可加 `--team "$IOS_TEAM_ID"`；脚本不会登录 Apple、注册设备或自动创建证书。没有团队参数会生成未签名归档。正式发布重签名由 Xcode Organizer 完成。

每次使用一个新的输出目录。脚本在准备树旁创建新的 `<输出目录名>-source`，保持 CocoaPods 外部相对路径所需的目录层级；不复制旧 Cargo target 和 Flutter build，并重新定位符号链接和 Dart package URI。源树和输出目录都必须处于仓库忽略范围，已有目录不会覆盖。随后依次执行 vcpkg、Cargo 和 Xcode archive。完整命令、输入哈希和进度写入输出目录的 `build-manifest.json`；原生逐对象审计写入 `native-object-audit.json`，归档审计写入 `archive-audit.json`。日志和签名资产不得提交 Git。

单独复核本次实际产物：

```sh
python3 scripts/qinban/audit_ios_distribution.py \
  --source artifacts/ios-local/distribution-source-13 \
  --manifest artifacts/ios-local/distribution-build-13/distribution-candidate.json \
  --native-library artifacts/ios-local/distribution-source-13/target/aarch64-apple-ios/release/liblibrustdesk.a \
  --archive artifacts/ios-local/distribution-build-13/Bangbang-0.1.2-13.xcarchive \
  --version 0.1.2 --build 13 --require-signature \
  --output artifacts/ios-local/distribution-build-13/reusable-audit-result.json
```

审计将静态库真实成员数量与逐对象解析数量比较；任一成员缺少部署命令、要求更高 iOS、属于 macOS/Catalyst/模拟器平台或不为 arm64 都会失败。`--self-test` 覆盖后续成员异常和源码漂移，不以首个对象代表整个库。

## 本次已有证据

证据位于被 Git 忽略的 `artifacts/ios-local/distribution-build-13/`：

| 项目 | 结果 / 文件 |
| --- | --- |
| 应用输入 | 235 个跟踪文件匹配冻结提交，4 个保留生成文件匹配清单；`archive-source-endpoint-verification.json` |
| 原生库 | 1,786 个对象均为 iPhone 平台且最低版本不高于 15.0；`native-library-compatibility-audit.json` |
| 归档 | 0.1.2（13）、Runner 最低 iOS 15.0、深度严格签名校验通过、较新系统链接告警为 0；`archive-verification.json` |
| 发布环境 | AOT 中为正式 Netlify 家人服务地址，没有模拟器 `10.0.2.2` 家人服务地址，没有测试 define |
| 正式分发签名 | Xcode 使用已有团队的 Cloud Managed Apple Distribution 和应用专用 Store profile；调试权限关闭，beta reports 开启 |
| 上传与送审 | Xcode 显示上传成功，App Store Connect 显示“正在等待审核”；`organizer-upload.json`、`Organizer-export-13/` |
| 脚本完整复现 | `artifacts/ios-local/reproduce-ios15-build13-attempt4/`：vcpkg、Cargo、未签名 archive 完成并通过 1,786 个对象及最终 App/Framework 审计；`build-manifest.json` 状态为 `archive-verified`，未重复上传 |
| 拒绝测试 | help、缺参、缺输入、非隔离目录、源清单漂移、旧库 minOS 26.5、后续 Catalyst 对象等验证；`reusable-script-verification.json` |

原 build 12 和首次未签名 build 13 证据保留。旧依赖及首次 build 13 仍有不兼容告警，不应再次用作公测包。

## Xcode 与公测后续

命令行导出曾报告 `No Accounts` 和没有本地 Distribution 私钥；这不代表用户没有付费团队。Xcode Organizer 使用既有登录和云端证书成功分发，无需导出私钥或配置 ASC API Secrets。选择 App Store Connect、保留 0.1.2（13）、关闭自动改构建号，确保未开启 “TestFlight internal testing only”。上传完成后才能称为已上传；签名安装本身不能称为 TestFlight 公测。

构建号 13 已上传并送审，不要重复上传相同构建号。审核通过且公开链接确实可用后，再更新既有 Netlify 下载站。公开入口为 [帮帮 TestFlight](https://testflight.apple.com/join/4sw7UNJe)，本记录时仍不可加入；不要把链接生成等同于可安装。若 Android 审核测试安排有缺项，应向产品负责人取得真实信息，不编造测试结果或联系方式。

用户已填写真实审核联系资料，测试说明、官网和隐私网址已保存。内部组“帮帮内部验证”关闭自动分发、无测试员；外部组“帮帮公开测试”有 1 个构建、0 个测试员。送审时再次明确“需要登录”为否，填写配对、接听、挂断后再次接听、画面操控及画质切换测试范围，并关闭自动通知测试员。未发送个人邮箱邀请。公开链接只有设备/平台筛选，未提供地区筛选；后续推广应与用户确认的不在法国分发计划一致。

原生传输使用 sodiumoxide 0.2.7 的 XSalsa20-Poly1305、Curve25519-XSalsa20-Poly1305 和 Ed25519；它不是仅使用 Apple 系统 HTTPS。不得为了通过流程选择“无加密”，也不得未经核实将使用开源密码库直接等同于出口合规豁免。本次按经核实的第三方标准算法类别填写；用户授权代填，并明确不计划在法国分发。保存后构建从“缺少出口合规证明”变为“准备提交”，继而成功送审。加密用途或地区计划变更时须重新核对申报。参见 [Apple 加密文稿要求](https://developer.apple.com/help/app-store-connect/reference/app-information/export-compliance-documentation-for-encryption)。

Release 家人服务固定使用现有 Netlify 域名。当前客户端需要服务器的 `request.progress` 和 `request.end`：首帧后的 active 状态、续租和结束通知都依赖它们。生产家人 API 已由发布任务完成部署并验证：27 项线上 HTTP 检查覆盖初始化、跨发布关系保留、progress/active/续租/end/迟到终态及 QA 撤销。该结果证明服务流程，不等于 iPhone 控制 Android 的双真机性能验收。

本脚本不修改原 CI。CI 后续迁移应采用相同的依赖 triplet、隔离环境和逐对象审计，不能继续复用声明 iOS 13 但包含 iOS 26.5 对象的缓存。
