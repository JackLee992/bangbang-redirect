# 阿里云远控默认配置

Android／iOS 正常构建未设置 `QINBAN_REMOTE_PROFILE` 时，默认选择 `aliyun-ecs-v1`。新安装及尚未保存其他服务范围家人关系、未自定义服务器或传输设置的旧公网安装，打开新版 App 后会整组启用该配置。已经由 App 管理的同配置继续使用，不重复写入或重启注册。

已有自定义配置或旧公网家人历史的安装保持原状，**不能宣称所有旧安装都自动迁移**。2026-10-04 的 iPhone 0.1.4（24）→ Android 阿里云 QA（24）真机测试已记录 `firstFrame / success / relay`；用户确认已接通。远程点击验收因会话结束仍待重测，尚无跨手机网络验收。详见 [连接事故记录](CONNECTION_INCIDENT_20261004.md)。该证据不等于后续每个正式构建已完成安装或分发。

显式空参数 `--dart-define=QINBAN_REMOTE_PROFILE=` 只用于受控 fixture：完全不读取或修改远控配置、管理标记或恢复记录。**关闭管理或去掉构建参数都不是回退操作**，不会自动把已启用 ECS 的安装切回公网；去掉参数会继续选择默认 ECS。

## 固定受信配置

`flutter/lib/qinban/remote_server_configuration.dart` 仅接受固定标识 `aliyun-ecs-v1` 和显式恢复操作 `restore-managed`。其他非空值直接返回 `profile_not_trusted` 错误，不解析地址、不从邀请选择服务器、不退到另一服务器。

| 引擎设置 | `aliyun-ecs-v1` |
| --- | --- |
| `custom-rendezvous-server` | `123.57.57.202:21116` |
| `relay-server` | `123.57.57.202:21117` |
| `key` | `lMADRklrhk4PQsqe1sy1VCqF6amA0WS6GImbUKnmbTo=` |
| `api-server` | 空 |

这里的 key 是服务器公钥，可以包含在 App 中；不是家人鉴权凭据或服务器私钥。公钥的大小写、`+`、`/` 和 `=` 必须原样保留。

家人及诊断仍使用 `service_configuration.dart` 的现有 Sites 地址；引擎 `api-server` 与家人 HTTP API 无关，不在这里互相替代。

## 构建选择

使用与现有流水线一致的 Flutter 3.24.5。仓库本机缓存位于 `.qinban-cache/toolchains/flutter/bin/flutter`；本文命令中的 `flutter` 指该版本。Homebrew 当前的 3.47.4 与仓库既有 UI／依赖不兼容，不在本次修改范围升级。

在已有、已验证的原生引擎构建基础上，正式 Flutter 构建无需额外参数即选择默认配置。也可以明确传入同一参数，便于构建记录审计：

```sh
--dart-define=QINBAN_REMOTE_PROFILE=aliyun-ecs-v1
```

例如在 `flutter/` 下进行 Android 构建时：

```sh
flutter build apk --release --target-platform android-arm64,android-arm \
  --dart-define=QINBAN_REMOTE_PROFILE=aliyun-ecs-v1
```

iOS 正式分发使用相同的 Dart 默认选择，不传额外 define；分发校验要求 `DART_DEFINES` 为空。受控 QA 可将显式参数传给 Flutter 的 `build ios --release --no-codesign --config-only`，再使用对应 archive／签名流程。此文档中的命令不表示已经生成或分发新 APK／IPA，正式包不依赖 QA 参数。

更新构建要保留既有包名、签名和应用数据，并使用合适的新版本号。两端都需要实际使用相同 profile，并核对生效结果；默认选择或构建参数本身不能证明服务器连通或配置已应用。

## 配置应用与历史保护

`initializeQinban()` 在 Diagnostics、Family 初始化以及原 `qinban-initialized` 早退之前执行配置检查。显式空参数的受控构建不调用任何配置回调。

配置作为 `server / relay / engine API / key` 整组处理：

- 仅整组为空、没有既有管理标记的安装可以第一次启用。
- 已管理的安装只有当前四项精确等于管理标记中的原配置时才允许升级。升级保留首次启用前的配置作为恢复目标。
- 任意部分配置、自定义完整配置、用户改过的管理配置和用户清空后的配置均返回 `preservedUserConfiguration`。即使用户手工设置的完整配置与固定 profile 相同，也不擅自取得管理权。
- `allow-websocket=Y` 或 `disable-udp=Y` 的用户选择保持原状，不自动关闭以强行启用 profile。
- 家人历史中有目标服务器范围之外的成员，或历史／恢复状态无法安全读取时，返回 `preservedFamilyHistory`，保持整个原配置。之后仍可初始化原 Family。没有删除成员、重置安装身份、改写旧成员 scope 或清空历史的步骤。

管理记录只保存公开的远控配置和 profile 名；不复制安装 bearer、家人 capability、推送 token 或整个其他设置。原语言、角色、权限、家人身份和家人归档均保留。

调用现有 `mainSetOptions` 时先合并当前的其他设置，再一次替换完整组。读回确认后写入管理标记，以同值 `custom-rendezvous-server` 调用现有 setter，使 Android 注册 supervisor 重启，同时重新启动移动端网络探测；不再依次写入不同服务器的 key／relay。一次成功应用只触发一次该重启调用，后续重复启动不再写入或重启。

该接入位于原生 `mainInit` 之后，因此首次原生探测仍可能先使用旧配置。最终配置 setter 会重新探测；这里没有修改 Rust 的探测启动时序。Android 已经在后台运行的服务也不能靠构建参数立即切换，需打开新 App 完成受控初始化。注册重启调用成功不等于已登记或远控会话成功。

## 失败及显式恢复

整组写入前，先写入并读回 `qinban-remote-profile-recovery-v1` 恢复记录。可观测的写入异常、读回不一致、标记失败或重启失败会恢复完整的前一组配置及其管理标记。即使恢复成功，本次初始化仍抛出 `profile_apply_failed`，不继续初始化 Diagnostics／Family，也不把旧服务器注册伪装成 ECS 成功。

若恢复也失败，保留恢复记录并返回 `profile_recovery_failed`。下一次启用管理的启动（包括正常默认构建）先检查并恢复该记录，然后以 `profile_transaction_recovered` 停止本次初始化；不会在同一次启动中再次应用目标。之后再启动才可以重试目标 profile。

若用户在中断后改了服务器组或管理标记，返回 `profile_recovery_conflict`，不覆盖用户选择。不应直接删除恢复记录绕过该检查。错误只含固定代码，不输出服务器元组、家人归档或底层异常细节。

恢复已成功应用的管理配置，使用明确的恢复构建：

```sh
--dart-define=QINBAN_REMOTE_PROFILE=restore-managed
```

仅当前完整组仍属于应用管理时，才恢复首次启用前的组，清除管理及恢复标记。后续恢复启动不再重复操作。如果回退会隐藏已经在 ECS 范围建立的家人关系，同样返回 `preservedFamilyHistory`；需要单独设计关系迁移，不能通过删除历史完成回退。

**原生持久化边界：** 当前 `mainSetOptions` 最终以一个 Rust 配置锁替换 options，但 `Config::store_()` 只记录磁盘写失败，FFI 返回 `void`。客户端读回只能确认该 API 可观察的状态，无法证明远控配置文件写入成功、断电原子性或多文件事务一致性。恢复记录和管理记录提供可观测故障及中断的处理路径；这不是断电或磁盘故障安全的原生事务实现。要获得该保证，需要另行提供可返回持久化结果的原生事务接口。

## 邀请及 OSS 网络限制

本改动没有修改 BB1 邀请格式。BB1 只带设备号，既不含服务器也不含公钥，无法区分公网、自定义服务器或 ECS。因此当前邀请**只允许在已核对同 profile 的两端之间使用**；不能直接发给仍在公网的 App 并宣称新旧互通，也不能对同一个号码盲试多个服务器。带受信 profile 的 BB2 是后续工作。

既有家人能力绑定 `serverScope`，其中包含 host／port 和公钥的身份。即使保持原安装身份，换服务器、公钥或把 IP 改成域名仍可能改变 scope；不自动重新赋予旧关系授权。

旧公网家人历史触发 `preservedFamilyHistory` 时，两端不会因安装新包就自动进入同一 ECS 范围，旧关系也不会获得新服务的授权。当前最小安全处理是两端明确核对并切换到上述受信配置，再通过邀请建立新范围关系，保留旧范围记录；这需要用户操作，不属于本次默认配置的自动迁移。不得通过清空家人记录、改写旧成员 `serverScope` 或拿同一设备号盲试多台服务来绕过保护。面向长辈的引导式双端确认与重新配对流程需要单独实现。

当前 OSS 1.1.16 需要 UDP `21116` 登记。仓库客户端虽有 UDP→TCP 注册回退，但所选 OSS 服务的 TCP／WS 路线不支持该客户端的 RegisterPk／RegisterPeer；TCP NAT／打洞健康不等于 TCP 登记成功。没有开启 WebSocket，也不承诺 WSS 443 回退或禁 UDP 网络可用。

## 本地验证入口

```sh
flutter test --no-pub test/qinban/remote_server_configuration_test.dart
flutter test --no-pub --dart-define=QINBAN_REMOTE_PROFILE=aliyun-ecs-v1 \
  test/qinban/remote_server_configuration_test.dart
flutter test --no-pub --dart-define=QINBAN_REMOTE_PROFILE= \
  test/qinban/remote_server_configuration_test.dart
```

测试使用受控配置回调，覆盖真实构造器的默认选择、显式空参数关闭管理、用户配置保护、整组应用、幂等升级、同范围及异范围历史保护、异常／读回失败、管理标记、恢复冲突及真实 `initializeQinban` 的失败初始化门槛。它们不操作服务器或设备，不能证明 Android／iOS 实际登记、跨网画面、UDP 阻断或实际磁盘失败行为。新正式构建仍需两端真机／明确网络范围的验收，并确认包中公钥与服务器持久公钥一致。
