# 帮帮服务端技术方案

版本：0.1 · 审核稿；基线日期：2026-10-04。
配套：[服务端产品需求](PRD-bangbang-server.md) · [迁移操作单](ALIYUN_DATA_CUTOVER.md) · [最新发布](releases/0.1.4.md)

本文描述当前实现和下一步设计。**已启用**指实际服务承担业务；**已部署、未启用**指代码或进程已经存在但尚未接管业务；**待建设**指新增方案。验收目标沿用产品需求的 `SFR-xx`、`SDEC-xx`，审核前不作为线上承诺。本文不含实际凭据、家庭记录或推送 token。

## 1. 基线与技术取舍

### 1.1 当前部署矩阵

| 部分 | 当前技术与位置 | 实际状态 |
| --- | --- | --- |
| 家人请求、配对、诊断 | 服务 Sites Worker + D1，`bangbang-services.s419505080.chatgpt.site` | 已启用；最新发布为服务版本 14、环境修订 19，D1 仍是唯一数据权威 |
| 阿里云业务候选 | Ubuntu 20.04 x86_64；Node 24.17.0 + 内置 SQLite | v3 包已部署，19 个运行文件核验通过；正式库四表为空，业务开关关闭，只监听 `127.0.0.1:8789` |
| 阿里云发现与中继 | 固定 RustDesk Server 1.1.16，`hbbs` / `hbbr` | 已运行，模拟器可显式选择；公开 App 尚未默认切换 |
| 宣发与安装 | `bangbang.yilin.fun` 为 GitHub Pages，Sites 为备用静态站；Gitee Release 为 APK 下载源 | Android 0.1.4（20）已发布并校验；Gitee 不维护 App 源码 |
| 阿里云静态站 | Caddy 2.11.6，20 文件只读发行目录 | 0.1.4 已内部部署，监听 `127.0.0.1:8080`；80/443 未开放，不是当前公开首页 |
| 推送 | APNs、FCM HTTP v1 provider；持久 outbox 和调度器 | 实现已有，生产凭据、调度及真机后台实收未形成完整验收，不作为已开放能力 |
| iOS 分发 | 0.1.4（21）已从冻结源码重编原生，正式签名及生产APS门禁通过；Apple处理、出口合规及内外组分配已完成，Beta App Review已提交 | 新包正在等待审核，正式导出与上传前IPA哈希一致；旧0.1.2（14）已批准且公开加入页已验收；新正式包手机安装、远控与APNs实收未验 |
| 账号、家庭和订阅 | 专项规划与独立领域基础模块 | 不在当前家人服务中启用登录、收费或会员授权 |

移动 0.1.4 冻结源码为 `b53519618457bd3e42e6a2123af4113ecc34a8da`。服务、网页和 App 有各自发布版本，不能只用 App 版本识别服务端。2026-10-04 较早的服务 v12/env15 记录是当时快照，最新状态以 [0.1.4 发布记录](releases/0.1.4.md) 及 [迁移记录最新交付](ALIYUN_MIGRATION.md) 为准。

### 1.2 保留的选择

复用现有家人状态机和原生远控引擎；业务服务与视频传输分别演进。阿里云业务使用单个 Node 部署单元和 SQLite，发现、中继使用独立受限进程；近期不为 1,000 个安装引入 Redis、Kubernetes 或新的数据分析 SDK。

家人 API 地址先保持现有 Sites 域名及兼容路径。数据迁移后由固定构建的 Sites 入口透明代理到 ECS，设备 Bearer 原样传递，禁止用重定向代替业务代理。唯一权威故障时明确返回错误；不自动写回 D1、旧 Netlify 或另一份空 SQLite。

## 2. 架构与两条链路

### 2.1 当前结构

```mermaid
flowchart LR
    E[Android 长辈端] <-->|HTTPS 家人状态与诊断| S[服务 Sites Worker]
    H[Android 或 iOS 家人端] <-->|HTTPS 家人状态与诊断| S
    S <--> D[(D1 当前唯一权威)]
    E <-->|原生加密画面与操作| H
    E <-->|发现与必要中继| R[现有公网远控服务]
    H <-->|发现与必要中继| R
    E -.显式内测配置.-> A[ECS hbbs 与 hbbr]
    H -.显式内测配置.-> A
    S -.推送实现 待上线验收.-> P[APNs 与 FCM]
    W[Pages 主站与 Sites 备用站] --> G[Gitee APK]
    W --> I[iOS 实际可用分发渠道]
```

家人请求、接听和结束是**业务状态链路**；注册、寻址、授权、画面和输入是**原生协助链路**。`health=ok` 不证明设备注册、首帧或推送可用。已授权且原生健康的会话可在短暂业务 HTTP 中断时继续，恢复后同步同一个 request，不能仅因 HTTP 不通重建远控授权。

### 2.2 正式业务迁移后的目标结构：尚未切换

```mermaid
flowchart LR
    C[两端 App 原家人 API 地址] --> S[Sites 永久 ecs-only 入口]
    S -->|HTTPS 与独立代理授权| T[ECS 唯一 TLS 入口]
    T --> N[Node 127.0.0.1:8789]
    N <--> Q[(SQLite 唯一业务权威)]
    N --> P[已验收的推送 provider]
    M[两端相同受信远控配置] --> R[ECS hbbs 与 hbbr]
    D[(旧 D1 冻结保留)] -.不再服务业务读写.-> S
```

业务权威迁移、远控默认配置切换、公开首页迁移是三个独立发布动作。当前北京资源尚无正式公网 HTTPS 接入，示例中的 `api.bangbang.yilin.fun` 只是待验收目标，不是已上线地址。后续接入按 [HTTPS 模板](../backend/aliyun/tls/README.md) 和已有域名操作单执行。

## 3. 完整呼叫、状态与异常

### 3.1 已保存家人的正常流程

1. 长辈本机确认权限、服务登记和共享准备；准备失败停在本机，不建立求助。
2. 已确认关系的长辈以 `pairId + capability + requestId` 创建求助。服务验证安装、角色、peerId、serverScope、关系及限流，持久化 request。
3. 家人前台轮询发现请求；后台通知完成上线验收后可提供额外唤醒。只有家人主动接听才提交 `request.respond`。
4. 两端建立原生连接并完成本机协助授权；家人端收到真实首帧后上报 `request.progress`。服务响应及 UI 状态不得替代真实画面。
5. 协助中原生通道维护健康；HTTP 更新活动租约。任一方结束先停止本机共享与提醒，再幂等同步 `request.end`。

### 3.2 当前状态的含义

| 状态 | 含义与产生方式 | 约束 |
| --- | --- | --- |
| `queued` | 请求已保存 | 不代表家人已收到 |
| `observed` | 家人经过已鉴权 poll 观察到请求 | 不代表系统通知出现或已接听 |
| `accepted` | 家人提交接听 | 不代表授权完成或收到画面；不延长原等待期限 |
| `active` | 家人提交经过鉴权的进度报告 | 客户端按首帧和原生健康触发；服务端不能独立证明首帧/native pong |
| `interrupted` | `native-v1` 活动租约过期后派生 | 可由仍有本机授权与原生健康的同一 request 恢复；不是重新呼叫 |
| `declined / cancelled / ended / failed / revoked / expired` | 拒接、取消、结束、失败、撤销或等待超时 | 终态不可被迟到接听、progress、轮询或重复 request 复活 |

配对 offer 有效 10 分钟，`pending → confirmed`，移除后为 `revoked`；peerId/serverScope 绑定变化可派生 `stale`。每个安装最多索引 32 个有效关系。呼叫等待期为 120 秒，活动租约 60 秒；旧租约模式仍有从 request 创建起 1 小时上限。已协商 `native-v1` 的活动会话不采用这一小时截断；已经超时的等待请求或旧模式终态不能事后升级。

请求 ID 有永久 claim，同一个当前 ID 重试返回原请求，旧 ID 不能重建或延长期限。每关系新请求至少间隔 15 秒；旧 outbox 仍有发送 claim/lease 时不允许用新请求覆盖。CAS 最多重试 6 次，写后强读核对，冲突最终返回固定错误，不无限等待。

### 3.3 业务故障与本机结束

客户端家人轮询定时为 2 秒，重叠请求、无有效关系、非前台等条件会抑制调用；HTTP 超时 8 秒。活动进度通常至少间隔 25 秒更新；原生 ping 每 10 秒，健康新鲜度 30 秒，单次探测截止 5 秒。具体行为见 [FamilyService](../flutter/lib/qinban/family_service.dart)。

结束同步失败可以前台重试，当前本机重试窗口为 10 分钟；它不延迟本机停止、不让旧会话自动重新启动。客户端 request epoch/generation 和完成集合阻止旧 poll 覆盖已结束状态，服务端终态规则再做防护。

`native-v1` 是**经过鉴权的客户端健康声明**，不是服务端验证的控制通道凭证，不能直接用于收费或证明用户已完成协助。新增漏斗需区分服务端状态、设备报告、真实验收三个证据来源。

## 4. API、身份与存储

### 4.1 当前接口契约

| 接口 | 用途 | 授权与状态 |
| --- | --- | --- |
| `POST /.netlify/functions/family` | 所有家人操作，JSON `{v:1, op, ...}` | 安装 Bearer、严格操作字段白名单；兼容路径名不意味着仍托管于 Netlify |
| `POST /v1/attempts` | 固定结构诊断 | 已登记且未撤销的安装身份及诊断预算 |
| `GET /v1/summary`、`POST /v1/diagnostics/cleanup` | 近 7 天统计和有界清理 | 独立诊断管理 Bearer |
| `GET /api/health` | 固定状态和真实数据库读取 | 不返回家庭数据；ECS 代理启用后还受代理边界保护 |
| `POST /api/push/dispatch` | 有界推送扫队列 | 独立 HMAC 调度授权，不接受设备 Bearer 代替 |
| `POST /api/admin/family-migration` | 旧家人记录批量导入 | 临时迁移授权且业务维护关闭；不能替代完整三表正式切换 |
| `GET /api/version` | 当前版本、下载地址、Android SHA256 | 公开；随发布 manifest 固定，不是动态配置后台 |
| `/downloads/<白名单附件>` | 下载与源码附件 | GET/HEAD，固定对象或 Gitee 跳转 |
| `/api/releases/<白名单附件>` | 临时发布附件 | 显式上传开关及独立临时秘密；当前已关闭并撤权 |
| `/api/admin/authority-export` | 源端限时加密导出 | Sites 专用，正式模式 HEAD/GET、独立临时授权；未开启 |
| `/api/admin/backups/migration-20261003.bgbak` | 固定旧迁移备份 | 独立私有授权，仅该对象；不是通用备份 API |

家人 `op` 为 `register`、`identity.verify/revoke`、`pair.offer/confirm/forget`、`poll`、`request.create/respond/cancel/progress/end`、`push.register/unregister/resolve`。`identity.revoke` 是内部授权操作；不能据此把所有 op 都当作普通设备可调用的功能。

当前身份为规范 base64url 的 16 字节安装 ID 加 32 字节 secret，格式 `Bearer <installationId>.<secret>`；配对 capability 32 字节、nonce 16 字节。安装 secret、pair capability、offer nonce 使用绑定 ID 的域分离散列，角色和原生 serverScope 另验；pairId 本身是记录标识，不是秘密或独立散列凭据。helper 建 offer、elder 确认；elder 发起/取消，helper 接听/进度，双方可结束和忘记关系。身份撤销用独立内部 HMAC，绑定原正文及 ±60 秒时间戳。

这些是设备安装身份和远控关系，不是账户、电话号码或实名家庭。换机恢复需要后续可信账号设计；当前不能凭称呼、peerId 或支付记录恢复他人关系。

### 4.2 持久数据

| 表或实体 | 当前保存内容 | 生命周期 |
| --- | --- | --- |
| `bangbang_family_records` | `(scope,key,json,etag,updated_at)`；安装验证、配对、当前 request/outbox、claims、ownership、发现索引及入口桶 | 设备、配对和防重放按协议处理；临时索引/入口桶另清理 |
| `bangbang_diagnostic_attempts` | 经 HMAC 的安装/尝试/呼叫标识，固定阶段、结果、耗时、版本等 | 查询近 7 天；删除有界，不保证空闲时准点物理删除 |
| `bangbang_diagnostic_limits` | 诊断及管理请求预算 | 保留窗口内预算，迁移不得清零绕过额度 |
| 源 D1 `bangbang_authority_fences` | scope、冻结 epoch、时间、DDL 摘要 | 正式冻结后不可通过 HTTP 修改或删除 |
| 目标 `bangbang_aliyun_authority` | 完整导入校验 marker | 正式 v3 验证通过才允许启用；后续导入使旧验证失效 |

家人表记录数不等于家庭数；pair 的当前 request/outbox 也不是完整历史会话账本。永久 claims、撤销墓碑和推送所有权不能按诊断 TTL 删除。当前有界维护只清超过 10 分钟的 `push-ready/` 和 `rate-limits/`，每类至多 500 条，永久记录增长需单独监控。

D1 使用主库读取和 ETag 条件写；单记录最多 128KiB、分页 128 条。ECS 保留同一存储接口，用 SQLite WAL、`synchronous=FULL`、5 秒 busy timeout；批次使用真实 `BEGIN IMMEDIATE`。目录 0700、数据库 0600，启动拒绝缺失数据库，不自动建空库；只有显式 init 能建新文件且拒绝覆盖既有库。当前设计只运行一个业务实例，不能多机共享 SQLite 文件。

## 5. 系统通知与呼叫提醒

### 5.1 已实现的投递机制

`push.register` 保存一个安装的当前注册。原 token 只在私有设备记录中存在，ownership 使用 `SHA256(provider:token)` 和注册代次；轮换、旧注销及跨安装重放不能误删新 token。APNs topic/environment、FCM appId/projectId 必须匹配服务配置，返回 `unconfigured / missingClient / mismatch / matched`；`deliveryConfigured` 只表示配置匹配。

`request.create` 先写分钟发现标记，在 pair 的同一次 CAS 中提交 request 与 pushOutbox，再尝试一次有界发送；provider 失败不撤销已经创建的求助。持久 claim/lease 为 15 秒，最多尝试 3 次；retry 至少退避 15/30 秒，FCM 限流至少 60 秒。超时、断连或进程中断导致发送结果不确定时记为 `unknown`，避免盲目再次响铃。已经提交给系统的通知不能通过服务端取消来保证召回。

调度器只扫描最近 3 个分钟桶，最多 4 项并行；ECS 每 15 秒串行触发一次 sweep，维护模式暂停。Sites 有 scheduled 和独立 HMAC dispatch 实现，但当前生产定时触发及完整 provider 配置未验收。每安装每分钟最多 6 次 token 变更、4 次发送，关系新请求仍受 15 秒间隔保护。

### 5.2 上线前必须补齐

| 环节 | 需要交付 | 验收边界 |
| --- | --- | --- |
| iOS | App 推送 entitlement、环境、topic；服务端独立 APNs team/key/私钥；真实 HTTP/2 provider 路径 | 开发包 sandbox 与 TestFlight 生产环境分别验；能签名不代表具备服务端 APNs 凭据 |
| Android | 明确 FCM 可用设备范围；必要时单独评估国内厂商通道 | 当前没有国内厂商 provider，不能对所有国内安卓承诺后台到达 |
| 调度 | 生产触发、最后执行时间、outbox 结果与积压监测 | 注册配置 matched 和 provider accepted 均不等于设备实收 |
| 提醒与操作 | 前台卡片、普通系统通知、接听/拒接；权限关闭后的清晰提示 | 通知点击先 `push.resolve` 再认证拉取当前请求；不得自动接听或跳过共享授权 |
| 新观测 | 设备收到/展示、通知点击、实际接听的有限回执 | 新协议待建设；分别计算到达率与接听率，说明系统状态和样本 |
| 异常 | 重复、取消后迟到、撤销后迟到、token 轮换、后台/锁屏和进程回收 | 过期 request 不再打开原生会话；不能把已送达通知的撤回写成保证 |

先验收普通通知与接听体验，再评估系统通话界面。CallKit、PushKit、安卓通话/全屏提醒的使用资格和审核要求在实施前单独核对；当前未接入这些电话 API，也没有独立语音通话产品。详见 [推送方案](PUSH_DELIVERY.md)。

## 6. 诊断、统计与管理

### 6.1 当前采集

新版默认上传到服务 Site `/v1/attempts`，用户可关闭。失败保留本机队列，4 秒超时、60 秒退避，不阻塞协助；本机最多 100 条/7 天，每次 flush 最多处理 20 条，当前客户端逐条发送，服务端另支持 1–20 条批次。

协议 v1 严格允许 15 个字段：`v, attemptId, callId, role, kind, platform, appVersion, build, startedAt, elapsedMs, phase, outcome, error, path, revision`。`kind` 为 connection/preparation/call，path 为 unknown/direct/relay。success 必须对应 firstFrame；ready 仅用于 preparation/serviceReady。耗时上限 600000ms、revision 0–64，开始时间允许最近 7 天到未来 5 分钟。

存储使用域分离 HMAC，不存原安装 Bearer、原 attemptId/callId；不接受画面、昵称、手机号、邀请码、剪贴板、原始异常文本。原始推送 token 及家人记录的保护属于另一数据域，不能据诊断脱敏声称整个业务数据库不含私有标识。中继 journal 可能含 IP/peerId，不能公开为诊断附件。

每 `(scope, installation_hash, attempt_hash)` 只有一条当前记录。仅 pending 接受更高 revision，且耗时/阶段不能倒退、不可变字段必须一致；这不是每一阶段独立追加的事件流。

### 6.2 当前保护上限与报表

| 限制 | 当前值 |
| --- | --- |
| 入口 | 共享出口 6000 请求/分钟；完整规范设备 Bearer 摘要 180 请求/分钟，错误 secret 不消耗真实安装桶 |
| 诊断正文 | 单条 2KiB，批次 1–20 条，总正文 16KiB |
| 安装诊断预算 | 每分钟 60 请求/300 条目 |
| scope 诊断预算 | 每分钟 300 请求/1000 条目；每日 10000 请求/10000 条目 |
| 诊断管理预算 | summary/cleanup 共用每分钟 4 次、每日 20 次 |
| 清理 | 合法上传或管理员调用时，每次最多删 500 条过期诊断和 500 个限流桶 |

条目预算包含修订、重试和重复补报，不等于独立协助次数；这些是应用保护值，不是托管套餐额度。空闲期尚无已配置的周期删除，需补有界定时清理和告警，才能把 7 天写成严格物理留存承诺。

现有 summary 只统计 `kind=connection, role=helper`，成功率为 `success/(success+failure)`，取消/中断/pending 单列。按最终记录阶段、路径、平台及失败错误分组；首帧仅对 `<600000ms` 的成功样本求均值，截断样本另计。appVersion/build 虽已保存，当前查询未按其分组。现有页面没有全流程漏斗、版本趋势、P50/P95、协助完成率、relay 用量或计费能力。

### 6.3 待建设的最小观测

不修改 v1 白名单偷塞新字段。建议版本化增加有限的呼叫事件，保留幂等 eventId 和关联呼叫的 HMAC、明确事件来源与阶段时钟；老客户端继续 v1。具体事件包含求助意图、准备结果、请求持久化、设备实收、接听/拒接、授权、首帧、中断/恢复和正常结束。客户端时钟差、离线迟报、修订、取消和缺失回执必须单列。

日汇总新增日期、App 版本/build、平台、路径、失败类别、样本数和分位数；完整求助漏斗采用同一 call 标识去重。首帧从必要授权完成计时，呼叫等待独立；流畅度用客户端有限采样或专门验收录像，不把首帧指标当控制反馈延迟。在线明细为 7 日查询及清理窗口，物理清理另实现；长期统计只留聚合，新增周期备份建议排除诊断明细。正式迁移临时快照保留完整三表，但保存及销毁期限单独审核，不能声称所有副本均在 7 日删除。

维护后台现有 `/`、`/admin` 只是公开页面外壳；统计输入独立管理 Bearer，秘密留页面内存、不进入 URL/浏览器持久存储，离页清除。新增一页私有运维视图：唯一权威、开关、版本、API 错误/限流、推送配置与扫队列结果、数据库/WAL/磁盘、relay 带宽和备份年龄。先提供聚合，不暴露家庭详情；诊断管理的每日 20 次额度不适合定时刷屏，需独立缓存汇总与监控预算。完整管理员账号/RBAC 尚未实现。

## 7. 阿里云迁移：唯一权威与回退

### 7.1 正式切换门槛

以下按 [完整迁移操作单](ALIYUN_DATA_CUTOVER.md) 执行，不能跳过源端证明。

1. **目标先就绪。** 验收真实公网 HTTPS、代理授权及可达性；准备并演练冻结前后的管理员恢复流程。现有 Caddy 回环映射测试不能替代这一项。
2. **排空旧发送者。** 关闭源 family/diagnostics、外部调度和所有写入口，证明旧 provider 历史未启用或真实任务/进程已经排空。当前未配置 provider、一个布尔开关或 `pendingDispatch=0` 不单独证明历史无在途调用。
3. **数据库实际冻结。** 精确核验控制表与 13 个触发器；一次原子 SQL 验证零 sending/残留 claim/lease 并插入 epoch。前后均验证 DDL 和 epoch，旧 Worker/旧 prepared statement 也受触发器约束。HTTP 不提供 thaw。
4. **可信源快照。** 用独立认证 HEAD 获取 digest、source epoch、counts、configFingerprint，再 GET `BBAE1` 加密包；RSA4096-OAEP 包装 AES256-GCM 密钥，离线解密。公开 SHA 或文件自带 proof 不是来源签名，不能拿待导入文件自己的摘要充当独立来源证据。
5. **停写导入与全量复核。** 新正式 SQLite 保持关闭，insert-only；同内容幂等，冲突、额外或缺失行拒绝。全三表规范摘要、数量及原 HMAC namespace 一致后才产生 activation marker。v2 rehearsal 和跨批部分完成永远不能启用。
6. **只切一个权威。** 私有目标验收后先发布 `--authority ecs` 永久入口，再受控启用 ECS family/diagnostics，最后启用 Sites 对应开关。入口产物不导入 D1 业务模块；代理错误或配置全部丢失都返回失败，不恢复旧库。撤除临时导出/迁移授权，再验收保存家人、求助、接听、首帧、结束、重放拒绝及诊断连续性。

必须保留安装验证、pair capability、serverScope、撤销/永久 claims、push ownership、原 updated_at/TTL、诊断 HMAC 和已有预算。配置连续性指纹由 scope 与诊断 HMAC 定义；推送、代理、管理员凭据的轮换仍要独立安排，不能误当 namespace 变化。

### 7.2 容量限制与实际演练

通用快照验证最多 128MiB、每表 10 万行；**当前 Worker 导出更严格**：每表 2048 行、预估 4MiB、实际明文 8MiB。家人导入每批最多 32 行/1MiB，诊断每批 128 行。生产增长超出源导出门槛时先实现有界分段、停写一致性和独立摘要协议，不能只提高下游 CLI 上限或截断快照。1,000 安装加配对、claims 和 7 日诊断很可能超过该导出行数，要在扩试前处理。

现有私有演练读入 family 41、attempts 6、limits 9，`activationEligible=false`；41 是混合家人记录，不是 41 个家庭。真实 ECS 受控目录 168/168 检查、重启和 v3→v2b→v3 代码回退通过，正式四表仍空。受控 HTTP、代理、SQLite、Caddy 成功不能替代正式 Sites→ECS 公网 TLS 和真机链路。

### 7.3 回退规则

发行代码可以原子切回 previous，数据库和中继身份不回滚。目标尚未写入时，回源也需要已演练的管理员数据库恢复来解除源冻结，恢复旧 Worker/env 本身无效；当前没有 HTTP/CLI 自动解冻。

ECS 首次写入后旧 D1 已过时，不能直接开旧库或用旧 Netlify 21 条备份“恢复”。需要暂停目标，导出最新完整状态并另行验收反向迁移；当前工具没有覆盖旧 D1 的反向切换流程。正式冻结前必须确定维护窗口、负责人和已验证恢复路径，否则不执行切换。

## 8. 部署、维护与备份

### 8.1 当前运行隔离

| 服务 | 代码与持久目录 | 保护边界 |
| --- | --- | --- |
| `bangbang-family.service` | `/opt/bangbang` → v3 只读发行目录；`/var/lib/bangbang` 为私有 SQLite 卷 | 受限 bangbang 用户；heap 384MiB、MemoryMax 768MiB；无 capabilities、只读系统、唯一可写数据目录 |
| `bangbang-hbbs.service` / `bangbang-hbbr.service` | 固定官方二进制及 manifest；`/var/lib/bangbang-relay` 保存密钥和 DB | 独立受限用户，目录 0700；hbbs 256MiB、hbbr 384MiB 内存上限；升级保留原身份 |
| `bangbang-web-loopback.service` | `/var/www/bangbang` 固定网页；独立网页部署器位于 `/opt/bangbang-web` | 文件 0444、目录 0555，current/previous 原子指针；只有回环 HTTP |

运行 env 在 `/etc/bangbang` 或独立中继配置目录，文件 0600；密钥不进源码、命令参数、公开构建信息和 journal。用途分离：设备身份、内部撤销、推送 provider、dispatch、代理、诊断 HMAC、管理、迁移、发布附件和备份授权不得互换。

Node 仅接受回环 host，转发 IP 默认丢弃；只有通过独立代理秘密的可信单个 client IP 才用于限流。请求头上限 8KiB、请求截止 15 秒、头截止 10 秒、keepalive 5 秒；正文按路径限定，chunked 同样有界。错误只返回固定分类，不返回 SQL、provider 原文或秘密。上线 TLS 接入使用同一个明确的反向代理入口，避免两个进程争用 80/443。

### 8.2 监控与恢复：待补齐

建议先增加外部 API 健康探测、内部独立原生登记探测、资源阈值和备份年龄告警。必须分别显示 API 可读、family 开关、发现协议、relay 负载、provider 配置/调度和真机体验，不能用一个绿色总灯推导全部正常。单 ECS 故障是共同风险，备份不等于高可用。

现有 R2 私有备份仅为固定 `migration-20261003.bgbak`、最多 2MiB、不可覆盖的 AES-GCM 封装；已验证旧 Netlify 21 条记录读回解密一致。它不覆盖后来 D1 数据，不支持通用列表/删除或周期恢复。BBAE1 正式迁移导出是另一套限时操作，不能混作已配置的灾备。

按 `SDEC-04/05` 建议新增独立的周期灾备格式：从一致性读取生成家人持久状态、预算、必要配置及日聚合备份，**不包含诊断尝试明细**，并另备份中继身份。需要定义自己的 schema、摘要和恢复验证，不能复用或削弱正式三表迁移 v3 的全量激活规则。加密后存第二故障域，解密密钥另存受限安全副本；不能直接复制正在 WAL 写入的主数据库文件当完整备份。建议保留 7 份日备份和 4 份周备份，计算密文大小/恢复摘要；月度在独立目录演练恢复，并验证求助、终态和旧凭据拒绝。RPO 24 小时/RTO 2 小时是待建设目标，完整迁移临时包的销毁计划另审。

复用 R2 需要新增经审核的有界备份命名、容量/保留/授权和账户额度核对，现有固定接口不够。服务器本地备份只帮助版本操作，无法覆盖整台机器丢失。OSS 未启用，本稿不默认新增 Bucket、费用或公开日志。

## 9. 1,000 安装以内的容量与成本

### 9.1 最小压测场景

| 维度 | 建议场景 | 需观察 |
| --- | --- | --- |
| 业务规模 | 1000 安装及真实分布的配对/claims | 表/索引大小、永久记录增长、快照限制、恢复耗时 |
| 前台活跃 | 20 台、每 2 秒 poll，另叠加 register/progress/结束与诊断 | 基础约 10 poll/s，600 poll/min；实际请求和 CAS/限流写入更多，测 API P95、锁等待和 CPU |
| 共享出口 | 运营商 CGNAT、多安装同出口 | 入口共享 6000/min 及 relay 每 IP 保护是否误限正常家庭 |
| 原生会话 | 先一路低码率 relay，同时保留 API 和运维流量 | 实际双向计数、帧率、队列、操作反馈和网络抖动 |
| 故障 | API 断连、provider 超时、重启、满盘及网络恢复 | 原生健康会话、本机停止、终态、防重放和无跨库写入 |

这些是建议测试负载，不是已实施的硬会话上限。20 台活跃包含双方设备，不能直接推导为 20 路协助；1,000 台若都按 2 秒轮询，光 poll 就是 500/s、30000/min，现有方案没有该容量证明。将来增加空闲退避、抖动或长连接前要保留来电时延和终态一致性验收。

### 9.2 3Mbps 中继的实际约束

当前限制为 `TOTAL_BANDWIDTH=2`、`SINGLE_BANDWIDTH=1.5`、`LIMIT_SPEED=0.75`，按程序二进制单位约为总 2097152bit/s、单连接 1572864bit/s、降级 786432bit/s；降级阈值 0.90、检查起点 30 秒。上下行都参与限制，数值不是按家庭的可靠配额，也没有严格的一路呼叫准入器。

能直连时保留直连，强制所有流量走 relay 会集中消耗有限出口。新增容量保护需使用真实并发/流量：协商降码率、优先控制反馈，饱和时限制新会话并给出清楚提示；需两端配合，不能仅调 Linux 限速保证流畅。API、系统和各服务内存上限总和必须留余量，MemoryMax 不是内存预留或容量报告。

中继只获授权放通 TCP 21115–21117、UDP 21116。WS 21118/21119 可在服务内监听，但有主机防护且未获准放通云规则；本机公网负向测试存在网络干扰，不能写成所有关闭端口已经独立外网验证。每 IP 的 TCP/UDP 防护不能替代安装鉴权或会员配额，并需关注运营商共享出口的误伤。

当前 OSS 发现/中继没有把帮帮安装身份或家庭权益接到原生会话准入。服务器公钥用于验证身份，不是秘密访问口令；仅增加家人 API 的会员判断无法约束绕过 API 使用原生 relay 的客户端。收费或扩大公网使用前需另验中继滥用监测、可信准入及有界流量策略。

### 9.3 成本核算

先记真实月成本：ECS 实际续费/套餐、托管请求与存储、relay 流量、域名、通知/未来验证码、支付渠道和退款。APK/源码大附件不经 3Mbps ECS；日志上传有预算，永久安全记录不能为了省空间直接删除。

用实测数据估算：`月中继用量 ≈ 中继分钟 × 实测平均双向流量/分钟`；`月贡献 = 到账收入 − 渠道/退款 − 增量带宽/请求/存储 − 支持成本`，再扣固定资源得到经营结果。价格、免费额度及学生优惠以实际合同和实施时核对为准，本文不提供未核对的市场价格或盈亏承诺。

## 10. 可靠传输的后续方案

当前官方 OSS hbbs 的被控端注册依赖 UDP `RegisterPeer/RegisterPk`。客户端已有 UDP→TCP 回退，但该服务版本的 TCP/WS 路径不接受这些注册消息；所以“TCP 端口通”“NAT 探测成功”“进入回退”都不能证明可登记。不能把 TCP 或 WebSocket 直接设为最稳默认。

| 路线 | 本期选择与下一项验证 | 状态 |
| --- | --- | --- |
| 现有原生直连/relay | 统一可取消总截止、注册与会话回退分别测；使用同一版本的真实首帧、点击与网络矩阵 | 已有实现及模拟器证据，真机/跨网未达验收 |
| ECS 默认远控 | 两端受信 profile 一致、原 key 持久；旧家人 serverScope 保护 | opt-in 有证据，不能直接全量改默认 |
| WSS/443 | 先确认服务器支持注册和媒体路径，再设计 TLS、路由和鉴权 | 当前 ECS 无已开放 WSS/443 fallback；给家人 API 加 WS 不能替代画面传输 |
| WebRTC / RTC 库 | Android 采集及控制、iOS 显示与输入；对照现有引擎验证首帧、反馈、弱网、兼容、许可证与 relay 费用 | 研究候选，不是已接入；选型时重新核对当前 SDK 和平台规则 |

BB1 邀请只携带 peerId，不携带服务器与 key。`aliyun-ecs-v1` 和 `restore-managed` 为显式受控 profile，公开 0.1.4 的 profile 为空；不覆盖用户自设配置。serverScope 包含服务配置绑定，IP 改域名或更换 key 也可能影响已有关系。

建议 BB2 携带受信配置标识和版本，经签名/白名单配置映射，不接受分享者任意指定 host/key；旧 BB1 按旧范围兼容，切换前明确两端一致。签名配置、BB2、UDP 受限注册备用路径和满载准入均需实现后验收。详细历史研究见 [传输评估](TRANSPORT_RELIABILITY_OPTIONS.md)、[流畅度](REMOTE_PERFORMANCE.md)；其中早期预编译库和服务部署描述不代表当前 0.1.4 构建。

## 11. 后续账号与家庭订阅

新增身份域区分 installation、可恢复 user、household、membership、remote pair。长辈保持安装即用和日常无表单；家人需要换机恢复、管理或购买时再完成可信登录。账号绑定需证明安装所有权，不能接受客户端自报 userId；关系迁移、退出、被移除及设备撤销分别定义。

家庭订阅由一位家人管理付款，产品家庭权益与系统商店家庭共享是不同概念。后续服务端验证交易、original transaction 唯一家庭归属、签名回调、恢复、到期与退款；事件幂等及乱序处理，不把截图或客户端“已付款”当到账。

权益检查安排在新协助开始前，结束/撤销及必要清理永远可用，续费失败不应突然打断正在进行的关键协助。若按分钟提供额度，另建可信预约/用量账本：服务端时间、有界租约、双端确认与幂等结算，并定义中断宽限和争议规则。当前 request.progress、单端诊断、pair 当前状态均不能直接做收费凭据，relay 字节也不等于协助分钟。

独立基础模块只能按 [家庭账号与订阅方案](ACCOUNT_SUBSCRIPTION_PLAN.md) 逐步接入同一权威，不能启用第二份 household SQLite 形成用户/权益分裂。候选价格和分钟数仍待审核；本稿不新增支付、短信或会员开关。

## 12. 实施顺序、审核与验收

| 工作包 | 对应需求 | 完成门槛 |
| --- | --- | --- |
| A 连接和状态基线 | SFR-01–05、07 | 同一候选真机 iPhone→Android、Android→Android，首装/已配对/拒接/取消/挂断；Wi-Fi/蜂窝、直连/relay 分开，达到 PRD 建议目标后发布 |
| B 通知和最小观测 | SFR-06–07、09 | 环境/凭据/调度实际配置、后台/锁屏实收及迟到拒绝；版本报表、分位数、明确采集口径和有界清理 |
| C 正式业务迁移 | SFR-08、10 | 源发送历史排空、真实冻结、独立 HEAD、v3 全量一致、永久 ecs-only、真实公网 TLS、恢复路径与业务验收 |
| D 默认远控与容量 | SFR-04、09 | BB1/BB2 兼容、受信 profile、旧关系保护、UDP 受限回退和低带宽准入；不以协议端口通代替画面验收 |
| E 发布与灾备 | SFR-10–11 | Gitee 可安装包、官网/版本 manifest 一致；周期加密备份、实际恢复；iOS 按真实 Apple 状态展示 |
| F 家庭商业基础 | SFR-12 | 可信账号绑定、沙盒购买/恢复/退款、权益/用量一致和真实成本模型；不影响免登录基础流程及本机授权 |

连接与流畅度优先；B 与 C 的准备可以并行。每项留存版本、环境、设备和网络、期望/实测、异常及脱敏摘要。受控/JVM/Node/模拟器、ECS 回环、正式公网、真实手机和后台通知的结果分别报告，不能互相替代。

主要审核点直接见 [产品决策 SDEC-01–06](PRD-bangbang-server.md)：权威和切换顺序、负载场景、后台提醒范围、留存、恢复目标、收费时机。技术审核另外确认源导出 2048 行扩展、CGNAT 限流与 relay 准入、BB2 受信配置，以及目标写入后的反向迁移预案。

## 13. 实现与证据索引

| 主题 | 入口 |
| --- | --- |
| 家人协议及状态机 | [family-service.mjs](../site/server/family-service.mjs)、[Sites 适配与限流](../site/server/sites_family_service.mjs)、[客户端 FamilyService](../flutter/lib/qinban/family_service.dart) |
| 业务存储 | [D1 存储](../site/server/sites_family_store.mjs)、[SQLite](../backend/aliyun/sqlite.mjs)、[ECS HTTP](../backend/aliyun/http.mjs)、[ECS 应用](../backend/aliyun/service.mjs) |
| 推送 | [注册与 outbox](../site/server/push-delivery.mjs)、[provider](../site/server/push-providers.mjs)、[调度](../site/server/push-dispatcher.mjs)、[推送专项](PUSH_DELIVERY.md) |
| 诊断 | [字段校验](../backend/diagnostics/worker.mjs)、[D1 诊断与聚合](../site/server/sites_diagnostics_store.mjs)、[客户端队列](../flutter/lib/qinban/connection_diagnostics.dart) |
| 迁移 | [源冻结](../site/worker/authority-fence.mjs)、[限时导出](../site/worker/authority-export.mjs)、[快照导入](../backend/aliyun/snapshot.mjs)、[永久入口](../site/worker/ecs-only.mjs)、[操作单](ALIYUN_DATA_CUTOVER.md) |
| 中继与真实验收 | [中继部署](ALIYUN_RELAY.md)、[固定发行清单](../backend/aliyun/relay/release.json)、[2026-10-04 验真](ALIYUN_VALIDATION_20261004.md)、[原生会话恢复](ACTIVE_CALL_RECOVERY.md) |
| 分发与备份 | [固定发布附件](../site/worker/releases.mjs)、[旧加密备份](../site/worker/backups.mjs)、[静态部署](../backend/aliyun/web/README.md)、[0.1.4 发布](releases/0.1.4.md)、[iOS 状态](IOS_TESTFLIGHT.md) |

引用历史操作记录时使用其标注日期；当前基线以第 1 节和最新发布为准。完整家庭快照、密钥、token、原始设备记录及操作证据仅留受限忽略目录，不随审核稿或公共安装站分发。
