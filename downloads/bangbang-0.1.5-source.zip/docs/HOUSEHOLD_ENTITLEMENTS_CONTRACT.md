# 家庭权益与用量计算契约

2026-10-02 · 本地基础模块，未接入生产接口或收费。

实现：`site/server/household-entitlements.mjs`。测试：`node --test site/server/household-entitlements.test.mjs`。

## 输入信任边界

仅供后端内部调用。调用方先认证请求身份并核验其家庭成员资格，从服务端数据库读取 familyId 和经平台验证的规范订阅记录，再传入模块。函数接收的ID和订阅对象本身不构成认证证据。不得将HTTP请求体、客户端购买成功回调或自报的 `verified: true` 直接转换成参数。

`familyId`、`callId`为长度1～128的ASCII字母、数字、下划线或短横线opaque ID，不含手机号或设备号。所有时间均为非负、安全整数的Unix毫秒，由可信服务端/计量适配提供。

## householdEntitlement

参数：`{ familyId, subscription, now, freePolicy, paidPolicy }`。

- `subscription=null`返回免费策略。规范订阅包含同一familyId、status、startsAt、expiresAt；status仅允许active/grace/expired/revoked。
- 有效区间为左闭右开；尚未开始或当前时间等于到期时间时没有付费权益。
- grace必须由支付平台确认并提供晚于expiresAt的graceExpiresAt；客户端扣款失败不是宽限依据。
- expired/revoked立即回到免费，不能因旧expiresAt仍在未来继续授权。异步回调乱序须在上游规范订阅适配器解决。
- 两种策略均由服务端配置，字段allowanceSeconds、maxMembers、maxConcurrentCalls。模块无价格、SKU或商业默认额度。
- 返回tier、配置额度、人数/并发上限、validUntil。返回结果不是远控授权、家庭加入许可或原子额度预留。

## householdUsage

参数：`{ familyId, startsAt, endsAt, allowanceSeconds, records }`。

可信已结束协助记录：`{ familyId, callId, connectedAt, endedAt, route }`；route为direct/relay/unknown。未接通不生成记录；进行中会话、画面FPS和客户端连接诊断不能用于结算。混合路线无法确认时归unknown，未来可另扩独立成本分段表，不对同callId塞多个互相冲突的结算记录。

- 账期和会话区间均左闭右开，按重叠部分累计毫秒。跨账期两次汇总不会重复取整。
- 相同callId且内容一致只算一次，重传幂等；时间/路线冲突拒绝整次计算，留给对账处理，不能静默改账。
- 直连、中继、未知路线均计入协助额度，路线分类仅用于诊断/成本分析。不同家庭记录拒绝，禁止跨户共享额度。
- 返回usedMilliseconds、remainingMilliseconds、exceededMilliseconds、各路线毫秒和该账期非零区间的call数。
- 最多10000条输入，超限要求分账期查询或真正的数据库聚合；不静默截断。不按每次协助向上取整，UI显示分钟的舍入不能回写账本。去重只涵盖单次输入，持久计量需要数据库 `(familyId, callId)` 唯一约束；跨账期的connectedCalls不可直接相加当作全局唯一通话数。

## 接入前还缺什么

身份/成员校验、数据库持久化、交易签名验证、退款乱序处理、原始购买单家庭绑定、原子用量预留、会话票据与中继可信计量、断线对账及审计均尚未由本模块实现。不能先用本函数挡住UI就宣称可收费或已防额度绕过。详见 [家庭订阅方案](ACCOUNT_SUBSCRIPTION_PLAN.md)。
