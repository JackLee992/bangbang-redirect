# Android 0.1.3（18）Gitee 与网站交付记录

用户已将公开 APK 分发改为 Gitee Release。Gitee 仓库只维护发布信息和安装包，对应源码使用既有独立合规渠道；不再推进 R2 APK 或 OSS 默认发布方案。

本记录交接可复核的固定产物和实际发布进度。私有 GitHub 的 `v0.1.3` 已发布为预览版，目标仍为 APK 源码 `b8bbd580…`；四个原冻结附件的真实名称与 API 长度均已核对。[Gitee APK](https://gitee.com/yilin-dev/bangbang-releases/releases/download/v0.1.3/bangbang-0.1.3-arm.apk) 及两个小附件已实际公开，并完成匿名全量下载 SHA 验真。APK 本次由根代理通过 Gitee 官方浏览器上传，之前两次 CI 上传因网络失败；不能写成新 APK 的自动上传已经验真。根代理现已完成原下载 Site 与产品域名的静态首页切换；本轮未安装手机。

根代理已在既有 Sites R2 单独提供本版本对应源码，并完成匿名全量 SHA、HEAD 和 Range 验真；新 APK 未上传 R2。服务随后已晋升到 Site 版本 9 / 环境 11，源码 `f2bac3b5d8994567ff3867104b70a27ce4215489`；`/api/version` 实际返回 0.1.3 和 Gitee APK 地址。7,770 字节完整 `BUILD_INFO` 已公开并完成匿名 SHA / Range 验真，上传开关已关闭并实际验证 403。`site/release.json` 和 `site/releases/0.1.3.json` 已同步实际 `android.downloadUrl`，两份字节一致、SHA-256 为 `7c2f6e2a1415baee4da40aa00aa844456d4cf60df3954c750d30692329431672`；APK、source、完整 build-info 校验值与来源保持不变。提交和后续网页发布由根代理整合。

## 固定来源与验收

| 项目 | 固定对象 |
| --- | --- |
| APK / 对应产品源码 | `b8bbd580c22aba7543e717c686f1c056fb28bb78` |
| 固定 `hbb_common` | `7e1c392c62d39c364127307cd408421dd5f8cfb0` |
| 三 ABI 原生构建、聚合、签名 APK | [37089840907](https://github.com/JackLee992/bangbang-android/actions/runs/37089840907)，`interface`、三个 `native-*`、`apk` 作业通过 |
| 同一 APK 完整双模拟器重验 | [37097853972](https://github.com/JackLee992/bangbang-android/actions/runs/37097853972)，实际完整流程通过 |
| 独立验收脚本来源 | `353bb2acd4eb257ab9ccd2968045114f789489ea` |
| 验收 x86_64 APK SHA-256 | `b1a85c252146cecfdeb4d152898ee34dd9351221075aacddd29b83be9bafa5a2` |
| 原签名证书 SHA-256 | `af793353035d26390f3f4c577194576f50d613e9fdf1144f43e05eecdb95da83` |

## GitHub 与自动发布进度

[私有 GitHub 预览版 v0.1.3](https://github.com/JackLee992/bangbang-android/releases/tag/v0.1.3) 的 `draft=false`、`prerelease=true`、`target_commitish=b8bbd580c22aba7543e717c686f1c056fb28bb78`。API 核对的四个附件为：

| 文件 | 实际字节数 |
| --- | ---: |
| `bangbang-0.1.3-arm.apk` | 49,169,392 |
| `bangbang-0.1.3-source.zip` | 14,249,404 |
| `build-info.json` | 7,770 |
| `SHA256SUMS` | 263 |

自动同步脚本来源为默认分支 `97a4c5b9c4f73ff6ad9327ea37f44101916c39e5`，不替代 APK 的源码提交，也没有以默认分支的新生产改动重编译安装包。[真实只读验真 37104272807](https://github.com/JackLee992/bangbang-android/actions/runs/37104272807) 已成功，23 项自动发布回归通过。发布所用 `GITEE_TOKEN` 已由用户明确批准并安全保存，文档和仓库不记录令牌值。

[首个真实同步 37104707402](https://github.com/JackLee992/bangbang-android/actions/runs/37104707402) 已创建 Gitee Release `id=1181257`，两个小附件实际到达并完成匿名全量下载验真。CI 的新 APK 上传因网络失败，随后根代理通过官方浏览器上传同一冻结 APK，附件 `id=3311128`；实际公开下载为 49,169,392 字节、SHA-256 `628c6183febae70f0a8159e86caef7a80f37d6b7d2b0a48cbab267ddeb1a9af6`。证据 `gitee-release/gitee-publication-verification.json` 的 `cloud_verified=true`、`automatic_new_apk_upload_verified=false`，两者不能混写。

0.1.3 APK 原生引擎是固定源码自编的 ARM64、ARMv7、x86_64 完整交付。公开 ARM APK 的原字节、源码/桥接/锁文件、三 ABI manifests、ELF、各原生库与证书的既有门禁输入已重新核对 SHA，未重新编译或签名。两个 ARM `libapp.so` 均含新的 Sites 服务、下载站及旧 Netlify 兼容域名。

原构建的 `devices` 步骤和第一次独立重验曾在图像匹配处失败，历史没有改写。后续验收通过实际本地收起按钮处理覆盖层，保留严格 `>0.8`；完整文字/图标实际匹配为 `0.9419595599`，随后真实远程点击打开帮助页，另一端视频更新，手机主人结束后 `MediaProjection` 为 `null`。99 项相关受控回归和 35 项网站构建/下载路由回归通过，无跳过。

该证据来自同一 runner 上两台 Android 35 x86_64 模拟器。Quickstep 系统桌面 ANR 提示被既有明确平台提示处理记录；不能写成没有任何系统告警。iPhone → Android、真机跨网、弱网及长时流畅度仍待验证。APK 推送配置为 `none`，未宣称生产后台通知已送达。iOS 下载状态继续保留 `pending`。

自动发布后续修复已到默认分支 `c6b799613cedfd97bd2339fa5cec9f8843bdc43c`：恢复标准TLS默认值、匿名诊断非阻塞，并仅兼容发行说明CRLF换行，实际正文和其他门禁不变。40项回归通过。[只读37110789080](https://github.com/JackLee992/bangbang-android/actions/runs/37110789080)与[真实续跑37110941079](https://github.com/JackLee992/bangbang-android/actions/runs/37110941079)均成功，三个附件全SHA匹配并输出unchanged，无重复写入；新APK首次自动大文件上传仍未证明。

## Gitee 附件状态

Gitee 公开以下三项附件，不上传产品源码：

| 文件 | 字节数 | SHA-256 | 状态 |
| --- | ---: | --- | --- |
| `bangbang-0.1.3-arm.apk` | 49,169,392 | `628c6183febae70f0a8159e86caef7a80f37d6b7d2b0a48cbab267ddeb1a9af6` | 官方浏览器上传，匿名完整下载验真 |
| `SHA256SUMS` | 89 | `3c9b2c84582fcc752f638cfa70adad19acae6dc58ce8974636a26278d89544d7` | 已上传，匿名完整下载验真 |
| `build-info.json`（最小公开信息） | 1,262 | `9cef8d1d04b7a836d230fe4b7d31cfb633eabfaabb01d3ea6a8a6c3ef7de49d3` | 已上传，匿名完整下载验真 |

Gitee 校验清单只有 APK 一行；不能误上传下面完整审计目录中的三项校验清单或源码 ZIP。上表的 1,262 字节最小信息是自动发布工具生成的派生资料，独立注明 SHA；它与 GitHub / 对应源码中保留的 7,770 字节完整构建信息不同，不能替换网站的 `buildInfoSha256` 或完整冻结产物。

先前本机 `artifacts/android-release-0.1.3-18/gitee-release/assets/` 保存原 APK、89 字节校验清单和 7,770 字节完整构建信息，作为原字节复核目录保留，不是本次实际最小附件的来源证明。简短说明草稿在 `gitee-release/release-notes-draft.md`。GitHub → Gitee 自动发布由另一个 agent 维护，根代理负责授权和执行；本次 APK 已用官方浏览器补齐，后续新包自动上传仍需修复网络路径并实际验真。

Gitee 平台自动显示的 `Source code ZIP` 是下载仓库 README 外壳的归档，不是帮帮产品源码，也不是安装文件。用户要求 Gitee 只分发安装 APK；此说明仅写在开发交接中，不增加到宣发首页。

许可链接使用 [GNU 官方 AGPL v3](https://www.gnu.org/licenses/agpl-3.0.en.html)。当前 GitHub 项目经 API 确认为私有，不能把其源码或许可证链接当作公众可访问的渠道。[0.1.3 对应源码](https://bangbang-services.s419505080.chatgpt.site/downloads/bangbang-0.1.3-source.zip) 已公开：匿名完整 GET 为 14,249,404 字节、SHA-256 `b0b2e3736bf5534b7f19188a25881407e537d956f1c45589487fb6fa653c2964`，HEAD 200、Range 206。根代理已撤除临时上传凭据、关闭上传开关，并确认原凭据 PUT 返回 403。宣发首页不新增源码入口。

构建器已支持 `android.downloadUrl`：严格验证固定 Gitee Release 附件路径与当前 APK 文件名，再优先应用到 HTML、邀请资源和 `deployment.downloads.android`。未配置或 `null` 保留旧相对 / download-base 路径，非法值直接报错；source URL 继续使用独立 download base。与服务端受信地址合同一致的 12 项专用回归、总计 54 项相关构建与下载路由回归均通过，无跳过。使用 Gitee 地址仍需原 APK、源码和构建信息完整性门禁，失败时保留原输出。

## 本机完整审计资产

根目录：`artifacts/android-release-0.1.3-18/assets/`。这是保留的六项完整审计资产，不是 Gitee 上传目录；不包含 x86_64 验收 APK、SDK/编译缓存、原始日志、截图、安装身份、密钥、开发 IPA 或数据库备份。

| 文件 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `bangbang-0.1.3-arm.apk` | 49,169,392 | `628c6183febae70f0a8159e86caef7a80f37d6b7d2b0a48cbab267ddeb1a9af6` |
| `bangbang-0.1.3-source.zip` | 14,249,404 | `b0b2e3736bf5534b7f19188a25881407e537d956f1c45589487fb6fa653c2964` |
| `build-info.json` | 7,770 | `801074b39b4080cb7e983f2654f85a39cdb016f61e91479e6cdb928dfb36dd8b` |
| `AGPL-3.0.txt` | 34,523 | `8486a10c4393cee1c25392769ddd3b2d6c242d6ec7928e1414efff7dfb2f07ef` |
| `SHA256SUMS` | 263 | `67a40c247ddf8c90a140e85f47a84c76ffe7101fb7999bcd1a3016e1cb9a3a8b` |
| `manifest.json` | 902 | `1df585751d37112e2e6b5530cd1d997bd1d40303c37258b7907714eb9d2c1ff1` |

APK 最低 Android 7.0，仅 ARMv7 / ARM64，版本 0.1.3、构建号 18、包名 `io.github.jacklee992.qinban`。与旧公开包签名证书一致。

源码 ZIP 有 1,281 个普通文件、展开 27,356,556 字节，保留 APK 对应的 Git 快照及固定子模块。额外包含同一 CI 的生成桥接文件、准确依赖锁、原始三 ABI 构建 manifests、各 ABI 实际生成的版本文件，以及 `release-provenance/` 中单独注明来源的成功验收脚本。509 个原生构建输入逐一匹配原生 manifest。根 AGPL、enigo 许可证和 APK 实际携带的 Flutter/AndroidX notices 均保留。

冻结完整构建信息中的 `build_commit`、`release_commit` 和原站点 `sourceCommit` 为 APK 源码 `b8bbd580…`；新版网页的 `deployment.sourceCommit=f0dd1230…` 另列，不能混用。验收脚本提交另列为 `verification_harness_commit=353bb2a…`；不得将它写成 APK 来源。完整原生 manifests 在源码包中，7,770 字节构建信息提供其 SHA 与路径，满足 OSS 的 64 KiB 和现有 R2 元数据大小门禁。

源码隐私审计通过。公开配置示例只按准确路径和完整 SHA 允许；另一个准确冻结负向测试只包含裸 `PRIVATE KEY` header，无密钥 payload。未知路径、改字节、追加真实密钥/令牌仍拒绝；没有删掉对应源码测试。审计结果在 `artifacts/android-release-0.1.3-18/source-audit.json`。

## 旧方案的网站审核包

以下包在用户切换 Gitee 方案前完成，保留用于审计；其中 APK 链接仍指向旧 R2 方案，不能直接用于本轮发布。本机固定输入：`artifacts/android-release-0.1.3-18/website-input/`，哈希记录 `website-input-sha256.json`，assets 输入为上面的完整审计目录。这些审核产物的 `deployment.json.sourceCommit` 为 `null`，因为发布清单尚未整合提交。真实 Gitee 附件 URL 纳入审核提交后，必须重新构建网站，并使用真实网站提交记录来源。`releaseSourceCommit` 始终为 APK 源码。

| 构建 | 静态目录 | 文件数 / 展开字节 | ZIP 字节数 / SHA-256 |
| --- | --- | ---: | --- |
| Netlify | `artifacts/android-release-0.1.3-18/web-netlify/` | 24 / 64,658,634 | 63,606,738 / `3a59ee4533a47257653c462a11ec89034727f0a58040f34cef4c72fdade9b441` |
| Sites 下载站 | `artifacts/android-release-0.1.3-18/web-sites/` | 20 / 1,239,313 | 1,177,522 / `e69154059e0ae10491bc04e73656c7377968bb1f4d1d14d9924ebb73673a7212` |
| 阿里云静态站 | `artifacts/android-release-0.1.3-18/web-aliyun/` | 20 / 1,239,199 | 1,177,492 / `5d800c5f40882024a88b13ddfea475d21e9b6809455ee0de998963014356d5df` |

ZIP 与逐文件 SHA 清单均在同一准备根目录，详见 `website-build-verification.json`。Sites / 阿里云产物只有既有极简宣发、邀请、帮助、隐私、关联文件和少量下载元数据；不带 APK/源码 ZIP、函数、秘密或数据库。每个静态文件小于 25 MiB。Netlify 保留本地 APK/源码以兼容现有静态交付流程，公网链接仍指向独立服务；生成目录不证明 Netlify 用量超限已恢复。

旧审核包使用以下下载 base 和家人 API；新包的 APK 会由已验真的 `android.downloadUrl` 单独选择 Gitee，家人 API 保持不变：

```text
download-base-url = https://bangbang-services.s419505080.chatgpt.site/downloads/
family-api-base-url = https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family
```

Sites origin 为 `https://bangbang-download.s419505080.chatgpt.site`；阿里云 origin 为 `https://bangbang.yilin.fun`；Netlify origin 为 `https://bangbang-jacklee992.netlify.app`。家人 API 不随下载存储切换，不创建第二份家庭数据库。

根代理审核提交后可使用现有构建入口，例如：

```sh
node site/scripts/build.mjs --target sites \
  --site-origin https://bangbang-download.s419505080.chatgpt.site \
  --downloads-dir artifacts/android-release-0.1.3-18/assets \
  --output-dir artifacts/android-release-0.1.3-18/publish-sites \
  --download-base-url https://bangbang-services.s419505080.chatgpt.site/downloads/ \
  --family-api-base-url https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family
```

使用 `--target aliyun`、实际阿里云 origin 与新的输出目录生成国内静态站。以审核网站提交设置 `GITHUB_SHA`，同时保留 APK 的 `sourceCommit`；不能用新网站提交替换 APK 来源。

## 真实网站提交的冻结网页包

网站代码与清单已由根代理提交并核对远端为 `f0dd123042439d650ba3b8f00c5198d55006cfd3`。最终准备目录 `artifacts/android-release-0.1.3-18/publish-gitee-f0dd1230/` 从该提交执行精确 `git archive`，包含现有 `site/public`、原品牌资源、release、构建器、Pages 适配器与 LICENCE；快照中每个文件都再次逐字节对照该提交的 Git 对象。

| 准备包 | 文件数 / 展开字节 | ZIP 字节数 / SHA-256 |
| --- | ---: | --- |
| `web-sites/` | 20 / 1,239,500 | 1,177,666 / `0f624dbc845efe98d7237adbb3dca667f6618442ca7593871c510aab2e2d5171` |
| `web-aliyun/` | 20 / 1,239,386 | 1,177,595 / `622def9255c46ce46f430fe8740ae6f777ea825a90472042de8945c81e392c70` |
| `web-github-pages/` | 25 / 1,248,211 | 1,182,765 / `2b8b7c0634220ac69e54e872e042d4cc29e9a5859519da58f610df527684736e` |

各包 `deployment.sourceCommit=f0dd1230…`，`releaseSourceCommit=b8bbd580…`；完整 build-info 仍为 7,770 字节、SHA `801074b39b4080cb7e983f2654f85a39cdb016f61e91479e6cdb928dfb36dd8b`，验收脚本另列 `353bb2a…`。它们分别表示网页代码、APK 产品源码和验收工具，不能混用。包中没有 APK、源码 ZIP、函数或秘密；实际 Gitee 下载地址、现有家人 API 和独立源码引用已逐项核对。

`website-build-verification.json`、各 `*-sha256.json`、`website-input-sha256.json` 和 `PREPARATION_STATUS.json` 与 ZIP 同目录。原网页没有被新设计预览覆盖。根代理执行实际 Sites / GitHub Pages / ECS 发布，本机打包结果不代表上线；Pages 的目录规范化与手机、微信打开仍需真实验证。

下面保留本次发布前的工作树审核包，它们不是最终冻结发布输入：

### 未提交工作树审核包

`artifacts/android-release-0.1.3-18/publish-gitee-review/` 使用冻结原资产、真实 Gitee APK 地址和原 `site/public` 模板生成，家人 API 与对应源码保持现有 Sites 地址。它不采用独立极简设计预览，也不改 iOS 的真实 pending 说明。下面仍是未提交工作树审核快照，`deployment.sourceCommit=null`；根代理审核提交后以实际网站 commit 重建，再记录线上结果。

| 小包 | 文件数 / 展开字节 | ZIP 字节数 / SHA-256 |
| --- | ---: | --- |
| `web-sites/` | 20 / 1,239,462 | 1,177,640 / `9cd4abc8c4039c7cdfb670cbd88a1a4011e4776db165ec18acb57045e26165ac` |
| `web-aliyun/` | 20 / 1,239,348 | 1,177,568 / `f1e244b7350568f45713e118b238d7d52f2df0cdc6bd965fbae15a7195f7e5b8` |
| `web-github-pages/` | 25 / 1,248,173 | 1,182,743 / `d5560ac9731afe62ba2310ea7a57490d920f6215ed7c8eeca16543e1f9a1d81c` |

逐文件 SHA、完整输入快照和 `website-build-verification.json` 在同一目录。包中没有 APK、源码 ZIP、函数或秘密；7770 字节完整 build-info 原 SHA 保持不变。GitHub Pages 使用新适配器生成空 `.nojekyll`、固定 `CNAME` 和三个 HTML 实体目录别名；`provider/target=github-pages`，原构建类型单独列为 `sourceBuildTarget=sites`。12 项适配定向回归和共 58 项相关构建/下载回归通过，无跳过。[模板判断与精确 Pages 发布清单](GITEE_STATIC_PROMO.md)单独说明。

## 实际网页与 ECS 发布

- 产品域名 `https://bangbang.yilin.fun/` 的公开网页仓库提交为 `e3a6e2608159b69485582c657ae745c8e752494c`，GitHub Pages实际构建完成。25个静态正文SHA、九个实体别名、编码查询、404与HTTPS升级全部通过。首页不再跨站跳转；没有新的浏览器、微信或真实手机验收。
- 原下载Site已发布版本3，源提交 `60e045272b95a377a78ada3aee3963d7915d96a1`，部署 `appgdep_6ac0baf072d881919dab937327181d53` 成功。15个非HTML正文SHA相同；五个HTML经过路径规范化后原内容完整，但有Cloudflare检测脚本注入，原始响应SHA不会等于冻结HTML。
- ECS内部网页使用网站f0原20文件与冻结验证器 `1ca43a7498d0b354e9b37418eb04b0f6fb4276fc`。部署tar为1,176,300 bytes，SHA `e164eb25bc6e3c5f4324e4717534c4307608a5a6de81070676b1963f4f651bb4`；实际HTTP SHA、5入口、9拒绝路径、systemd重启和0.1.3→0.1.2→0.1.3回退全部通过。只监听回环，无80/443、安全组或DNS变更，API与D1权威不变。
- 私有证据为 `github-pages-gitee-http-verification.json`、`download-gitee-publication.json`、`download-gitee-http-verification.json`，以及 `artifacts/aliyun-migration/web-upgrade-0.1.3-f0dd1230/` 内完整升级记录。临时上传入口关闭的实际403证据保留。

## Gitee 与网站联动状态

1. 已完成：根代理在既有合规服务提供 `assets/bangbang-0.1.3-source.zip` 和完整 `assets/build-info.json` 原字节，并完成公开验真；完整构建信息的 R2 对象名为 `BUILD_INFO.json`，API 已实际晋升 0.1.3 / Gitee 下载地址。APK 不上传 R2，上传开关和临时凭据已撤除。
2. 已完成：Gitee Release 与三个附件已公开并验真；APK 是根代理官方浏览器上传，两个最小附件来自 CI。继续诊断后续新 APK 自动上传的网络失败。Gitee 不上传源码 ZIP。
3. 已完成：实际 APK 地址写入 `site/release.json` 的 `android.downloadUrl`，同步 `site/releases/0.1.3.json`。保留 APK、source、build-info 的校验值与 `sourceCommit=b8bbd580…`，不把附件仓库或验收脚本提交冒充 APK 来源。
4. 已完成：现有构建入口与下载服务仅接受固定受信附件地址；按真实网站提交 `f0dd1230…` 和同一原 assets 生成 Sites / 阿里云 / GitHub Pages 三套小包，metadata 中网页与 APK 来源分别记录。首页继续保留原有最简宣发与安装入口。
5. 已完成：原下载 Site 版本 3 与 GitHub Pages 实际静态首页均已发布；产品域名25项HTTP正文SHA、九个实体路径、编码查询、404和HTTPS升级通过。ECS内部0.1.3网页也已实际部署，20项HTTP SHA与服务重启、真实回退验证通过；保持回环监听和原D1权威。

当前已有真实 Gitee APK 地址和公开全量 SHA 证据。构建器支持已通过回归，下载服务与自动发布工具由另一个 agent 负责；旧审核包仍不能直接用于本轮发布，需要以下实际链接生成新小包。实际网站上线与 GitHub Pages HTTP 别名验收已由根代理完成；证据见下面发布记录，不把本机打包当作上线证明。

## 保留的 OSS 审核记录

此前 OSS 六对象本机审核目录为 `artifacts/aliyun-migration/oss/assets-0.1.3-preview-review/public/releases/0.1.3/`，报告 `asset-review.json` 的 `cloudVerified=false`，总计 63,462,762 字节。它未上传，已不作为本轮默认发布方案。APK、源码、build-info、AGPL 与完整审计目录逐字节相同；OSS 专用两个元数据为：

| OSS 专用元数据 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `SHA256SUMS` | 342 | `ae8d33ed4da4ed3fa38650b7c08b1d6a7d7d23e37e2a0c1bacef9567e501e254` |
| `manifest.json` | 1,331 | `1f03fbf98183581e9cac67cb89528c67a524d86ad1d0fdb2d836f790edcbdab4` |

保留报告用于日后复核，不据此修改桶 ACL、创建资源或切换下载 base。现有通用发布脚本会重新生成当前 HEAD 的源码包和更大的完整构建信息，也不能无检查地覆盖这套已经核验的资产。

## 保留与回退

原 `site/releases/0.1.2.json` 未改。`artifacts/android-release-0.1.3-18/rollback/0.1.2/` 保存原 release 清单、原 APK、源码、build-info、AGPL 和三文件校验清单；长度与 SHA 原样一致，并增加一个只用于本地核验的派生 manifest。详情在 `rollback-verification.json`。

回退下载入口时重新选择这套旧清单和目录，不覆盖旧附件，也不删除新版附件或回滚家庭数据。0.1.2 仍含旧 Netlify 服务配置，保留该包不代表它能恢复已超限的旧接口。旧包下载入口回退和家庭服务恢复是两项独立操作。

发布准备脚本、原生/APK/验收下载证据、哈希与所有大包仅在 Git 忽略的 `artifacts/` 中。本 agent 的可提交变化限于主 release 清单、0.1.3 版本记录、发布说明、本文、发布交接中的链接、`GITEE_STATIC_PROMO.md`，以及 `site/scripts/build.mjs` / `build-gitee.test.mjs` / `prepare-github-pages.mjs` / `prepare-github-pages.test.mjs`；根代理负责的备案/转发文档和其他 agent 文件未修改。
