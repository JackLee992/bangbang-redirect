# GitHub → Gitee 安装包自动发布

更新：2026-10-04。用户要求 Gitee 只维护公开发行包，不托管 App 源码，不使用 OSS。独立下载仓库已建立：[帮帮安装包](https://gitee.com/yilin-dev/bangbang-releases)，默认分支 `master`。0.1.3 的可安装 APK 已通过 Gitee 官方网页上传，并完成匿名全量下载、长度和 SHA 验收；网站版本接口已更新为该实际附件地址。GitHub自动同步的只读与安全续跑已验真；新APK的首次自动大文件上传仍未验真，不能把本次网页上传视作该分支的证明。

## 发布流程

GitHub 的 `JackLee992/bangbang-android` 继续维护源码、编译、签名及双机验收。通过原发布门禁的 GitHub Release 是同步输入；Gitee 只接收下列三项：

| 附件 | 内容 |
| --- | --- |
| `bangbang-<version>-arm.apk` | 已签名并验收的 ARM64 / ARMv7 安装包，保持原字节 |
| `SHA256SUMS` | 只有这一 APK 的 SHA-256，不混入源码 ZIP 的校验项 |
| `build-info.json` | 从经过校验的构建信息重造公开字段，不转发原始日志或设备记录 |

不执行 Git 仓库镜像，不上传源码、x86 验收 APK、密钥、用户数据或开发 IPA。发行说明自动保留对应源码的独立公开地址和 GNU AGPL v3 许可链接；宣发首页仍不增加源码入口。

Gitee 平台会为标签自动显示 `Source code (zip/tar.gz)` 入口；当前发行仓库只有 README 说明，这些自动生成的仓库归档不是 App 源码，也不是可安装文件。用户的安装入口必须指向经过完整下载验真的 `.apk` 附件，不能用平台归档替代 APK。

## 触发与失败处理

独立工作流已推到 GitHub 默认分支 `main`，执行代码固定从可信默认分支取出。初始提交为 `b957394d7c98e01666ea8550b55607612964b0f1`，手动构建关联 PR 元数据的兼容修复为 `72817adb60667176e1d8d78992702abc845c5d40`，Gitee 未创建发行版返回 HTTP 200 JSON `null` 的兼容修复为 `97a4c5b9c4f73ff6ad9327ea37f44101916c39e5`。原 APK 发布工作流和生产输入门禁不改动；实际触发类型仍必须为可信的手动构建或主仓库推送，关联 PR 信息不等于 PR 触发。

- 原“发布帮帮试用版”工作流成功完成后自动同步。严格核对原仓库、工作流、源提交、执行时段和唯一对应 Release，不直接取 `latest`。
- 用户在 GitHub 发布 Release 时，同步同一标签的白名单附件。
- 需要重试或补发时，可在 GitHub Actions 选择这项工作流并填写已有标签；无需手动下载、上传 APK。

GitHub 自带 `GITHUB_TOKEN` 创建 Release 不会触发新的 `release` 工作流，因此同时监听原发布工作流的完成事件，避免“GitHub 已发布、Gitee 没有动作”。同一目标串行执行，失败时先检查远端已有附件：同名且实际字节 SHA 一致便跳过，不同则停止；不删除旧版或覆盖不同文件。[GitHub 官方触发规则](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/trigger-a-workflow)

同步前核对 APK 身份、签名、版本、实际构建与独立验收；对应源码必须先通过独立下载渠道匿名可用检查。同步后匿名下载每个附件核对长度和 SHA。只有远端核验成功，才能把实际 APK 附件地址写进宣发站和服务 `/api/version`。

## 同版本对应源码渠道

本轮候选代码新增一个固定的备用许可源渠道；这里记录的是实现与受控回归，不能证明该版本文件已部署或匿名可下载。原 GitHub 仓库当前为私有，GitHub Release 浏览器下载地址不能充当匿名分发渠道，也不通过在地址中加入凭据解决。

准备同步时，先从可信 GitHub Release 取出同版本、同文件名的 `bangbang-<version>-source.zip` 附件，完整核对其声明长度、Release `SHA256SUMS` 和 ZIP 格式。源码只在内存中用于校验，不写入 Gitee 安装附件目录。随后匿名 GET 完整源码，按顺序检查这两个精确地址：

1. `https://bangbang-services.s419505080.chatgpt.site/downloads/bangbang-<version>-source.zip`
2. `https://bangbang.yilin.fun/downloads/bangbang-<version>-source.zip`

第一项为既有渠道；只有 HTTP／传输不可用才尝试第二项。已收到的长度、媒体类型、文件名或 SHA 不符会直接停止，不用备用渠道掩盖错误身份。两种渠道都须返回与私有 GitHub Release 同一附件相同的完整字节和 SHA，不接受自选 origin、查询参数、凭据、跨域跳转或其他版本文件。宣发域名的静态 Pages 可没有 `Content-Disposition`；此时仅以固定版本路径、ZIP 媒体类型和完整字节 SHA 验真。若提供该头，则仍要求精确的附件文件名。

发布前再次验证所选匿名渠道。Gitee 正文及精简 `build-info.json` 必须与实际已验证的来源一致，不把 Pages 分发说成 Services 已上传。既有许可链接、三项安装附件白名单、署名与签名门禁保持；宣发首页不增加源码入口。备选源部署由静态网站发布步骤负责，同步脚本不能靠检查失败来授权或伪造部署。

如果某个已发布标签重新运行时变成另一来源，会触发现有正文／附件身份冲突并安全停止；不自动覆盖旧版发行信息。正式 APK 构建和独立 `qinban-device-check.yml` 验收须使用生产输入一致的源码提交，不能把 Android 构建中的 reusable 双机 job 的 run ID 当作独立验收 run。

[真实只读演练 37104272807](https://github.com/JackLee992/bangbang-android/actions/runs/37104272807) 成功：23 项发布测试、GitHub 实际 APK 的签名/版本/原生构建与独立验收校验、独立源码公开可用性、码云公开仓库及三附件计划全部通过。演练未向 Gitee 写入发行版或附件，不能代替首轮真实上传的验收。

## 首轮真实同步的当前结果

- [第一次真实同步 37104707402](https://github.com/JackLee992/bangbang-android/actions/runs/37104707402) 已创建 `v0.1.3` 发行版（ID `1181257`）与 `SHA256SUMS`、`build-info.json`，APK 写入结果无法确认。
- 为区分大文件传输故障，提交 `e5aba444d641bb1796545d774635c40b57601900` 增加固定类别诊断、上传 socket 超时 600 秒和失败后的只读对账。相应 30 项定向测试通过，不自动重发 POST、覆盖或删除附件。
- [第二次真实同步 37106132491](https://github.com/JackLee992/bangbang-android/actions/runs/37106132491) 于 `2026-10-03T07:23:08Z` 发起 49,169,392-byte APK 写入，约 555 秒后报告 `shape=unavailable; result=network`；后续只读对账仍未发现 APK。该标签将多种网络异常合并，现有日志不能进一步断言为配额、特定限流或 socket 超时。
- 当前两个小附件已匿名完整下载，`SHA256SUMS` 为 89 bytes，SHA-256 `3c9b2c84582fcc752f638cfa70adad19acae6dc58ce8974636a26278d89544d7`；公开精简 `build-info.json` 为 1,262 bytes，SHA-256 `9cef8d1d04b7a836d230fe4b7d31cfb633eabfaabb01d3ea6a8a6c3ef7de49d3`。它们不能替代可安装 APK。
- 两次未确认上传后，重新只读核对无 APK，再经已登录的官方网页上传同一冻结安装包。实际附件 ID 为 `3311128`，匿名下载 [可安装 APK](https://gitee.com/yilin-dev/bangbang-releases/releases/download/v0.1.3/bangbang-0.1.3-arm.apk) 获得 49,169,392 bytes，SHA-256 `628c6183febae70f0a8159e86caef7a80f37d6b7d2b0a48cbab267ddeb1a9af6`，与原签名安装包完全一致。未重新编译、签名、覆盖或删除附件。
- 后续诊断提交 `6605ae355619ddac8670a5d381b6b90df4ed8e21` 增加固定操作阶段、耗时、已发送字节下界和安全错误类别，37 项回归通过。只读运行 [37108600749](https://github.com/JackLee992/bangbang-android/actions/runs/37108600749) 在匿名目的探测步骤失败，尚未执行准备或同步步骤；本次没有新的上传写入。实际故障原因及修复另按日志核对。
- 实际日志确认上轮探针在TLS建立后收到HTTP403，不能断言403的原因。提交 `3c44176c22acc055d496bfa58123e809f380e8e6` 恢复Python标准TLS默认设置，并将匿名探针改为非阻塞诊断；38项回归通过，证书/hostname与真实发布门禁均保持。新只读运行 [37109874312](https://github.com/JackLee992/bangbang-android/actions/runs/37109874312) 的探针和实际APK来源/签名/版本检查通过，但已有发行版文本比较报冲突，未执行同步写入。
- 当前Gitee的tag、title、prerelease实际与期望完全一致；正文内容及两个对应源码链接也一致，唯一差异为官方网页保存后的CRLF行尾序列。仅CRLF→LF后两份文本完全相等，属于严格比较的序列化兼容问题，不是这一轮的网络、APK或来源错误。本轮不修改远端发行正文；比较修复及新运行结果另行记录。
- 默认分支提交 `c6b799613cedfd97bd2339fa5cec9f8843bdc43c` 已只对正文比较两侧规范化CRLF→LF，保留原有strip，不折叠内部空格、不转换裸CR；tag、title、prerelease、源码链接、签名与附件SHA保持严格。40项回归通过，CRLF/LF双方向幂等零写入成立；正文、链接、内空格、裸CR和其他元数据负向检查仍拒绝。无需恢复或重写远端发行说明。新只读运行 [37110789080](https://github.com/JackLee992/bangbang-android/actions/runs/37110789080) 已成功，实际APK来源/签名/版本、独立源码可用性、已有发行说明和三附件完整SHA通过；同步写入步骤按dry-run跳过，不作为首次自动上传新APK的证明。
- 主分支 `master` 与发行标签对应 Git 树均只有两份 README；说明页已改为明确选择 `.apk` 安装。Gitee 自动生成的源码归档不含 App 源码。

故障日志和真实远端核对结果保存在忽略目录 `artifacts/android-release-0.1.3-18/gitee-release/`；`gitee-publication-verification.json` 明确记录 `cloud_verified=true`、网页上传路径及 `automatic_new_apk_upload_verified=false`。实际三附件均已匿名全量验真。后续新版仍须完成同等远端检查，不能仅按文件名推断上传成功。

## 修复后的真实续跑

[真实续跑37110941079](https://github.com/JackLee992/bangbang-android/actions/runs/37110941079)在同一默认分支 `c6b799613cedfd97bd2339fa5cec9f8843bdc43c` 上以 `dry_run=false` 实际成功。40项回归、匿名探针、GitHub原APK签名/版本/来源及独立源码可用性通过；三个Gitee附件均经完整下载SHA检查后输出 `unchanged`，没有新建、覆盖或删除附件，也无需修改发行说明。

私有运行日志和复核记录为 `gitee-release/github-dry-run-37110789080*` 与 `github-resume-run-37110941079*`。这证明目前已发布包的恢复与幂等路径可用；49MB APK本次仍来自先前的官方网页上传，下一次实际新版本仍需验证CI首次大文件POST路径，不冒用续跑成功代替首次上传。

## 一次性授权

GitHub 仓库的加密 Secret 名称为 `GITEE_TOKEN`，不能写进源码、网址、命令参数、构建产物或日志。

用户已明确确认生成及保存凭据。Gitee 仓库级私人令牌仅指定 `yilin-dev/bangbang-releases`，勾选 `projects`；系统强制勾选 `user_info`，`pull_requests`、`issues`、`hook` 不勾选。有效期为 90 天，表单显示 2027-01-01 到期；过期前需在平台内更换 Secret。GitHub 实际确认 `GITEE_TOKEN` 更新时间为 `2026-10-03T06:55:17Z`；凭据经受限临时文件送入加密 Secret 后，临时文件已删除，浏览器明文显示已关闭。凭据不进入聊天、Git、发布附件或公开静态站。

Gitee 当前发行页显示：普通项目单附件不超过 100MB，仓库全部附件不超过 1GB。当前 ARM APK 约 49MB，符合单附件限制；不把此方案理解为无限容量，历史保留策略另按实际发布量确定。本轮不自动清理旧附件。

## 对应源码与网站

对应源码放在现有服务 Site 的 R2，Gitee 仓库不保存源码。增加了固定文件名、大小和 SHA 的源码候选白名单，使源码可以先发布，同时保留旧版 APK 和 `/api/version`。候选名单不授权新 APK，也不替换当前构建信息。

0.1.3 已作为预览版发布到原 GitHub 私有仓库，标签 `v0.1.3` 指向 APK 源提交 `b8bbd580c22aba7543e717c686f1c056fb28bb78`；不是将自动化提交误作 App 源码版本。四个冻结附件的文件名和大小与实际 GitHub Release 一致。

0.1.3 对应源码已匿名完整下载验真：[源码包](https://bangbang-services.s419505080.chatgpt.site/downloads/bangbang-0.1.3-source.zip)，14,249,404 bytes，SHA-256 `b0b2e3736bf5534b7f19188a25881407e537d956f1c45589487fb6fa653c2964`。HEAD 200 和 Range 206 通过；当时线上版本仍为 0.1.2。临时上传开关已关闭、Secret 已删除并重新部署（服务 Site 版本 8、环境版本 9），旧上传凭据的实际 PUT 返回 403 `release_upload_forbidden`。私有验真记录为 `artifacts/android-release-0.1.3-18/source-channel-source-verification.json` 和 `source-channel-closure-verification.json`。

服务 Site 后续已发布版本 9、环境版本 11，源提交 `f2bac3b5d8994567ff3867104b70a27ce4215489`。`/api/version` 和 `/api/health` 实际返回 200，版本为 0.1.3；APK 路径返回固定 Gitee 地址的 307。原完整 `BUILD_INFO.json` 7,770 bytes、SHA-256 `801074b39b4080cb7e983f2654f85a39cdb016f61e91479e6cdb928dfb36dd8b` 已上传并匿名完整下载验真，没有用 Gitee 的 1,262-byte 精简信息替换。临时上传入口已再次关闭，旧凭据 PUT 返回 403；既有家人 API、D1 权威及其他环境变量保持原配置。证据为 `services-gitee-publication.json`、`services-gitee-http-verification.json` 和 `source-channel-metadata-verification.json`。

本机以默认 Python urllib 发起的一次请求被边缘规则返回 403，随后普通 HTTP 客户端的版本、健康和下载转发请求均通过。该差异不能证明其他手机、微信或网络也可访问；宣发首页另部署独立 GitHub Pages，而接口仍依赖现有服务 Site。

源码上传的私有证据、临时凭据与原始构建材料保存在忽略目录，不进入 Gitee 或公开静态站。后续网站及 ECS 只更新小型网页包，安装包直接从 Gitee 下载。
