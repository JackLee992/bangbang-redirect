# 帮帮静态首页与产品域名

核对日期：2026-10-03。`https://bangbang.yilin.fun/` 已从转发入口升级为实际静态宣发首页，部署在 GitHub Pages。首页不再跳转到 ChatGPT Sites；Android 安装包直接从已验真的 Gitee Release 下载。主域名与个人博客保持原配置；ECS 仅内部测试，先不备案，确需备案时优先个人身份路径。

## 当前实际静态发布

公开网页仓库仍为 `JackLee992/bangbang-redirect`，本机和远端 `main` 提交一致：`e3a6e2608159b69485582c657ae745c8e752494c`。GitHub Pages 实际构建为 `built`、构建提交同上；绑定 `bangbang.yilin.fun`，发布源 `main` 根目录，强制 HTTPS 已开启。本轮没有修改 DNS。

网页构建来源为 `f0dd123042439d650ba3b8f00c5198d55006cfd3`，APK 源码仍为 `b8bbd580c22aba7543e717c686f1c056fb28bb78`。公开仓库只有 25 个静态文件和 README，不含 App 源码、APK、源码 ZIP、日志、密钥或数据库。沿用现有最简首页和品牌设计，只更新实际 Android 安装入口；邀请、帮助、隐私与真实 iOS pending 说明保持。

真实默认解析与完整证书校验下，25 项静态文件正文 SHA 与冻结包完全相同。首页 SHA-256 为 `a1b3261c14f24ca37050beb93cba39f019dc97db8518e9350326ae2877fab6aa`，没有跨站自动跳转，Android 按钮是可安装 `.apk` 附件地址。`.well-known/assetlinks.json` 实际返回 200、SHA 相同。

邀请、帮助、隐私的无后缀、目录、`.html` 路径共九个入口通过；目录规范化只添加斜杠，编码查询 `BB1_test%2B%2F%3D` 保留，最终正文 SHA 相同。未知路径实际返回 404、匹配自定义页；HTTP 邀请地址升级 HTTPS 时保留查询。片段不会通过 HTTP 传输；页面邀请码逻辑另有 12 项适配器、共 58 项相关受控回归。这些检查不构成新版浏览器、微信、真实手机 App 唤起或配对验收。本轮浏览器自动操作已被当前页面的安全规则终止，没有复用旧转发浏览器结果。

原下载 Site 也已更新为版本 3，实际源提交 `60e045272b95a377a78ada3aee3963d7915d96a1`。15 个非 HTML 文件的 HTTP SHA 相同；五个 HTML 路径规范化后原内容完整，但边缘插入 Cloudflare JavaScript 检测脚本，不能写成原始 HTML 响应 SHA 一致。该渠道仍存在 Cloudflare 依赖。

家人 API 与对应源码继续在原服务 Site，生产权威仍为原 D1；这次独立首页发布不能解决接口在其他网络的全部访问问题。本机成功也不能证明所有国内手机网络均可访问。ECS 私有部署状态见 [迁移记录](ALIYUN_MIGRATION.md)。[模板调查与静态发布清单](GITEE_STATIC_PROMO.md)已记录 Gitee Pages 下线和 Blowfish 建议，当前没有引入新主题或框架。

私有证据：`artifacts/android-release-0.1.3-18/github-pages-gitee-http-verification.json`、`download-gitee-publication.json`、`download-gitee-http-verification.json`。最终网页包和逐文件摘要位于 `publish-gitee-f0dd1230/`。

## 旧转发与回退依据

下列内容保留旧转发发布历史。回退提交 `adc627246261936ce867a26822ccfe8de5fc270c` 仍在网页仓库 Git 历史；恢复它会重新跳转到原 Cloudflare 下载 Site，不能称为独立备用托管。回退网页无需改 DNS、个人博客或家人数据库。

### 旧转发入口

- 转发域名：`bangbang.yilin.fun`。
- 固定目标：`https://bangbang-download.s419505080.chatgpt.site/`。
- 独立转发仓库：`https://github.com/JackLee992/bangbang-redirect`，仅包含 11 个转发网页及配置文件，17,940 字节；App 仓库保持原有私有状态。
- GitHub Pages 已启用，`main` 分支根目录发布；已在 GitHub 绑定 `bangbang.yilin.fun`。

这是静态网页中的浏览器跳转，地址栏最终显示下载站地址。GitHub Pages 不提供本方案需要的任意服务端 302 配置；未把网页脚本测试当作实际 HTTP 重定向。关闭 JavaScript 时保留直接打开下载站的按钮，但无法自动携带当前口令。App 接口和安装包仍采用现有服务地址。

转发保留原始查询参数和片段，固定使用目标站点，不接受查询参数指定其他转发站。`/invite`、`/invite/` 会映到现有站点的 `/invite.html`，`/help` 和 `/privacy` 同样映到对应 HTML 页面；GitHub 项目路径 `/bangbang-redirect/` 仅在默认 GitHub 主机上移除。页面不引入分析 SDK，不主动发出埋点请求，跨站跳转使用 `no-referrer`。

生成源为 [build-redirect.mjs](../site/scripts/build-redirect.mjs)。独立目录 `/Users/jacklee/develop/daillyTasks/bangbang-sites/redirect` 由该脚本生成并发布，不能将 App 仓库或构建目录整体推入转发仓库。

## 已保存的域名解析

2026-10-03 12:42（北京时间），已通过已登录的 Chrome 在阿里云云解析中编辑 `yilin.fun` 下现有的 `bangbang` 记录，并在保存后核对记录值及更新时间：

| 字段 | 新值 |
| --- | --- |
| 主机记录 | `bangbang` |
| 记录类型 | `CNAME` |
| 解析请求来源 | 默认 |
| 记录值 | `jacklee992.github.io` |
| TTL | 10 分钟，可保留现有值 |

旧记录值为 `custom-domains.chatgpt.site`，用于回退。主域名、www、博客和服务站的记录继续保持当前配置。GitHub 要求子域名指向用户名的 `github.io` 主机，记录值不带协议、路径或仓库名；先绑定 GitHub 域名再改 DNS。[官方自定义域名说明](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site)

GitHub 已实际签发域名证书并启用 Enforce HTTPS。HTTPS 首页、邀请口令和片段保留、目标页面可用性均已核验；手机和微信实际打开测试仍待进行。验收保持证书校验开启，未使用 `--insecure`。

### 旧转发实际验收

转发域名 `https://bangbang.yilin.fun/` 已通过 HTTPS 和真实浏览器跳转验收。当前提交 `adc627246261936ce867a26822ccfe8de5fc270c` 已在 GitHub 实际构建完成，远端提交与本机一致；11 项公开文件从精确 Git 快照导出并通过发布审核，与生成源逐个相同，主分支提交信息使用 GitHub 匿名邮箱。未发布 App 源码、安装包、密钥或日志。

2026-10-03 13:00（北京时间），GitHub 返回证书 approved，覆盖 `bangbang.yilin.fun`，有效期至 2027-01-01，强制 HTTPS 已开启。实际 GitHub 地址及本机默认解析的 HTTPS 首页均返回 200、证书校验通过；首页、编码测试口令的邀请页、帮助与隐私页正文均与发布源码相同，SHA 为 `8010e8b9544d978ffd4db0b2546f6632a27aa7cb127f07715344a85f9be88d0e`。HTTP 邀请页会升级到 HTTPS，查询参数完整保留。

内置浏览器实际访问新域名后自动打开下载首页。带 `BB1_test%2B%2F%3D#family-test` 的邀请链接自动到达目标邀请页，编码参数和片段保持；目标下载站将 `.html` 地址规范为 `/invite`。测试口令本身无效，邀请页按预期显示重新分享提示，不将该测试当作实际配对。对实际生成 HTML 的八项本机检查也已通过，覆盖项目路径、固定目标及编码。上述结果不构成手机、微信或 App 唤起验收。

Mac 解锁后，Chrome 原生操作实际完成阿里云解析保存，权威及公共 DNS 的 TCP 查询均已确认指向 GitHub Pages。证书首次申请迟迟未完成，按 GitHub 官方排查方式重新绑定后取得有效证书；仅调整该子域名，旧值仍可用于回退。[证书排查说明](https://docs.github.com/en/pages/getting-started-with-github-pages/securing-your-github-pages-site-with-https)

直接地址保留为 `https://bangbang-download.s419505080.chatgpt.site/`。旧转发切换前自定义域名的 403 是原托管平台的 Cloudflare 安全拦截，当时 Mac 转发成功但目标仍位于 Cloudflare。用户随后仍反馈拦截，因此本轮改为上文的实际静态首页；没有关闭平台安全规则。ECS 内部部署结果在 [迁移记录](ALIYUN_MIGRATION.md) 跟进。

阿里云自带 URL 转发的服务器在中国内地，要求转发前域名已备案，而且入口只支持 HTTP，因此本轮不使用该记录类型。[阿里云 URL 转发规则](https://help.aliyun.com/zh/dns/pubz-add-parsing-record)
