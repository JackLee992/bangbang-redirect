# iOS 构建与真机记录

产品：帮帮 iOS 控制端。日期：2026-10-02。最新方块按钮、家人历史、剪贴板连接确认和移动端无账号入口已冻结，完整 Flutter 测试 **155/155 通过**。最新 **0.1.1（10）** 已完成本机归档及 liyilin 既有团队开发签名，导出 IPA，并安装到真实 iPhone 17 / iOS 26.5；启动后两次检查同一进程仍存活。

构建 8 是历史视觉的 ARM64 本机归档和未签名 IPA；构建 9 是中间权限界面的未签名 archive，均不能代表最新源码。此前 **0.1.1（6）已使用 liyilin 团队开发签名、安装并启动真实 iPhone**。

## 当前源码与构建 0.1.1（10）

- 构建在 `artifacts/ios-local/current-source/` 隔离目录进行，保留本机已编译原生库和 Pods，没有修改生产 UI。
- 244 个 Flutter/iOS/图标文件已逐 hash 同步；源码 manifest SHA256：`5501790525cab147f6cf6768a5bfd34b2adcfc25ab63af824dd99a4d119f8137`。提交 `32a8e2402b0edfcb581ed406f2053750aed524a8` 中的 242 个生产文件与快照逐 hash 一致；其余是本机生成桥接文件。
- 295 个原生源文件与本机编译 manifest 一致，原生静态库仍为 SHA256 `b4c9bee033ce98b166db567031bfc8604d672e85c4767577a1c7c1e63024bbc7`；没有重建 Rust 或复用旧 CI 原生二进制。生成的 Rust bridge/version 与 iOS C header 沿用已核验的本机快照，未改变 FFI ABI。
- 使用现有 Apple Development 身份、liyilin 团队 `5BG4VDJKTY` 和已包含授权 iPhone 的 wildcard 开发描述文件，未新建证书、账号或描述文件。
- 同一次开发签名构建于 2026-10-02 07:26 完成，未叠加签名进程。应用的 `codesign --verify --deep --strict` 通过；导出 IPA 的 ZIP CRC、Bundle ID、版本/构建号、团队和目标设备描述文件包含关系均已核验。
- 开发 IPA：`artifacts/ios-local/current-development-10/bangbang-0.1.1-10-ios-development.ipa`，25,420,844 bytes，SHA256 `ee89c745f65ee4160bb9b4d83f188a118305322db48bd9709a6d5ef108815495`。解包后的导出应用也通过严格签名检查。开发包仅适用于描述文件已注册设备，没有公开发布为通用安装包。
- 07:31 安装及启动真实 iPhone 17 / iOS 26.5，系统应用清单确认为 0.1.1（10）。PID 3648 的路径位于真机 `/private/var/containers/Bundle/Application/.../Runner.app/Runner`；07:31:58 与 07:34 后续查询均保持同一进程，非模拟器结果。签名、安装、启动、UI 操作和远控会话分别记录。
- 构建日志、逐文件快照和当前状态保留于 `artifacts/ios-local/build10-development-archive.log`、`build10-source-snapshot.json`、`build10-status.json`。构建 9 单独保留在 `artifacts/ios-local/intermediate-9/Runner-0.1.1-9.xcarchive`。


## 历史视觉构建 0.1.1（8）

- 生产源码：`ff32acbdde6f1cef3c84f777e24f7ed0d1662427`。独立快照与提交中的 157 个 Flutter/iOS 文件、263 个原生文件及批准的图标 master/导出脚本逐 hash 一致。
- 本机 Xcode 26.6（17F113）/ iPhoneOS 26.5 SDK，Flutter 3.24.5，ARM64，最低 iOS 13.0。
- 应用标识 `io.github.jacklee992.bangbang`，显示名“帮帮”，实际 Info.plist 版本 `0.1.1`、构建 `8`。
- 该快照的 Dart/Swift/宿主完整编译归档成功。原生 Rust/codec 未改变，复用此前在本机从源码完整编译、已核验的静态库，没有使用旧 CI archive 的原生二进制。
- 本机 native 静态库 SHA256：`b4c9bee033ce98b166db567031bfc8604d672e85c4767577a1c7c1e63024bbc7`。
- 未签名 IPA：`artifacts/ios-local/current-development-8/bangbang-0.1.1-8-ios-unsigned.ipa`，SHA256 `b11ddad820a72265bbd0e285554bea0d64208e3889a77adf6ec1c4dc1d4f5021`。完成 ZIP CRC 和包内版本复核；未签名包不能直接安装。
- 归档：`artifacts/ios-local/current-development-8/Runner-0.1.1-8.xcarchive`。打包 tar.gz SHA256：`7f78178d06d002bac546b984da1ca75477cf98fdf88f53c8a6a81ab769d7baef`。
- 本机记录保留于 Git 忽略目录 `artifacts/ios-local/`，没有公开上传签名/设备证据。

## 已验证的本机开发签名和真机安装

- 阶段源码 `ceaba9008f5923cf405d442d3529f701aa120f5b`，版本 **0.1.1（6）**。
- 使用本机现有 Apple Development 身份、liyilin（li yilin）团队 `5BG4VDJKTY` 和现有开发描述文件。没有创建新证书、描述文件或 Apple 账号配置。
- 开发 IPA SHA256：`d1cec722bf4732acb34452083fa47c63310a5f3b380f027d9b0fe564147eea11`，`codesign --verify --deep --strict` 通过，实际 bundle/version/team 已核验。
- 已安装到真实 iPhone 17 / iOS 26.5；仅查询本应用的安装清单确认 `0.1.1（6）`。
- 19:03:59 启动成功，系统确认启动时已激活前台；19:04:10 同一安装路径的进程仍存活，覆盖至少 11 秒。后续设备断连不能解释为 App 失败。
- 详细包身份和安装/启动 JSON 在 `artifacts/ios-local/current-development/`，保持本地。

本机开发签名 IPA 可以安装到描述文件已注册的设备。**这条路径不需要 App Store Connect API Secrets，也不需要先上传 TestFlight。** 最新源码已通过同一既有团队签名、导出并安装。没有 Rust/FFI 变更时可核验并复用本机原生库，无需重新配置 Apple 账号。

## 验证边界与分发

历史构建 8 对应 91 项 Flutter 测试通过。当前源码测试和交付状态见 [交接记录](RELEASE_HANDOFF.md)。这是宿主测试和编译证据，不等于 iPhone UI 或远控会话验收。

当前没有 iOS 实机截图，也未证明分享、邀请预填、剪贴板识别和 iOS 到 Android 的真实远控会话。旧构建两次 XCTest 都在 runner bootstrap 前报 DTX 通道拒绝/IDE 断开，实际执行 UI 方法为 0；没有对新版重复相同 XCTest。QuickTime 未提供设备 Screen 输入，没有选择摄像头或麦克风、没有录制无关内容。

本地开发签名不等于 Apple 分发签名。TestFlight 上传、Apple 处理、外部测试审核和 App Store 上架均未完成；分发路径见 [TestFlight 说明](IOS_TESTFLIGHT.md)。最低 iOS 13.0 是构建声明，不表示所有系统版本均实测。

历史 [CI run 36816343331](https://github.com/JackLee992/bangbang-android/actions/runs/36816343331) 曾成功构建未签名 0.1.0（5）；它是历史基线，不是当前最终界面产物。
