# 完整呼叫候选验证

日期：2026-10-02。本轮改动在本地工作区，尚未提交、推送或发布；线上 Android / 网站仍是 0.1.1。Cloudflare、Oracle 依照用户要求只准备代码与部署文件。

## 修复与实现

- 先完成屏幕共享准备和在线检查，再发邀请。准备失败不会继续发出无法使用的邀请。
- 保存家人的求助保持同一请求到终态：呼叫、接听、实际画面接通、挂断；拒接、撤回和超时不能被迟到响应恢复。
- 接听本身不算连接成功。控制端真实第一帧回调才标记成功，两端通过随机 callId 关联；首次 BB1 分享仍不具备共同 callId。
- Android 系统通知可接听/拒接；应用内展示呼叫状态并响铃。iOS 的本地通知和前台提示音实现已编译验证。后台新请求仍需要远程推送。
- 修复家人端挂断后长辈录屏未停止、旧会话异步清理干扰新连接、正常结束被显示为连接失败，以及较窄屏幕的工具栏溢出。
- 诊断只保存固定分类字段，处理异步上传的最终状态与超过一批的离线补报；缺少统计配置时只保存在本机。

## 主机与构建检查

| 检查 | 结果 | 本地证据 |
| --- | --- | --- |
| 全量 Flutter 测试 | 173 通过 | `.qinban-cache/call-all-flutter-final-tests.log` |
| 网站和家人协议测试 | 40 通过 | `.qinban-cache/call-site-final-tests.log` |
| Cloudflare Worker / SQLite | 6 通过 | `.qinban-cache/call-backend-final-tests.log`，其中另含家人协议测试 |
| Python 发布/打包测试 | 22 通过 | `.qinban-cache/call-python-tests.log` |
| Qinban 代码静态检查 | 无问题 | `.qinban-cache/call-final-analyze.log` |
| Android ARM64 debug | 构建成功 | `.qinban-cache/call-android-candidate-build.log` |
| iOS 0.1.2（11）Release | 未签名设备构建成功 | `.qinban-cache/call-ios-candidate-build.log` |
| Cloudflare Wrangler 4.146.0 | dry-run 通过，未部署 | `.qinban-cache/cloudflare-dry-run.log` |

iOS 使用已准备的隔离源码/Pods/原生依赖目录，168 个应用源文件及资源与当前工作区逐文件 SHA256 一致，记录在 `artifacts/ios-local/call-flow-source-snapshot.json`。这不是模拟器运行、真机安装或 App Store 分发证据。

Android 候选位于 `flutter/build/app/outputs/apk/debug/app-debug.apk`，SHA256 为 `90881d8ebfcac5be7cc5b1033a7016a3bc0a32530695d92aef6cc62fe732b7ad`。这是指定本机测试服务的 debug 包，不作为公网下载包发布。

## 双模拟器实测

测试使用两台 Android 15 ARM64 模拟器（elder `emulator-5560`、helper `emulator-5562`），实际 RustDesk 原生加密连接、MediaProjection 和远程触控。发现/中继服务是从官方 `rustdesk-server` 1.1.16 源码在本机编译运行；家人 HTTP 服务执行实际协议与内存 CAS。没有连接生产家人记录。

首次邀请流程已验证：屏幕授权 → 准备好后打开系统分享 → 编码邀请唤起控制端确认 → 长辈允许协助 → 真实画面及远程操作 → 在原生加密会话中记住家人。原始截图在 `artifacts/call-flow/`。

保存家人的重复呼叫通过 `scripts/qinban/emulator_family_call.py` 验证系统通知接听、第一帧、远程点击引起长辈界面变化并回传新画面、家人端挂断释放长辈录屏、再次响铃、通知栏展开时撤回以及拒接清理。最终候选结果和截图位于 `artifacts/call-flow/verified/`，`result.json` 同时记录 APK hash 和实际 direct / relay 路径。本轮实际走的是 direct，没有将“中继服务启动”算作中继链路成功。

另在 `artifacts/call-flow/elder-hangup/` 验证长辈挂断：录屏停止，家人端显示“协助已结束”，点击“返回”回到首页，不再显示“没能连上家人”。该路径验证使用前一个相同呼叫代码的候选；后续只调整诊断补报队列。

复验前必须已完成两台模拟器的首次配对、操作权限和通知许可；重装可能重置操作权限。测试不会安装应用、清空数据或修改连接服务器：

```sh
PATH="$HOME/Library/Android/sdk/platform-tools:$PATH" \
  QINBAN_CALL_EVIDENCE=artifacts/call-flow/verified \
  .qinban-cache/qa-venv/bin/python scripts/qinban/emulator_family_call.py
```

本地服务需保持运行：`node scripts/qinban/local_family_server.mjs` 监听 `127.0.0.1:8089`；模拟器映射为 `10.0.2.2`。测试构建通过 `QINBAN_TEST_FAMILY_URL=http://10.0.2.2:8089/family` 指定它，release 忽略该调试覆盖。原生服务测试地址为 ID `10.0.2.2:23016`、relay `10.0.2.2:23017`，两端必须配置同一真实生成的公钥，私钥只留在忽略的本机运行目录。

## 尚未证明的范围与发布顺序

- 无真实 iPhone → Android、跨移动网络、强制中继或后台推送的端到端证据。公共服务的 UDP 注册不稳定问题仍需用真实网络对比；本机直连成功不能证明已解决所有连接失败。
- iOS 未使用 CallKit / PushKit，Android 未使用系统全屏电话界面。当前是已收到请求后的通知与应用内呼叫呈现。
- Netlify 的新增 `request.progress` / `request.end` 和独立隐私页尚未上线。下一次发新客户端前，先升级同一站点的家人接口，并用专用 QA 身份核验 active、挂断与跨发布保留；下载首页继续保持简洁。
- Cloudflare D1/Worker 与 Oracle VM 未创建。准备内容分别在 `backend/diagnostics/`、`deploy/oracle/`；上线后仍需检查实际免费额度、网络连通和中继路径。
- 第三方分析/崩溃/推送 SDK 尚未加入依赖，也未发送数据给候选供应商。后台提醒下一步需要开发者 APNs / 厂商凭证与推送 token 绑定，不需要为家人引入账号登录。
- TestFlight / App Store 分发、可公开访问的开发者联系信息、隐私申报和加密分类仍待完成，不能将本轮未签名构建视作可提交的上架包。

所有截图、设备日志、临时身份、服务私钥和构建产物都留在忽略目录，不进入源码或公开下载。
