# 帮帮双站与独立服务

更新：2026-10-03。

宣发下载站：<https://bangbang-download.s419505080.chatgpt.site/>。服务与后台：<https://bangbang-services.s419505080.chatgpt.site/>。原 Netlify 站仍保留；本轮线上访问返回 `503 usage_exceeded`，没有把它标记为已恢复。

两个宣发版本都指向同一个家人服务、同一份 D1 数据和同一份 R2 附件。不能把两个独立数据库当作自动 fallback，否则已保存的家人、撤销和呼叫状态会分裂。App 无需用户账号、手机号或 ChatGPT 登录，继续用本地安装身份授权请求。

| 资源 | 当前用途 | 边界 |
|---|---|---|
| 下载 Site 静态文件 | 简洁首页、安装说明、邀请落地页、隐私说明、图标、版本与许可证信息 | 不放后台密钥、数据库备份或原始诊断；单文件上限 25 MiB |
| 服务 Site Worker | 家人登记、配对、请求/接听/取消/结束、原请求防重放、健康与版本接口 | 复用原 consent 状态机；HTTP 服务不等于视频中转服务器 |
| D1 `DB` | 安装验证摘要、家人关系、呼叫/推送 outbox、撤销与防重放记录 | 原始 `prepare` 读主库；CAS 条件写；这些永久验证记录不适用诊断 TTL |
| D1 诊断表 | 连接阶段、结局、耗时和错误分类；后台聚合查看 | 安装 Bearer 验真、编号 HMAC；禁止屏幕、邀请码、家人称呼、原始日志 |
| R2 `RELEASES` | 校验过的 Android APK、对应源代码压缩包、构建信息 | 白名单对象，流式传输、SHA-256、不可覆盖、HEAD/ETag/单段 Range |
| R2 私有备份对象 | 21 条旧记录的完整迁移前快照 | 本机先用 AES-256-GCM 加密，另设后台读取授权；解密密钥不上传 |
| 本机私有目录 | 完整迁移备份、受控测试证据、构建缓存与签名材料 | 不进公共 Site、Git 或下载附件 |

目前没有把 `hbbs/hbbr` 的 TCP/UDP 监听端口迁到 Sites。远程画面和操作仍走现有公网 RustDesk 服务；自建 relay、APNs/FCM 凭据、支付回调与家庭会员服务需独立验证。现有家庭/订阅方案及 SQLite household 服务不能直接宣称已迁为 D1。

## 接口

| 路径 | 方法 | 权限 |
|---|---|---|
| `/`、`/admin` | GET | 公开外壳；统计需独立后台密钥 |
| `/api/health` | GET | 固定服务状态，实际读 D1 表，不公开记录 |
| `/api/version` | GET | 当前版本、APK 下载地址与校验值；iOS 有实际公测地址才展示 |
| `/.netlify/functions/family` | POST | 原安装 Bearer，路径保留但域名独立于 Netlify |
| `/v1/attempts` | POST | 已登记且未撤销的安装 Bearer；固定单条或有限批次 |
| `/v1/summary` | GET | `BANGBANG_DIAGNOSTICS_ADMIN_SECRET` |
| `/v1/diagnostics/cleanup` | POST | 同一后台密钥，正文 `{"v":1}` |
| `/downloads/<白名单附件>` | GET/HEAD | 公开下载 |
| `/api/releases/<白名单附件>` | PUT | 显式上传开关及临时上传密钥，日常关闭 |
| `/api/admin/family-migration` | POST | 临时独立迁移密钥且 API 必须维护关闭；迁移后撤除 |
| `/api/admin/backups/migration-20261003.bgbak` | PUT/GET/HEAD | 独立备份密钥；固定加密文件，无公开下载或列表 |
| `/api/push/dispatch` | POST | 单独 HMAC 调度授权，未配置时关闭 |

后台密钥只在当前页面内存中使用，不进入 URL、Cookie、浏览器存储或 App。运行秘密保存在 Sites secret 配置；本机应急副本为 `~/.config/bangbang-sites/services-runtime-secrets.json`，权限 600。不要将其内容贴到聊天或公开反馈。

## 统计口径与用量

只把控制端实际记录到首帧的协助计为成功；成功率分母为成功加失败。取消、中断和未完成单列；“最后记录阶段”不是完整漏斗。首帧时间超过截断上限的样本单列，不能把截断值当真实时延。

统计查询只使用近 7 天数据；合法上传时每次有界清理最多 500 条过期诊断和 500 个限流桶。空闲服务没有已配置的定时器，不保证没有请求时也执行物理删除；管理员可调用 cleanup，日后接入经过授权的定时任务。家人 API 的临时入口计数与 push-ready 标记另通过 `waitUntil` 后台有界清理，持久防重放/撤销记录保留。

诊断预算：每安装每分钟 60 请求/300 事件，服务每分钟 300 请求/1000 事件、每天最多 10000 事件；单条最多 2 KiB，批次最多 20 条/16 KiB。后台查询每分钟 4 次、每天 20 次。达到限制时 App 保留本地记录，不阻塞协助。

家人入口使用双桶保护：共享出口每分钟最多 6000 次，每个规范安装 Bearer 的摘要每分钟最多 180 次。移动运营商共享公网出口时，多个安装有独立额度；伪造密钥不会占用被冒用安装的桶。入口限流不代替后续身份验真。

这些是应用设置的保护上限，不是 ChatGPT Sites 的免费额度或 SLA 承诺。本轮工具没有提供账户存储/调用的总额度；两个 Site 的资源是否共享套餐额度应按实际账户规则核实，不能通过创建多个 Site 推断获得无限免费资源。

## 旧数据迁移证据

Netlify 管理通道仍可读取生产 Blobs。本轮对 `bangbang-family-v1-production` 做了两次完整强一致分页读取，21 条记录及 etag 一致（devices 11、pairs 6、claims 4）。备份留在忽略目录 `artifacts/sites-migration/`，权限 600。没有把错误响应或空列表当成空库。

首次 D1 导入为 `received=21, inserted=21, unchanged=0`；再次导入为 `inserted=0, unchanged=21`，两次规范摘要相同：

```
6ec149f62ae4b0111f0c9cec7b55de99e4395eadd4eb24580a594737ba8e054d
```

导入保留全部 JSON 状态、原过期时间与 claims，重建 D1 etag；不同已有内容禁止覆盖，每批 `DB.batch` 原子提交。旧公网接口正因用量超限不可用；本轮未声称另外成功设置了旧平台写入冻结。今后在两个服务均可写时迁移，必须先冻结旧入口及旧推送调度，再做最终快照。新服务开始写入后，不能直接把旧 Blobs 当作回滚数据库。

在线测试使用隔离的 `verification-20261003` scope，走完登记、配对、求助、观察、接听、原生连接 lease、结束、取消、重放拒绝与移除家人。诊断上传、修订去重、敏感字段拒绝和私有统计均实际经过 Sites/D1；统计测试样本与 `production` 分开。这是受控 HTTP 状态机证据，不是真机视频、跨网质量或通知送达证据。

R2 0.1.2 APK 已完整下载核对 49,491,396 字节及 SHA-256，并验证 Range 返回 206。此包来自旧版本，不能将它称为已包含新服务地址的 0.1.3。

迁移前备份为固定 `BGBK01 + nonce(12) + tag(16) + ciphertext` 封装；AES-256-GCM 附加验证信息为 `bangbang/migration-20261003/v1`。解密密钥只在上述本机私有配置的 `backupEncryption`；备份接口授权为不同的 `backupAdmin`，服务端只保存授权密钥。上传 R2 前先在本机验证解密结果等于完整原备份，再对线上取回文件做同样核对。失去本机解密密钥将无法恢复，需自行保留私有配置的安全副本；这是一份迁移前快照，尚非新 D1 数据的每日自动备份。

2026-10-03 服务版本 4 / env revision 5 的在线验收：加密备份取回 12,986 字节，解密后与完整 21 条原文件逐字节一致；匿名备份访问 401，公开附件路径 404，原临时上传凭据返回 403。两个构建信息文件名均读取同一对象。完整站点测试 234 项通过。

同日服务版本 5（源 `b6376645ef043855eaf599583ac5239552f89b90`，env revision 仍为 5）已发布 ECS 转发准备代码；生产没有 ECS 配置，继续使用原 D1。线上 health、0.1.2 版本元数据、匿名备份拒绝、私有统计、无鉴权家人请求拒绝、旧上传凭据拒绝和 APK Range 共 7 项通过。后台、代理与 OSS 本地完整 Node 回归 264 项通过，其中代理包含真实回环 HTTP→SQLite 呼叫流程；尚未验证公开 HTTPS→ECS，也没有迁移当前数据。

当前服务版本 6（源 `c9f254f2b9afa8d425b58ec18401751195331985`，env revision 5）包含永久 ECS 入口准备，实际构建入口仍为 D1，未激活迁移。线上健康、0.1.2 元数据、匿名备份拒绝及 Range 再次通过。新增严格入口、真实 Caddy 边界及已有后台的完整回归 285 项通过、无跳过；D1/ECS 两种全新产物均实际加载核验，ECS 产物不含旧家人表访问代码，配置缺失也不会触碰旧 DB。

阿里云资源和域名的实际进度见 [迁移记录](ALIYUN_MIGRATION.md)。`bangbang.yilin.fun` 的 DNS 和证书已绑定；重发下载站版本 2 后，本机默认 curl 验收仍返回 403，原 Sites 下载入口返回 200，因此不切默认分享地址。

## 复现构建与发布

1. 从已审核提交准备独立服务 checkout：

   ```sh
   node site/scripts/prepare-service-site.mjs --output-dir /绝对路径/服务站 --project-id 已注册的精确SiteID
   ```

2. 使用 Sites 安装依赖流程；`npm run db:generate` 生成 Drizzle 迁移。已应用的迁移不改写；运行时不建表。`npm run build` 输出 `dist/server/index.js`，绑定名固定为 `DB`/`RELEASES`。
3. 用 Sites 自带 `site-workflow.mjs` 完成来源提交、构建和归档，凭据只经内存和 stdin。保存归档版本再公开部署；环境变量更新也需要重新部署，使该版本实际使用新的 env revision。
4. 初次设 `BANGBANG_FAMILY_API_ENABLED=false`，验证 health 200 与错误迁移 Bearer 401，再导入并核对完整备份。上传时还须显式设 `BANGBANG_RELEASE_UPLOAD_ENABLED=true`；完成后设为 `false`、撤除迁移/上传秘密，再用 `production` scope 重新部署启用 API。环境列表删除不能单独证明运行时已撤权，必须实际验证旧上传凭据返回 403；上传开关缺失或不是字符串 `true` 都关闭，迁移接口在家人 API 启用时关闭。
5. APK 必须来自通过三 ABI 自编、聚合、APK 哈希与签名门禁的移动提交，同时发布对应源包和构建信息。旧版 Android 包仍含上游引擎，新源码修复不能用旧缓存冒充；当前新版完整 CI 已启动。

宣发两套产物：`site/scripts/build.mjs --target netlify|sites`，指定各自 `--site-origin`，两者使用相同 `--download-base-url` 与 `--family-api-base-url`。Netlify 产物保留本地附件以兼容原发布校验；Sites 静态包只带约 1.3 MiB 宣发内容，大附件从 R2 下载。

新 App 默认使用独立服务地址，分享使用新下载站；解析继续兼容旧邀请。本轮相关 Flutter 测试 102 项通过。iOS 0.1.3（18）已在冻结源上完成编译与本机开发签名，签名、最低系统版本和 sandbox 推送配置审核通过；未修改钥匙串权限。安装时 CoreDevice 返回连接失效（设备已不可达），因此仍未完成安装、运行或上传，也未验证真实推送交付。

国内外服务器费用与学生优惠见 [学生云选型](STUDENT_CLOUD_RECOMMENDATION.md)。如果后续自建 relay，应优先用真实跨网测试和并发流量测算决定配置。
