# 帮帮 iOS：本机安装与 TestFlight 分发

> 公开入口启用核对（2026-10-04）：Chrome 的 Apple 登录页面已恢复，用户完成密码及验证后，实际进入 App 列表和帮帮 TestFlight。**0.1.2（14）显示“已批准”，89 天后过期**；当时“帮帮公开测试”为 0 个测试员、1 个构建。按用户发布公测入口的要求，对该已批准构建执行“通知测试员”后，实际访问[官方公开链接](https://testflight.apple.com/join/4sw7UNJe)，页面显示“获取 TestFlight”和“在 TestFlight 中查看帮帮 Beta”，已接受公开加入。没有新增个人邀请或修改测试员上限。公开链接页可加入与测试员手机安装是不同证据，后者尚未重新验收。先前等待审核及“不接受新测试员”的页面已不是实时状态。截图和脱敏探测摘要位于忽略目录 `artifacts/ios-local/apple-login-20261004/`。

> 最新正式候选 **0.1.4（21）** 已从冻结源码重编原生、完成正式签名、实际IPA审计和Apple上传。解锁后已核对处理完成、保存出口合规、加入既有内外测试组并提交Beta App Review，当前**“正在等待审核”**、90天后过期。内部组包含21，状态“准备测试”，目前0个测试员。签名与profile的生产APS权限通过门禁，上传后正式导出包与上传前哈希一致。见[构建21发布记录](IOS_RELEASE_21.md)。网站继续按已批准且实际可加入的0.1.2（14）提供公测入口；21获批后需完成公开启用和邀请页验收，才能更新版本标注。另一本机开发体验包0.1.4（20）已安装启动，并非本次正式上传包；真机记录仍见忽略目录`artifacts/ios-local/qa20-device/`。

### 2026-10-04 登录页故障与恢复

Chrome 最初停在带 `authResult=FAILED` 的登录 URL，页面没有样式和登录框。实际控制台记录 `Failed to fetch dynamically imported module`，目标为 Apple 的 `unpkg.apple.com/@maison/olympus/dist/readonlyTerms.mjs`。这个故障发生在登录界面加载阶段，不能据此认定密码错误、账号锁定或 Apple 全面故障。

强制重新载入后，页面恢复完整登录组件，并能正常进入密码验证；用户本人完成登录，随后 App 列表、TestFlight 构建及公开组实际加载成功。当前公开登录页面、身份主机及相关 JS 通过本机直连和现有代理探测均返回 200。具体是旧缓存还是间歇资源访问导致首次失败尚未区分；排查未清除全站 Cookie、重置密码、改动代理/DNS、关闭扩展或绕过证书验证。开发者状态页曾出现一次代理路径证书名称不匹配，随后同路径复验成功，未用它推导账号异常。

> 状态更新（2026-10-02）：App Store Connect 已将 0.1.2（13）标为“二进制文件无效”，对应 ITMS-91061 的 SDK 隐私清单缺失。修复候选 0.1.2（14）已完成独立归档、正式分发签名及实际 IPA 隐私审计，已通过 Xcode Organizer 上传和 Apple 处理，出口合规已保存，已加入“帮帮公开测试”并提交 Beta App Review，当前“正在等待审核”。公开链接已创建，但无获批可用构建，不能加入或安装。见[构建 13 记录](IOS_RELEASE_13.md)、[构建 14 修复](IOS_RELEASE_14.md)。下文 CI 云签名是可选路径，不是本机 Xcode 发布的前提。

iOS 版提供控制端，连接家人的 Android 手机。应用标识为 `io.github.jacklee992.bangbang`，开发者团队为 liyilin（`5BG4VDJKTY`）。

## 本机开发签名安装

已有 Xcode 开发身份和描述文件时，可选择既有 liyilin 团队导出开发签名 IPA 并安装到已注册设备。此路径不需要 ASC API Secrets，也不需要先上传 TestFlight。0.1.1（10）曾完成该安装流程；之后构建 13 已由 Organizer 用既有云端分发证书正式上传。开发签名安装与 TestFlight 分发是不同证据，历史设备记录见 [iOS 构建记录](IOS_VERIFICATION.md)，最新修复以本页顶部链接为准。iPhone 控制 Android 的新版本双真机性能验收仍未完成。

以下配置仅针对 TestFlight/App Store 分发；没有本机 Apple Distribution 私钥身份或可用云签名认证时，开发 IPA 不会自动变成分发包。

### 推送环境必须在签名前确定

`Info.plist` 的 `BangbangPushEnvironment` 由 Xcode build setting `BANGBANG_PUSH_ENVIRONMENT` 展开。Debug、Release、Profile 都默认 `unverified`；仅选择团队或 Release 配置不会声称具备 APNs。

`build_ios_distribution.py` 的本机开发入口可在既有参数后加入 `--team 5BG4VDJKTY --development-profile /本地已安装的开发描述文件.mobileprovision`。脚本只读核对该 profile 的团队、应用标识、有效期和开发设备范围，再显式传给 Xcode：确有 `aps-environment=development` 时声明 `sandbox`；没有 APNs 能力时声明 `unverified`，并只在独立构建目录生成移除 APNs 请求的 entitlement 文件。没有指定 profile 的自动开发签名仍为 `unverified`。脚本不会创建 Apple 标识、profile 或凭据。

CI 正式候选先让 Flutter 准备构建配置，再直接向 `xcodebuild archive` 传入 `BANGBANG_PUSH_ENVIRONMENT=production`；本地未签名分发归档可显式使用 `--production-push`。归档后会核对实际 App Info 中的值。声明不代表已获得生产推送权限：TestFlight 流程仍需先导出，然后核对最终签名、profile 与声明一致才上传；开发包对应 `development → sandbox`，正式导出对应 `production → production`。不能在签名后修改 App 的 Info.plist。

## 通过手机准备 TestFlight 云签名认证

1. 用手机 Safari 打开 [App Store Connect](https://appstoreconnect.apple.com)，登录 liyilin 的 Apple 账号并完成双重认证。页面拥挤时，在 Safari 页面菜单选择“请求桌面网站”。手机登录会话不会同步到开发电脑。
2. 打开“用户和访问 → 集成 → App Store Connect API → 团队密钥”，创建名为 `Bangbang GitHub Actions` 的密钥。自动云签名需要具有云端分发签名权限的团队密钥；Admin 团队密钥可用于此流程。它能访问团队所有应用，请在自己的私有仓库中保存；也可使用已有的适当权限密钥。首次使用 API 时，Apple 可能要求账号持有人申请访问并同意条款，这一步由账号持有人操作。
3. 在 [GitHub Secrets 页面](https://github.com/JackLee992/bangbang-android/settings/secrets/actions) 依次点 **New repository secret**，保存以下三项。只在 Apple 和 GitHub 官方页面填写，不要发到聊天或提交到代码。

| Name | Secret 内容 |
| --- | --- |
| `ASC_KEY_ID` | Apple 页面显示的 Key ID |
| `ASC_ISSUER_ID` | Apple 团队密钥页面显示的 Issuer ID；不是 Team ID |
| `ASC_PRIVATE_KEY` | 下载的 `.p8` 文件完整文本，包括 BEGIN / END 行；不需要 Base64 编码 |

`.p8` 只允许下载一次。可保存到手机“文件”，以文本方式打开并复制到 GitHub。不要使用第三方在线文件转换工具。

## 首次创建应用记录

Apple 的公开 App Store Connect API 不支持创建新的应用记录。首次上传前，需要在手机网页完成以下设置：

1. [Apple Developer 账户](https://developer.apple.com/account) → Certificates, Identifiers & Profiles → Identifiers → 加号 → App IDs → App。描述填“帮帮”，Explicit Bundle ID 填 `io.github.jacklee992.bangbang`。需要后台来电提醒的版本必须启用 Push Notifications，并使用包含相应 APNs 环境的描述文件。
2. 回到 App Store Connect → Apps → 加号 → New App。平台选 iOS，名称填“帮帮”，主语言选简体中文，Bundle ID 选刚创建的标识，SKU 填 `bangbang-ios-001`。如果名称已被其他开发者占用，先反馈提示，安装后的名称仍为“帮帮”。

## 构建与上传

最近实际上传的正式候选为 **0.1.4（21）**，归档、正式签名、实际IPA审计、Apple处理和出口合规均已完成；已加入既有内外测试组并提交外部审核，当前等待Apple审核。**0.1.2（14）**已批准并完成公开加入页验收；测试员手机安装尚未重新验收。另一本机**0.1.4（20）**是开发签名体验包，不能直接作为正式分发IPA上传。工作流或脚本中的历史默认版本不代表下一次发布目标；执行新归档时应显式指定审核后的版本和未使用过的构建号。打包脚本读取实际Info.plist并核对请求值。

0.1.1（10）的本机开发归档已经完成，但没有对应的 Apple 上传结果。若采用 CI 云签名路径，`archive_run` 必须填写所选实际成功的“帮帮 iOS”CI run；旧 **36816343331** 对应 **0.1.0（5）**，不能当作 0.1.1 或最新候选的来源。本机 Xcode 的归档/分发路径不要求提供这个 CI 参数。历史产物与 hash 见 [iOS 构建记录](IOS_VERIFICATION.md)。

- `帮帮 iOS` 工作流先运行共享界面测试，再用 macOS / Xcode 26 构建真实 ARM64 控制引擎和应用。产物包括未签名 IPA、完整 Xcode archive、构建信息。
- 未签名 IPA 不能直接安装，也不代表已进入 TestFlight。
- Secrets 和应用记录齐备后，运行 `帮帮 TestFlight`，填写已成功的 iOS 构建 Run ID。工作流核对构建、应用标识和团队，通过 Apple 云端签名上传，再查询 Apple 的处理状态。
- Apple 处理状态查询使用构建产物中的实际 app version 和 build number，不固定查询旧 0.1.0。
- Apple 处理成功后，在 TestFlight 的内部测试中添加需要使用的测试人员。外部测试可能需要 Apple 的 Beta App Review，上传成功不等同于外部审核通过。
- 仓库不会保存 `.p8`、分发私钥或个人密码；凭据只写入临时 runner 文件并在作业结束时清理。

## 参考

- [Apple：创建和管理 API 密钥](https://developer.apple.com/help/app-store-connect/get-started/app-store-connect-api/)
- [Apple：通过 Xcode 和云签名分发应用](https://developer.apple.com/videos/play/wwdc2021/10204/)
- [Apple：Apps API 的创建限制](https://developer.apple.com/documentation/appstoreconnectapi/apps)
- [Apple：Xcode 26 SDK 最低要求](https://developer.apple.com/news/upcoming-requirements/?id=04282026a)
