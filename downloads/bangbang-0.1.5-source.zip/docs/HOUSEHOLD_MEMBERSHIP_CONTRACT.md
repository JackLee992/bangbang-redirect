# 家庭成员关系领域契约

状态：独立领域模块，尚未接 HTTP、生产存储、客户端、账号恢复或支付。现有家人呼叫与远控授权协议不变。本模块不证明亲属关系，不提供无人值守控制。

实现：[household-membership.mjs](../site/server/household-membership.mjs)；测试：[household-membership.test.mjs](../site/server/household-membership.test.mjs)。无新增依赖，使用 Node 内置 `crypto`。

## 身份与责任边界

- `principal.userId` 必须来自上层已完成的身份认证。模块只检查格式和家庭内权限，**不会验证一个传入的 userId 是谁**；从请求 body、二维码、邀请链接或手机号参数构造 principal 是不安全的。
- 已认证的匿名安装身份可以确认邀请，不要求长辈先注册账户。未来适配器必须先验证该安装持有的凭据，再取得稳定 userId；RustDesk 数字 ID、连接码、设备名称、单独的 installationId 都不能替代认证凭据。
- `familyId`、`userId` 统一为 `[A-Za-z0-9_-]{1,128}` 的稳定 opaque string。调用方负责生成不含 PII 的标识；格式校验不能判断一串数字是否其实是手机号。不要保存姓名、电话、联系人关系、远控密码或画面。
- familyId 是未来家庭权益/计费的归属单位。成员关系、订阅权益、设备配对、每次远控授权是独立判断。加入家庭或付款成功不得跳过设备授权、接听、屏幕共享许可和停止协助能力。
- 本模块不限制同一 userId 加入多个家庭，也不限制创建家庭数量；未来服务层应按明确产品策略、配额和限流控制。跨家庭唯一归属若成为需求，需要额外全局原子约束，不能靠各家庭分别查询后写入。

## 数据与调用接口

所有时间为服务端 epoch 毫秒安全整数。所有状态转移显式传入 `nowMs`，不读取客户端时钟。除安全随机生成器外，函数无网络、文件或全局状态；相同输入产生相同候选，不修改输入，返回值递归冻结。

共同参数：

```js
{
  familyId,
  principal: { userId }, // 由认证中间件注入；其他 claims 不授予 owner 权限
  policy: { maxMembers }, // 来自服务端策略，包含 owner；必须显式传入
  nowMs,
  expectedRevision,
}
```

`maxMembers` 允许 1～128；128 只是当前数据结构的保护上限，不是赠送名额或付费 SKU。策略收紧时可暂时存在超额成员，但不能新增；现有成员仍能退出，owner 仍能移除。服务端每次确认时必须重新读取适用策略；不要信任客户端上传的 policy。

| 函数 | 额外参数 / 结果 | 规则 |
| --- | --- | --- |
| `createHousehold(input)` | `expectedRevision: null` | 生成 revision 1，principal 成为唯一 owner；提交必须 insert-if-absent |
| `createHouseholdInviteSecret()` | 返回 `{ inviteId, token }` | 仅可信服务端调用；分别为 16 / 32 字节安全随机值的规范 base64url |
| `inviteHouseholdMember(state, input)` | `targetUserId, inviteId, token, ttlMs?` | 仅已保存的 owner；指定唯一目标；不立即增加成员 |
| `confirmHouseholdInvite(state, input)` | `inviteId, token, confirmed: true` | 仅被邀请 principal；校验秘密、期限和最新人数策略；添加 member 并消费邀请 |
| `revokeHouseholdInvite(state, input)` | `inviteId` | 仅 owner；删除未消费邀请 |
| `removeHouseholdMember(state, input)` | `targetUserId` | 仅 owner 可移除 member；不能移除 owner |
| `leaveHousehold(state, input)` | 无 | member 只能退出自己；owner 不可退出，转让/解散留待单独设计 |

状态结构如下；其中 `invites` 只保存尚未消费/撤销的邀请，过期记录可能保留到下次成功发邀请时清理，不能仅凭数组存在就视为有效。

```js
{
  v: 1, familyId, revision, createdAt, updatedAt,
  members: [{ userId, role: "owner" | "member", joinedAt }],
  invites: [{ inviteId, targetUserId, tokenHash, createdAt, expiresAt }],
}
```

每个候选结果是 `{ familyId, expectedRevision, nextState }`，确认邀请另带 `validBefore: expiresAt` 作为原子提交前置条件。它表示**待提交变更**，不是已经创建/加入家庭的成功响应。内部状态含认证相关哈希与目标身份，不能直接当客户端响应；后续 HTTP 层应单独实现按需可见的白名单投影。

## 邀请生命周期与秘密管理

默认 TTL 10 分钟，可由可信服务端设置 1～900000 毫秒，最多 15 分钟。过期边界为 `nowMs >= expiresAt`。同一目标最多一个未过期邀请；最多保存 64 条待处理记录作为存储保护上限，与套餐名额无关。

邀请 ID/令牌必须由 `createHouseholdInviteSecret()` 生成，再传入纯转移函数。**不得将客户端提供的 inviteId/token 透传到发邀请函数，不得重复使用已发过的秘密。** 接受邀请时的令牌则来自目标用户提供的邀请内容。这一拆分使随机生成与纯状态计算各自可测试；模块不会把格式正确的客户端自选秘密误称为已验证随机熵。

持久记录只保存带版本前缀及 familyId、inviteId、targetUserId 绑定的 SHA-256 哈希；确认时用 `timingSafeEqual` 比较。原始令牌只供提交成功后一次交付，禁止写入日志、诊断、分析事件、持久记录和错误文本。上层仍需使用 HTTPS、脱敏和限流，令牌放进链接时防止 Referer、代理日志或统计 SDK 泄漏。

确认必须来自用户明确动作：单纯打开邀请、预览链接或收到推送不得调用确认。只有指定目标持有的已认证身份和正确令牌同时满足条件才能加入；转发给其他身份不能生效。确认与删除邀请在同一份 nextState 中完成。已消费/撤销邀请再次使用返回 `invalid_invite`；成员退出或被移除后，旧令牌仍不能重新加入，必须发新邀请。

邀请不预占人数，确认时再次检查名额。过期、取消及消费不另存无限增长的历史墓碑；一次性保证依赖随机秘密不复用、整个家庭记录的单调 revision、持久层 CAS 和旧快照不可写回，不能依赖本机对象冻结。

## 原子提交契约

生产适配器必须以 familyId 为事务单位，强一致读取并执行条件写入：

1. 在受保护的服务入口认证，取得 principal。独立读取服务端策略与当前时间；读取该家庭最新状态和存储版本。
2. 调用对应纯函数，传入读到的 revision。函数拒绝家庭 ID 不符、旧 revision、非法状态、倒退时钟和越权操作。
3. 一次原子写入整个 nextState，条件是 familyId 一致且原 revision / ETag 仍匹配。创建必须要求记录不存在。成员增加和邀请消费禁止分成两次写入。
4. 仅在持久层确认提交成功后交付令牌或返回加入成功。冲突必须重新读取状态、策略和当前时间，重新执行所有检查；不能给旧候选换个 revision 就重写。
5. 确认候选的 `validBefore` 必须由原子提交检查：数据库/事务权威时间严格小于此值。不能先检查时间后无限等待再单独按 revision 写入；存储若不支持这样的条件，应使用具备事务或等价期限保证的适配器。单有 revision 条件不能防止把很久以前计算的“尚未过期”确认迟到提交。
6. 存储异常或未知提交结果不得报告成功。适配器需通过可靠的提交结果/强一致读回消除未知状态；没有确认前不可将秘密或新成员状态发布给客户端。

示意契约（不是可上线的存储实现）：

```js
const principal = await authenticateExistingInstallationOrAccount(request);
const policy = await loadServerMembershipPolicy(familyId);
const saved = await store.readStrong(familyId);
const change = confirmHouseholdInvite(saved.state, {
  familyId, principal, policy, nowMs: serverClock(),
  expectedRevision: saved.state.revision,
  inviteId: requestInviteId, token: requestInviteToken, confirmed: true,
});
// Must atomically check version AND the time-sensitive invitation precondition.
const committed = await store.compareAndSwapMembership(saved.version, change);
// False/unknown: reread + recompute, or fail; never publish change as success.
```

两个请求读取同一 revision，可以分别算出合法候选；**只有一个能提交**。后一个必须重新计算，因此不能冲开最后一个名额，也不能撤销成功后再用旧确认候选把邀请恢复。测试中的 `AtomicRecord` 只是对此契约的内存模拟，不代表 Netlify Blobs、SQL 或任意线上存储已经满足它。

创建家庭跨请求的重试/重复创建防护、请求幂等键、成员查询索引、策略版本事务、匿名账号恢复/合并和迁移、审计保留/清除、删除家庭、HTTP 鉴权与限流，均由后续集成单独实现。没有这些适配与验收，不开放公网。特别是跨存储的策略变更与家庭确认需要明确一致性方案，不得将旧权益当作永久名额许可。

## 验证边界

`node --test site/server/household-membership.test.mjs` 覆盖：owner 创建、严格策略与 ID、身份参数注入、秘密格式和哈希、目标冒用、显式匿名确认、跨家庭、TTL、消费重放、撤销、人数限制、成员移除/退出、旧 revision、最后名额竞争、撤销与确认竞争、过期后延迟提交、异常存储形状。

测试证明纯领域规则和模拟 CAS 契约。它不证明认证系统、云端持久化、真实并发事务、客户端两步体验、家庭付费同步或远控授权已经接通。现有 [家人呼叫服务](../site/server/family-service.mjs) 未修改。
