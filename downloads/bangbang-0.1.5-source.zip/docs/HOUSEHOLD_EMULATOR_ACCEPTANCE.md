# 家庭恢复双模拟器验收

`scripts/qinban/emulator_household.py` 只面向已经准备好的 Android 15 模拟器
`emulator-5560`（长辈）和 `emulator-5562`（家人）。它不会安装、构建、清空应用数据、
修改应用存储或启动模拟器。手机流程执行前必须明确指定候选提交和 APK SHA-256；
两台已安装 APK 的实际哈希均须相同。

## 前提

- 候选包编译时使用 `QINBAN_TEST_FAMILY_URL=http://10.0.2.2:8090/family`、
  `QINBAN_HOUSEHOLD_URL=http://10.0.2.2:8788/v1/household`。
- 两台手机的原生协助连接使用同一套本地测试 hbbs/hbbr（现有 23016/23017）；
  脚本不更改原生网络设置，也不把公开服务的连接结果归因于本地夹具。
- 长辈已开启输入辅助权限，两台角色正确，均无正在进行的协助/系统录屏授权弹窗。
- 独立测试观察器 `io.github.jacklee992.bangwo.test` 已安装。它使用
  `FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES`；不运行会暂停输入辅助服务的 stock uiautomator。
- 本地端口 8090、8788 空闲；脚本只停止自己启动的夹具进程，不清理占用端口的其他程序。
- `.qinban-cache/qa-venv/bin/python` 有 OpenCV，Node 支持 `node:sqlite`。
  本次准备检查的 Node 为 bundled v24.19.0。

## 运行

先由负责人完成候选包安装、网络配置和运行授权，再从仓库根目录执行以下命令；
替换提交、APK 哈希和新建的证据目录名。帮助入口只解析参数，不访问设备。

```sh
.qinban-cache/qa-venv/bin/python scripts/qinban/emulator_household.py --help
.qinban-cache/qa-venv/bin/python scripts/qinban/emulator_household.py \
  --run --candidate-ref <approved-commit> --apk-sha256 <64-character-sha256> \
  --evidence artifacts/household-emulator/<fresh-run>
```

脚本通过已有的观察器读取界面，按中文控件与观察到的边界点击，使用页面的复制按钮
保存恢复卡。跨模拟器传递邀请码和恢复卡时，只向测试剪贴板种入已观察到的内容，
再走普通输入框粘贴和确认。不会直接写入应用身份、配对或家庭数据。

预期流程：

1. 原生邀请、长辈批准、真实远程点击与画面变化、双方停止协助。
2. 从长辈页面发起一条已配对请求，家人明确拒绝，录屏结束。
3. 家人创建家庭、复制并确认保存恢复卡、选择当前已配对长辈生成邀请。
4. 长辈粘贴家庭邀请并明确加入；界面和 SQLite 均出现两名成员。
5. 重启真实 household 子进程，保持同一数据库，重新打开页面确认成员与称呼。
6. 家人在页面中用恢复卡找回，生成新安装身份；家庭成员身份、家庭和称呼保持，
   恢复卡旋转，旧安装被撤销。
7. 等待真实内部 HMAC 撤销确认，验证旧安装 register/poll/identity.verify/push.resolve/
   household.list 都返回 401，新身份没有配对且不能接通旧请求；页面显示撤销完成，
   无原生协助或录屏自动启动。
8. 再发普通邀请并由长辈批准，重新建立配对，验证真实远程点击与画面，再停止协助。
   新增的原生连接总数必须恰好两次，恢复本身不得创建连接。

## 夹具与证据边界

`local_household_server.mjs` 绑定 127.0.0.1；family 是真实服务加受控内存 CAS，
household 使用真实 SQLite、HTTP 身份验证和 HMAC 撤销。固定测试 HTTPS 地址只在
注入的测试 transport 中映射到 loopback，没有更改生产 HTTPS 校验或增加生产管理接口。
未提供推送凭据，本流程不验证 APNs/FCM 或厂商推送送达。

family 父进程持续运行；SIGUSR2 关闭并重新启动 household 子进程，进程号必须改变。
这样保留配对认证，同时证明 SQLite 和撤销 outbox 能跨进程重启。整个夹具重新启动
会丢失 family 的内存数据，因此必须使用全新证据目录，不能复用此前数据库。

私有目录采用 0700/0600 和 umask 077，全部位于 Git 忽略的
`artifacts/household-emulator/`。截图、界面 XML、恢复卡、邀请码、SQLite、日志，以及
为旧身份拒绝测试保留的真实测试 Bearer 都在该目录内。只读服务/数据库断言补充 UI
证据，不替代用户点击。`result.json` 仅含静态检查摘要、候选提交/哈希、成功/失败和
异常类型；不含身份、口令、成员称呼。不要上传整个证据目录或把私有文件纳入 Git。

2026-10-02 准备阶段：Node 语法、Python 编译、两个帮助入口通过；随机空闲 loopback
端口验证了真实注册/配对/家庭创建、子进程重启持久化、恢复卡和持久 outbox 驱动的
真实 HMAC 撤销。此阶段没有运行任何 ADB 命令、安装/构建或手机 UI 操作。
实际手机流程仍需候选包运行后检查 `result.json`；主机准备检查不代表模拟器、实体手机
或生产验收通过。
