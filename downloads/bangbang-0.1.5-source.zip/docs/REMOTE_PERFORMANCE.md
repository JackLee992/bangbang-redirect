# 远控流畅度：实现检查、优化与替代方案

更新：2026-10-02。针对“iPhone 帮助 Android，连接后画面和操作不顺畅”。本轮优先建立可验证的性能记录并修复交付错误，保留现有 RustDesk 引擎；替换引擎需先做小范围对照。本文的代码判断、模拟器检查、待验收目标分开描述，不代表已在真实 iPhone 或跨运营商网络达标。

## 已确认的实现约束

| 环节 | 当前实现 | 对优化的影响 |
| --- | --- | --- |
| 版本与构建 | RustDesk 1.4.9，固定源提交 `6c578292e8ebbbec708b76986ba8c4bc7c509747`；Android 复用核验过的官方原生库 | 改 Rust 源码必须重新构建 Android `.so`，只构建 Flutter 不会包含这些修改 |
| Android 采集 | MediaProjection、ImageReader RGBA、`acquireLatestImage`、JNI；实际没有走 Kotlin VP9 编码分支 | 调整未使用的 Kotlin VP9 常量不能解决当前链路问题 |
| 缩小画面 | 软件编码路径有长边超过 1200 时减半的逻辑；硬件编码不等价；Android 未实现通用远程改分辨率消息 | 不能仅加一个“720p”菜单就声称实现降分辨率 |
| iOS 解码 | 该固定版本关闭 iOS 硬解判定；H264/H265 可走 FFmpeg 软件解码 | 高分辨率软件解码是待实测的瓶颈假设；启用 hwcodec 编译特性不等于接入 VideoToolbox |
| 移动端显示 | native RGBA → Dart 借用缓冲区 → `ui.Image` → Flutter 绘制 | 有复制和图像构造成本；本轮记录其交付耗时，未改为 Texture |
| 帧背压 | 原生有效帧未释放时丢弃后续帧，Dart 完成读取后才调用 `nextRgba` | 已有丢帧保护，不能提前释放借用内存或擅自并行解码 |
| FPS | 原生解码计数在交付丢帧判断前累加 | 原生 FPS 可能高于实际交给 Flutter 的帧率，必须分别测量 |

代码入口：`flutter/lib/models/model.dart`、`flutter/lib/models/platform_model.dart` 相关原生适配、`flutter/lib/utils/image.dart`、`src/flutter.rs`、`src/client/io_loop.rs`、`src/server/video_service.rs`、`src/server/video_qos.rs`、`libs/scrap/src/common/codec.rs` 与 `hwcodec.rs`、Android `MainService.kt`。

## 本轮改动

1. **画面有效后才记首帧成功。** 移动 RGBA 路径等待 `ui.Image` 构造、画布准备和安装；构造失败保留上一张有效画面。关闭、同一设备重新连接、同 stream 重连均拒收过期帧，并释放未交付图像。借用像素的所有权和释放顺序保持不变。
2. **本机性能记录。** 每 5 秒聚合一次，结束时补最后短窗口；最多保留最近一次协助的 60 段。记录原生解码 FPS、`ui.Image` 交付率、画面构造与交付平均/最大/P95 耗时、编码、尺寸、网络往返、目标码率、接收速率。P95 使用窗口内最近最多 128 个样本，其余均值/最大值覆盖所有有效交付。静止画面低 FPS 不作为卡顿结论。
3. **诊断可查看、可复制。** 控制端的连接诊断中展示最近画面表现，与“连上且看到第一帧”的成功率分开。指标只在本机保存，不含设备号、邀请、像素或原始事件，不接入云端上传；网络往返不等于点击响应，交给界面也不等于屏幕实际刷新。
4. **流畅优先入口。** 在协助工具条提供现有低画质预设的快捷入口，减少画面细节；保留恢复画质操作。调用原生真实设置接口，不修改编码协商。这个预设会影响引擎的 FPS 自适应行为，并非仅更改按钮文字；自定义画质恢复须回发原参数。
5. **挂断固定可见。** 挂断位于工具条固定左侧，其他工具横向滚动，不会因新增快捷键而把挂断挤出屏幕。

本轮未实现硬解、零拷贝 Texture、触控 RTT 协议或新的后端部署。成功首帧也不能证明后续持续流畅。

## 验证与证据

当前验证环境为两台本地 Android 15 ARM64 模拟器、本机 RustDesk 与家人请求服务。Debug 包开启明确的模拟器测试后端配置，不能作为公开下载包。性能记录可以验证事件和单位是否接通；Debug、模拟器与本地直连的数值不能外推为 iPhone、Release、跨网或 TURN/中继表现。

0.1.2（12）候选的实测结果：

- Flutter 175 项测试、网站/家人服务 40 项、诊断 Worker 6 项、打包工具 22 项通过；Android Debug 构建和 iOS unsigned Release 构建通过。
- 双安卓模拟器通过通知接听、实际视频、远程点击和画面更新、家人端挂断释放录屏、再次求助、撤回清通知、拒接释放录屏；该次首帧耗时 2816ms，走本地直连。证据：`artifacts/remote-performance/lifecycle/result.json`。
- 固定滚动场景每档取得 4 个完整窗口，共20秒。普通画质交给界面29.1帧/秒，平均交付4.03ms；流畅优先21.75帧/秒，平均交付3.80ms。均为VP8、360×800。仅各一轮，不能推导因果收益；尤其不能把“流畅优先”解读为一定提高FPS，因此保留自主开关，不自动替用户开启。数据：`artifacts/remote-performance/quality-clean-start/result.json`；复跑脚本：`scripts/qinban/emulator_remote_performance.py`。
- 同时复现长时间中断后呼叫过期、下次接听无反应。后者已定位到 `_acceptedLocally` 和首帧状态未清理，在 `fix/call-accept-reset` 修复并合并；租约容忍策略仍按F-04另行推进。失败记录保留在 `artifacts/remote-performance/quality-replay/`。
- iOS新构建核对239个应用输入SHA及534个依赖/生成输入；复用原生库出现“编译目标iOS26.5，高于链接目标13.0”告警，旧系统兼容仍是发布阻塞项。仅编译，不证明可分发或真机性能。清单：`artifacts/ios-local/remote-performance-source-snapshot.json`。

0.1.2（13）补充回归：

- App 源码冻结于 `37da688`；Flutter **189项通过**。Android Debug APK SHA-256：`4b4ad9683061868b26494c0c0b1d6b64402b46e48b8de9971a8cb896ff9b107d`。iOS unsigned Release 13 构建通过，原生最低系统兼容仍须在正式分发构建中修正。
- 双安卓模拟器验证：长辈结束已接通协助，家人确认“协助已结束”返回，然后同一进程接听下一次求助；两次均记录真实图像交付，双方结束后均释放录屏。没有通过重启家人端掩盖旧接听标记。证据：`artifacts/remote-performance/reaccept-13-complete/result.json`；脚本：`scripts/qinban/emulator_call_reaccept.py`。
- 首轮回归脚本错误地等待直接返回首页，实际产品会先显示结束弹窗；观察后补齐正常点击“返回”的流程再完成两通回归。首轮证据保存在 `reaccept-13/`，不是新的产品连接失败。
- 该修复只恢复终态后的再次接听，不改变60秒活动租约或1小时上限；F-04仍未完成。画质比较继续引用12号包的明确样本，不虚构13号新的FPS结果。

iOS分发修复补充：aom/opus/yuv与Rust静态库已在隔离构建目录重编，1,786个原生对象最低系统均不高于iOS15；最终归档minOS15.0，旧413条较新系统链接警告归零。0.1.2（13）已签名上传并送审，后续收到 ITMS-91061，不能继续作为可用公测候选。0.1.2（14）已补充可追溯隐私清单并移除未用媒体依赖，归档等待 Mac 钥匙串授权；尚未上传或获批。公开链接已建但不可加入。没有据此补写真机性能结论，见 [修复记录](IOS_RELEASE_14.md)。

后续真机基线按同一台 Android、同一台 iPhone、同一组操作、相同画质与网络重复，记录版本和构建方式。至少覆盖同 Wi-Fi、不同网络、强制中继、丢包/高延迟；连续滚动、文本输入、应用切换与静止画面分开。用两机同步录像或带回执的测试协议测触控到画面响应，不能用现有网络探测值替代。

## 基础库选择

调研日期：2026-10-02。以下为官方文档与仓库信息，版本主分支仍会变化；真正接入时锁定 release 并复核最低系统与许可。

| 方案 | 可复用能力 | 仍需我们实现 | 建议 |
| --- | --- | --- | --- |
| 当前 RustDesk | 屏幕、输入协议、穿透/中继、配对和现有客户端 | iOS 瓶颈实测，硬解/Texture 改造，可靠恢复 | 近期主线，先修可证实问题，避免整体迁移打断产品 |
| `flutter_webrtc` | WebRTC 视频、DataChannel、连接统计，P2P/TURN | MediaProjection 接入、输入协议与授权、身份和配对、挂断、信令及 TURN | 下一阶段做“Android 发屏 + iPhone 看屏 + 少量控制事件”A/B，小范围验证后决定 |
| LiveKit | Flutter SDK、SFU、屏幕共享、连接恢复、媒体/数据统计，AdaptiveStream/Dynacast | 现有设备配对与权限、输入控制、服务部署与鉴权；E2EE 要密钥管理 | 需要多人协助或统一 RTC 平台时评估；增加 SFU 路径不自动意味着更快 |
| droidVNC-NG | Android 屏幕共享和输入能力参考 | iOS 查看端、可靠配对、受保护传输、网络适配和产品流程 | 暂不替换；尚无证据证明该产品的手机间流畅度更好 |

官方来源：

- [RustDesk 与 AGPL-3.0](https://github.com/rustdesk/rustdesk)，[官方高级设置](https://rustdesk.com/docs/en/self-host/client-configuration/advanced-settings/)。
- [flutter_webrtc 与 MIT](https://github.com/flutter-webrtc/flutter-webrtc)，[PeerConnection/getStats](https://flutter-webrtc.org/docs/flutter-webrtc/api-docs/rtc-peerconnection/)，[DataChannel](https://flutter-webrtc.org/docs/flutter-webrtc/api-docs/rtc-data-channel/)。
- [WebRTC 建立连接](https://webrtc.org/getting-started/peer-connections)，[TURN](https://webrtc.org/getting-started/turn-server)。
- [LiveKit Flutter SDK](https://github.com/livekit/client-sdk-flutter)，[LiveKit Server 与 Apache-2.0](https://github.com/livekit/livekit)，[屏幕共享](https://docs.livekit.io/transport/media/screenshare/)，[AdaptiveStream](https://docs.livekit.io/transport/media/subscribe/)，[Dynacast](https://docs.livekit.io/transport/media/advanced/)，[部署](https://docs.livekit.io/transport/self-hosting/deployment/)，[端到端加密](https://docs.livekit.io/transport/encryption/)。
- [droidVNC-NG](https://github.com/bk138/droidVNC-NG)，[GPL 许可](https://github.com/bk138/droidVNC-NG/blob/master/COPYING)。

Flutter 当前为 3.24.5。调研时 LiveKit 主分支依赖要求 Flutter ≥3.38、Dart ≥3.10，因此不能直接添加最新版便假定兼容。flutter_webrtc 主分支声明 Dart ≥3.3、iOS ≥13，仍需在我们的固定 Flutter/Xcode/Android 工具链上实际编译和运行。两者都不能免除 Android 录屏和无障碍授权，iOS 作为控制端无需新增屏幕广播扩展。

WebRTC 试验保留控制消息的顺序和按下/抬起配对；只允许合并过期移动，不能把所有点击命令改为不可靠传输。国内直连、UDP 与 TURN 可达性需真实网络验证，免费额度和机房地理位置不是可用性的证明。

## 下一步合并与决策

按 [功能研发规划](FEATURE_ROADMAP.md) 的功能边界、依赖和验收门槛推进。先以同一套测量比较现有引擎的设置，再做硬解/Texture 试验；只有替代方案在首帧、持续交付、触控响应、恢复成功率和资源消耗上有可重复证据，才决定迁移。

另已发现前台恢复/网络轮询间隔可能触发活动呼叫租约过期。它影响持续连接，不能当成图像卡顿的同一个根因；单独修复并覆盖跨端状态机、取消、挂断和恢复测试。
