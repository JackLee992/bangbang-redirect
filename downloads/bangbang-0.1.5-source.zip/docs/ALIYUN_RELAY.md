# 阿里云 RustDesk OSS 发现 / 中继部署

核对日：2026-10-03。目标为现有北京 ECS `123.57.57.202`，Ubuntu 20.04 x86_64、2 核 2GB、固定公网 3Mbps。部署包在 [backend/aliyun/relay](../backend/aliyun/relay)，只新增独立服务，不代理 APK、家人 API 或宣发网站。家人数据权威切换有独立验收。

本轮已完成真实 ECS 安装、最小安全组规则、公网注册/验签/双向转发，以及重启、幂等和实际回退。手机远控和客户端切换尚未验收；协议探测不代表 iPhone→Android 已接通或画面流畅。

## 固定发行包与许可

使用官方 **OSS 1.1.16** 原生 amd64 ZIP，固定源提交 `73523b31cfd25d77dee862e6fc9f5e1fb5e485ef`。该版本修复了未认证 UDP 打洞请求的反射放大问题。版本、资产 ID、长度及每个二进制的 SHA 已固定在 [release.json](../backend/aliyun/relay/release.json)，安装不查询 `latest`、不执行网上安装脚本、不安装 Docker 或 TURN。[官方发行页](https://github.com/rustdesk/rustdesk-server/releases/tag/1.1.16)

| 文件 | 字节数 | SHA-256 |
| --- | ---: | --- |
| rustdesk-server-linux-amd64.zip | 6,013,895 | `0565c41affe6c3f409b0bddfaf5a24ccbf3f64f5f8e3fec250b69a0d5f6bdbcf` |
| hbbs | 9,678,448 | `374c821722b04f6d7ef063c78bc5b4db7109b8b9613508822d803e31fdc5b625` |
| hbbr | 3,372,192 | `3ad04953242db5a9a78d45d41d13b9c6ecff651881e3a7f594f8b36a321e2457` |
| rustdesk-utils | 574,000 | `bdac47af7201b702e43a8262c08cef3e5703e081ddbf6c679c4ceef98d8744c9` |

ZIP SHA 来自官方 [GitHub Release API asset digest](https://api.github.com/repos/rustdesk/rustdesk-server/releases/tags/1.1.16)，并经本机实际下载复算相同；成员 SHA 来自同一已验真 ZIP。摘要验证文件与固定来源的一致性，不宣称存在未核实的发行方独立签名。

服务端为 **GNU AGPL v3**，原始完整许可随部署包及安装目录保留：[LICENSE.rustdesk-server](../backend/aliyun/relay/LICENSE.rustdesk-server)。固定原版源代码公开可得；分发或修改时须遵守相应源码与许可义务。网络交互相关条款见原许可证第 13 节。OSS 安装不使用 Pro 许可、控制台、策略或账号能力。[固定版本许可](https://github.com/rustdesk/rustdesk-server/blob/1.1.16/LICENSE)、[对应源代码](https://github.com/rustdesk/rustdesk-server/tree/73523b31cfd25d77dee862e6fc9f5e1fb5e485ef)

## 公网端口与客户端

| 入站 | 用途 | 本次处理 |
| --- | --- | --- |
| TCP 21115 | NAT 测试 | 安全组 / 主机现有策略允许 |
| TCP 21116 | NAT 测试、打洞及会话协商 | 安全组 / 主机现有策略允许 |
| UDP 21116 | RegisterPeer / RegisterPk 注册与心跳 | 安全组 / 主机现有策略允许 |
| TCP 21117 | 原生加密会话中继 | 安全组 / 主机现有策略允许 |
| TCP 21114 | Pro API | 保持关闭 |
| TCP 21118 / 21119 | OSS Web 客户端的 WS 监听 | 安全组关闭；本机独立链拒绝非回环访问 |

只开放上述四种原生入站，不照抄 `21114:21119` 全范围。SSH 沿用现有管理来源规则，不扩大权限。安装器不在主机上添加原生端口的 ACCEPT；已有 UFW/iptables 若拒绝原生流量，执行者须检查实际策略并只补上述规则。既有回环后台 8789、Caddy 8080 不应公开。官方说明了 [端口及 WS 信任头风险](https://rustdesk.com/docs/en/self-host/rustdesk-server-oss/install/)。

两端必须使用同一服务器和实际公钥：

```text
ID server:    123.57.57.202:21116
Relay server: 123.57.57.202:21117
Key:          /var/lib/bangbang-relay/id_ed25519.pub 的内容
API server:   留空（这是 RustDesk 引擎字段，区别于帮帮家人 API）
WebSocket:    关闭
```

`hbbs -p 21116 -r 123.57.57.202:21117 -k _` 与 `hbbr -p 21117 -k _` 都从同一持久目录读取 `id_ed25519`。`-k _` 把许可匹配值设为该密钥的公钥；客户端缺少 / 不匹配该公钥时，发现与中继请求被拒绝。私钥从不作为命令参数、环境变量或输出。安装后 `/etc/bangbang-relay/client-config.json` 是可读取的公开连接配置，包含公钥、不包含私钥；实际帮帮配置由客户端改动及安装包验收确认。[官方客户端配置](https://rustdesk.com/docs/en/self-host/client-configuration/)、[1.1.16 hbbs 校验逻辑](https://github.com/rustdesk/rustdesk-server/blob/1.1.16/src/rendezvous_server.rs)、[hbbr 校验逻辑](https://github.com/rustdesk/rustdesk-server/blob/1.1.16/src/relay_server.rs)

公钥用于校验服务器签名和要求匹配的连接，**不是家庭身份凭据**；它可以分发给客户端，得到公钥的人也可尝试使用公开发现 / 中继。原生会话端到端加密由 RustDesk 两个客户端的握手建立；服务器协议检查不证明某个手机会话已加密或已得到双方授权。家人求助、每次分享授权及结束控制仍由帮帮客户端实施。

## OSS 的 TCP 注册 / WSS 边界

1.1.16 的 UDP 分支处理 `RegisterPeer` / `RegisterPk`；TCP 和 WS 共用 `handle_tcp`，`RegisterPk` 返回 `NOT_SUPPORT`，没有 TCP `RegisterPeer` 注册分支。TCP 21116 可达用于协商，不等于 TCP 设备注册可用。该版本有意不接受 UDP `PunchHoleRequest`，受支持打洞请求走 TCP / WS；这不取消 UDP 注册。[固定版本源码](https://github.com/rustdesk/rustdesk-server/blob/1.1.16/src/rendezvous_server.rs)

OSS 确实监听 21118/21119，但不能据此承诺帮帮移动原生的完整 WSS 注册路线。官方 `allow-websocket` 明确要求客户端 ≥1.4.0、**Pro 服务端 ≥1.5.7**；本次不开该选项、不配置 443 WSS 反向代理、不申请证书。若某网络屏蔽 UDP，客户端自动转 TCP 注册在这个 OSS 版本无法解决；应保留有界失败并用实际网络验证，不能用 NAT 测试成功代替注册。[官方 allow-websocket](https://rustdesk.com/docs/en/self-host/client-configuration/advanced-settings/#allow-websocket)

## 安装、持久数据与资源限制

先把这个目录完整传到 ECS 的 root 私有暂存目录。若 ECS 无法直连 GitHub，可以将上述已核 SHA 的 ZIP 一同传入；安装仍复核长度、包 SHA、路径白名单、三个 ELF 类型和成员 SHA。

```sh
# 默认使用已知公网 IP；读取官方 HTTPS ZIP。
sudo sh /root/bangbang-relay/install.sh --public-host 123.57.57.202

# 预先传入官方 ZIP 时，避免云端重新下载。
sudo sh /root/bangbang-relay/install.sh \
  --public-host 123.57.57.202 \
  --archive /root/rustdesk-server-linux-amd64.zip
```

运行环境需要 Python 3.8+、systemd 245+、`ss`、`iptables`/`ip6tables`、`flock`、`runuser`，Ubuntu 20.04 常规环境通常已有；缺失会在写服务前拒绝。安装器不自动升级 OS、安装依赖或改变 Node / Caddy。新增用户 `bangbang-relay` 无登录 shell。

| 位置 | 内容 / 权限 |
| --- | --- |
| `/opt/bangbang-relay/releases/<version>-<deployment hash>/` | 已验真的原版二进制、管理及验收程序、许可；root 所有，文件 0555/0444 |
| `/opt/bangbang-relay/current` | 原子切换到当前发行目录 |
| `/etc/bangbang-relay/relay.env` | root 0600；只含公网地址及带宽值 |
| `/etc/bangbang-relay/client-config.json` | root 0644；公开连接配置。父目录 0700，只通过受控读取交付给客户端 |
| `/var/lib/bangbang-relay/` | 服务用户 0700；共享密钥、SQLite、服务器运行数据，**不随版本回退重建** |
| `id_ed25519` / `id_ed25519.pub` | 服务用户 0600；缺一、权限异常或不匹配即拒绝，绝不自动重生 |
| `/opt/bangbang-relay/snapshots/` | root 0700 / 文件 0600；只快照两个 unit、公开连接配置、容量配置与原有启用状态，不复制密钥或设备数据库 |
| `/var/cache/bangbang-relay/` | root 0700；固定官方 ZIP 缓存 |

`rustdesk-utils genkeypair` 的输出仅在安装进程内捕获并写入文件；不打印 Secret Key、不用 `validatekeypair` 把私钥传进进程参数。现有完整密钥对被保留。`key_check.py` 做文件类型 / 权限 / 长度 / 公私结构一致检查；一次性真实注册 probe 另外验证服务器签名，区别于结构检查。

systemd 两服务都无 Linux capability、文件系统只读、限制设备 / 内核 / 命名空间访问，只能写持久目录；hbbs `MemoryMax=256M` / `CPUQuota=50%`，hbbr `MemoryMax=384M` / `CPUQuota=100%`，各 `LimitNOFILE=1024`。重启间隔 5 秒，120 秒内最多 5 次失败启动；异常不无限重启。正常日志为 `warn`，进 system journal、每服务 30 秒 60 条限流，不另建未限量访问日志或录屏文件；沿用主机 journal 保留策略，不修改其他服务日志。日志可能包含 IP/设备 ID，只在服务器受限读取，不原样入 Git/公开报告。

两个 unit 的 `ExecStartPre=+.../firewall.sh` 只以 root 更新本包独立 INPUT 链，其后进程以低权限用户启动；重启与开机重新保证 WS 拒绝规则。IPv4/已启用 IPv6 均覆盖，不 flush 其他链。回环协议验收不受限；非回环原生 TCP SYN 超过每源 IP 30 次/秒（突发 60）或 UDP 21116 超过 60 包/秒（突发 120）丢弃。这个粗限流不能阻止分布式滥用，共享运营商出口也可能受影响；它不是家庭账号配额。

### 3Mbps 初始容量

原版 hbbr CLI 只有 `-p` / `-k`；容量使用环境变量。固定配置如下，[源码按 bit/s、1024² 换算，双向转发都消耗同一限速器](https://github.com/rustdesk/rustdesk-server/blob/1.1.16/src/relay_server.rs)：

```text
TOTAL_BANDWIDTH=2         # 总 2,097,152 bit/s，约 2.097 十进制 Mbps
SINGLE_BANDWIDTH=1.5      # 每个配对 1,572,864 bit/s
LIMIT_SPEED=0.75          # 被降档配对为 786,432 bit/s
DOWNGRADE_THRESHOLD=0.90
DOWNGRADE_START_CHECK=30  # 秒；超过该时长且会话平均速率高于阈值后降档
```

这为既有轻量 API 和协议开销留余量，先按**约一路低码率、低帧率的手机协助**试用。限速会增加拥塞下的排队，不能替代客户端码率自适应；两路同时中继会共享约 2.097Mbps，即便有多个已注册设备也不能宣称多路画面流畅。没有严格“最多一路”的会话配额或商业服务 admission control。维持可直连路径，不默认强制所有会话中继；无需为了测试购买资源。

## 健康与实际验收

```sh
# ECS：读取受限状态、版本摘要、unit、监听、WS/flood guard 和原生协议。
sudo python3 -B /opt/bangbang-relay/current/health.py --local

# ECS：额外真实 RegisterPeer/RegisterPk 及签名公钥验收。
sudo python3 -B /opt/bangbang-relay/current/health.py --local --register

# Mac 或另一网络：只准备服务器公钥文件，再验证公网路径。
python3 -B backend/aliyun/relay/health.py \
  --host 123.57.57.202 --key-file /private/path/relay-public-key.pub --register
```

默认探测依次验证 TCP 21115/21116 的 NAT 协议、UDP 21116 的无状态短 ID 错误应答、hbbs 缺公钥拒绝 / 正确公钥接受、hbbr 缺公钥拒绝以及两条 nonce 流之间各 64 字节的实际双向转发。公网模式还要求 21114/21118/21119 不可连接；任何一项不成立就失败，不跳过失败项。输出只保留验证结果、时延和非用户服务指标，失败不回显密钥、线上的 protobuf、日志或异常参数。

本机验收使用实际路由的私有 IPv4，而不是 `127.0.0.1`：固定版本 hbbs 对回环 TCP 21115 使用管理命令协议，不能在那里发送 NAT 探测。真实注册后的 `LocalAddr` / `PunchHoleSent` 应答通过 TCP 21116 发送，UDP 注册成功不意味着可以用 UDP 完成这个协商步骤。

`--register` 每次创建一个全新随机 ID/UUID/公钥，通过真实 UDP 注册和心跳，模拟接收打洞 / 局域网请求，再校验 hbbs 返回 `IdPk` 的 Ed25519 签名确实匹配已配置服务器公钥及该 nonce 设备。验签实现仅用于诊断，并以 RFC 8032 公共向量及篡改样本核对；生产 RustDesk 密码学由原版实现负责。此选项**会保留一个合成 peer 记录**，不删除/编辑其他数据库行；探测 socket 关闭后不续心跳。不把随机数据转发标为完整端到端加密视频成功。输出显式 `client_remote_desktop=NOT_TESTED`、`tcp_device_registration=UNSUPPORTED_BY_OSS_1.1.16`。

后续仍须验收同一候选 APK / iOS 包的 UDP 注册、双方明确同意、实际首帧、远程点击/滑动和主动结束投屏。Wi-Fi / 蜂窝及跨运营商分别验收；实际路线需区分直连与本 ECS 中继。[统一连接验收口径](CONNECTION_RELIABILITY_ACCEPTANCE.md)

### 2026-10-03 真实部署结果

- 当前固定发行目录为 `1.1.16-bd5428e28546f6d2`；两个低权限 systemd 服务已运行并启用开机启动，共用持久密钥及数据库。
- 用户在提交前明确批准两条入站规则。北京时间 20:44/20:46 在现有安全组新增 TCP `21115/21117` 和 UDP `21116/21116`，来源仅 `0.0.0.0/0`；实际表格为原三条加这两条，共五条。没有新增 80/443、8080、8789、21114、21118 或 21119 规则，既有管理规则保留。
- Mac→公网地址的六项正向检查通过：两个 TCP NAT 应答、UDP 无状态应答、发现服务公钥校验、双向 64 字节中继、随机设备 UDP 注册及服务器 Ed25519 验签。一次观察的 NAT 应答为 31–86ms、双向转发检查为 152ms，属于小报文协议样本，不是视频时延指标。
- ECS 本机完整健康和真实注册验签通过。相同配置重新安装返回 `changed=false`，两个服务 PID 保持；实际重启、回退到上一发行目录、恢复当前目录均成功，每步核对原私钥/公钥字节与数据库 inode 保持。没有以新密钥替代原身份。
- **关闭端口的独立公网负向证据仍不完整。** 当前 Mac 网络对未开放的 21114/21118/21119，以及仅回环监听的 8080/8789，都先返回 TCP 连接成功、随后无应答。不能据此确认真实服务暴露，也不能把完整公网 `health.py` 标成通过。安全组表格与 ECS 的 IPv4/IPv6 独立防火墙检查已通过；仍需另一条可准确反映拒绝/超时的外网复核。检查没有被削弱。
- 聚合证据保存在忽略的 `artifacts/aliyun-migration/`，不含私钥、家庭数据或原始服务器日志。`--register` 留存少量随机探测设备行，其范围在输出中明确标记。

### 客户端接入条件

现有公开 APK 和 iOS 包仍使用原远控服务器，本次没有静默改动已配对家庭的 `serverScope`。两端必须同时采用上面的服务器/公钥组合，否则仅分享当前 BB1 邀请码不足以识别新的服务器。需要先完成携带受信服务器配置版本的邀请协议、网站与两端接收兼容，再发布候选包；已有自定义配置及旧家庭能力凭据不应被覆盖或重新标记。部署成功不等于客户端已迁移。

## 幂等与回退

同一固定包、同一公网配置且健康时，再运行安装返回 `changed=false`，不重启、不生成密钥。不同配置先保存受限快照，原子切换发行与配置，随后验收；失败自动恢复旧 unit、当前发行及原启用/运行状态，保留持久密钥/数据库。第一次失败时停用并移除本次 unit/当前指向及新建独立防护链，但保留私人状态以便排查，不删除身份。

```sh
# 最近一次成功且 changed=true 安装之前的完整服务配置。
sudo python3 -B /opt/bangbang-relay/current/manage.py rollback

# 指定安装输出里的快照文件名；脚本拒绝任意路径。
sudo python3 -B /root/bangbang-relay/manage.py rollback --snapshot YYYYMMDDTHHMMSSZ-xxxxxxxx.json

# 暂停本包两个服务并取消开机启动，保留钥匙、数据库和主机 WS 防护。
sudo python3 -B /root/bangbang-relay/manage.py stop
```

首次安装之前没有旧服务，执行其回退后 `/opt/.../current` 不再存在，继续管理使用上传的 `/root/bangbang-relay/manage.py`。回退不自动关闭云安全组或修改客户端；执行者根据真实安装结果同步客户端端点与云安全组，原公共服务配置可作为客户端回退。

本机验证：19 项标准库测试无跳过通过（篡改 ZIP/成员、路径越界、重复条目、密钥半写/权限/链接/不一致、环境注入、截断/超大帧、错误 key 拒绝、RFC 8032 验签与篡改、回退保留身份及 SQLite）；两项 shell 语法检查通过；实际官方 ZIP 与三项 ELF SHA 复核通过。Mac 未运行 Linux ELF、systemd 或真实 iptables；这些须由 ECS 的真实安装与健康验收补齐。
