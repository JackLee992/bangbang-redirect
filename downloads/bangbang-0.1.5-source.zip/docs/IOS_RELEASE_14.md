# iOS 0.1.2（14）隐私清单修复

## 原因和范围

构建 13 上传及提交 TestFlight 审核后，Apple 邮件要求修复 ITMS-91061，
点名 DKImagePickerController、DKPhotoGallery、SwiftyGif、device_info_plus、
file_picker、package_info_plus、sqflite 七个框架缺少隐私清单。上传成功或
网页短暂显示等待审核不能替代后续校验结果；构建 13 不能作为已获批公测包。

本次保持 Flutter/Dart 业务代码和 Android 依赖不变，只修改 iOS 依赖配置、
SDK 隐私资源及验证。iOS 最低版本继续为 15。不得给所有 SDK 统一套用一份
空清单，也不得以 App 根清单代替每个动态框架自身的声明。

## SDK 处理

file_picker 5.5.0 本身提供 `Pod::PICKER_MEDIA`、`Pod::PICKER_AUDIO` 编译选项。
当前 iOS 控制端不提供媒体/音频选择入口，关闭这两个选项，保留文档选择能力。
CocoaPods 实际移除了 DKImagePickerController、DKPhotoGallery、SwiftyGif，
以及仅由该链引入的 SDWebImage。共享代码中的文件保存调用保留。

其余四个 SDK 使用上游已发布的隐私资源回补，避免为 iOS 的资源缺失升级
公共依赖、连带改变 Android。每个来源归档、manifest、实际旧版本 iOS 源码
都有 SHA-256 记录。CocoaPods 在 SDK 源码或声明漂移时停止，并将清单加入
相应 SDK framework 的 Resources 阶段。

具体来源、源码用途和 file_picker 的 Required Reason API 修正见
[SDK 隐私资源说明](../flutter/ios/PrivacyManifests/README.md)。前三个 SDK 的
无追踪、无收集、无 Required Reason API 数组来自上游并经过实际旧源码核对。
file_picker 读取选中文件/沙盒缓存文件的大小，按实际用途补充 FileTimestamp
的 `C617.1` 和 `3B52.1`，没有照搬它的空 API 数组。

仓库旧 `Podfile.lock` 与构建 13 的实际准备树存在差异：共享 pubspec 锁定
sqflite 2.2.0，对应 iOS pod 0.0.2 和 FMDB；旧提交却记录 darwin pod 0.0.3。
本次锁文件以真实 pubspec 和实际归档依赖为准重新生成。除此之外移除上述
媒体链；未执行公共 `pub upgrade`，未改 Android 构建文件。

应用根清单另声明两项有源码证据的用途：`libs/hbb_common/src/config.rs`
读取沙盒内 LanPeers 配置文件修改时间，适用 FileTimestamp `C617.1`；
`src/client/io_loop.rs` 和 `src/client.rs` 使用 `Instant` 计算帧率、连接超时
及 RTT，适用 SystemBootTime `35F9.1`。不宣称应用没有收集数据，也不按
孤立的 `_getfsstat` 符号臆造磁盘空间用途。应用层派生设备标识和家人服务
的数据用途仍需与实际隐私说明、App Store 隐私标签一致。

## 构建和验证入口

1. 在被忽略的新隔离目录准备原有 Flutter 业务输入、生成桥接和已审计的
   iOS 15 原生库，保留构建 13 的原包、日志和源清单。
2. 将本次 iOS Podfile、锁文件、privacy_manifests.rb 和 PrivacyManifests
   同步到隔离树，然后在 `flutter/ios` 执行 `pod install --no-repo-update`。
3. 核对锁文件仅为预期变化，保存新的应用/SDK/Pods/构建配置哈希清单。
   不再把变化后的 iOS 构建输入声明为构建 13 的原清单。
4. 以 0.1.2（14）、最低 iOS 15 生成签名 archive。检查最终 framework
   的隐私清单及其用途、被移除 SDK 不再存在、版本/签名和逐对象平台/minOS。
5. 新包验证全部通过后才上传。保持实际标准加密申报、不在法国分发、无需
   账号登录和用户已填写的真实审核联系人。不得重复上传构建 13。

`ruby scripts/qinban/test_ios_privacy_resources.rb` 验证 SDK 自身资源打包、
可重定位路径、幂等添加及源码/清单漂移和缺失 target 拒绝行为。它不代替
最终 IPA 检查，也不能据此声称 Apple 已经接受构建。

## 修复后的归档与分发核验

2026-10-02 接续时，App Store Connect 已将构建 13 标为“二进制文件无效”。
构建 14 首次归档因钥匙串签名失败退出；恢复后 SDK 签名通过，但 Runner
链接仍硬编码已从 Pods 移除的四个媒体框架。提交 `a8f2c0a` 仅删除
`Runner.xcodeproj/project.pbxproj` 的 Debug、Profile、Release 三套
`OTHER_LDFLAGS` 中 DKImagePickerController、DKPhotoGallery、SDWebImage、
SwiftyGif 的成对链接项，共 24 行；其余链接项保持原样。

原 `privacy-prepared-source-14` 与失败日志完整保留。新的独立准备树为
`privacy-prepared-source-14-linkfix`，240 个应用输入全部匹配原冻结清单，
原生源和库沿用已审计输入。550 个应用/准备输入中仅 Xcode 项目配置和
三个绝对路径生成文件发生预期变化，并记录前后 SHA-256。
后续开发中的通知、家庭恢复代码未进入此次候选。

新归档成功，版本为 0.1.2（14）、最低 iOS 15。使用既有 liyilin 团队和
Cloud Managed Apple Distribution 签名。在点击 Xcode 最终 Upload 前，
保存并检查了该分发流程实际生成的 IPA：

| 核验 | 结果 |
| --- | --- |
| 原生静态库 | 1,786 个对象通过 iPhone 平台与 iOS 15 兼容审计，库 SHA-256 与原冻结值一致 |
| 归档与 IPA 隐私清单 | 各含 16 个 framework、12 份有效 manifest，0 个结构或缺失错误 |
| 移除的 SDK | DKImagePickerController、DKPhotoGallery、SDWebImage、SwiftyGif 均不在最终包中 |
| 实际 IPA 原生载荷 | App 与 16 个 framework，共 17 个 Mach-O，最低系统与平台检查通过 |
| 正式分发签名 | 深度严格签名检查通过；`get-task-allow=false`、`beta-reports-active=true`、团队 `5BG4VDJKTY` |
| 发布环境 | AOT 包含正式家人服务域名，不含模拟器 `10.0.2.2` 地址；没有测试 define |
| 版本设置 | 保留 0.1.2（14），关闭自动改构建号和“TestFlight internal testing only” |
| IPA SHA-256 | `7b801b6b09bd8f2373f95d45e9101b0ea7fc08156af1fe353d18b39f91b7ca4a` |

SDK 资源规则测试为 4 项、8 个断言，全部通过；归档没有较新 iOS 版本链接告警。
这些结果证明本次包体和签名门槛通过，不代替 Apple 处理、外部审核、最低系统真机
或 iPhone 控制 Android 双机验收。

证据位于忽略目录 `artifacts/ios-local/distribution-build-14-linkfix/`：
`source-snapshot-14-linkfix.json`、`link-flags-verification.json`、
`archive-native-signature-audit.json`、`archive-privacy-audit.json`、
`archive-identity-endpoint-check.json`、`preupload-distribution-audit.json`、
`preupload-ipa-privacy-audit.json`、`organizer-upload.json`。

## 本记录状态

2026-10-02 19:14（北京时间），Xcode 明确显示 `帮帮 0.1.2 (14) uploaded`。
上传后导出的 IPA SHA-256 与上传前已审计的实际 IPA 完全一致。
Apple 随后处理完成，构建进入“缺少出口合规证明”；按既有已核实的标准加密算法用途
以及用户确认的“不在法国分发”计划保存申报后，状态变为“准备提交”。

19:20（北京时间），构建 14 已加入既有“帮帮公开测试”并提交 Beta App Review。
页面明确显示“正在等待审核”，组内 1 个构建、0 个测试员。已填写本次隐私修复与
邀请、配对、接听、操控、画质、挂断再接听的测试范围，关闭自动通知测试员；
沿用已保存的真实审核联系人与无需登录设置，未发送个人邮箱邀请。
当前并无已批准构建；直接访问公开链接仍只显示 TestFlight 一般说明，未显示可安装邀请。
公开入口继续使用 [帮帮 TestFlight](https://testflight.apple.com/join/4sw7UNJe)；
在外部组具有获批、启用的构建前，不能称为已公开可安装。
