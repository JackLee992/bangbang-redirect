# 家庭成员与换机恢复

2026-10-02。本轮在现有纯成员规则之上增加真实 HTTP 鉴权、SQLite 持久事务和换机恢复。代码与受控 HTTP/数据库测试已完成；没有上线、创建主机、购买服务或开通收费。基础远程协助继续免建家庭，长辈不需要填写账号表单。家庭身份、成员权益和每次远控授权分别判断。

## 身份与数据归属

独立 `POST /v1/household` 接受现有安装身份 `Authorization: Bearer <installationId>.<secret>`，将其通过固定 HTTPS family endpoint 转发给 `identity.verify`。服务端只信该响应，不接受 body 中的 principal、userId、配对关系、角色或策略。每次操作都验证当前身份，认证服务不可用时失败关闭。

已验证安装映射到服务端随机生成的稳定 userId。新安装首次进入时创建临时身份，创建家庭必须在当前 verified pairs 中至少有一个 helper 角色。owner 每人只创建一个家庭；重复创建返回同一家庭，不重复显示恢复卡。同一用户加入家庭、家庭成员数有可配置安全上限，默认 8 个家庭、16 人；这些上限不是订阅权益或已批准的定价。

每个稳定用户当前只允许一台 active 安装，其余为 revoked。恢复把新安装原子绑定到原 userId，保持 familyId 和成员角色，旧安装留永久撤销记录，不能再次自动登记为新用户。新安装若已有家庭或恢复卡则拒绝合并，避免隐式吞并另一身份；本轮不做账户合并。

服务不保存安装 Bearer、原始邀请码、换机挑战秘密或恢复卡秘密。邀请码绑定家庭、指定目标用户及原始配对，令牌散列沿用成员纯模块；恢复和换机各自使用独立前缀与 256 bit 安全随机秘密。旧邀请不能成为恢复凭据。家庭称呼仅保存在受限 SQLite 标签表，并仅随授权家庭成员查询返回，不进入推送或日志。

## HTTP 契约

请求为 `application/json`，最多 8192 字节，body `{v:1,op,...}`，未知字段拒绝。成功 `{v:1,ok:true,...}`；失败 `{v:1,ok:false,error:"snake_case"}`，所有响应 `no-store`。API 为原生客户端使用，不接受浏览器 Origin 请求；所有公开接入必须由批准域名提供 HTTPS。

| op | 额外字段 | 成功返回 |
| --- | --- | --- |
| `household.list` | 无 | `userId, currentInstallationId, households:[{familyId,revision,role,memberCount}]` |
| `household.get` | `familyId` | `household:{familyId,revision,members:[{userId,role,joinedAt,displayName}],invites?}` |
| `household.create` | 无 | `household`，首次另有一次展示的 `recoveryCode` |
| `member.invite` | `familyId,expectedRevision,targetInstallationId,displayName?` | `household,inviteCode,expiresAt` |
| `invite.confirm` | `inviteCode,confirmed:true` | `household`，该成员尚无恢复卡时另有 `recoveryCode` |
| `invite.revoke` | `familyId,expectedRevision,inviteId` | `household` |
| `member.remove` | `familyId,expectedRevision,targetUserId` | `household` |
| `member.leave` | `familyId,expectedRevision` | `left:true,familyId` |
| `device.list` | 无 | `userId,devices` |
| `device.revoke` | 自己旧设备的 `installationId,confirmed:true` | `devices` |
| `device.transfer.begin` | 新设备发起，无额外字段 | `transferCode,expiresAt` |
| `device.transfer.approve` | 旧设备提交 `transferCode,confirmed:true` | `approved:true,expiresAt` |
| `device.transfer.complete` | 准确的新设备提交 `transferCode,confirmed:true` | `userId,households,recoveryCode,devices` |
| `recovery.rotate` | 当前有效设备提交 `confirmed:true` | 新 `recoveryCode`，旧卡立即失效 |
| `recovery.redeem` | 丢旧机时，新设备提交 `recoveryCode,confirmed:true` | `userId,households,recoveryCode,devices` |

`invites` 仅 owner 可见，项目为 `{inviteId,targetUserId,expiresAt}`，不返回 tokenHash。成员显示名默认“家人”，owner 默认“家庭管理者”；客户端应把自己的稳定 userId 显示为“我”。邀请时可提交 1–24 Unicode 码点的 displayName，禁止控制、格式及换行分隔字符；名称不参与认证。标签与邀请 revision、成员变化在同一事务中提交，恢复后仍按稳定 userId 保留。

`devices` 项为 `{installationId,status:"active"|"revoked",createdAt,revokedAt?,familyCredentialRevocation}`。最后字段取 `not_required / not_configured / pending / confirmed`，准确区分本库撤销与原 family 凭据撤销。只能管理自己的设备，不能由家庭 owner 全局撤销另一个成员的安装身份；owner 可将该成员移出当前家庭。不能撤销自己的唯一当前安装而让身份失去入口。

客户端把以下代码视为不透明文本，显式复制或输入，不放在 URL/query：邀请码 `BH1.<base64url JSON{familyId,inviteId,token}>`，换机挑战 `BHT1.<JSON{transferId,token}>`，恢复卡 `BHR1.<JSON{userId,token}>`。客户端不必解包。打开代码、预览或收到通知均不自动确认。

常见错误：401 `unauthorized`；403 `helper_required / confirmed_pair_required / owner_required / not_household_member / device_revoked / invalid_invite / invalid_transfer / invalid_recovery / transfer_target_mismatch`；400 `unexpected_field / invalid_code / invalid_identifier / invalid_display_name / confirmation_required`；409 `revision_conflict / member_limit / household_limit / invite_expired / deadline_expired / transfer_not_approved / transfer_changed / transfer_consumed / new_device_has_household / recovery_changed / current_device_required / owner_cannot_leave`；429 `rate_limited`；503 `identity_unavailable / household_unavailable`。旧 revision 需重拉家庭，不能原样强行重试。响应丢失后先用 `household.list/device.list` 确认状态；一次性代码不会重新显示，可由当前有效设备重新旋转恢复卡。

## 邀请与恢复流程

邀请只能由已保存的 owner 发起，目标必须来自该请求最新 `identity.verify` 的已确认 pairs。10 分钟有效的邀请码绑定原家庭、目标稳定用户、目标安装以及 pairId；接收人明确确认时再次检查当前 verified pairing、邀请人本库设备仍 active、最新容量及期限。邀请码转发给其他身份、配对撤销、目标换机或邀请人旧机撤销后，不能继续使用旧邀请加入。

旧设备尚可用时：新设备生成 10 分钟挑战，旧设备输入该代码并明确批准，最后由创建该挑战的新安装完成迁移。挑战绑定精确新 installationId；第三台手机不能凭同一代码完成。完成在一个事务中撤销旧机、绑定新机、消费挑战、取消旧身份其余已批准挑战、旋转恢复卡，并写入原 family 凭据撤销 outbox。

旧设备丢失时：持有提前保存的高熵恢复卡，并在全新安装通过 family 认证后，可明确恢复原稳定用户。卡一旦消费就旋转，两个同时恢复者只能一个成功。恢复卡只在创建、首次加入、主动旋转或成功恢复的响应里一次展示，原始秘密不持久存储。既无有效旧设备又无恢复卡时，本轮不提供找回；普通配对、普通邀请码、设备号或自报手机号都不能替代该证明。

每个安装对恢复/换机合计每小时最多 20 次操作，其他接口每分钟最多 120 次，失败证明也会计数并跨重启保留。恢复卡的高熵是核心证明，限流不把低熵口令变成可用的替代方案。

## 手机重启与结果不确定时的恢复

客户端在请求换机/找回之前，将新安装身份与待确认恢复记录作为同一次本地写入保存；记录绑定准确的家庭服务地址，普通保存不能覆盖该检查点。服务端成功但响应丢失后，重启沿用这一个安装身份，先查询其稳定 userId 和当前 active 设备，确认服务端已提交后补领新恢复卡，不再次兑换旧证明或生成第三个安装身份。状态查询失败时继续保留检查点。

换机挑战保存于现有应用私有身份存储，过期后在同一安装生成新挑战。原始恢复卡和补领的新恢复卡均不落入该存储；用户明确完成保存后才清除待确认记录，清除写入失败时仍保留可重试状态。恢复开始后页面立即清空旧家庭与设备快照，避免失败时仍显示旧身份数据。长辈接受家庭邀请依然只需一次确认，不强制处理恢复卡；家庭恢复入口不成为基础协助的前置步骤。

已离开或被移出家庭的稳定用户可能仍持有此前的恢复卡。其当前有效设备可以旋转既有恢复卡，即使当前家庭列表为空；这只维持该用户身份，不能恢复已经删除的成员关系。没有既有恢复卡且没有家庭的新安装仍被拒绝，已撤销设备仍无法调用，旧卡旋转后立即失效。

## 持久事务与原凭据撤销

`HouseholdStore` 使用 Node 内置 SQLite、WAL、FULL 同步、外键和 `BEGIN IMMEDIATE`。先完成外部 HTTP 认证，再在短同步事务中重新检查设备、最新家庭状态及容量；不把网络 await 放进数据库事务。纯成员模块生成 candidate，SQLite 按 familyId+revision 条件写入，成员索引和称呼同一事务更新。邀请与换机 deadline 在原子写入和 COMMIT 前再次核对，过期事务整体回滚。

成员确认和邀请码消费不会分成两次写入；恢复卡消费、设备替换、旧机撤销与待撤销 outbox 也在同一事务。独立连接拿旧 revision 写入必须失败。账号身份和设备映射不是客户端缓存，因此进程重启后仍保持旧机撤销和稳定家庭编号。

原 family 凭据撤销适配发送固定 HTTPS：`{v:1,op:"identity.revoke",installationId,revocationId}`，revocationId 为 canonical 16 byte base64url。`x-bangbang-timestamp` 是 epoch 毫秒十进制，`x-bangbang-signature` 为 HMAC-SHA256（共享密钥 UTF-8 文本，消息 `${timestamp}\n${rawBody}`）。共享密钥 32–128 byte 随机值的 canonical base64url 编码。family 端校验 ±60 秒及签名，双方不转发用户密码或原安装 secret。

常驻进程每 15 秒扫描持久 pending outbox，失败按有界退避重试并复用同一 revocationId。只有匹配安装的 200 `revoked:true` 确认才写 confirmed，超时或 503 保持 pending；缺少内部密钥显示 not_configured。记录不会因进程退出而丢失。未完成远程撤销前，旧机已无法访问本 household 库，但原 family 凭据是否还能调用其独立服务要按该字段判断。

远程撤销成功也不意味着强制切断已离线的原生协助链路。双方下次在线同步须处理撤销；恢复只转移家庭身份，不继承原 pair capability、远控密码、自动接听状态、屏幕录制授权或正在进行的会话。重新远控仍需当前安装重新配对和明确授权。

## 运行及验证边界

部署准备在 [deploy/household](../deploy/household/README.md)。使用一台现有主机和持久卷，不放 Netlify 临时文件系统。本轮本机运行时是 **Node 24.19.0**；其 `DatabaseSync`、`prepare/run`、事务和 deadline 检查已实跑。SQLite 持久化不是已部署公网后端或高可用承诺。

新增受控测试涵盖真实本地 HTTP 两跳身份验证、固定 HTTPS 目标及禁重定向、身份冒认/字段注入、稳定 userId/家庭重启、私密值不落库、最后名额并发确认、独立连接 stale CAS、提交期限回滚、标签与 revision 同步、跨家庭越权、旧邀请码重放、配对失效、成员移除/退出、旧机确认挑战精确绑定、丢机恢复卡并发消费、恢复后称呼保留、旧设备永久拒绝、限流跨重启、内部 HMAC 原始字节及撤销回执匹配、失败后的持久重试。

这些测试使用受控身份服务和本地数据库/HTTP，不证明生产 family、公开 TLS、容器镜像、真实手机换机、主机磁盘故障、容量或外部备份已验收。本轮没有短信、邮件账户、付款、购买恢复或订阅接入，也没有声称会自动继承远控许可。官方 API 核验：[Node SQLite](https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html)。

后续整合补充：`household-integration.test.mjs` 的 6 项跨服务测试将真实 `createFamilyService`、真实 `identity.verify/identity.revoke`、HMAC 适配、两个实际 loopback HTTP 服务和文件型 SQLite 连起来。只有 family 的 Netlify Blobs 存储由受控内存 CAS 替代，认证结果和签名校验没有 mock。验证了 register→配对→家庭创建/邀请→SQLite 重启→恢复→HMAC 撤销后旧安装 register/poll/identity.verify 全部 401、新安装不继承配对、旧机确认换机、过期与重放拒绝、称呼访问权限、错误 HMAC 不误报完成、写入旧机 tombstone 后存储中断的持久补偿，以及跨撤销暂停的旧 push.register 不能夺回新安装已经认领的 token。固定 HTTPS 地址只由测试注入传输转到 loopback；生产端 HTTPS 与禁止重定向规则保持不变。这里仍未验证生产 Blobs、外部 HTTPS 或真实设备。

本轮手机恢复整合增加了真实 SQLite 的“恢复已提交、响应丢失、客户端重启、首次查询再失败、同身份重试”场景，覆盖普通找回、旧机确认换机，以及离开家庭后空成员列表的身份。另覆盖恢复完成检查点写入失败、已保存换机码过期、跨 endpoint 拒绝、长辈一次确认与 320px 大字页面。96 项定向 Flutter 测试和 22 项家庭 HTTP/跨服务测试通过；两个新增 HTTP 用例分别覆盖主动离开和被移出后补领卡，旧代码均返回 403，修复后通过。原始记录留在忽略目录 `artifacts/household-integration`，没有新增公网端点或真机验收结论。

整合后完整回归：Flutter 316 项、站点/服务 156 项通过。9 个 Dart 文件检查无错误或警告；当前工作页保留的既有无大括号样式产生 8 项 info，未为通过分析而覆盖未归属页面改动。
