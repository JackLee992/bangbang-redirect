# 帮帮：发布交接与当前状态

默认分支安装包自动同步修复为 `c6b7996`，40项回归及实际只读/安全续跑 `37110789080`、`37110941079`通过；三个已有附件全SHA相同并跳过写入。当前APK先前由官方网页上传，新版本首次自动大文件上传仍需真实验证。[完整自动发布记录](GITEE_RELEASE.md)保留前两次传输失败、探针403与CRLF兼容修复证据。

0.1.3（18）的最新资产、源码对应关系、完整双模拟器重验和 Gitee 安装包发布进度见 [0.1.3 交付记录](SITE_RELEASE_0.1.3.md)。私有 GitHub 的 `v0.1.3` 预览版已按 APK 源 `b8bbd580…` 发布，[对应源码](https://bangbang-services.s419505080.chatgpt.site/downloads/bangbang-0.1.3-source.zip) 已在独立合规渠道公开并验真。[Gitee APK](https://gitee.com/yilin-dev/bangbang-releases/releases/download/v0.1.3/bangbang-0.1.3-arm.apk) 和两个小附件也已匿名全量验真；APK 本次由官方浏览器上传，CI 两次新 APK 上传因网络失败，后续自动上传仍需验证。两份 0.1.3 网站清单已同步真实下载地址；产品域名已发布实际 GitHub Pages 首页，原下载 Site 版本 3 已更新，ECS内部页也已实际部署和重启/回退验收。家人接口仍保持原 Sites D1 唯一权威，手机和微信验收待完成。该记录区分实际完成、进行中和本机候选，保留 0.1.2 回退资产。下面继续保留此前 0.1.1 发布时的交接与验收记录。

更新日期：2026-10-02。

> 后续新增的完整呼叫、系统通知、连接诊断以及 Cloudflare / Oracle 部署准备见 [呼叫与服务选型](CALL_FLOW_AND_SERVICES.md)。这些改动当前在本地候选中，未包含在下面已上线的 0.1.1 中。用户已将系统来电提醒纳入后续范围；文中旧版“后台推送不在本次范围”仅描述 0.1.1 验收。Cloudflare / Oracle 尚无账号，按用户指示只准备代码与部署文件，先用模拟器测试。

## 当前决定

用户先暂停发布并要求记录，随后在 Mac 解锁后明确回复「恢复发布网站和安装包」。发布现已恢复授权，继续推送源码、正式构建、验收和更新原站点；不创建自动发布任务。

- 工作目录：`/Users/jacklee/develop/daillyTasks/bangbang-android`。
- 分支：`feat/family-invites-elder-mode`。完整源码 checkpoint `32a8e2402b0edfcb581ed406f2053750aed524a8` 已推送；正式 Android 构建及双机验收为 [Actions 36873929455](https://github.com/JackLee992/bangbang-android/actions/runs/36873929455)。
- 原有草稿 PR：[PR #1](https://github.com/JackLee992/bangbang-android/pull/1)，本轮继续更新。
- 原站点：[帮帮下载站](https://bangbang-jacklee992.netlify.app/)。Netlify 与 [GitHub Release](https://github.com/JackLee992/bangbang-android/releases/tag/v0.1.1) 均已提供 Android 0.1.1，APK/对应源码/构建信息/校验文件齐全。直接下载生产站点的 APK、源码及 build-info，长度与 SHA256 全部匹配已验收产物。
- 用户回复「继续发布」后，在其原 Chrome 中完成已说明的官方 CLI 授权，随后更新同一站点，没有创建新项目。当前生产部署为 `6abeee9cb4651b458ae0c918`；家人 Functions 与 Blobs 已通过真实生产接口和跨发布保留检查。登录凭据仅由官方 CLI 保存，没有输出或提交。
- iOS 0.1.1（10）已使用本机 liyilin 既有身份签名、导出开发 IPA，并安装及启动真实 iPhone 17。安装清单版本和启动后进程均已核验；尚未上架 App Store，网站保留真实未上架说明。

## 已保存的改动

1. 首页权限与邀请为方形按钮，主要按钮约 190×190 dp，次要约 95×95 dp，面积相差四倍；窄屏按比例缩放。未授权邀请为明显灰色、带锁且不可点击；授权后绿色对勾缩为小块，邀请变为大块。标题「请家人帮忙」弱化。
2. 系统字体放大得到保留。大字号小成功块只显示大绿色对勾，朗读仍为完整「已开启」，不显示截断词。两个控件的可访问节点和点击动作独立。
3. 真正授权协助后保存家人，支持改称呼、移除。长辈的邀请按钮进入家人选择页；没有历史时仍打开安卓原生系统分享，可选微信。添加家人仍走原分享流程，首页没有增加一排历史卡片。
4. 用户已选择「先支持双方打开帮帮时收到请求」。新前台求助服务需双方完成一次真实加密会话配对；长辈准备好屏幕共享后选择家人，家人明确接受，再按原方向连接长辈。不会自动批准录屏或远控。
5. 请求两分钟过期。结束、撤回、移除、切换身份或退后台时，迟到响应不能恢复已取消请求。已撤销或过期的关系能力只能通过新的真实授权会话重新建立。
6. Netlify Functions + Blobs 后端、协议和测试已落盘。根部署配置及网站工作流会一并保存函数、实现、依赖锁与已校验下载文件。静态首页仍保持精简。
7. 修正 iOS 打包和 Apple 查询时的实际版本/构建号核验。后续新归档默认 0.1.1（10），仍使用本机 Xcode 与 liyilin 团队，开发安装不需要 ASC Secrets。
8. Android / iOS 控制端复制整条邀请后打开 App 自动弹窗「连接家人 / 稍后」，明确确认后连接。安全空闲时才提示；旧剪贴板、切前后台与页面重建不反复打扰，换邀请或主动粘贴可重新提示。正在协助或有家人求助时保留邀请，结束后再处理，不连接已替换的旧邀请。
9. 不设置用户账号系统。移动端完整界面的账号登录、账号地址簿/分组、账号审计备注也隐藏，移动启动不刷新上游旧账号缓存。远程设备密码、2FA 与本机「允许协助」是原连接授权，仍保留。
10. iOS 能力固定为控制端，保留接收/粘贴邀请、连接、家人管理及完整界面切换；不显示分享邀请、分享安装、本机连接号码、被帮助者角色、操作权限或录屏入口。其分享方法也有能力门禁。

## 本地检查与证据

全量 Flutter 测试 155 项通过。扩展到移动主入口、设置、账号和侧栏的静态分析为 0 error、0 warning，29 条既有 info。日志：`.qinban-cache/full-flutter-tests.log`、`.qinban-cache/elder-analyze.log`。

- 网站和家人后端 Node 测试：38 项通过，其中 24 项后端、14 项原网站测试。包括认证、角色、设备与 scope 绑定、TTL、防重放、明确观察/答复、撤回、撤销、CAS 并发、存储假成功和部署隔离。
- Python 发布/打包测试：22 项通过，日志 `.qinban-cache/release-checkpoint-python-tests.log`。
- 工作流 YAML 解析与 `git diff --check` 通过。
- 安卓本地 debug 编译通过；临时 Android 15 ARM64 模拟器检查大小比例为 4.0、锁定按钮不可点击、已开启与邀请节点独立，以及真正打开系统分享面板。没有登录微信或发送消息。证据：`artifacts/app-home-square-family/`、`.qinban-cache/android-square-family-capture-ready.log`。正常字号截图已更新到 `docs/screenshots/`。
- 最终源码已完成 debug 重编，并在 Android 15 模拟器验证完整邀请消息唤起确认弹窗、稍后及返回前台去重、主动粘贴再次提示、完整设置页无账号入口。真实截图与 observer XML：`artifacts/android-invitation-preview/`；`docs/screenshots/helper.png` 已替换为当前弹窗。180% 系统字体的最终绿色对勾截图为 `07-final-font-180.png`，无截断。完整新版 smoke 在本地 debug 上通过，见同目录 `full-smoke/`。以上预览不代表正式包或真实双机远控验收。
- 当前本机 debug 授权共享后，45 秒内仍为「正在连接」，未进入在线；点击「结束协助」后 `dumpsys media_projection` 为 null。证据 `artifacts/android-invitation-preview/current-network/`。这是当前本机网络路径的失败，不能直接归因于代码或公共服务整体故障。
- 客户端与后端回环 TLS 互操作检查保存在 `artifacts/family-interop/`；使用真实 Dart 服务/HTTP transport 与真实 Node handler，Blobs 是内存 CAS，Chat 是受控授权会话夹具。它不能证明线上 Netlify、Rust 真实加密会话或手机后台提醒已验证。

本地 `artifacts/`、缓存、签名和设备记录均忽略，不提交用户凭据或私有设备证据。

## 正式产物与验证边界

- 家人 Functions 已上线。专用随机 QA 身份通过真实生产 TLS / Blobs 完成 12 项配对、角色、求助、观察、接受及撤回检查；再次发布相同产物后，2 项检查确认关系和状态仍保留；3 项检查撤销 QA 关系并确认不能继续求助。已有用户关系未修改，QA 凭据保持本地且不公开。接口检查不代表手机真实加密 Chat 首次配对和再次求助已完整验收。
- 最新源码 `32a8e24` 的正式 Android 构建 36873929455 APK 作业成功；首次双机验收已经完成真实连接、授权、画面与远程打开「更多」，但控制端浮动导航挡住「使用帮助」整行，后续画面匹配未通过。验收脚本现通过实际可见的「收起」按钮关闭这条工具栏，再保持原图像阈值、完整远控和停止共享断言复验。ARM 发布候选为 0.1.1（2），49,333,720 bytes，SHA256 `23131085a2529fc54ed94c3ca8e09c60410579496b65f650b6a3264b70be5828`；签名 v2 和旧证书一致，仅 ARM V7/V8。下载产物的 18 个 Qinban 源/测试文件及 pubspec.lock 与本轮一致。该正式 ARM 包在本机 Android 15 模拟器完整 smoke 通过，证据 `artifacts/android-release-36873929455/`。随后同一构建产物的 [双机复验 36877880052](https://github.com/JackLee992/bangbang-android/actions/runs/36877880052) 完整通过：邀请确认、真实授权、实时画面、远程点击、画面更新和停止后释放 MediaProjection。result.json 的 x64 APK hash 与构建产物精确相同。签名 ARM 包额外在本机通过完整 smoke 和已验证 HTTPS 域名直接唤起确认弹窗。CI 成功不能消除本机网络路径尚未上线的限制，也不代表线上家人服务或真实 iPhone 验收通过。
- 最新 iOS 0.1.1（10）已完成同一次本机归档，使用 liyilin 既有身份开发签名；严格签名校验、IPA CRC、版本/构建号、团队及设备包含关系均通过。IPA 25,420,844 bytes，SHA256 `ee89c745f65ee4160bb9b4d83f188a118305322db48bd9709a6d5ef108815495`。安装及启动真实 iPhone 17 / iOS 26.5 后，同一 PID 3648 至少保持 152 秒。证据位于 `artifacts/ios-local/build10-*.json`；详情见 [iOS 记录](IOS_VERIFICATION.md)。
- 尚无最新版 iPhone UI、iOS→Android 真实协助、双端真实家人历史配对及再次求助证据。后台推送不在本次约定范围。

## 网站发布与交付目录

网站清单已固定为 Android 0.1.1。[网站构建 36879656828](https://github.com/JackLee992/bangbang-android/actions/runs/36879656828) 成功并更新 `site-deploy` 分支；下载的 CI 静态产物与 Release 的 APK、源码、build-info 长度及 SHA256 一致。`artifacts/netlify-ready/` 已刷新为这套产物，并通过官方 Netlify CLI 的 offline production 构建，包含完整 Functions ZIP、路由与运行依赖。查看该目录 `READY.md` 和 `verification.json`；旧 0.1.0 的校验记录另保留。

2026-10-02 通过官方 CLI 对原 Site ID `3e8053ab-2226-4cd7-a6ec-37bb1cb9e768` 完成生产发布。首次 deploy 为 `6abeeda9bbdbc83ad4c97032`，为检查关系跨发布保留，再次发布相同产物得到当前 deploy `6abeee9cb4651b458ae0c918`。CLI 返回成功；原 Chrome 显示新版极简首页与 0.1.1 下载链接，线上下载哈希与 Release 一致。Android assetlinks 返回 200，邀请落地页仍使用 BB1 与 `bangbang://invite` 入口。

完整部署结果在 `artifacts/netlify-ready/production-*.json`。真实后端检查及下载结果在 `artifacts/netlify-live-qa/`；`init`、跨发布 `verify` 和专用 QA 撤销 `cleanup` 均通过。仅使用独立 QA 身份，没有触碰已有用户关系。iOS 的开发 IPA 留在本地，未将带设备描述文件的开发包作为通用下载上传。

## 后续验收范围

已完成：源码推送、正式 APK 构建、完整双机验收、原 Release 守卫发布、Netlify 原站点与 Functions 发布、生产下载及跨发布数据验证、最新版 iOS 开发签名和真机安装启动。发布 run 为 [36879130802](https://github.com/JackLee992/bangbang-android/actions/runs/36879130802)。本轮不再等待 Netlify 或钥匙串授权。

1. 真实手机的加密 Chat 首次保存家人、双方前台再次求助、接受/撤回/过期/移除仍需单独端到端验收；不可用本次直接接口 QA 代替。
2. 最新 iOS 的可见界面、剪贴板操作及 iOS→Android 真正远控仍未实测。旧 UI runner 曾在执行测试前因 DTX 通道错误退出，不能将安装启动结果写成 UI 验收通过。
3. Apple TestFlight / App Store 分发尚未完成。继续本机安装使用现有 liyilin 开发签名即可；只有开展 Apple 分发时才处理对应账号权限与发布流程。
4. 本机 Android 网络路径的注册失败证据仍保留；CI 双机成功不能证明所有用户网络均可达。后台推送不在本次约定范围。

复验入口：Flutter 3.24.5 位于 `.qinban-cache/toolchains/flutter/bin/flutter`；在 `flutter/` 运行全量 `flutter test`，在 `site/` 运行 `npm ci`、`npm test`，Python 运行 `python3 -m unittest discover -s scripts/qinban -p 'test_*.py'`。
