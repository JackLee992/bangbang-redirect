# iOS 本地测试版 0.1.2（16）

2026-10-02。此记录对应本地开发签名安装，不是 TestFlight 上传或生产推送验收。

## 包与代码

- 冻结源码：`f4dcd6267686e9ee8ef993b3a94db80f68c729be`。
- Bundle ID：`io.github.jacklee992.bangbang`；团队：`5BG4VDJKTY`。
- ARM64 真机包，最低 iOS 15.0；244 个应用输入哈希与冻结源码相符，17 个包内原生映像及严格签名检查通过。
- 沿用 QA15 已审核的本地 iOS 引擎静态库。此后两个 Rust 变更文件属于 `rendezvous_mediator` 及其子模块，均由 `lib.rs` 的 iOS 条件编译排除；不能把此结果说成这次重编了 iOS 引擎。
- IPA SHA-256：`a97d0c0b6f791cfb43766d47d5d342821ddcabdaa80acd70a3849a14b173036c`。
- 冻结候选的 316 项 Flutter 测试、156 项站点/服务端测试通过。测试快照首次缺少 Netlify 依赖；接入既有锁定依赖后重跑通过，未修改业务代码以跳过测试。

## 推送签名配置已更新

本机旧通用开发描述文件没有 `aps-environment`。命令行自动更新曾报 `No Accounts`，但 Xcode 的 Apple Accounts 页面实际仍登录正确团队。打开本轮隔离工作区的 Signing & Capabilities 后，Xcode 生成了匹配帮帮专属 App ID、包含该 iPhone 的开发描述文件。

最终安装包签名和内嵌描述文件均核实含 `aps-environment=development`，签名、包标识与团队一致。由此可确认本机开发安装并不排斥 APNs 能力；不能由签名权限推断 APNs 注册或消息投递已成功。

当前 Apple 团队 Keys 页面显示空列表，目标 Netlify 项目环境变量页显示尚未配置变量。尚未创建 APNs 服务端密钥、配置 Netlify 凭据或验证真实通知实收。

## 真机证据与边界

- JackLee iPhone 17、iOS 26.5：USB 安装成功，已安装应用列表确认 `0.1.2 / 16`。
- 安装后首次启动请求被系统以 `Locked` 拒绝。用户解锁并打开应用后，两次设备进程检查确认同一进程持续运行，路径与新包的真实安装目录一致。页面功能、新的 iPhone → Android 远控会话和 APNs 实收仍需独立验收。
- 未修改用户正在体验的 Android 模拟器，未上传 TestFlight，未发布网站。
- 本轮后续推送配置匹配与发布门禁属于更新的候选代码，不包含在此冻结包中。

构建、签名、包检查、设备安装及运行证据位于忽略目录 `artifacts/ios-local/qa16-device/`；设备标识、描述文件与安装包不提交到源码仓库。
