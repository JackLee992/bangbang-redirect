# 家人服务与诊断数据迁移操作单

这份操作单用于把现有 Sites D1 的 `production` 数据迁到 ECS SQLite。网站搬迁、SSH 登录成功、健康接口返回 200，都不能替代数据迁移。任何时候只允许一个后端接受业务写入；Apps 保留原 Sites API URL，由原入口透明代理到 ECS，不做 HTTP 重定向，也不让用户重新注册或配对。

本轮开始时（2026-10-04）的已核验基线：生产 Sites 仍是唯一权威；ECS `127.0.0.1:8789` 家人服务和诊断上传关闭，正式库为空。前一轮已通过 Chrome 正常后台完成真实加密演练导出，并在独立私有库导入/读回核对 41 条家人记录、6 条诊断事件、9 条诊断额度；原 HMAC 配置指纹一致，目标激活标识为零。临时导出配置已移除。本轮补齐数据库写入栅栏与 v3 正式快照；本机验证不代表生产已冻结或已切换。本文件没有保存实际设备记录、账户资料或密钥。

## 先完成的技术条件

- 部署本轮冻结的 `snapshot.mjs`、`cli.mjs`、`sqlite.mjs`、`authority-fence.mjs` 及其原有运行依赖；旧 ECS 包不能直接使用新 CLI 或激活标识。本轮为 17 个运行模块、加 unit/env 模板共 19 个运行文件，无 npm 安装。按 `runtime-manifest.mjs` 核对逐文件 SHA。
- Sites 的控制表和 13 个触发器通过受托管的追加 schema migration 安装，再部署新版 Worker。`service-schema.ts` 声明四字段控制表；固定 DDL 来自 `AUTHORITY_FENCE_SCHEMA_STATEMENTS`，共 14 条。**安装表/触发器不插入冻结记录**，线上继续写入。HTTP 请求不会建表或补齐缺失触发器；迁移缺失/不兼容时正式导出关闭。不能改已部署的 migration 或丢掉旧 journal。
- 正式冻结前须独立核验发送历史：guard 安装前必须有可信的未启用 provider 历史，或已获得旧发送者实际排空的独立证据。新 schema 无法找回旧版本曾被新请求覆盖的 claim，也无法从当前“未配置 provider”或数据库计数为零推导全部历史发送者已退出。历史不明的通用源保持正式冻结/导出通道关闭，不能用另一个环境布尔值代替证据。
- 验收一个仅管理员可用的**受控加密全量导出通道**，在原 Worker 内从原 `env.DB` 绑定读取。本次请求的 `first-primary` 会话可用于导出演练，不长期复用副本会话。Sites 管理工具的投影行会截断长 `json`，不能作为生产快照。现有 `POST /api/admin/family-migration` 仅支持家人记录的小批次导入，不能导出三表。
- Sites 返回的秘密环境变量可能是 `null`。必须通过原服务器内的受控加密通道保持原 `BANGBANG_DIAGNOSTICS_HASH_SECRET`；不能重新生成它后宣称诊断历史延续。密钥仅在离线解密后的私有文件和目标运行环境中存在。
- ECS API 的公开 HTTPS、域名及相应备案/网络条件另行验收。北京站点未满足公开条件时，只做私有演练，不开放 80/443，不设置 Sites ECS 代理参数，不开启 ECS 家人服务。
- APK、源码下载及远控流量不经过此 JSON API 网关。App 的 `serverScope`、安装身份、配对 capability 和现有 Sites origin 均保持；更换远控服务器的 scope 属于另一项迁移。

ECS 已使用 `/opt/bangbang` 原子版本符号链接。沿用该别名运行 `cli.mjs` 时，Node 必须加 `--preserve-symlinks-main`；也可以使用 `readlink -f /opt/bangbang` 得到的真实发行路径。主入口会比较 `import.meta.url` 与启动路径，缺少此参数可能直接退出且没有执行命令；不能把退出码 0 当成导入成功。实际 systemd unit 已加入该参数。下面的 CLI 示例包含此参数。

旧解密工具 `/root/bangbang-migration-tools/20261003/decrypt.mjs` 只用于先前 v2 演练，不能解密/审核本轮 v3 正式包。本轮准备的新工具树根为 `/root/bangbang-migration-tools/20261004`，入口为其中的 `backend/aliyun/transfer/decrypt.mjs`；已部署并逐文件核验 SHA，独立 Node 导入证明相对依赖树可用；所有工具目录 0700、文件 0600。它不在 19 文件业务运行包中。工具需保留相对目录结构，包含 `decrypt.mjs`、`snapshot.mjs`、`authority-fence.mjs`、`sites_diagnostics_store.mjs`、`backend/diagnostics/worker.mjs` 五个文件，不能只复制新版 `decrypt.mjs` 覆盖旧单文件入口。所在目录 0700、私有输入/输出 0600；原配置 CLI 仍须读取真实私有 env，禁止生成替代 HMAC 秘密。

`site/worker/authority-export.mjs`、`authority-export-page.mjs` 和 `backend/aliyun/transfer/decrypt.mjs` 提供默认关闭的通道。具体演练步骤如下：

- `GET /api/admin/authority-export`，禁止查询参数和 Origin；只接受独立随机管理员 Bearer，不接受安装凭据。设置 `BANGBANG_AUTHORITY_EXPORT_ENABLED=true`、私有 `BANGBANG_AUTHORITY_EXPORT_SECRET`、未来不超过一小时的毫秒 `BANGBANG_AUTHORITY_EXPORT_EXPIRES_AT`，以及 `BANGBANG_AUTHORITY_EXPORT_PUBLIC_KEY`（固定离线 RSA-4096 SPKI 的规范 base64url）。`BANGBANG_AUTHORITY_EXPORT_PURPOSE` 默认 `rehearsal`；只有可信服务器配置能选 `cutover`，query/body 不能选择用途。源存在任何 ECS 代理配置时拒绝导出。
- 每张源表先预检至多 2048 条、估算总量不超过 4 MiB；明文最终至多 8 MiB。异常或超限不输出部分数据。
- 响应仅是 `BBAE1` 加密 envelope：`v,format,keyFingerprint,wrappedKey,iv,ciphertext`。RSA-OAEP/SHA-256 包裹 AES-256-GCM key，使用固定 AAD；离线私钥不会上传。私有响应文件必须直接落盘，不在终端显示。
- 内部明文是演练 `{v:2,snapshot,configuration}` 或正式 `{v:3,snapshot,configuration}`。配置白名单为 scope、原诊断 HMAC/admin secret、原 backup admin secret；不导出推送 provider、内部签名或调度凭据。正式包必须由源数据库实际冻结校验产生，不能给演练包改用途或版本后使用。
- 正式用途支持同路径的认证 `HEAD`。它同样执行真实冻结、三表完整读取和摘要校验，无正文，返回 `x-bangbang-authority-digest`、`x-bangbang-source-epoch`、`x-bangbang-config-fingerprint`、`x-bangbang-authority-counts`；演练 HEAD 返回 405，未冻结或有发送中任务返回 503。正式 GET 也带同一组元数据。保留认证源 HEAD 与随后密文 GET 的独立采集证据，不能从待导入明文文件重算预期摘要来代替它。
- 一次限时演练用后立即关闭，并删除 export secret/public-key/expiry 的临时环境项。保持原业务开关和权威不变。
- 若授权的自动请求在平台边缘返回 403/1010，但普通后台会话可用，使用正常网页 `/admin/authority-transfer`。该页沿用同一临时 Bearer 和同一加密路由，只下载指纹匹配的 BBAE1 envelope；不修改平台保护或访问受众、不把授权放到 URL、不在页面显示解密内容。它随开关/过期/代理配置关闭，CSP 仅允许固定脚本及同源连接，临时密钥不存入浏览器存储。正式文案明确源暂停；该页不执行冻结，也不替代独立 HEAD 元数据核验。认证 HEAD 无法完成时，不通过复制文件字段补足正式证据。

## 快照和连续性契约

`snapshot.mjs` 的真实导出调用如下。`configuration` 必须来自该 Worker 的真实环境；不使用截断的工具结果。

```js
const snapshot = await exportAuthoritySnapshot(env.DB, {
  scope: env.BANGBANG_FAMILY_STORE_SCOPE,
  configuration: env,
  apiEnabled: env.BANGBANG_FAMILY_API_ENABLED,
  purpose: "rehearsal", // 正式停写之后改为 "cutover"
});
```

v2 只允许演练，顶层字段固定为 `v, scope, purpose, configFingerprint, createdAt, records, diagnostics, counts, digest`。v3 只允许正式用途，在这些字段上增加固定 `freezeEvidence`：

```json
{"v":1,"mechanism":"sqlite-write-fence-v1","scope":"production","epoch":"SOURCE_EPOCH_FROM_AUTHENTICATED_STATUS","frozenAt":1800000000000,"schemaDigest":"92ec6f431af877bfa0aba809d71c9b14a33fd981fa16a4e33bf0718c21ce5c98","pendingDispatch":0}
```

上面的 epoch 是说明性占位符，不能作为输入；真实值是规范 base64url 的 16 随机字节、22 字符。冻结记录中的 epoch 和原时刻不可由 HTTP 修改。源端校验完整控制表约束、13 个精确触发器，并在读取全部业务表前后再次检查同一冻结证据；旧请求后来尝试的写入由数据库触发器拒绝。

其中一条触发器在冻结前就保护配对 outbox 的发送预约：旧 warm writer 不能覆盖或丢掉仍有 `claimId`/`leaseUntil` 的 outbox。新版 `request.create` 在初读和最终 CAS 内都拒绝这种替换，返回现有 `409 request_pending`；目标正常四表库无需自动安装源栅栏也会遵守该规则。取消、忘记家人、lease 过期只改变原状态，任何残留字段（包括 null）都算未排空。发送调用真正返回后，新 finish 只清理同 request、同 claim 的字段，保留已形成的 unknown/obsolete 状态，不碰新请求或新 claim。普通 cleanup 只删除 `push-ready/` 和 `rate-limits/`，从不删除 pairs 或永久请求 claim。

旧版本 finish 在 unknown/obsolete 后可能仍不清理预约，因而安全地阻止冻结；新部署不能替旧进程完成其收尾。不得手工擦掉字段、按 lease 超时宣称结束，或将 provider 的 timeout/abort 返回当成通知已撤回。已经交给 APNs/FCM 的通知仍可能到达；本次栅栏保证数据库单写者和已记录发送预约的保护，不提供跨 provider 的撤回或 exactly-once 送达证明。

| 内容 | 原表/字段 | 保持方式 |
| --- | --- | --- |
| 家人授权、撤销、重放、推送地址和内部限流 | `bangbang_family_records`，快照记录为 `{key,data,updatedAt}` | 保存 JSON 全部状态和原 `updated_at`；ETag 可重新生成 |
| 诊断事件 | `bangbang_diagnostic_attempts`，16 个非 scope 字段 | 保留主键散列、revision、started_at、received_at 等全部字段 |
| 诊断额度 | `bangbang_diagnostic_limits`，6 个非 scope 字段 | 保留已使用次数、事件数、窗口和原更新时间 |
| 目标激活标识 | `bangbang_aliyun_authority` | 不从源迁入；仅在完整正式导入和读回一致后生成 |

家人键白名单包括 `devices/`、`pairs/`、`claims/`、`push-tokens/`、`push-ready/`、`dispatch-claims/`、`rate-limits/`。过期不能删除身份墓碑、请求 claim 或旧推送所有权；原 `expiresAt` 和诊断七天保留时钟不刷新。不会原样复制表外内容。

每页 128 条、每表最多 100000 条，快照总 JSON 上限 128 MiB。这个文件上限**不代表** Worker 可以在 128 MiB 内存限制内处理同样大的快照；导出端必须先核对实际总量，超出其较小操作上限就中止或实施另行验收的分片，不能接收半包。

`digest` 是按键排序的三表内容、scope、purpose、配置指纹及 v3 冻结证据的规范 SHA-256；`createdAt` 不参与，所以两个正常导出文件的文件 SHA 可以不同而内容摘要相同。冻结证据不含 snapshotDigest，避免摘要自引用。

**公开 proof 和 SHA 不是密码学来源签名。** 拥有修改文件权限的人可以构造一个外形正确的 epoch 并重算 digest；持有源 DB schema 管理权限的人也能拆掉触发器。真实来源保证来自受认证的原服务 HTTPS 管理通道、固定离线接收密钥及独立保留的源元数据。正式 CLI 必须传入从认证源另行取得的 `--expected-digest` 与 `--expected-source-epoch`，不能拿待导入文件的同名字段作为预期值。直接模块调用也必须遵循这一可信 digest 前提，可额外传 `expectedSourceEpoch` 比对；结构检查不能阻止恶意管理员自行伪造整套输入。

`configFingerprint` 是以原诊断散列密钥为 key、绑定 scope 的域分离 HMAC。它不输出原密钥，保证迁移前后同一 installation/attempt/rate 的散列命名空间一致。管理员、scheduler、APNs/FCM 凭据可独立轮换，不加入这个持久化身份指纹；原有推送配置仍须私密转交并单独验证。

旧 v1、旧 v2 cutover 快照以及没有配置指纹/冻结证据的旧激活标识被拒绝。目标仍使用 schema 1 的四表结构；激活标识的 `counts` 私有 JSON 有 family/attempts/limits、configFingerprint、freezeEvidence 五字段。源冻结表不迁入目标：目标只保存已认证源证据，成功启用后能够写入。没有线上自动 DDL。

## 先做不停写的私有演练

原源服务保持在线。受控导出必须显式用 `purpose: "rehearsal"`，标明这不是停写后的同一时刻快照。加密包只包含必要源数据和原配置，解密文件权限 0600、所在目录 0700；不进入 Git、下载桶、聊天、终端输出或 CI 附件。

离线解密的四个参数都只传私有绝对路径，输出仅聚合元数据；输出文件独占创建，重复运行不会覆写原快照或配置：

```sh
/opt/bangbang-node/current/bin/node /root/bangbang-migration-tools/20261004/backend/aliyun/transfer/decrypt.mjs \
  /private/migration/source.bbae.json /private/migration/recipient-private.pem \
  /private/migration/source-rehearsal.json /private/migration/target.env
```

目标使用一个**新的空演练数据库**，与已安装服务的数据文件分开。目标配置文件仅需这些实际值：scope=`production`、原诊断 HMAC 密钥、`BANGBANG_FAMILY_API_ENABLED=false`、`BANGBANG_DIAGNOSTICS_INGEST_ENABLED=false`。真实秘密只放私有文件，不能作为命令行参数。

以下路径是模板，替换为实际私有绝对路径；`APPROVED_DIGEST` 是可信导出渠道给出的公开内容摘要，不是秘密。

```sh
/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs configuration \
  --scope production --env-file /private/migration/target.env

/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs init \
  --db /var/lib/bangbang/migrations/rehearsal-ID.sqlite

/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs import \
  --db /var/lib/bangbang/migrations/rehearsal-ID.sqlite --scope production \
  --snapshot /private/migration/source-rehearsal.json \
  --expected-digest APPROVED_DIGEST --env-file /private/migration/target.env --paused

/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs verify \
  --db /var/lib/bangbang/migrations/rehearsal-ID.sqlite --scope production \
  --snapshot /private/migration/source-rehearsal.json \
  --expected-digest APPROVED_DIGEST --env-file /private/migration/target.env --paused
```

只有操作成功的聚合结果允许进入审计：三个 counts、digest、configFingerprint、purpose、activationEligible、inserted/unchanged，以及正式冻结 epoch/时间/schemaDigest/pendingDispatch。CLI 失败仅输出固定 `authority_operation_failed`，解密失败仅输出 `authority_transfer_failed`，不回显原记录、SQL 或环境内容。

演练导入应返回 `activationEligible:false`，目标激活表为空。即使误把目标开关改为 true，服务也拒绝启动。允许在同一演练库重试同一快照；不同内容、不同原时间或额外记录会冲突，不能覆写。正式切换必须重新从最新源导出并使用另一个新空数据库，不复用演练库。

## 正式切换的停写窗口

1. 完成私有演练、真实 HTTPS/网关及业务验收，保留原版本、原 D1 绑定与目标启动配置。先核验上述发送历史前提，确认控制表和 13 个触发器完整安装且没有冻结行。准备目标库的新空路径、原 HMAC、两份源采集文件、独立预期摘要/epoch，以及失败时保持单源的恢复操作。目标始终关闭。
2. 在原 Sites **原 D1 入口**同一配置变更中设置 family=false、diagnostics=false，并设置 `BANGBANG_AUTHORITY_FENCE_ENABLED=true`。暂停外部调度、统计、清理和旧迁移导入调用。不要设置任意 `BANGBANG_ECS_*`，否则会提前换入口。维护布尔只是关闭新入口；旧 isolate、旧 prepared statement 和在途 `waitUntil` 仍可能执行，不能认为变更 env 就已停写。
3. 临时开启独立的冻结管理路径：`BANGBANG_AUTHORITY_FREEZE_ENABLED=true`、随机 32 字节规范 base64url 的 `BANGBANG_AUTHORITY_FREEZE_SECRET`、未来不超过一小时的 `BANGBANG_AUTHORITY_FREEZE_EXPIRES_AT`。`GET /api/admin/authority-freeze` 只返回 schemaDigest、phase、pendingDispatch 等聚合状态；要求 `scope=production`、两个业务开关均为字符串 `false`，不接受 Origin/query 或设备 Bearer。HTTP 永远不安装 DDL。
4. 验证业务维护 503，并让已在途 provider 请求结束、提交其 durable finish；冻结前状态必须为 `phase:open,pendingDispatch:0`。不要用旧 15 秒 lease 已过期或“没有配置推送”证明排空。不能用 `GET /v1/summary` 监控，它会写诊断预算。单独等 30 秒也不能证明所有旧 HTTP 都退出。
5. 用独立管理员 Bearer 调用 `POST /api/admin/authority-freeze`，仅允许不超过 64 字节的 JSON `{"v":1,"op":"freeze"}`。冻结 INSERT 与“没有 sending、残留 claim/lease 或异常配对”条件是**同一条数据库写语句**：旧 claim 先提交则拒绝冻结且不落 epoch；冻结先提交则三个表上每种后续 INSERT/UPDATE/DELETE 都被触发器拒绝。返回必须是同一 scope 的 `phase:frozen,pendingDispatch:0`；重复调用保留原 epoch/frozenAt。拒绝后仍保持两个入口关闭，先处理真实排空，不把未成功的尝试称为冻结。
6. 保持此 epoch 和 schema，不执行 DROP/ALTER 或其他 schema 管理。新 Worker gate 关闭家人、诊断上传、统计/清理额度写、push dispatch、旧导入入口、定时派发和请求后 maintenance；旧版本未实现 gate 的写入仍受三表 DB 触发器约束。读取和冻结前已提交的写入属于源最终状态；冻结点之后的写事务不能完成。冻结时未完成的多步骤请求可返回失败，其此前已提交的原状态全部保留。
7. 按下面的独立 HEAD→密文 GET→显式 cutover 解密采集正式包。认证源提供的 counts/digest/configFingerprint/epoch 应一致；两次正式包一致是附加核对，**不能替代触发器和真实 epoch 的证据**。超限、schema/epoch 改变、pendingDispatch 非零、截断、缺页或无法取得可信元数据时，中止并保持维护。
8. 停止 ECS service，确认本地 dispatcher/其他进程不使用目标库。创建**新的空正式库**，fresh v3 快照和真实关闭的目标配置进行 init/import/verify。不能用旧 21 条 Netlify 备份或 v2 演练库。每批 family 至多 32 条/1 MiB、diagnostics 至多 128 条；整批错误回滚，多批失败可留下部分数据但没有激活 marker。目标的 `--paused` 不会自动暂停远端服务。
9. 全量读回一致后 `activationEligible:true`，marker 保存源 proof 和原配置指纹；用独立预期 digest/epoch 再 verify。启动前核对 DB/目录/WAL 所有权为 bangbang、目录 0700、文件 0600。不能复制仍被写入的 SQLite 主文件代替完整备份，也不能借符号链接绕过路径检查。
10. 私有目标验收后发布原 Sites **永久 ECS-only**入口：`prepare-service-site.mjs --authority ecs`。它完全不导入 D1 业务模块，任何 ECS 参数缺失/错误/上游故障都 503；不允许恢复旧 D1 写入。配置固定 HTTPS API origin、独立代理 secret，安装 Authorization 原样传递，清除伪造地址/代理头。旧 App 不跟随 301/302，必须原路径透明返回。
11. 受控启用目标 family/diagnostics，再启用原 Sites 对应开关。启动重新核对 scope＋原 HMAC 指纹，旧 marker、错 secret、非正式包都拒绝。随后关闭冻结/导出临时 HTTP 通道并移除对应临时 secret/publicKey/expiry/purpose；**删除临时 env 不会解除源 DB 栅栏**。
12. 验证已保存家人、原 request replay、撤销、原推送所有权、诊断去重/额度和重启持久化。原 D1 不写、不调度，Sites ECS 参数全丢失仍 503。健康 200 或 `authority:ecs-sqlite` 不能替代真实业务和跨网设备体验。

`RAISE(ABORT)` 拒绝当前 SQLite 写语句；adapter 的事务或 D1 batch 负责整个失败批次回滚。[SQLite 触发器规则](https://www.sqlite.org/lang_createtrigger.html)、[Cloudflare D1 batch 事务规则](https://developers.cloudflare.com/d1/worker-api/d1-database/)支持这个边界。它不依赖 isolate 内存锁或 HTTP 请求最长时长。[Workers 请求时间规则](https://developers.cloudflare.com/workers/platform/limits/)也说明不能把固定等待期当成旧 HTTP 请求全部排空。

若 DB 已有一个手工/旧版本生成的 frozen 行却仍有发送中或残留 claim/lease 记录，正式导出继续拒绝。触发器会阻止记录结束写入，不能靠等待或修改状态文字制造 `pendingDispatch:0`。这种情况必须保持双端关闭，在目标从未接受写入的条件下另行处理受控源恢复；没有 HTTP thaw/overwrite 接口。

## 正式证据的两路采集和目标导入

下面仅是路径模板；执行前私有目录 0700、输入权限 0600，临时管理员头只放私有 curl 配置中，不放命令行/URL。source-freeze.curl 与 source-export.curl 各使用对应独立临时 Bearer，不输出配置内容。不跟随重定向，实际 origin 必须为仍持有源 D1 的服务。

```sh
# 第一路：认证源实际冻结状态和独立摘要/epoch。只保存聚合元数据。
curl --config /private/migration/source-freeze.curl --proto '=https' --max-time 60 \
  --output /private/migration/source-freeze-status.json \
  https://bangbang-services.s419505080.chatgpt.site/api/admin/authority-freeze

curl --config /private/migration/source-export.curl --proto '=https' --head --max-time 60 \
  --dump-header /private/migration/source-head.headers --output /dev/null \
  https://bangbang-services.s419505080.chatgpt.site/api/admin/authority-export

# 第二路：原字节密文，再离线解密。不要将元数据来源替换成导入文件本身。
curl --config /private/migration/source-export.curl --proto '=https' --max-time 60 \
  --dump-header /private/migration/source-body.headers --output /private/migration/source.bbae.json \
  https://bangbang-services.s419505080.chatgpt.site/api/admin/authority-export

/opt/bangbang-node/current/bin/node /root/bangbang-migration-tools/20261004/backend/aliyun/transfer/decrypt.mjs \
  --purpose cutover /private/migration/source.bbae.json /private/migration/recipient-private.pem \
  /private/migration/source-cutover.json /private/migration/target.env
```

必须检查每个 HTTP 操作的实际状态为 200、无 Location，HEAD 正文为空，四个元数据头完整、与 GET 元数据及独立 freeze 状态 epoch 一致。curl 退出 0 不表示业务请求成功；403/503 的文件不能解密/导入。源通道必须采用可信 TLS 和已核验的原管理认证；BBAE1 的 AES 认证只能防密文篡改，不能把公开 proof 变成来源签名。

把认证源头的 digest/epoch 记为 `SOURCE_DIGEST`/`SOURCE_EPOCH`（非秘密）。下列参数值须取自该独立审计，不能从 `source-cutover.json` 提取或重算：

```sh
/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs init \
  --db /var/lib/bangbang/migrations/cutover-ID.sqlite

/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs import \
  --db /var/lib/bangbang/migrations/cutover-ID.sqlite --scope production \
  --snapshot /private/migration/source-cutover.json --env-file /private/migration/target.env --paused \
  --expected-digest SOURCE_DIGEST --expected-source-epoch SOURCE_EPOCH

/opt/bangbang-node/current/bin/node --preserve-symlinks-main /opt/bangbang/backend/aliyun/cli.mjs verify \
  --db /var/lib/bangbang/migrations/cutover-ID.sqlite --scope production \
  --snapshot /private/migration/source-cutover.json --env-file /private/migration/target.env --paused \
  --expected-digest SOURCE_DIGEST --expected-source-epoch SOURCE_EPOCH
```

为 ECS 作为源的反向恢复准备时，可显式运行 CLI `freeze --db /absolute/source.sqlite --scope production --env-file /private/source.env --paused`；它安装固定已审核 DDL 并执行同一原子冻结机制，`export --purpose cutover` 才会接受真实 DB proof。此能力不提供覆写旧 D1 的导入操作，也不自动停止 systemd。

## 回退界限

在 ECS 尚未接受任何业务写入时，可制定受控单源恢复：关闭目标，保留真实 source epoch 和 schema 审计，验证所有源管理操作仍在维护窗口，再使用已验收的管理员数据库恢复流程解除栅栏，恢复 d1 构建和原配置。**仅恢复 env/旧 Worker 不会解除触发器。** 当前代码不提供 HTTP/CLI 自动 thaw，也不提供任意 DROP/overwrite 捷径；没有完整恢复流程时保持维护，先修复同一新库的导入/入口问题。正式冻结前就须准备这项恢复能力，不能在失败后假定关闭旗标即可回退。

**ECS 已接受第一条写入之后，旧 D1 已经过时。** 不能删除代理参数、改回 d1 构建或用旧源备份简单回退，这会丢掉撤销、重放 claim 和新配对状态。先暂停 ECS 和入口，排空目标任务、导出新的完整 cutover 快照，再制定单独验收的反向迁移；当前工具只提供 insert-only 的 SQLite 导入，不提供覆写旧 D1 的捷径。通常修复并恢复同一 ECS 权威比另开一个写库更可控。

## 本轮证据与限制

本轮最终专项 Node 回归 133/133 通过、零跳过，使用真实 SQLite、独立连接/CLI 进程和本机 HTTP。覆盖三表各 140 条分页、同数据幂等、并发异内容的整批回滚、原更新时间与 TTL、诊断散列/去重/额度延续、旧格式和错配置拒绝，以及演练不能激活。新增证据包含旧 prepared statement、claim 与 epoch 竞争、取消/忘记/lease 超时后真实 provider 收尾、四表 target 不丢预约、新请求初读与最终 CAS 保护，以及不同 request/claim 不被迟到 finish 改写。SQLite 受控结果不是生产 D1 已执行新迁移的证明。

先前实际 ECS 已执行对应旧轮运行文件的 15 项 service/snapshot 受控测试，无失败或跳过，并再次重启部署服务，确认健康、家人/诊断维护 503、正式四表仍为空、SQLite 完整性与原 inode 保持。先前网页及加密通道的 29 项相关测试通过，涵盖默认关闭、过期、禁止 ECS/D1 混写、CSP、不同接收密钥/明文字段/HTTP 错误不下载、单次密钥清理，以及原统计后台兼容；这些不能替代本轮最终运行包的实际云端验收。

真实导出首次自动请求在平台边缘返回 403/1010；随后 Chrome 后台刷新正常。经正常后台生成 27,469 字节 BBAE1 文件，严格 SSH 传到 ECS，只在该服务器解密；RSA 私钥没有离开 ECS，明文记录及原配置没有复制到 Mac/Git。独立演练库完整导入和 CLI verify 均返回：family=41、attempts=6、limits=9，内容摘要 `40ab5a2a87513c9fa2fc4f5fc71a7774ee78777dcc6319ed2e8eb8c18aa48c98`，原配置指纹 `82dff96ad5e1788c2f3c59ba3698e6aa4aa7248d2d0846380cbd668e2a9d929f`，`activationEligible=false`。这不是 41 个家庭；计数包括设备、配对、claim、限流等家人表记录。

先前演练期间源端始终继续接受正常业务；演练不是停写同一时刻的正式快照。正式数据库四表和 inode 保持，API 仍关闭。当时 Sites 版本 11、源码 `5828b70859548881dbba4e9df3871c8d21c3bf9a`、环境 15 已发布成功，四个临时导出环境项全部移除；浏览器重新加载演练页显示 Not found，临时输入文件已清理。聚合证据在忽略的 `artifacts/aliyun-migration/actual-source-rehearsal-aggregate-evidence.json`；没有在此文件保存明文记录、秘密或原始日志。

本轮尚未暂停 Sites 或切换生产权威，也不证明正式 TLS、APNs/FCM 到达或 iPhone→安卓远控链路。正式切换必须重新取得实际停写后的 cutover 快照，不能直接激活这份演练数据库。

## 2026-10-04 实际部署结果

最终 v3 业务包已部署 `/opt/bangbang-releases/20261004-migration-v3`，19 文件 SHA 全匹配，实际重启、v2b 回退及恢复通过；原运行 env、正式 SQLite inode/完整性/私有权限/四表空状态保持。最终代码在 ECS 独立受控目录执行 168/168，零失败、零跳过，包含真实 Caddy 与代理呼叫全流程；受控回环不是正式公网 HTTPS。

Sites 版本 12、源码 `5755aee30c7481e2662ed376be9f2f9ec6de90b4`、环境 15 已发布。追加 migration 包含控制表及 13 个触发器，原 0000 与 journal 历史保留；托管读取确认四张表存在、控制表四字段且零行。业务与诊断开关、秘密环境元数据、public 受众保持；未开启导出/冻结、执行 source epoch、切代理或更改 D1 权威。线上精确栅栏校验和独立认证源元数据仍须在后续正式窗口执行，不能把此次发布当作冻结证明。

新五文件解密工具树已部署上述 `20261004` 私有路径，逐 SHA、目录 0700/文件 0600及 Node 依赖导入通过。旧 20261003 v2 工具、演练库、离线接收密钥均保留。部署过程没有重新导出或读取私有明文数据。聚合结果见 [本轮验真](ALIYUN_VALIDATION_20261004.md)。
