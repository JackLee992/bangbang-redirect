# 帮帮 iOS 0.1.4（21）正式公测候选

2026-10-04。使用既有 liyilin 团队 `5BG4VDJKTY` 和
`io.github.jacklee992.bangbang`，由 Xcode Organizer 上传。

## 当前状态

Apple ContentDelivery 和 Xcode Organizer 均确认上传成功。解锁 Mac 后，
已在 App Store Connect 实际核对新构建处理完成，保存出口合规申报，
加入既有“帮帮内部验证”和“帮帮公开测试”并提交 Beta App Review。
**0.1.4（21）当前显示“正在等待审核”，90 天后过期，尚未获准公开安装。**

内部组实际包含21，状态为“准备测试”，目前0个测试员；没有新增个人
邀请。测试说明已保存，明确无需注册或登录、没有会员支付、家人请求
暂时需要双方打开 App，后台来电推送尚未作为可用服务开放。
保留本次提交的“自动通知测试员”关闭状态；获批后仍需完成公开启用
及邀请页验收，再更新两站版本标注。

既有[官方公测链接](https://testflight.apple.com/join/4sw7UNJe)现已开放，
实际可用的是已批准的 **0.1.2（14）**。主站和备用下载站已提供该入口，
见[网站发布记录](../site/releases/TESTFLIGHT_PUBLIC_BETA.md)。

## 版本和构建来源

发布来源为已验收的冻结源码 `b53519618457bd3e42e6a2123af4113ecc34a8da`。
247 项应用输入、419 项原生输入和1,459项实际插件文件最终校验未漂移。
本轮全量重新编译原生引擎，没有把旧安装包改版本号后上传。

实际 App 版本为0.1.4、构建号21、最低iOS15，构建声明为production。
原生静态库SHA-256为
`896b36d6a24b1e5b7d8bf4ac132eeb044f55eb59f72cbb67c1cb9223119700d2`。

## 签名问题与修复

第一次未签归档没有携带源码中的APS请求，Organizer沿用了没有APS权限
的Store描述文件。虽然第一次导出的IPA已正式签名，其签名和profile均
缺少`aps-environment`，生产门禁失败，未上传该包。

Apple Developer实际应用标识的Push Notifications已开启；没有新增账号
能力、证书、钥匙串访问或服务端凭据。本轮在独立未签归档副本中，用临时
ad-hoc签名承载现有源码的APS请求，随后由既有Cloud Managed Apple
Distribution正式重签。临时签名只是请求载体，不能作为发行证据。

正式上传IPA重新审计通过：

- 实际签名与profile均为`aps-environment=production`，对应同一团队和应用标识；签名证书属于该profile授权的证书。
- App构建声明为production，`get-task-allow=false`，不启用“仅内部测试”，关闭自动修改版本/构建号。
- 1,786个原生库对象及17个实际包内原生镜像均满足iPhone平台和iOS15最低系统门槛。
- 16个框架中实际存在12份有效隐私清单，未发现结构错误；已移除的旧SDK未重新进入安装包。

实际上传前IPA SHA-256为
`9bd878df33e360c2a96189dbfbb34936ba8ca804296c7e97d14bb19e6d0d6a96`。
上传完成后由 Organizer 导出的正式 IPA 与上传前包逐字节一致，SHA-256
相同；再次执行分发和隐私审计均通过。
原始未签归档、首次失败IPA及两次审计均保留在本机忽略目录，未公开上传
开发签名包、描述文件或私密日志。

## 出口合规与送审依据

按实际第三方标准加密实现（libsodium 的 XSalsa20-Poly1305、Curve25519、
Ed25519），选择“代替在 Apple 操作系统中使用或访问加密，或与这些
操作同时使用的标准加密算法”；沿用用户明确确认的“不会在法国分发”。
保存后构建由“缺少出口合规证明”转为“准备提交”，随后送审成功。
该选择依据[Apple 加密文稿要求](https://developer.apple.com/help/app-store-connect/reference/export-compliance-documentation-for-encryption/)，
未将第三方加密申报成“未使用加密”或修改 Info.plist 以跳过问卷。
公开邀请没有实施地理过滤，推广计划须符合已确认的分发计划；算法或
地区计划变化时重新评估申报。

Apple 实际构建 ID 为 `d5611388-1e4e-4a0b-8e71-c7e2ded33cfa`，
既有审核联系人资料未改动；原公测链接和群组沿用。

## 验证边界与待完成事项

本轮证明了正式包的构建来源、原生兼容门槛、隐私文件结构、签名和生产
推送配置。iOS不会编译注册supervisor/fallback模块，因此不能把本次
原生重编解释为iOS UDP转TCP或画面流畅度改善。

本轮未进行该正式包的手机安装、真实iPhone到Android远控、跨网或APNs
实收测试；具备生产签名权限也不等于服务端推送凭据和后台来电已上线。
隐私清单结构通过不能替代App实际数据用途及Apple隐私标签的核对。

剩余发布步骤为等待 Apple 审核结果；若获批，完成公开测试启用并实际
核对邀请页，再更新两个宣发站的可安装版本。网页当前保持14的可安装
状态。该正式包手机安装、远控、跨网及后台推送仍需单独验收。

本机交付证据：`artifacts/ios-local/qa21-distribution/`和
`artifacts/ios-local/qa21-distribution-aps-request/`，均为Git忽略目录。
