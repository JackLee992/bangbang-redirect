# 后台求助提醒：服务端契约与部署

2026-10-02。代码与受控测试已完成；没有部署生产、购置服务、录入推送密钥或证明真实设备收到通知。普通通知不授予远控权限，不自动接听，也不保证应用被系统强制退出后的送达。Android 当前提供 FCM HTTP v1；国内无 GMS 设备尚无厂商通道，不能据此标为可后台接收。

## 客户端契约

沿用 `POST /.netlify/functions/family`、`content-type: application/json`、安装身份 `Authorization: Bearer <installationId>.<secret>`。身份不能由设备号、配对能力或客户端自报字段代替；只允许明确白名单字段。`register` 返回 `backgroundPush:1,pushConfiguration:1`，后者表示支持非秘密配置匹配。新客户端遇到缺少后者的旧服务不会发送其不认识的新字段，也不会把旧布尔值解释成匹配成功。

| 请求 `op` | 额外字段 | 成功结果 |
| --- | --- | --- |
| `push.register` | `provider:"apns"` 或 `"fcm"`，`token`，可选 `clientConfig` | `push:{provider,registered:true,deliveryConfigured:boolean,configurationStatus}` |
| `push.unregister` | 原 `provider`、原 `token` | `push:{provider,registered:false}` |
| `push.resolve` | `pairId`、`requestId` | `actionable`、原两个 ID；仅可接听时另含 `expiresAt` |
| `identity.verify` | 无 | `identity:{installationId,peerId,serverScope,pairs:[{pairId,role,peerInstallationId,peerId}]}` |

上述返回均另有 `v:1,ok:true`。失败返回现有规范化 `error`，不返回原始网络错误。

`clientConfig` 对 APNs 严格为 `{appId,environment}`，环境为 `sandbox` 或 `production`；对 FCM 严格为 `{appId,projectId}`，这里 `appId` 是 Android 包名，不是 Firebase SDK app ID。只接受这两个字段，不能附带 secret、任意URL或其他配置。元数据不授予身份或远控权限，也不进入通知。

`configurationStatus` 为 `matched`、`missingClient`、`mismatch` 或 `unconfigured`。APNs 比较实际候选声明的 bundle ID/环境与服务端 topic/环境；FCM 比较本应用包名 `io.github.jacklee992.qinban` 和 Firebase project ID。`deliveryConfigured` 现在仅在服务器配置可解析且客户端配置匹配时为 `true`，缺少元数据的旧注册返回 false。配置随 token 保存，实际发送前（FCM 在 OAuth 后再次）核对当前部署，避免更换项目/环境后错投。

**匹配不证明厂商接受或设备送达。** 密钥可能已被撤销，网络或系统也可能阻止提醒。界面仅显示“通知设置已保存，实际提醒仍受系统与网络影响”；没有匹配能力/声明时显示未确认，配置不齐或不匹配时显示后台提醒暂未就绪。完全缺少 provider 的正式包继续安全降级到前台求助。

通知自定义数据严格为 `{v:"1",kind:"family.request",pairId,requestId}`。标题和正文固定为“家人求助”“家人正在请求帮助，请打开 App 查看”。不发送 capability、安装身份 secret、远控密码、peer ID 或联系人。推送数据本身不可成为接听授权。

点击通知时，已认证帮助端必须调用 `push.resolve`。只有该安装仍是已确认且设备绑定有效的帮助端、ID 匹配当前请求、状态为 `queued/observed` 且未到 120 秒期限，才返回 `actionable:true`。已接受、拒绝、取消、过期、撤销、被新请求替换均为 false；陌生安装或长辈端返回 403。客户端随后拉取当前状态，等待用户明确接听；按家庭和请求 ID 去重。没有有效本地安装身份时不能依据通知创建新身份或自动恢复远控。

`identity.verify` 供独立家庭身份服务通过服务端 HTTPS 原样转发 Bearer 验证；只返回已确认且两端设备绑定仍有效的关系。它不返回 authHash/capabilityHash/secret，不允许客户端注入 principal。安装记录存在 `revokedAt` 或 `status:"revoked"` 时，认证和重新注册均失败。

## 手机端接入

- iOS 使用系统 APNs 注册及 `aps-environment` entitlement；只在帮助者明确开启来电提醒后申请通知权限。本次进程取得系统 token 后，才返回客户端配置。`Info.plist` 的显式非秘密 `BangbangPushEnvironment` 声明必须由发布门禁与最终导出包的签名/profile核对（`development` 映射 `sandbox`），不从 Debug/Release 推断、不调用非公开 iOS SecTask API；缺声明按未确认降级。正式包与开发包分别使用对应 provider 环境。本轮已上传的冻结隐私修复 build 14 不含此新功能。
- Android 通过构建环境 `QINBAN_FIREBASE_CONFIG=/绝对路径/google-services.json` 选择 FCM 实现，发布门禁另区分 `none/compile-only/production`。native 仅在生成资源 `bangbang_push_mode=production` 时请求 token、返回客户端配置；保存 token 同时绑定配置摘要，更换 Firebase 配置不能复用旧摘要的地址。配置必须匹配正式包名；仅引入 `firebase-messaging:24.1.2`，不引入 Analytics。客户端标识生成应用资源，服务账号私钥不能放进该文件。没有配置时编译不含 FCM SDK 的降级实现，保持前台求助能力，不声称已开启后台通道。
- Android 13 及以上等待用户完成系统通知授权，才显示开启结果。FCM 初始自动注册关闭，帮助者明确开启后才启用；token 轮换持久保存，前台启动/返回及每 30 秒同步。进程未运行时发生的 token 轮换，需下次回到应用才能同步到服务端，这段期间可能漏提醒。
- 两端的通知只携带不透明请求引用。前台走已认证的状态拉取和原有响铃；后台点通知先 `push.resolve` 再拉取当前请求，仍需按接听按钮。过期通知不能拉起旧协助，也不触发屏幕录制。
- 切回长辈模式或检测到系统通知权限关闭后，注销当前注册；网络失败在下次前台刷新重试，不影响正在进行的协助。普通系统通知不能替代电话，也没有接入 PushKit/CallKit。

## 换机服务撤销旧安装

家庭身份服务在自身恢复事务完成后，通过持久 outbox 调用同一 family endpoint，JSON 为 `{v:1,op:"identity.revoke",installationId,revocationId}`；两个 ID 都是规范 16 字节 base64url。该操作不接受普通安装 Bearer。

双方仅在私密服务环境配置同一个 `BANGBANG_FAMILY_INTERNAL_SECRET`：32–128 字节随机值的规范 base64url 文本。请求头 `x-bangbang-timestamp` 为 13 位毫秒时间戳；`x-bangbang-signature` 为 `HMAC-SHA256(secret文本UTF8, timestamp + "\\n" + 原始HTTP请求body字节)` 小写十六进制。允许正负 60 秒时差，固定 HTTPS 地址、不跟随重定向。

验证通过后先写不可重新注册的安装撤销记录，再撤销已保存配对、终结其呼叫、停止待投递通知。成功返回 `{v:1,ok:true,revoked:true,installationId}`；重复请求幂等，503 时家庭 outbox 必须保留并重试。旧安装在部分清理失败时也已无法认证。设备离线时不能强制停止已建立的原生连接，另一端恢复在线后通过撤销状态结束协助；家庭恢复不会继承原生远控许可。

## token 所有权与隐私

每个安装只保存一个当前推送注册（APNs 或 FCM）；轮换会替换当前值。全局 `push-tokens/<SHA256(provider:token)>` 记录绑定安装及注册代次，其他安装不能夺取仍绑定的 token。旧 token 的注销不会删除当前轮换后的 token；原绑定安装明确注销后可由新安装重新认领。轮换后旧 token 的散列 claim 保留到其所属安装明确注销，避免旧客户端意外重新绑定；仅知道 token 不能转移现有归属。

原安装经家庭恢复服务正式撤销后，持有同一系统token的新安装可重新认领该地址；旧安装仍不能认证或抢回。此流程只转移通知地址，不恢复配对能力。手机端换身份时同步清除注册缓存，旧身份注册的迟到结果不能让新身份误认为已经注册。

发送时必须同时匹配安装当前注册与 token claim。原始 token 仅保存在服务端私有设备记录中以调用厂商 API，不进入通知、API 返回、异常日志或仓库。发送错误仅保存枚举状态。APNs 410 还核对厂商失效时间和当前注册更新时间；迟到失效回复不能删除已经刷新或轮换的注册。缺少有效失效时间的畸形 410 不自动删除 token。FCM 仅明确 `UNREGISTERED` 删除注册；参数或凭据错误不误删。

每个安装每分钟最多 6 次 token 变更，重复注册可刷新有效时间；现有每家庭呼叫间隔至少 15 秒仍保留。发送尝试另限每安装每分钟 4 次，超过后延后并受原呼叫期限约束。

## 持久投递与并发

1. `request.create` 在提交呼叫前写入当前分钟的 `push-ready/<minute>/<pairId>/<requestId>` 发现标记。标记仅含不透明 ID。标记可早于实际呼叫出现，worker 必须核对正式记录；创建失败留下的标记不会产生通知。
2. 当前请求与 `pushOutbox` 在同一个家庭记录的强一致 CAS 中提交，随后等待一次有界 provider 调用。provider 失败不会把已经创建的呼叫改为失败，也不影响接听、首帧及保活。
3. `push-dispatch` 是每分钟执行的 Netlify Scheduled Function。扫描当前及前两个分钟桶，至多并行 4 个任务；新 worker 从持久 outbox 恢复，不依赖进程内定时器或响应后的悬空 Promise。
4. CAS 认领写入唯一 `claimId` 和 15 秒 lease，同一请求只允许一个当前发送者。每次发送前重新读取关系、请求状态、时限、安装撤销及 token 归属；FCM 获取 OAuth 后再检验一次。
5. 仅明确可重试的厂商拒绝重试（429/5xx 等），尊重 Retry-After，并有 15/30 秒递增下限、FCM 限流至少 60 秒，最多 3 次尝试。所有尝试受原始 120 秒 TTL 限制。
6. 网络断连、发送超时、发送进程崩溃后的过期 lease 记为 `unknown`，不会盲目重发。此策略可能漏提醒，以避免一次结果未知的发送重复响铃。APNs collapse ID / 固定 apns-id 与 FCM collapse/tag 都绑定家庭及请求，客户端仍需去重。

终态回复只能改变投递记录，不能复活呼叫或覆盖下一通请求。已经交给厂商的通知无法事务性撤回；系统可能展示一条已取消的旧提醒，因此服务端点击校验是必要边界。厂商 accepted 只表示接收请求，不等于手机实收，更不能提供端到端 exactly-once 承诺。

发现标记不自动删除，且与永久防重放 claim 分离。运行成本和旧标记清理需按规模规划；当前调度器扫描近 3 分钟而非所有历史家庭。Netlify scheduled function 有 30 秒执行上限；上线前必须以目标并发量验证能在此窗口扫描完近 3 分钟任务。拥塞或调度中断可能漏掉 TTL 窗口，服务仍应把请求判为过期，不补发过期提醒。更大规模应接入受管队列，保持现有认领、终态及点击校验契约。

## 部署配置

使用 Netlify Functions 的私密环境变量，按生产和测试环境分开设置。私钥使用完整 PEM（支持真实换行及字面 `\\n`）；不要写入代码、公开站点文件、日志或提交附件。函数只访问固定 Apple/Google 官方端点，不接受客户端 URL 或可任意重定向的 token 交换地址。

| 变量 | 内容 |
| --- | --- |
| `BANGBANG_APNS_TEAM_ID` | Apple 团队 ID（10 字符） |
| `BANGBANG_APNS_KEY_ID` | APNs `.p8` 密钥 ID（10 字符） |
| `BANGBANG_APNS_PRIVATE_KEY` | APNs P-256 私钥 PEM |
| `BANGBANG_APNS_TOPIC` | 已批准签名候选的 bundle ID，不能客户端自选 |
| `BANGBANG_APNS_ENVIRONMENT` | `sandbox` 或 `production`，必须匹配候选签名环境；TestFlight 通常为 production |
| `BANGBANG_FCM_PROJECT_ID` | 启用 FCM API 的项目 ID |
| `BANGBANG_FCM_CLIENT_EMAIL` | 具备该项目 FCM 发送权限的服务账号 email |
| `BANGBANG_FCM_PRIVATE_KEY` | 对应 RSA 私钥 PEM |

APNs 使用 HTTP/2、ES256 JWT、alert push type、绝对到期时间；同一温热实例缓存 JWT 最多 40 分钟。FCM 以 RS256 服务账号断言向 OAuth 交换短期 token，再调用 HTTP v1，设置剩余 TTL/high priority。单次网络阶段最多 3 秒；FCM 冷启动可能包含 OAuth 和发送两个阶段。

`family.mjs` 与 `push-dispatch.mjs` 必须一同部署。生产仅在 `context.deploy.context === "production" && published === true` 时使用固定生产 Blobs store；预览依 deploy ID 独立。缺少部署上下文失败关闭。不要让预览共用生产推送环境变量；APNs sandbox 和 production token 不能混用，Android 测试项目也应隔离。Scheduled Functions 只在已发布部署自动调度，线上没有可公开调用的 URL；预览应在 Netlify 后台 Run now 或本地工具显式运行。调度失败只输出规范化 `push_dispatch_unavailable`，不输出 token 或原始错误。

部署后先核对 `deliveryConfigured`、函数 Scheduled 标记及下一次执行时间，再用批准的真实设备做前台/后台/锁屏、权限关闭、token 轮换、断网、超时、撤回、重复投递和多家人限流检查。分别记录 APNs 接收、FCM 接收、设备实际显示、点击后校验、用户明确接听，不把它们合并成一个“推送成功”。国内无 GMS 真机应显示尚未配置可用通道；`createPushProviders` 为服务端适配边界，新增厂商需真实签名、注册鉴权、TTL、失效 token 和同等级测试，当前没有伪造厂商实现。

## 本轮证据

手机端 236 项 Flutter 测试及目标文件静态分析通过；新增 7 项覆盖注册轮换/去重、权限收回、切长辈角色、并发响应、网络重试、旧服务兼容和过期引用拒绝。Android 不含provider和FCM两个配置均成功构建；FCM编译使用明确标为compile-only的虚构客户端配置，未进行厂商投递。iOS新APNs源码在独立依赖树完成未签名Release编译与链接，未覆盖已上传构建14。此轮增加安装撤销测试后全站共123项通过。

移动通知整合候选（`4080baf`代码、debug APK SHA-256 `69e4bf9e9c984d08ea35168a785bdcf5c3e97eb5ff4483987e5dfc9fbb85fa4a`）在两台Android模拟器回归通过：家人HTTP服务暂停85.1秒时仍能操作并看到远端画面，恢复后帮助端结束、下一通接听及长辈端结束均通过；双端保持同两个callId。私有证据位于 `artifacts/background-push/emulator-regression-final/result.json`。该回归证明前台协助未被通知整合破坏，不证明后台厂商实收或后续家庭页面已经验收。

站点完整测试通过；新增服务端场景包括安装冒认/token 抢绑、轮换后旧注销、认证信息白名单、撤销设备、终态点击、持久重试、并发认领、崩溃 lease、provider 失败隔离、取消竞争、迟到 token 失效、调度恢复。Provider 测试动态生成测试密钥并验签；APNs 使用实际本地 HTTP/2 server，FCM mock 校验真实 OAuth/HTTP v1 请求形态，并覆盖断连和实际 3 秒超时。测试私钥只在测试进程内生成。

这些结果是协议/受控证据。2026-10-02 主线另通过已登录页面只读确认：当前 Apple 团队 Keys 列表为空，目标 Netlify 项目环境变量列表为空；因此当前服务尚未配置 APNs/FCM 推送凭据，本轮未创建 key。新的 APNs 签名 profile 与 iPhone 安装启动并不替代服务端凭据，也没有证明通知实收。Firebase 账户是否另有凭据未核查；国内厂商通道和线上调度容量也仍待验收。

配置匹配补充验证：85 项服务端目标测试、17 项 Flutter 目标测试及相关 Dart 静态分析通过；覆盖旧服务协商、缺少声明、同 token 换项目后缓存失效、注销未被确认后重试、APNs 环境/topic 与 FCM 项目错配不发网络请求，以及 OAuth 期间配置改变后停止投递。AppDelegate 通过 Swift 语法检查。本次配置匹配改动未另行构建/签名安装包或联系厂商，不将这些受控结果计作设备实收。

2026-10-03 本机开发包更新：候选 `48ab7aa` 的242项Flutter/iOS源码输入经冻结清单核对，构建0.1.2（17），使用li yilin团队开发签名。最终App全部原生镜像、签名证书归属、profile有效期、精确bundle ID、`aps-environment=development`与`BangbangPushEnvironment=sandbox`均通过产物门禁；42项iOS发布工具测试通过。实际产物检查发现证书提取参数需使用`--extract-certificates=prefix`，已修正工具和对应测试夹具。新包已安装到JackLee iPhone 17并由系统成功启动；复用已核对未变更输入的原生库，本轮未重编译原生库。没有上传TestFlight、创建服务端密钥或验证后台推送实收。

官方依据：[Apple APNs 请求](https://developer.apple.com/documentation/usernotifications/sending-notification-requests-to-apns)、[Apple Token 及失效响应](https://developer.apple.com/library/archive/documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/CommunicatingwithAPNs.html)、[FCM HTTP v1](https://firebase.google.com/docs/cloud-messaging/send/v1-api)、[FCM 错误与重试](https://firebase.google.com/docs/cloud-messaging/error-codes)、[Google 服务账号 OAuth](https://developers.google.com/identity/protocols/oauth2/service-account)、[Netlify Scheduled Functions](https://docs.netlify.com/build/functions/scheduled-functions/)。
