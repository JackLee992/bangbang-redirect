# 帮帮静态宣发站与模板选择

核对日期：2026-10-03。模板调查和构建准备由并行 agent 完成，随后根代理已发布实际 GitHub Pages 宣发首页，并更新原下载 Site。Android 0.1.3 的 Gitee 安装包已匿名全量验真。产品子域名沿用既有 DNS；个人博客未改。实际域名与路径验收见 [静态首页发布记录](DOMAIN_FORWARDING.md)。

根代理发布的网页仓库提交为 `e3a6e2608159b69485582c657ae745c8e752494c`，网站构建来源为 `f0dd123042439d650ba3b8f00c5198d55006cfd3`；25 个静态文件的实际 HTTPS 正文 SHA、九个实体路径入口、查询保留、未知路径 404 和 HTTPS 升级均通过。下文“准备”与命令描述保留并行 agent 的责任边界；本机设计预览未替换生产页面，新版浏览器、微信和真机唤起仍未验收。

## Gitee 仓库与网页托管

[Gitee 当前官方帮助目录](https://gitee.com/help.com/)在“静态页面托管”下将 Gitee Pages、Pages Pro 和单页面应用支持均标为“功能已下线”。2024-05-23 创建的[官方反馈问题](https://gitee.com/oschina/git-osc/issues/I9RGKI)中，成员回复暂无重新上线计划；2026-03-21 创建的[后续反馈](https://gitee.com/oschina/git-osc/issues/IHMP10)仍报告 Pages 不可用。问题创建日期不是回复日期；当前帮助目录是本轮结论的主要依据。

这些证据不支持新开通免费 Pages，也不支持购买旧 Pages Pro 来恢复服务。旧教程中的开通、实名和自定义域名步骤不能作为当前能力；[旧 Pages Pro 地址](https://gitee.com/help/articles/4228)本轮转到帮助首页，没有给出可用套餐。若账号控制台另有特殊服务，需要根代理登录后实际核实，不能在未核实时承诺可开通、免费额度或域名条件。

静态网页资源仍可放在 Gitee Git 仓库，再交给另一个实际可用的宿主。模板负责生成网页，托管服务负责让网址公开访问；换模板不会恢复已经下线的 Gitee Pages。App 的 Flutter、Rust 源码和对应源码 ZIP 不进入 Gitee 安装包仓库。2026-10-04 补充：Services 管理入口不可用时，现有公开 Pages 仓库可仅追加经过冻结 Release 审核的对应源码 ZIP 到独立 `/downloads/` 许可渠道；不上传源码工作树、不在首页加源码入口。普通网页白名单保持原限制，操作见 [下载站说明](../site/README.md#对应源码的固定备用下载)。

## 六个模板如何选

下面是结合帮帮“简短介绍 + 安装入口”形态的选择判断，不是各项目对性能或可用性的保证。它们生成的静态资源可以保存到 Gitee，部署地点仍需另外选择。

| 模板 | 主要形态 | 对帮帮宣发的适合程度 |
| --- | --- | --- |
| [Hugo Blowfish](https://github.com/nunocoracao/blowfish) | Hugo，多种首页布局 | 从名单选择时优先；官方 `landing` 支持简介和 CTA，也可完全自定义首页 |
| [Hugo PaperMod](https://github.com/adityatelange/hugo-PaperMod) | 简洁的 Hugo 博客 | 轻量备选，需要收起文章导航与列表 |
| [Astro Pure](https://github.com/cworld1/astro-theme-pure) | Astro 博客、文档 | 后续要教程或内容站时考虑，目前增加构建成本 |
| [Vdoing](https://github.com/xugaoyi/vuepress-theme-vdoing) | VuePress 知识库、博客 | 更适合使用文档，不必用于两按钮下载页 |
| [Huxpro](https://github.com/Huxpro/huxpro.github.io) | Jekyll 个人博客 | 文章与导航较重，需要较多删减 |
| [Leopardpan](https://github.com/leopardpan/leopardpan.github.io) | Jekyll 个人博客 | 适合文章展示，当前宣发页没有这类需求 |

Blowfish 的[官方首页说明](https://blowfish.page/docs/homepage-layout/)提供 `landing`、`heroButtons`、介绍文字和自定义布局；`homepage.showRecent=false` 可收起最近文章，完全自定义使用 `layouts/partials/home/custom.html`。它采用 [MIT 许可证](https://github.com/nunocoracao/blowfish/blob/main/LICENSE)，复制或分发主题时保留 Nuno Coração 的版权和许可声明。本轮没有安装或复制这些主题。

当前建议继续使用已有纯 HTML/CSS 小站。现有页面和资源不到 1.3 MB，不需要引入 Hugo、Astro 或博客框架。若未来需要持续发文章，再选 Blowfish；当前下载宣发与个人博客分开维护。

## 现有域名的可行路线

现有公开仓库 [JackLee992/bangbang-redirect](https://github.com/JackLee992/bangbang-redirect)已经绑定 `bangbang.yilin.fun`。GitHub Pages 支持公开仓库的静态网页与自定义域名，实际账号和证书状态沿用根代理已经验证的配置。[GitHub Pages 官方说明](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)

将该仓库的转发首页替换成真实的帮帮宣发页后，HTML 不必再跳转到 ChatGPT Sites。只使用 `bangbang.yilin.fun`，不改 `yilin.fun`、`www` 或个人博客仓库；也不需要阿里云额外的 URL 转发记录。该路线只去除首页的跨站跳转，App 家人 API 和对应源码仍在现有 Sites 服务，不能据此声称已经消除全部 Cloudflare 依赖或完成国内手机网络验收。

当前已验真的安装入口：

- Android：[0.1.3（18）APK](https://gitee.com/yilin-dev/bangbang-releases/releases/download/v0.1.3/bangbang-0.1.3-arm.apk)，49,169,392 字节、SHA-256 `628c6183febae70f0a8159e86caef7a80f37d6b7d2b0a48cbab267ddeb1a9af6`。
- iOS：没有已核实的公开 TestFlight 地址。最终发布沿用既有首页的真实 `pending` 说明按钮，不添加公测或 App Store 假入口；额外极简本机预览隐藏这项。

## 本机准备与验证

独立极简预览：`artifacts/gitee-static-promo-preparation/preview/`，仅有 `index.html`、`styles.css`、原品牌 PNG、`.nojekyll`、`CNAME` 和开发说明。无文章列表、源码入口、第三方字体、埋点 SDK 或跨站首页跳转。它只是可审阅的首页设计，缺少完整邀请和隐私页，不直接替换生产包。

本地查看可在项目根目录执行：

```sh
python3 -m http.server 4178 --bind 127.0.0.1 \
  --directory artifacts/gitee-static-promo-preparation/preview
```

最终生产网页继续使用现有 `site/public`。`site/scripts/prepare-github-pages.mjs`将已校验的 Sites 静态构建适配为 GitHub Pages：它要求固定静态白名单、外部下载与现有家人 API，拒绝私密文件、符号链接、额外安装包或函数；不会重新编译或签名 App。适配 metadata 使用 `target/provider=github-pages`、`sourceBuildTarget=sites`，保留 release 来源与服务 URL，避免把 GitHub Pages 称为 Sites 托管。

三个路径别名直接复制对应 HTML 到目录 `index.html`，没有额外跳转；页面继续读取原始查询与片段。`404.html` 保留原来的未知页面，不引入任意路径路由。`.well-known/assetlinks.json` 与根副本保持原字节，空 `.nojekyll` 防止 Jekyll 忽略点目录；`CNAME` 固定为 `bangbang.yilin.fun`。[GitHub 静态构建与 .nojekyll](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)

12 项适配器定向回归和共 58 项相关构建/下载回归通过，无跳过。覆盖实体别名与编码参数、原页面脚本读取邀请码、未知路径、输出保留、隐私/大文件/符号链接拒绝，以及 source/API/BUILD_INFO 校验。它们是本机受控检查；GitHub 的目录斜杠规范化、实际 HTTP 200/301、微信打开与手机唤起仍由根代理上线后验收。

实际网站代码已冻结为 `f0dd123042439d650ba3b8f00c5198d55006cfd3`，根代理已核对远端一致。可交付完整 Pages 小包为 `artifacts/android-release-0.1.3-18/publish-gitee-f0dd1230/web-github-pages/`：25 文件、1,248,211 字节；对应 ZIP 为 1,182,765 字节、SHA-256 `2b8b7c0634220ac69e54e872e042d4cc29e9a5859519da58f610df527684736e`。相邻的逐文件 SHA 与构建报告记录精确 Git 快照校验；APK 源仍为 `b8bbd580…`，不是网页提交。具体三套包与服务已发布状态见 [0.1.3 交付准备](SITE_RELEASE_0.1.3.md)。本准备任务未操作远端发布。

## 精确发布清单与命令

在包含本轮已审核网页配置的真实提交上构建，不能给未提交工作树填入旧 HEAD 来源。默认下载 manifest 已写入验真的 Gitee APK；对应源码和完整 BUILD_INFO 保持独立渠道与原校验值。以下命令仅生成本机小包，不执行网站、Git 或 DNS 发布：

```sh
website_commit="$(git rev-parse HEAD)"
GITHUB_SHA="$website_commit" node site/scripts/build.mjs --target sites \
  --site-origin https://bangbang.yilin.fun \
  --downloads-dir artifacts/android-release-0.1.3-18/assets \
  --output-dir artifacts/gitee-static-promo-preparation/pages-input \
  --download-base-url https://bangbang-services.s419505080.chatgpt.site/downloads/ \
  --family-api-base-url https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family
node site/scripts/prepare-github-pages.mjs \
  --input-dir artifacts/gitee-static-promo-preparation/pages-input \
  --output-dir artifacts/gitee-static-promo-preparation/pages-ready \
  --site-origin https://bangbang.yilin.fun \
  --download-base-url https://bangbang-services.s419505080.chatgpt.site/downloads/ \
  --family-api-base-url https://bangbang-services.s419505080.chatgpt.site/.netlify/functions/family
```

发布内容恰好 25 个静态文件，不能推入 App 仓库、`.openai` 配置、设备日志、ZIP 或安装包缓存：

```text
.nojekyll
.well-known/assetlinks.json
404.html
CNAME
app.js
assetlinks.json
assets/app-welcome.png
assets/brand.png
assets/brand.svg
deployment.json
downloads/AGPL-3.0.txt
downloads/SHA256SUMS
downloads/build-info.json
help.html
help/index.html
index.html
invite-utils.js
invite.html
invite.js
invite/index.html
privacy.html
privacy/index.html
release.json
site-share.js
styles.css
```

根代理确认这份小包的逐文件 SHA、真实网站提交与待发布目录后，才在已经绑定子域名的独立 checkout 执行下面的发布步骤。先核对 remote 为 `JackLee992/bangbang-redirect`、工作树无未保存改动，并记录原 HEAD；不要在个人博客 checkout 执行。先看 `rsync` 预演，再复制和审查；现有 `.git` 不被复制或删除。

```sh
promo_checkout=/Users/jacklee/develop/daillyTasks/bangbang-sites/redirect
git -C "$promo_checkout" remote get-url origin
git -C "$promo_checkout" status --short
git -C "$promo_checkout" rev-parse HEAD
rsync -an --delete --exclude=.git \
  artifacts/gitee-static-promo-preparation/pages-ready/ "$promo_checkout/"
rsync -a --delete --exclude=.git \
  artifacts/gitee-static-promo-preparation/pages-ready/ "$promo_checkout/"
git -C "$promo_checkout" diff --check
git -C "$promo_checkout" add --all
git -C "$promo_checkout" diff --cached --stat
```

暂存审查必须确认只有上述白名单、没有 App 源码和私密资料。根代理再提交、推送现有 `main`，核对远端提交一致并等待 Pages 实际构建；此准备任务没有执行这些操作。上线需实际验证首页无跨站跳转、APK 匿名完整 SHA、`.well-known` 200、`/invite`/`/invite/`/`.html` 的编码参数与片段、帮助/隐私实体别名，以及未知路径 404；页面关闭 JavaScript 时不应再发生转发口令丢失。邀请页已有功能脚本及无脚本提示保持原样。

旧转发 checkout 的基线为 `adc627246261936ce867a26822ccfe8de5fc270c`，本轮只读检查时干净。它与旧 0.1.2 安装资产均保留回退依据；不要通过覆盖个人博客或修改家庭 API 来回退网页。
