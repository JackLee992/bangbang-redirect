# 公网连接可靠性与操作流畅性：传输方案评估

检索日：2026-10-02。适用场景：家人用 iPhone / Android 帮助长辈操作 Android；基础协助免登录。代码阅读基线为 `4f0e6ab` 附近的工作区；源码分析不等于指定安装包已采用或通过手机验收。本文结合源码、一手资料及标明范围的主线实测，未部署新服务或开通付费账户。

建议顺序是：**先完成现有原生链路的有界回退与帧链测量，再验证服务器允许的备用路线；若仍不能达到体验目标，用同一场景对照 WebRTC / 托管 RTC。** 不以协议名称代替真实首帧和操作反馈。验收流程、首轮目标与网络矩阵统一使用 [核心链路验收](CONNECTION_RELIABILITY_ACCEPTANCE.md)，功能优先级见 [NEXT_FEATURES](NEXT_FEATURES.md)。

## 一、先区分连接阶段与画面传输

| 部分 | 当前职责 | 能解决的问题 | 不能由此推导的结论 |
| --- | --- | --- | --- |
| 家人 HTTPS 服务、轮询、APNs / FCM | 配对、求助请求、接听/结束、通知唤醒 | 找到当前可接听请求，明确双方许可 | HTTP 可用或推送成功，不代表画面链路可用 |
| RustDesk `hbbs` | 原生注册、寻址、协商直连/中继 | 找到对端、建立候选路径 | 注册成功，不代表已采集或显示画面 |
| 原生 TCP / UDP-KCP 直连、`hbbr` 中继 | 承载 RustDesk 会话、编码画面与控制消息 | 真正的远程协助传输 | 端口可连接，不代表认证、首帧、输入反馈均成功 |
| RustDesk WebSocket | `/ws/id` 用于服务器通信，`/ws/relay` 承载中继会话 | 在部署支持时提供另一条服务器接入路径 | 给家人 HTTP 服务增加 WS，不能自动替换原生媒体路径 |
| WebRTC | ICE 选路、媒体轨道、DataChannel | 另一套媒体和数据传输引擎 | WebRTC 本身不提供家庭关系、呼叫信令或系统控制权限 |

本项目的 iOS 角色由 `RustDeskAssistController.helperOnly` 限制为家人端，`supportsSharing` 返回其反值。研究重点是 Android 采集和执行操作、iOS 解码显示和发送输入，不将 SDK 的“支持 iOS”解释成能远控 iPhone。[控制器源码](../flutter/lib/qinban/rustdesk_assist_controller.dart)

## 二、现有 RustDesk 路线：先把已有能力用可靠

### 2.1 源码已经有直连和中继回退，但各阶段需共享总截止时间

| 源码入口 | 阅读到的行为 | 对本项目的含义 |
| --- | --- | --- |
| [`src/client.rs`](../src/client.rs)，约 319–365 行 | 允许时探测 UDP NAT；带 UDP 和不带 UDP 的连接策略并发，取先成功者 | 已有会话建立阶段的并发尝试；不能据此认定被控端注册心跳也具有同样回退 |
| 同文件，约 462–488 行 | `PunchHoleRequest` 最多三轮，等待参数为 3 / 6 / 9 秒 | 局部重试并非整个用户操作的总截止时间 |
| 同文件，约 697–737 行 | TCP、UDP/KCP、IPv6 候选并发；直连失败或要求中继时，有中继地址才继续请求中继 | “自动回退”仍依赖真实服务器响应及可用中继 |
| 同文件，约 852–928 行 | 中继申请最多三轮，每轮等待参数 18 秒，然后连接中继并发送 `RequestRelay` | 不能简单叠加局部等待；取消必须贯穿寻址、协商和连接 |
| 同文件 `force_relay`；[`rendezvous_mediator.rs`](../src/rendezvous_mediator.rs) 的 `PunchHole` 处理 | WS、代理、强制中继，以及特定 NAT / 监听限制影响选路 | 显示最终使用的路线用于诊断，不把协议选择交给长辈 |

上述数值是分支中的等待参数，不是实测接通时间。应为一次邀请/接听建立一个可取消的总预算，记录每个阶段花费，成功后取消失败候选；迟到的成功回复不得重新打开已结束的会话。把 **被控端注册回退** 与 **家人端连接回退** 分别验证，避免只修其中一边。

主线较早使用官方 1.4.9 预编译库的公网对照报告如下原始观察，包含成功和失败：

| 前置条件 | 路线 | 观察 |
| --- | --- | --- |
| 清除 `stop-service`，新进程，本机网络，`rs-ny` | UDP，一轮 | 20 秒内注册未完成，状态 `-1` |
| 相同前置条件 | TCP，第一轮 | 约 6.3 秒观察到系统分享入口 |
| 相同前置条件 | TCP，后续一轮 | 20 秒仍超时，原生状态 `0`，原因继续排查 |
| 保留旧 `stop-service=Y` 状态 | TCP，另一次 | UI 刚到 20 秒截止，原生随后才变为可用，提示旧等待不能及时唤醒也是原因 |

这些是单网络小样本；**TCP 也有失败，尚未证明其稳定或已解决问题。** 观察支持继续检查唤醒、单实例、注册响应与有界备用路径；系统分享入口出现也不等于远程首帧或点击已成功。

该旧库对照中，双 Android 模拟器使用公网注册服务完成剪贴板邀请、双方授权，并用图像匹配确认远程画面；约 38 秒出现 `os error 103` 断开，该轮远程点击结果未验证。这条首帧证据未记录确定的最终媒体路线，也不能替代真实 iPhone → Android 跨运营商验证；后续新库 WSS 观察另列于 2.2 节，不能混为同一轮成功。

Android 构建证据需要单独核对：当前 CI 经 [`prepare_engine.py`](../scripts/qinban/prepare_engine.py) 复制固定的官方 1.4.9 原生库；iOS 分发脚本以 `flutter,hwcodec` 编译当前 Rust。源码修改与 APK 内 `.so` 不等价；Rust 改动必须重新编译并核验产物后才能声称手机已使用。`Cargo.toml` 中的版本或 feature 名称也不能证明运行时启用了某种编解码器。[Android CI](../.github/workflows/qinban-android.yml)、[iOS 构建脚本](../scripts/qinban/build_ios_distribution.py)

本轮私有 QA 包已另外换入源码构建的新库（SHA-256 前缀 `8499be`）：先前 `sodium_base64_encoded_len` 缺失已修复，严格符号闭包检查 498/498、Android `RTLD_NOW` 加载及 APK 实际首启均通过。该包的两轮自动路线都在 UDP 约 6 秒后进入 TCP，但均未完成注册；其中观测到 TCP 后续 EOF。因此已验证回退发生，尚未证明该自动路线解决本网络接通问题；加载通过也不等于连接验收通过。

### 2.2 WSS 443 是有条件的中继路线

官方高级设置明确：`allow-websocket` 需要 **客户端 ≥ 1.4.0、Pro 服务端 ≥ 1.5.7**，默认关闭，只支持中继，且需要正确反向代理。不能把 OSS 的 Web 客户端端口说明等同于本项目移动原生客户端已可使用完整 WS 注册/中继。[RustDesk 高级设置](https://rustdesk.com/docs/en/self-host/client-configuration/advanced-settings/#allow-websocket)

官方配置将 `/ws/id` 转发到 21118、`/ws/relay` 转发到 21119；正确部署后可只暴露 443。开启该模式的自定义客户端使用中继，直接 IP 连接除外。[RustDesk WSS 配置](https://rustdesk.com/docs/en/self-host/rustdesk-server-pro/faq/#8-add-websocket-secure-wss-support-for-the-id-server-and-relay-server-to-enable-secure-communication-for-all-platforms)

仓库中 `config::use_ws()` 读取 `allow-websocket=Y`；`socket_client::connect_tcp()` 据此进入 WS；`websocket::check_ws()` 对 IP 和域名拼接不同地址，域名的 `wss` 选择还依赖 API server 是否为 HTTPS。**当前开关不是 TCP 失败后的自动 WSS 兜底，也不是天然安全的 443 配置。** [配置](../libs/hbb_common/src/config.rs)、[连接入口](../libs/hbb_common/src/socket_client.rs)、[URL 构造](../libs/hbb_common/src/websocket.rs)

证书策略需看完整调用链：`allow-insecure-tls-fallback` 默认关闭，此时 `tls::get_cached_tls_accept_invalid_cert()` 返回 `Some(false)`，不会进入允许无效证书的回退；显式开启后才可能放宽。候选验收应保留默认严格校验，并覆盖错误证书拒绝。另 `WsFramedStream::new` 当前未使用代理参数，不能假定现有 SOCKS 配置自动适用于 WS。[TLS 策略](../libs/hbb_common/src/tls.rs)、[WebSocket 实现](../libs/hbb_common/src/websocket.rs)

工程判断：WSS 适合验证“普通 HTTPS 可用、原生端口受限”的网络，但它依然在 TCP 上有序传输；丢包造成的等待、服务端绕路和客户端帧积压不会因加了一层 WebSocket 自动消失。全量改为中继也会增加中继带宽需求。若未来实现自动备用路线，应在确认服务器支持后按会话选择，并测试混合版本、双端配置、失败取消和回滚，不能在健康协助中随意翻转全局开关。

主线另从 Mac 对公共主机做标准 WS 升级探测并校验 `Sec-WebSocket-Accept`，报告如下（本地证据 `artifacts/transport-qa/public-websocket-probe.json`，不提交探测产物）：

| 地址 | 响应 | 本次耗时 |
| --- | --- | --- |
| `https://rs-ny.rustdesk.com:443/ws/id` | 101，升级校验通过 | 0.97 秒 |
| `https://rs-ny.rustdesk.com:443/ws/relay` | 404 | 1.32 秒 |
| `http://rs-ny.rustdesk.com:80/ws/id` | 301 | 未用于判定可用 |

这组探测本身只证明 Mac 当前网络下该 `/ws/id` 能升级；同主机的 `/ws/relay` 本次不可用，不能推导服务器实际返回的其他中继目标也不可用。后续 Android 实测返回的 `relay_server` 是 **`ovh-west2.rustdesk.com`**，不能用 `rs-ny` 的 404 否定它。服务版本和容量仍未核实；**不因单个 101 响应全局开启 WS**。自建/替换服务仍作为待授权的预备方案。

主线随后在新库 `8499be` 私有 QA 包上临时开启 WSS，API server 使用 HTTPS，显式保持 `allow-insecure-tls-fallback=N`，取得以下手机原生路径证据（设备是两台 Android 模拟器，本地证据目录 `artifacts/transport-qa/wss`；含私有邀请与身份的原始产物不提交）：

| 验证阶段 | 本轮结果 | 证据边界 |
| --- | --- | --- |
| Android 注册与分享入口 | 实际注册成功，系统分享面板出现 WeChat；原生启动到最终 online 约 3.76 秒 | 这是注册阶段耗时，不是用户点击求助到首帧的端到端耗时；没有据此计算线上成功率 |
| 邀请与画面 | 剪贴板邀请、双方明确确认、远程画面已通过 | 两模拟器当前网络中的观察，不是实体手机跨运营商验证 |
| 输入执行与反馈 | 家人端点击 More 后长辈端菜单打开；再点 Help 后长辈端帮助页打开，回传画面确认 | 已有真实输入执行和反馈，尚无连续操作延迟分布 |
| 结束与持续性 | 本轮从会话取得屏幕唤醒锁到主动结束约 6 分 47 秒，期间完成上述点击；长辈端结束后采集停止，家人端显示协助已结束；再次邀请也打开系统分享面板，并正常停止 | 包含静态等待，不是持续操作压力测试；尚无重复运行成功率与长时间稳定性结论 |
| 单指滑动 | 旧 QA16 单指只移动家人端画布；修复后的 QA17 已在同类 WSS 双端流程验证上滑、下滑，长辈页面与回传画面都更新 | 旧兼容层重复注入触摸，已用设备日志和组件 RED/GREEN 定位；修复后组件 20/20 通过，新包日志为 2 次 oneFingerPan、0 次 twoFingerScale。尚非持续手势压力或延迟分布验证 |

原图像匹配脚本因家人端底部工具栏裁剪 Help 行而误判失败；人工检查可见 Help 文字并点击后，页面变化与回传画面确认通过。原失败记录保留，区分自动匹配失败与功能结果，不把后者改写成原脚本全绿。这轮支持将 WSS 列为优先复测候选，仍需同包重复运行、持续手势与延迟测量、不同网络及真实 iPhone → Android 的同口径验证，才能决定正式路线策略。正式发布默认配置未变；当前 WSS 设置仅用于两台私有 QA 模拟器。

补测使用本地提交 `3feb07f` 的 Android 触摸修复，私有 QA17 APK SHA-256 为 `54ff0de57c131c82192d85d067bb5de6a6e70901aec0caa97a90d462b8499f30`，包含已验证原生库 `8499be`。重新验证系统分享含 WeChat、邀请确认、双方同意、More/Help/Back 三次远程点击、上下两个方向的单指滑动、长辈端停止采集和家人端结束状态；两端已返回首页。完整记录在本地 `artifacts/transport-qa/gesture-fixed/verified-result.json`。首次等待弹窗遇到同一已取消邀请的正常去重，随后通过显式“粘贴邀请”重新确认；不将这一步改写为自动弹窗重现成功。配置只保留在两台 QA 模拟器，未发布新包或更改正式默认路线。

### 2.3 流畅性必须沿采集 → 编码 → 传输 → 解码 → 显示测量

下表是源码审查发现的具体测量点，尚未证明哪个环节是当前手机的瓶颈。尤其 Android 使用预编译库，需要先确认库与源码行为一致。

| 环节 | 当前源码行为 | 应记录或验证的重点 |
| --- | --- | --- |
| Android 采集 | `MainService.useVP9=false`；RGBA `ImageReader(maxImages=4)` 通过 `acquireLatestImage` 取新帧；Rust 原始帧只有一个覆盖式 slot，100 ms 过期 | 没有从采集开始无限堆积的帧 FIFO；未走的 VP9 分支中的 `setFrameRate(1F)` 不能用来断言实际只有 1 FPS |
| 分辨率 | 起点是实际屏幕像素；软件编码半尺寸选项默认开启，符合条件且某边大于 1200 时宽高减半；硬件路径不同 | 实际尺寸、软件/硬件路径、文字可读性与编码耗时；当前不是固定 720p |
| 编码和 QoS | 自动 codec 取双方能力交集；有硬件失败后软件回退；目标 FPS 为 30、初始 15，QoS 还会动态下降 | 不用目标 FPS 冒充采集/编码/显示 FPS，也不默认永远 VP9 |
| 发送排队 | 视频与其他消息分两个无界队列；视频服务等待消费通知，最长等待参数 3 秒；通常 `video_ack_required=false`，取出待发送视频就通知 fetched | 这个通知不是 iPhone 显示完成 ACK；补队列长度、最老帧年龄、真正发送完成时间 |
| 发送与输入 | 被控端同一异步选择循环还负责读取输入；视频 `send().await` 可能占住循环，流写超时参数为 12 秒 | 在限速/丢包下实测写阻塞与输入延迟相关性；候选优化是有界输出及分离读写进度，不能仅增大缓冲 |
| iOS 接收与解码 | 每显示器 120 个普通帧的有界队列，溢出替换旧帧并请求刷新；关键帧与通知另经通道；已有解码速度驱动的降 FPS | 原始队列长度与帧龄；丢弃预测帧需配合关键帧恢复，不能随意清空参考链 |
| iOS 解码与 Flutter 交付 | iOS 硬件选项在当前源码关闭；VP8/VP9 等走软件解码；移动端 RGBA 交付仅保留一个待取缓冲，Dart `decodeImageFromPixels` 完成后才释放 | 编译了 `hwcodec` 不等于使用 VideoToolbox；显示交付满时新显示事件可被跳过，解码却仍继续，应比较解码 FPS 与 UI 交付 FPS |
| 输入回传和 Android 执行 | Dart → 原生无界发送通道 → 同一会话流 → Android JNI / `InputService`；滚轮队列是无长度上限的 `LinkedList`，消费包含 50 ms + 10 ms 等待 | 高频滚动最老事件年龄；断网后不得连放过期输入；只合并可覆盖事件，保留 down / up / stop 及结束时释放指针 |

源码入口：[MainService](../flutter/android/app/src/main/kotlin/com/carriez/flutter_hbb/MainService.kt)（239、288、433 附近）、[原始帧 slot](../libs/scrap/src/android/ffi.rs)、[video_service](../src/server/video_service.rs)（875、1095、1161 附近）、[connection](../src/server/connection.rs)（423、479、928–1002 附近）、[video_qos](../src/server/video_qos.rs)、[codec](../libs/scrap/src/common/codec.rs)（851 附近）、[hwcodec](../libs/scrap/src/common/hwcodec.rs)（313、631 附近）、[io_loop](../src/client/io_loop.rs)（1170、1340、2425 附近）、[Flutter 原生交付](../src/flutter.rs)（1190 附近）、[Dart 图像交付](../flutter/lib/models/model.dart)（2001 附近）、[InputService](../flutter/android/app/src/main/kotlin/com/carriez/flutter_hbb/InputService.kt)。行号随并行修改可能变化，应按函数定位。

现有 [`remote_performance.dart`](../flutter/lib/qinban/remote_performance.dart) 已提供原生解码 FPS、UI 图像交付 FPS、BGRA 构图交付耗时、codec、RTT、吞吐和实际尺寸；[`frame_delivery.dart`](../flutter/lib/qinban/frame_delivery.dart) 明确不含网络、原生解码和屏幕实际绘制时间。先使用这些数据定位，再补发送/解码队列帧龄、编码耗时和点击到可见反馈；不能把“图像交付耗时”宣传成端到端操控延迟。

当前 UDP 媒体候选是可靠 KCP 字节流，不是 RTP。故把 TCP 换为 UDP 路径，并不自动具有 WebRTC 媒体轨道的过期帧和拥塞处理语义。对现有引擎先做受控测量，若发送写阻塞或解码/显示错配成立，再做小范围有界队列、调度或编解码实验；不直接把 FPS 拉高，也不在没有功耗、文字清晰度和首帧证据时全量切换 codec。

## 三、WebRTC + TURN：解决媒体传输，但需要端到端接入

WebRTC 可以传音视频和二进制数据；SDP offer/answer 和 ICE 候选仍需应用自己的信令交换。现有家人服务可以保留身份和呼叫状态，再新增受当前会话权限约束的协商接口；使用 HTTPS 或 WSS 传信令都可以。Trickle ICE 可边发现候选边交换，减少等待全部候选的时间。[WebRTC Peer connections](https://webrtc.org/getting-started/peer-connections)

STUN 用于发现可达地址；TURN 在无法直连时转发流量。标准要求支持 ICE，以及端到 TURN 的 TCP / TLS-over-TCP 路线来应对 UDP 被阻断的网络。**TURN/TLS 443 与 WebSocket 443 是不同协议**，也不能保证穿过所有仅允许 HTTP 的代理。当前 `hbbs` / `hbbr` 不能因为同为“中继”就直接充当 TURN。[RFC 8835](https://www.rfc-editor.org/info/rfc8835/)

仓库虽有可选 `hbb_common/webrtc` feature 与流类型，当前主 crate 没有启用该 feature；这不构成 Android → iOS 完整 WebRTC 视频路线已接通的证据。仅把原有编码数据塞入可靠 DataChannel，也不会自动获得媒体轨道的实时调度能力。[主 Cargo 配置](../Cargo.toml)、[公共库 feature](../libs/hbb_common/Cargo.toml)

适合本项目的验证切片是：Android 明确授权后发布一条屏幕视频轨道，iOS 接收显示；两端通过独立的逻辑数据通道回传输入，保留现有 Android 无障碍执行与坐标映射。需要同时完成采集、编码协商、拥塞调节、关键帧恢复、解码渲染、网络切换和会话结束，而非只添加 TURN 地址。独立通道不意味着独立网络带宽，真正要验证的是控制读写不会被媒体队列长时间阻塞。

DataChannel 可选有序/无序、可靠/部分可靠；同一 SCTP association 内的数据流共享拥塞窗口。建议把可覆盖的移动位置做合并和过期丢弃，把按下/抬起、确认、结束等事件做有序确认与幂等处理；动作必须带当前会话代次，断网后不回放旧手势。具体手势合并需要在 Android 执行端验证，不能任意丢弃组成一次滑动的必要节点。[RFC 8831](https://www.rfc-editor.org/info/rfc8831/)

自管 WebRTC 的收益是媒体策略和部署选择更可控；成本是两端引擎接入、TURN 运维、跨运营商覆盖及后续兼容工作。TURN 走 TCP/TLS 时仍存在 TCP 传输约束，所以需要分别测直连 UDP、TURN UDP、TURN TLS，不能只报一个“WebRTC 接通率”。这是可对照的长期候选，现阶段不建议直接替换全部会话。

## 四、其他传输与远控协议：适用位置和替换代价

以下是工程候选比较，均未在本项目接入或完成手机对照。当前原生会话 [`Stream`](../libs/hbb_common/src/stream.rs) 没有 QUIC / WebTransport 分支；新增协议需要双方及相应服务器支持，现有公共服务是否支持不能从端口开放或 WS 升级成功推导。

| 候选 | 能提供什么 | 本仓库仍需完成什么 | 优先考虑的用途 |
| --- | --- | --- | --- |
| QUIC + Datagram | UDP 上的加密、多路可靠流；Datagram 扩展提供受拥塞控制的不可靠数据报。多流可减少流之间的有序等待，但仍共享网络瓶颈。[RFC 9000](https://www.rfc-editor.org/rfc/rfc9000.html)、[RFC 9221](https://www.rfc-editor.org/rfc/rfc9221.html) | 两端原生接入、消息分帧和调度、媒体过期与关键帧恢复、寻址/中继、认证；仍需现有采集、编解码和显示 | 确认媒体排队阻塞输入后，验证独立控制流与可过期媒体；不能只把整个旧字节流搬入一个可靠流 |
| WebTransport | Web API 提供双向/单向流和数据报；2026-07-30 W3C 候选推荐包含 HTTP/3 与 HTTP/2 会话，具体能力依赖实现。[W3C WebTransport](https://www.w3.org/TR/2026/CR-webtransport-20260730/) | 浏览器支持不等于 Android / iOS 的 Flutter + Rust 原生链路已可用；需原生库或另一套 Web 客户端、服务器协议映射，以及同样的媒体/控制调度 | 将来确有浏览器控制端需求时评估；当前两手机原生流程不因浏览器 API 存在而缩短接入工作 |
| VNC / RFB | 帧缓冲更新和键鼠输入；客户端请求驱动更新，慢端可跳过中间状态；使用可靠传输，通常是 TCP。[RFC 6143](https://www.rfc-editor.org/rfc/rfc6143.html) | Android 被控端 RFB server，把真实采集帧编码成更新、输入映射到无障碍手势；iOS viewer、家庭许可和公网寻址/中继 | 静态文字界面的兼容性对照；更换协议本身不会修复 TCP 拥塞或 iOS 显示瓶颈 |
| RDP | 图形、输入和多通道；现代扩展还包含可靠/有损 UDP 路线，并非仅 TCP。[微软多传输规范](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-rdpemt/5aa61c5c-e864-4ec6-bd80-e1df51555a48) | 微软移动应用是连接 Windows / RDS 的客户端，不代表 Android 已有被控端；这里需要额外的 Android server、采集/输入适配及 iOS viewer。[官方角色说明](https://learn.microsoft.com/en-us/windows-server/remote/remote-desktop-services/connect-remote-desktop-services) | 未来增加 Windows 被控端时更值得评估；本场景无法直接套用 Windows 图形栈优化 |
| SRT | 面向实时传输的 UDP、丢包重传、时间戳缓冲与过期丢包；不限定媒体载荷。[Haivision SRT](https://github.com/Haivision/srt)、[官方 API](https://github.com/Haivision/srt/blob/master/docs/API/API.md) | 两端库、视频打包/解码显示、缓冲参数和拥塞处理；家庭信令、输入确认及结束协议仍要实现，仍需 UDP 不可达时的备用路线 | 仅媒体传输的受控实验；直播的低延迟指标不能当作点击到画面反馈的延迟 |

**UDP 受限时，QUIC 仍需要 TCP / TLS 等备用路线。** RFC 9308 明确要求应用处理这类失败，并保持回退的安全与应用语义；QUIC 的 0-RTT 有重放风险，不应直接承载未经防重放设计的控制动作。WebTransport 的 HTTP/2 映射也不能据规范文字就宣称当前手机和服务器已经支持；要求不可靠传输的模式不能依赖可靠传输自动获得同样的效果。[RFC 9308](https://www.rfc-editor.org/rfc/rfc9308.html)、[WebTransport 连接选项](https://www.w3.org/TR/2026/CR-webtransport-20260730/)

这些路线均不能代替每次屏幕共享许可与输入执行授权。若启动实验，应继续复用现有家庭会话边界、坐标映射和停止逻辑，严格保留 down / up / stop 顺序；每次只替换一个可测量环节。现阶段优先级仍是修好当前链路，再用 WebRTC / 一个托管 RTC 做完整协助对照；QUIC、WebTransport、VNC、RDP、SRT 保留为有具体瓶颈或平台需求时的候选。[Android 共享同意](https://developer.android.com/media/grow/media-projection#user_consent)、[无障碍手势执行](https://developer.android.com/guide/topics/ui/accessibility/service#perform-gestures)

## 五、国内托管方案：先比较完整协助，不只看视频演示

| 候选 | 一手资料确认的能力 | 我们仍要实现/验证 | 适合的下一步 |
| --- | --- | --- | --- |
| 腾讯云 TRTC | Android 屏幕共享、iOS 接收端及自定义消息 | 家庭许可、房间级凭据、输入确认、坐标转换；弱网增值功能的套餐条件 | 一个 Android → iPhone 场景，与原生路线同网同任务对照 |
| 声网 RTC | 屏幕共享、Flutter / 原生 API、数据流消息 | 同上；具体机型采集限制与屏幕场景参数 | 与 TRTC 二选一先做小范围验证，避免同时维护两套正式引擎 |
| 贝锐向日葵 SDK | 嵌入式远控方案，公布多系统和公有/私有部署选择 | 必须确认 iOS 主控 → Android 被控的确切 SDK 角色矩阵、免注册嵌入方式及授权费用 | 取得适用版本和书面计费口径后，评估能否减少输入/远控集成工作 |

TRTC 通过 `startScreenCapture` 发布 Android 屏幕。其自定义消息指南规定每秒最多 30 条、单条最多 1 KB；可靠且有序模式会引入等待，不能把它当作无限吞吐的输入通道。平台 API 文档的总码率说明存在差异，接入时固定 SDK 版本并按该版本校准，不在此把单平台数字扩展到所有端。[TRTC Android 屏幕共享](https://cloud.tencent.com/document/product/647/45751)、[自定义消息](https://cloud.tencent.com/document/product/647/32241)

声网 Android 数据流文档给出的限制是每客户端最多 5 个通道、合计 30 KB/s，每通道每秒最多 60 个包、每包最多 1 KB；可靠模式仍有超时错误回调。屏幕共享支持指定帧率、码率和内容场景，但文档列有华为共享过程中调整编码分辨率等设备限制。迁移后仍需真机覆盖，不能把 SDK 默认参数当作长辈手机的最佳参数。[声网数据流](https://doc.shengwang.cn/api-ref/rtc/android/API/toc_datastream)、[屏幕共享](https://doc.shengwang.cn/doc/rtc/android/basic-features/screen-share)

向日葵官网提供 SDK / 开放 API 方案，没有足以计算“1000 用户以内嵌入式远控”的公开确定报价。本轮不使用其个人会员价格代替 SDK 授权费用，也未联系销售。[向日葵 SDK](https://sunlogin.oray.com/product/sdk)

这些 SDK 能改变媒体路径，不能替代系统授权：Android 14+ 每次 MediaProjection 会话仍需用户同意，并正确处理前台服务与 `onStop`。任何候选都应保留当前双方明确确认、停止共享、结束控制和换机后重新授权的语义。[Android Media projection](https://developer.android.com/media/grow/media-projection)

### 可核实的成本口径

“1000 注册用户以内”不是 RTC 计费单位。预算至少要有每月实际参与分钟、接收画面档位、同时协助数和额外录制等服务用量。以下为检索日中国站公开刊例价，单位是**人民币 / 1000 个计费分钟**，不是每 1000 个账户；优惠、免费额度和合同条款未计入预算。

| 服务 | 音频 | HD | FHD | 计量差异与来源 |
| --- | ---: | ---: | ---: | --- |
| 腾讯云 TRTC | 7 | 28 | 63 | 按订阅视频流及实际接收分辨率分档；未订阅视频的在房用户也产生音频用量。[时长计费](https://cloud.tencent.com/document/product/647/44248) |
| 声网 RTC 音视频通话 | 7 | 28 | 63 | 按频道用户时长，视频用集合分辨率；不可混用其极速直播或录制价格。[价格页](https://www.shengwang.cn/price-prom/) |
| 向日葵嵌入式 SDK | 未取得适用报价 | 未取得适用报价 | 未取得适用报价 | 官网咨询定价，需确认计费按设备、并发、时长还是最低套餐 |

以**已按供应商口径统计的** 10000 个 HD 计费分钟为例，刊例用量费用为 280 元；这不是 1000 人使用一个月的总价。腾讯多路订阅会叠加，屏幕共享另有虚拟主播计费说明，超码率可能跳档；必须用试点的实际账单核对完整两端费用。腾讯标准分钟中 HD 按 4 倍抵扣，不能将“11 万分钟套餐”理解为 11 万 HD 协助分钟。[TRTC 统计与抵扣规则](https://cloud.tencent.com/document/product/647/44248)

腾讯最新计费概述列入门版 0 元开通、无赠送时长、默认后付费；基础版 625 元/月、11 万标准分钟。特定弱网卡顿优化属于高档套餐功能，不能把所有宣传能力计入入门版。声网价格页有标准分钟套餐与试用信息，本轮仅采用上表刊例单价，账户资格与免费额度未验证；正文读取受工具限制，价格表已由官方页面搜索索引核验，采购前再核对控制台。[TRTC 计费概述](https://cloud.tencent.com/document/product/647/17157)、[声网价格页](https://www.shengwang.cn/price-prom/)

自有 `hbbr` / WSS / TURN 也有中继流量和运维成本。工程估算可用：单向屏幕码率为 `b Mbps`，中继时长为 `m 分钟`，仅该方向的出口数据约为 `0.0075 × b × m GB`（十进制，不含协议开销、音频和反向流量）；并发 `c` 路对应约 `b × c Mbps` 的该方向出口。直连比例、地域和云厂商计费模型未知，本文不编造服务器月租或总费用。

## 六、渐进实施与进入下一阶段的条件

| 顺序 | 范围 | 继续投入的依据 | 暂不做的扩展 |
| --- | --- | --- | --- |
| P0：现有引擎 | 有总截止时间的注册/连接回退，取消传播，真实首帧/操作指标，采集到显示与输入的队列测量 | 当前公网同包对照能定位失败阶段；原生修复确实进入安装包 | 通知、家庭管理等功能扩张 |
| P1：确认可用备用路径 | 核对现有服务真实能力；服务支持时验证 WSS 中继，比较 TCP 中继、直连和 WSS | 特定网络接通有改善，正常网络延迟/流量没有不可接受退化 | 未验证公共服务就全局开启 WS；未经授权部署新服务器 |
| P2：一个 RTC 验证切片 | 若 P0/P1 仍不能达标，选择自管 WebRTC 或一个国内 RTC SDK；覆盖屏幕 + 输入 + 双方结束 | 同网、同设备、同操作脚本下显著改善首帧与反馈，账单可解释 | 只演示视频就宣称远控迁移完成；同时正式接入多家供应商 |
| P3：有限推广 | 会话级路线选择、失败回滚、短期房间凭据、成本限额；继续按同一验收口径比较 | 真机跨运营商覆盖、旧版本共存、会话终止和权限边界全部通过 | 把房间身份或家庭恢复当成新的远控授权 |

各阶段保留同一用户流程：长辈邀请、双方同意、出现最新画面、操作有及时反馈、任一端能结束。UI 只显示可理解的进度和有效下一步；详细协议和路径写入脱敏诊断。无论使用哪条路，健康会话不应因短暂家人 HTTP 失联被无故打断，已撤销或结束的会话也不能被迟到响应复活。

## 七、证据边界与待补实测

- 源码阅读说明存在的分支和潜在瓶颈，不证明某个 APK、iOS 安装包或公共服务器已运行该分支。
- 官方 SDK / RFC 文档说明可实现能力，不证明中国每个运营商或特定真机上的性能；国内服务候选也需同样的跨网验收。
- 两模拟器的受控网络实验可用于重复故障注入；真实 iPhone → Android、不同网络与真实低性能手机的测量需单独保留。
- WSS 已验证上述 Android 模拟器注册、双方邀请、画面、点击反馈、修复后双向单指滑动、旧 QA16 约 6 分 47 秒会话保持，以及长辈主动结束后双方结束状态；另已验证再次邀请打开分享面板并停止。重复完整协助、连续操作压力、延迟分布和跨网真机仍待验证。TURN、服务地域、负载与带宽保障未核实，也没有供应商试点账单。
- 本文档改动不新增依赖、不修改运行配置、不发布版本；临时 QA 配置与产物单独管理。后续结论以 [核心链路验收](CONNECTION_RELIABILITY_ACCEPTANCE.md) 中同候选版本的原始样本和指标为准。
