# 帮帮宣发网站：阿里云 ICP 备案准备

核对日期：2026-10-03。用户已确认 `yilin.fun` 尚未备案；个人证件所在地为河北邯郸、现居北京，另已提供海南个体工商户执照展示截图。当前比较河北个人、邯郸个体工商户和已有海南主体的路径，尚未选定并提交官方订单。证件图片、证件号码、姓名、手机号、详细住址和核验信息不写入源码仓库。

## 当前迁移条件

宣发站由静态页面组成，可以先单独部署到已购买 ECS；家人后台的数据库迁移不是网站部署的前提。北京属于中国内地节点，取得备案并完成阿里云接入后才能正式开放 Web 服务。备案期间可以准备文件、安装与本机验收，继续保留原 Sites 下载入口。[阿里云网站搭建流程](https://help.aliyun.com/zh/dws/getting-started/the-whole-process-of-website-building)

| 项目 | 已知情况 | 申请前需核对 |
| --- | --- | --- |
| 云服务器 | 已购买北京 ECS，2 核 2GB，公网 IP、固定 3Mbps 带宽 | 在备案控制台确认此实例可选、包年包月购买时长符合要求；不能只凭“99 元”判断资格 |
| 域名 | `yilin.fun` 在阿里云，已核对有效期至 2029-08-31 | 实名认证、域名持有人与备案主体的对应关系、域名注册商资质 |
| 域名后缀 | 阿里云域名核验文档列有 `.FUN` | 后缀可备案不等于具体域名已通过实名/主体核验 |
| 当前网站地址 | `bangbang.yilin.fun` 仍指向 Sites；自动化访问返回其 Cloudflare 403 | 备案批准和阿里云部署验收前，不提前改到北京 ECS |
| 内容与主体 | 自研 App 宣发、安装下载、安装帮助；产品规划有家庭订阅 | 个人路径按本人河北证件核对；单位路径按实际营业执照核对，不能用海南单位条件替代个人条件 |

阿里云最新服务器检查文档对 ECS 的要求是：中国内地节点、包年包月且购买时长大于 3 个月（含续费累计）、有公网带宽；购买时长按订单核对，不要求等服务器实际运行 3 个月。部分其他官方快速入门使用“3 个月及以上”的表述，临界期限以备案控制台校验为准；如果购买的是一年期，期限通常满足该条件。同一个阿里云账号下备案会自动关联符合条件的实例，无需另买服务码。[服务器检查](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/icp-filing-server-access-information-check)

域名需通过实名认证并符合域名持有人核验要求。提交时重新核对持有人，不假定阿里云账号实名、Apple 签名人或聊天昵称就是备案主体。[域名准备与检查](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/prepare-and-check-the-domain-name)

## 个人路径：河北证件、北京现居

个人身份证登记地址已确认在河北邯郸，现居北京。可以优先核对与身份证住所一致的河北个人备案路径；北京现居属于实际联系信息，服务器部署在北京也不要求备案地区必须为北京。最终地区与材料以如实填写后的系统校验及初审为准。[个人跨省备案处理](https://help.aliyun.com/zh/icp-filing/basic-icp-service/support/for-the-record-to-dismiss-the-faq)

| 表单或材料 | 准备原则 |
| --- | --- |
| 备案性质、证件 | 个人、居民身份证；本人有效身份证原件正反面 |
| 证件住所 | 按身份证登记地址填写河北邯郸，详细信息直接填写官方系统 |
| 通信地址 | 填写真实的北京现居联系地址；如与证件地址不同，按页面要求说明 |
| 域名实名 | `yilin.fun` 的实名姓名、证件类型、号码需与本人备案资料一致 |
| 联系与核验 | 常用手机、应急联系方式、邮箱及本人真实性核验、工信部短信核验 |

河北公开个人规则列明身份证、域名与负责人核验，没有列出海南小型经营主体的社保或居住证要求。河北身份证剩余有效期要求大于 1 个月，域名剩余有效期大于 30 天；同时核对阿里云通用材料与域名要求。证件地址和通信地址是两个字段，不把实际北京住址改成虚假河北联系地址。[河北个人备案规则](https://help.aliyun.com/zh/icp-filing/icp-filing-regulations-for-hebei)、[主办者信息填写](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/the-fill-in-the-sponsor-information)

若选择按北京现居办理，需核对个人跨省受理和当前订单要求。北京公开个人规则同样未单列社保证明要求，不能推断外省户籍必定需要北京社保，也不能仅凭页面未列出就保证完全无需附加材料。[北京个人备案规则](https://help.aliyun.com/zh/icp-filing/icp-filing-regulations-for-beijing)

个人内容可用于个人作品分享等场景，单位内容可包含产品宣传等。现有网站有 App 展示和安装下载，是否可按个人开发免费作品受理，应以真实页面和用途接受初审；不得把将要经营的业务伪装成个人博客。新增家庭订阅等业务时重新核对主体与实际经营内容。[备案性质与内容](https://help.aliyun.com/zh/icp-filing/basic-icp-service/support/faq-about-icp-filing-preparations)

## 单位路径：邯郸个体工商户

用户同时要求准备邯郸个体工商户登记，经营场所按自有住宅理解，所在区县和住宅登记材料仍待官方核对。完整流程、经营范围候选及已有海南执照迁入选项见[邯郸个体工商户办理清单](HANDAN_SOLE_PROPRIETOR_SETUP.md)。取得实际河北营业执照后，按真实单位信息核对河北单位备案、域名实名及负责人资料，不把新主体或迁入结果当作已完成。

## 备用单位路径：已有海南个体工商户

若最终沿用海南个体工商户，才使用本节的海南单位备案条件。在系统中选择与个体工商户营业执照对应的备案性质和证件类型，主办者名称逐字采用执照全称，不能只填写 App 品牌名。[基础信息校验](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/basic-information-check)

备案地区按该经营主体真实所在地选择海南，再按执照和系统选项填写市、区。北京服务器可以作为接入资源，无需为海南主体另买海南服务器。[海南管局办事指南](https://hnca.miit.gov.cn/bsfw/bszn/art/2020/art_95dd38fddd944b35ba5c81b5bb242040.html)、[基础信息校验](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/basic-information-check)

阿里云账号的个人/企业实名认证类型不决定备案主体类型，个人实名账号也可以提交真实企业主体；域名持有人和网站负责人仍需符合该省的单位备案要求。[账号与主体规则](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/overview)

海南需要特别核对以下条件：

- 个体工商户等小型经营主体的主体负责人，省规则要求为法定代表人；个体执照实际列的是经营者，应以该经营者作为主体负责人准备，并在初审核对系统角色名称。网站负责人也由经营者本人承担，可减少另设负责人的材料。
- 若该负责人不是海南户籍，海南规则要求提供本人有效海南居住证或在海南缴纳社保的证明；执照注册在海南不自动免除这项条件。
- 省规则允许域名持有人为主办单位或法定代表人；阿里云通用核验还检查名称、证件类型和号码。因此不能仅凭个人姓名相同就认定单位备案可通过。先查看 `yilin.fun` 现有实名，优先核对其与执照主体的一致性；如使用经营者个人实名路线，先由初审确认是否适用于此订单，需修改时再按官方页面办理。
- 海南要求域名剩余有效期大于 30 天、身份证有效期大于 1 个月；阿里云通用域名文档要求至少大于 45 天。当前域名到期日符合这两项域名期限要求，身份证期限仍待本人核对。

上述地区要求依据[海南备案规则](https://help.aliyun.com/zh/icp-filing/icp-filing-regulations-for-hainan)，域名还需同时满足阿里云的[域名核验规则](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/prepare-and-check-the-domain-name)。

若需要修改域名实名，主办者名称和证件类型、号码应按证件原文核对，包括中文括号。实名认证或过户后信息同步到工信部通常需要 2–3 天；阿里云域名可先提交阿里云初审，再由系统等待同步后提交管局。当前未执行域名持有人变更。[域名准备与检查](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/prepare-and-check-the-domain-name)

## 海南单位路径的资料

| 资料 | 准备方式 |
| --- | --- |
| 营业执照 | 当前有效营业执照原件的清晰彩色照片；在官方表单填写执照全称、证件号码、登记住所等 |
| 负责人身份证 | 经营者有效身份证原件正反面；如另设网站负责人，再按系统要求提供其证件和授权材料 |
| 联系资料 | 负责人常用手机、邮箱、实际联系地址及系统要求的应急联系方式 |
| 域名资料 | `yilin.fun` 实名信息和必要的域名证书；核对与经营主体的对应关系 |
| 接入与网站 | 可备案的北京 ECS、网站名称、实际域名和功能说明；备案名称至少三个汉字，并与主体相关 |
| 非海南户籍材料 | 仅在经营者非海南户籍时准备有效海南居住证或海南社保证明 |
| 本人核验 | 按阿里云 App 或官方链接完成负责人真人核验；收到短信后及时核验 |
| 订单附加材料 | 真实性核验单及订单要求的授权、承诺等材料；按系统模板和初审意见办理，不预先假定需要全部盖章材料 |

用户提供的是执照展示页截图，可用于本轮确认主体类型；正式提交仍按阿里云页面要求提供真实证件原件照片，不能把屏幕截图再次翻拍当成原件。是否支持电子营业执照的官方核验方式，以当前订单页面为准。照片格式、大小、拍摄方法以上传页面为准；通用材料文档列出 JPG/JPEG/PNG/GIF、200KB–4MB，负责人需本人完成真实性核验。[基础信息校验与原件要求](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/basic-information-check)、[官方材料清单](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/overview)、[资料上传与真实性核验](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/upload-data-and-authenticity-verification)

身份证照片、身份证号、密码和验证码直接提交官方系统，不发送到聊天或上传到 GitHub。

## 怎么申请

1. 用购买 ECS 的同一阿里云账号打开 [ICP 备案入口](https://beian.aliyun.com/)，选择免费自助备案。账号下最多有一个备案主体；如果该账号已有主体，先核对，不创建冲突订单。
2. 按最终选择的真实个人或单位资料输入主办者、省市、证件和网站域名信息，完成基础校验；选择账号下可备案的北京 ECS。个人填写本人身份证资料，单位填写实际营业执照资料，二者不混用。准备备案域名 `yilin.fun`，实际宣发子域名为 `bangbang.yilin.fun`；按系统规则核对本域名下各个网站用途。
3. 填写网站和负责人资料，上传系统要求的原件材料，通过官方流程完成本人真实性核验，检查资料后提交初审。网站备案名称要求至少三个汉字，并与主体和真实内容符合规定；当前品牌名“帮帮”只有两个汉字，备案名称需另按真实用途核对，不能直接照填。[网站信息与命名要求](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/fill-in-website-information)
4. 保持负责人手机畅通，接听阿里云初审电话；需要补充资料时按订单提示修改。初审一般 1–2 个工作日。
5. 收到工信部核验短信后，相关负责人在 **24 小时内**完成官方短信核验；所有指定人员均需完成。验证码由负责人在官方系统填写。[短信核验说明](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/sms-check)
6. 等订单所对应的省通信管理局审核，阿里云一般预计 1–20 个工作日。总时长以真实资料、补正和审核进度为准；不能把海南时限或材料直接套入河北、北京订单。[ICP备案流程](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/icp-filing-application-overview)
7. 备案通过后在网站页脚显示真实备案号并链接工信部，完成服务器、HTTPS 和下载链接验收，最后把宣发子域名切到 ECS。网站正式开放后按官方要求办理公安联网备案。[备案后处理](https://help.aliyun.com/zh/icp-filing/basic-icp-service/user-guide/icp-filing-application-overview)

海南管局备案不收费，阿里云自助备案也免费；付费备案管家或智能助理是可选服务，本项目当前不购买这些服务。[海南管局收费与流程](https://hnca.miit.gov.cn/bsfw/bszn/art/2020/art_95dd38fddd944b35ba5c81b5bb242040.html)、[阿里云流程与费用选项](https://help.aliyun.com/zh/dws/getting-started/the-whole-process-of-website-building)

## 已准备的网站内容说明

以下说明对应现有产品，供填写时核对，不代表已获审核接受：

> 提供自行开发的家庭远程协助应用“帮帮”的功能介绍、安卓应用安装包下载、iOS 安装状态及安装帮助。应用用于家人之间经双方确认的远程协助。

当前网站首页、安装帮助、隐私说明及邀请页可以提供设计/内容截图；如本省要求建设或组网方案，可基于实际部署文件补齐后由负责人核对和签署。不编造负责人、公司、公章、备案号或额外业务资质。

网站备案与 App 备案是不同服务项。这里优先准备宣发网站；帮帮面向中国境内提供互联网信息服务时，App 备案需按实际 App 和平台信息另行核对，不能仅凭后端使用公网或境外服务就认定免除。网站备案号不当作 App 备案号使用。[App 备案入门](https://help.aliyun.com/zh/icp-filing/basic-icp-service/getting-started/quick-sta-rt-for-icp-filing-for-personal-app)、[App 备案适用条件](https://hnca.miit.gov.cn/bsfw/bszn/art/2020/art_95dd38fddd944b35ba5c81b5bb242040.html)
