# 完整求助呼叫与服务选型

更新：2026-10-02。产品没有用户注册/登录概念，家人关系仍由一次双方同意的加密协助建立。

当前为尚未发布的本地候选；实测结果、构建记录和发布前置条件见 [完整呼叫验证](CALL_FLOW_VERIFICATION.md)。

## 一次呼叫

长辈“邀请家人”先处理屏幕共享授权，确认连接服务在线后才分享或呼叫保存的家人。准备失败不会发出一个无法使用的邀请。

已配对流程：发起 → 等待家人收到 → 家人响铃/接听或拒接 → 等待长辈确认协助 → 接通并看到画面 → 任一方挂断。屏幕共享和远程操作权限仍由系统及长辈确认。接听求助本身不会自动授予远程控制权限。

信令：queued / observed / accepted / active / ended、failed、cancelled、declined、expired。accepted 只表示接听，active 必须由控制端收到第一帧后报告。两端保留相同 requestId 到终态；active 为 60 秒租约，每 25 秒续期，单次最长一小时。没有画面仍受最初 120 秒超时限制。终态不可被迟到的接听或第一帧恢复。

当前前台轮询周期 2 秒；离线和后台没有实时到达保证。原生连接已建立后会继续按原引擎运行，家人信令不能替代视频传输。

## 通知与电话式交互

本地已接入 Android 高优先级通知、提示音，以及 iOS UserNotifications、前台重复提示音。通知含“接听/暂不接听”，点击后重新校验已认证请求、编号和过期时间，再执行接听。重复请求不重复响铃，接听、撤回、过期和离开待接状态会清理提醒。“更多 → 开启来电提醒”申请系统通知许可。

这些是已收到请求的本地呈现能力；App 被暂停或关闭后，新请求需要远程推送才能送达。当前没有配置 APNs 或厂商推送，不能承诺锁屏或退出 App 后来电。

iOS 先采用普通 APNs 可操作通知。CallKit/PushKit 面向真实 VoIP 通话，不能只为唤醒屏幕协助而伪装 VoIP。是否加入语音通话及系统电话界面另行评估；大陆上架的可用性需以提交时 Apple 审核要求确认。安卓先用通知动作与应用内呼叫页，暂不依赖全屏来电权限。

远程推送接入约定：通知只携带 requestId 与短 TTL，不带远控口令或家人 capability；注册推送 token 必须绑定现有安装身份凭证；服务端验证家人关系后单播，过期不补响；收到后拉取权威状态；注销/移除家人后撤销对应投递。推送 token 不进入统计日志，不需要为此添加用户账号。

官方：[Apple UserNotifications](https://developer.apple.com/documentation/usernotifications)、[PushKit VoIP](https://developer.apple.com/documentation/pushkit/responding-to-voip-notifications-from-pushkit)、[Android CallStyle](https://developer.android.com/develop/ui/views/notifications/call-style)。

## 国内 SDK

| 候选 | 用途 | 结论 |
| --- | --- | --- |
| [友盟 U-App](https://www.umeng.com/analytics) / [SDK](https://devs.umeng.com/) | 行为事件、呼叫漏斗、版本对比 | 首选统计候选。标准版目前免费，非实时且漏斗额度有限；平台支持 Flutter。需要创建应用取得 AppKey。 |
| [腾讯 Bugly Flutter 插件](https://github.com/BuglyDevTeam/Bugly-Flutter-Plugin) | Dart/原生崩溃定位 | 作为崩溃补充，不能把正常连接失败当崩溃上报；当前 Flutter/原生 SDK 版本兼容性仍需构建验证。 |
| [个推](https://docs.getui.com/getui/) / [Flutter 插件](https://github.com/GetuiLaboratory/getui-flutter-plugin) | APNs 与安卓厂商通知 | 后台求助提醒候选。免费基础推送可用，部分厂商策略/频率/分析收费；仍要配置 Apple 和厂商凭证。 |

本轮未把以上 SDK 加入正式依赖或初始化，也没有把用户数据发给它们。已有 `ConnectionDiagnostics` 白名单事件可映射给统计适配器；服务商 AppKey、初始化同意流程与隐私清单准备好后再接入一个主统计 SDK，避免重复自动采集。若使用第三方 SDK，需要同时更新独立隐私页和 iOS 隐私申报；统计不作为家人求助的必需条件。

## 国内免费后端

- [腾讯云 CloudBase](https://cloud.tencent.com/document/product/876/75213)：有免费资源点，免费环境需按当前规则续期，适合 HTTP 信令/结构化日志；[2026 续期规则](https://cloudbase.cloud.tencent.com/blog/2026/07/28/cloudbase-free-trial-renewal)带任务条件。
- [EdgeOne Pages](https://pages.edgeone.ai/zh/pricing)：可评估轻量接口/站点；大陆域名、单文件大小和云函数额度需核对。当前 APK 大于 25 MB，不直接把它当下载替代站。
- [uniCloud](https://doc.dcloud.net.cn/uniCloud/price)：有免费套餐，但续期和调用额度限制更明显，适合小规模原型。

这些不能直接代替需要 TCP/UDP 长连接的 RustDesk 中转 VM。先保留 Netlify 站点和家人接口，Cloudflare 做诊断，Oracle 或国内 Linux VM 做连接服务器。
