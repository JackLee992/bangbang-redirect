# 构建说明

## 固定输入

- 代码基于 RustDesk 1.4.9；原始基线为 `6c578292e8ebbbec708b76986ba8c4bc7c509747`，帮帮的引擎改动必须从当前源码编译。
- hbb_common 子模块锁定到 `7e1c392c62d39c364127307cd408421dd5f8cfb0`。
- Flutter 3.24.5、JDK 17、Rust 1.98.1、flutter_rust_bridge_codegen 1.80.1（uuid feature）、cargo-expand 1.0.95。
- Android NDK 28.2.13676358、原生 API 24，vcpkg 基线 `120deac3062162151622ca4860575a33844ba10b`；编译 feature 为 `flutter,hwcodec`。
- `flutter/pubspec.lock` 与每次 APK 构建产物中的锁文件逐字节比较。FFI 桥只生成一次，同一份 Rust/Dart 桥供全部 ABI 使用。
- Android minSdk 24；compileSdk 34、targetSdk 33 沿用该版本宿主兼容配置。此版本用于 APK 侧载，不宣称满足应用商店的最新上架要求。
- Rustls Android verifier crate 0.1.1 SHA-256：`f87165f0995f63a9fbeea62b64d10b4d9d8e78ec6d7d51fb2125fda7bb36788f`。源码构建只通过 `prepare_engine.py --verifier-only` 下载此 Maven 依赖。

## GitHub Actions

`.github/workflows/qinban-android.yml` 在 main 推送或手动触发时执行，分为四步：

1. `interface` 固定工具版本，生成一次 FFI 桥，运行 Flutter 与原生交付检查脚本的单元测试。
2. 三个 `native-<ABI>` job 并行编译 ARM64、ARMv7、x86_64。每个 job 恢复同一桥，从源码构建、strip 后检查 ELF、符号闭合和移动端 FFI 导出，再保存库与清单。
3. `apk` 聚合并核对三个 ABI 的源码摘要、工具链和清单，将已验证库装入正式 ARM APK 和 CI x86_64 APK；重新读取 APK 内实际 `.so` 核对 SHA-256。Gradle 保留已 strip 库的原始字节，不能在打包时二次改写。
4. `devices` 用同一源码编译的 x86_64 APK 进行双机验收。

缓存仅保存固定版本的桥工具、Cargo 下载和 vcpkg 二进制依赖；key 包含 ABI、Rust、NDK、API、vcpkg 基线、Cargo/vcpkg 输入、Android triplet 和构建脚本。不会缓存或复用完整引擎交付目录，不会以官方 1.4.9 库覆盖当前源码构建结果。

`qinban-android` 构建产物包含 ARM APK、x86_64 测试 APK、生成的桥、锁文件，以及 `build/qinban-native/` 中的总清单、各 ABI 清单、库和 APK 核验报告。清单绑定生成桥、原生源码、构建输入、工具链和库字节；仅有“编译成功”日志不构成交付证明。

仓库 Secrets 存放 `QINBAN_KEYSTORE_B64`、`QINBAN_STORE_PASSWORD`。证书别名 `qinban`。本地备份在被 Git 忽略的 `.signing/`；**请自行安全备份这份签名材料，以便后续 APK 能覆盖升级。不要提交签名私钥。**

推送配置通过 `QINBAN_PUSH_MODE` 显式选择 `none`（默认）、`compile-only` 或 `production`。默认构建不需要 Python 或 Firebase；启用后需 Python 3（可用 `QINBAN_PYTHON` 指定解释器）与 `QINBAN_FIREBASE_CONFIG` 客户端 JSON。`compile-only` 仅允许 debug，禁用消息服务，不能用于 release。`production` 还需 `QINBAN_FIREBASE_PROJECT_ID`、`QINBAN_FIREBASE_APP_ID`、`QINBAN_FIREBASE_SENDER_ID` 三项公开身份与 JSON 完全匹配；服务账号私钥会被拒绝。正式发布重读 APK 中的模式、配置摘要及公开身份，并写入 `build-info.json`；配置检查通过不表示通知已送达。现有 CI 未注入 Firebase 配置，仍默认 `none`。

双机验收也可单独运行 `.github/workflows/qinban-device-check.yml`，输入 APK 构建的 run ID。它安装同次构建的 x86_64 测试 APK 到两台 API 35 模拟器，保存截图、日志、MediaProjection 状态以及 APK SHA-256。模拟器通过不能代替真实 iPhone→安卓或跨网验收。

## 发布绑定

`.github/workflows/qinban-release.yml` 输入构建与已通过双机验收的 run ID。正式 APK 只含 ARMv7/V8；x86_64 APK 仅用于 CI，不发布。发布脚本会：

- 确认来源是 Android 源码构建工作流，桥、三个 ABI 和 APK job 全部成功。
- 检查当前生产源码、vcpkg 输入、构建/发布脚本及工作流与构建、验收提交一致；文档更新可单独提交。
- 将构建产物中的生成桥与源码清单对齐，拒绝缺桥、错桥、缺 ABI 清单、不同来源或被替换的库。
- 再次读取 ARM 和 x86_64 APK 内的原生库，与每 ABI 清单逐字节核对，同时验证测试记录属于该 x86_64 APK。
- 检查正式 APK 架构、证书、应用名称和版本，上传 APK、完整源码 ZIP、`SHA256SUMS`、`build-info.json`。`build-info.json` 保留总清单、每 ABI 清单以及两份 APK 的实际原生库校验结果。

没有源码构建清单的历史官方库 APK 不能通过新发布流程，需要重新构建、验收。工作流不会覆盖已有版本。修改工作流和通过本地检查并不表示 GitHub CI 已运行；首次三 ABI 构建与双模拟器验证仍须以实际 Actions 结果为准。

## 本地构建（需要足够磁盘空间）

准备上述固定版本的 Rust、Flutter、JDK、NDK，以及对应 Rust Android target。vcpkg checkout 必须在指定基线，执行过 `bootstrap-vcpkg.sh -disableMetrics`。Linux 需安装 build-essential、curl、zip/unzip/tar、pkg-config、cmake、ninja-build、autoconf、automake、libtool、nasm、libclang-dev。

```bash
git clone --recurse-submodules https://github.com/JackLee992/bangbang-android.git
cd bangbang-android
python3 scripts/qinban/prepare_engine.py --verifier-only
export QINBAN_VERIFIER_MAVEN="$PWD/.qinban-cache/verifier-maven"
cargo install cargo-expand --version 1.0.95 --locked
cargo install flutter_rust_bridge_codegen --version 1.80.1 --features uuid --locked
cd flutter
flutter pub get
cd ..
flutter_rust_bridge_codegen --rust-input ./src/flutter_ffi.rs --dart-output ./flutter/lib/generated_bridge.dart --c-output ./flutter/macos/Runner/bridge_generated.h
python3 scripts/qinban/build_android_native.py build \
  --repo . --output artifacts/android-native \
  --ndk "$ANDROID_HOME/ndk/28.2.13676358" \
  --vcpkg "$VCPKG_ROOT" --tool-cache .qinban-cache/native-tools \
  --abi arm64-v8a --abi armeabi-v7a --abi x86_64
python3 scripts/qinban/build_android_native.py verify --repo . --output artifacts/android-native
```

将 `artifacts/android-native/delivery/<ABI>/` 中两份 `.so` 放入对应的 `flutter/android/app/src/main/jniLibs/<ABI>/`，保留原生交付清单。不要将这些库或工具链提交 Git。构建前需配置 `flutter/android/key.properties`：

```properties
storeFile=/absolute/path/to/your.jks
keyAlias=qinban
storePassword=YOUR_PASSWORD
keyPassword=YOUR_PASSWORD
```

```bash
cd flutter
flutter test test/qinban
flutter build apk --release --target-platform android-arm64,android-arm --build-name 0.1.2 --build-number 17
cd ..
python3 scripts/qinban/build_android_native.py verify-apk --repo . \
  --output artifacts/android-native --apk flutter/build/app/outputs/flutter-apk/app-release.apk \
  --abi arm64-v8a --abi armeabi-v7a
```

独立应用包名 `io.github.jacklee992.qinban`，可与原版 RustDesk 共存。Java/Kotlin namespace 保留上游名称用于原生 JNI ABI 兼容。

## 历史官方库路径

`prepare_engine.py` 不带 `--verifier-only` 仍可下载 SHA-256 为 `57cfeac99c2f99d8c5848683c6ae06e6da0f6a869e98f790cab276cb7408f243` 的官方 1.4.9 APK 并恢复其库，仅用于历史对照。此操作会覆盖本地 `jniLibs`，不适用于包含帮帮原生修复的版本，CI 源码构建和发布链路不会调用它。

本仓库无定时工作流。不会部署自有中转服务，也没有把旧项目混入 DailyTasks 仓库。
