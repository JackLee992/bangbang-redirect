# 记住家人和前台求助

## 服务边界

家人关系只在一次真实、已授权的 RustDesk 协助会话中建立。helper 在本轮 outgoing `connection_ready.secure == true`、已收到真实 `peer_info` 后，通过加密 Chat 交换安装身份及配对能力。`secure` 来源于 native 实际 Stream 的密钥状态，而不是“启用加密”设置。双方 Chat hello 声明的设备号码必须等于当前会话 peerId，serverScope 必须匹配当前连接配置。

这项服务只传递“家人希望得到帮助”的短期信令。helper 收到后仍需明确点接受，再连接 elder；elder 原有本机屏幕共享授权和 incoming 允许协助继续生效。后端不会反向控制 helper，不自动批准远程连接，也不以请求队列状态证明已经进入真实远程会话。

当前源码为前台约两秒轮询与持久化队列，并在已收到请求后显示可接听/拒接的本地通知。通知栏展开时继续接收撤回，App 在后台/被系统结束时不能依赖轮询获得新请求；后台提醒仍需 APNs、Android 推送、设备 token 管理及真实设备验证。完整呼叫与通知改动尚未发布，线上 0.1.1 仍使用旧流程，详见 [呼叫与服务选型](CALL_FLOW_AND_SERVICES.md)。

## HTTPS 协议 v1

固定单一入口：`POST https://bangbang-jacklee992.netlify.app/.netlify/functions/family`。

所有调用都使用 `Content-Type: application/json`，HTTP 头 `Authorization: Bearer <installationId>.<authSecret>`。authSecret 不进入请求 URL、分享消息、Chat、响应或日志。每次安装由客户端密码学随机生成 installationId（16 字节）和独立 authSecret（32 字节），以无 padding 的 canonical base64url 表达，长度分别22/43。邀请码 BB1 和数字 RustDesk ID 均不作为鉴权凭据。

JSON 公共字段为 `{ "v": 1, "op": "操作名" }`；成功返回 `{ "v": 1, "ok": true, ... }`，错误返回 `{ "v": 1, "ok": false, "error": "稳定错误码" }`。不接受未知字段。请求体上限8192字节；返回 `Cache-Control: no-store`。所有时间为 Unix 毫秒。

| op | 额外请求字段 | 成功返回及权限 |
| --- | --- | --- |
| `register` | `peerId`, `serverScope` | `installationId`。首次原子认领身份，随后只允许同一个 auth 更新。 |
| `pair.offer` | `pairId`, `capability`, `nonce`, `elderInstallationId`, `elderPeerId`, `helperInstallationId`, `helperPeerId`, `serverScope` | `pair`。只允许指定 helper owner；双方必须已注册，号码和scope均匹配。helper offer算己方确认。 |
| `pair.confirm` | `pairId`, `capability`, `nonce` | `pair`。只允许指定 elder owner确认相同nonce/capability。双方随后poll confirmed才可视为已记住。 |
| `poll` | 可选 `pairIds` 数组，最多32个本地已知关系ID | `pairs` 与 `requests`。owner只能读自己的关系。helper实际poll才将 queued 原子改为 observed。 |
| `request.create` | `pairId`, `capability`, `requestId` | `request`。只允许elder，对已确认且绑定未变的家人创建120秒请求。 |
| `request.respond` | `pairId`, `capability`, `requestId`, `decision`=`accept`或`decline` | `request`。只允许helper，明确答复为accepted/declined。 |
| `request.progress` | `pairId`, `capability`, `requestId` | `request`。只允许helper，将accepted变为active，或续期active；客户端只在收到真实第一帧后调用。 |
| `request.end` | `pairId`, `capability`, `requestId`, `reason`=`ended`、`failed`或`cancelled` | `request`。双方已绑定owner均可结束；终态幂等且不可复活。 |
| `request.cancel` | `pairId`, `capability`, `requestId` | `request`。只允许elder撤回queued/observed/accepted请求；与接受并发也不会复活撤回。 |
| `pair.forget` | `pairId`, `capability` | `pair`=revoked。任一方owner可撤销双方关系能力，尚存请求同步revoked。 |

pairId、requestId、nonce均为各自随机16字节 canonical base64url；capability为每一段关系独立随机32字节。能力由helper在真实加密会话后创建并交换，不能从公开邀请码推导。peerId为6–20位ASCII数字；serverScope为1–200字节无空白ASCII，允许字符 `A–Z a–z 0–9 . _ : / + = -`，建议用当前server配置的稳定摘要或公共服务器scope。更换号码或scope后，旧关系变为stale，不能继续求助，需重新真实配对。

`pair` 包含 pairId、status、elderInstallationId、elderPeerId、helperInstallationId、helperPeerId、serverScope、offerExpiresAt。状态为pending/confirmed/revoked/expired/stale；offer只存活十分钟，同pairId重试不延期，过期/撤销后无法重新启用。响应不包含capability、authSecret或其哈希。

`request` 包含 pairId、requestId、elderPeerId、helperPeerId、status、createdAt、expiresAt，以及事件发生时的observedAt/respondedAt/cancelledAt/connectedAt/endedAt。请求状态为queued/observed/accepted/active/ended/failed/declined/cancelled/expired/revoked。

- queued仅表示服务端已持久化，不能向用户写“家人已收到”。
- observed表示helper的前台轮询已经读取请求，不能证明系统提醒已显示。
- accepted只表示helper明确答应；真实连接/本机授权另以native实际事件为准。
- active来自控制端第一帧回调，不能用accepted或授权代替。客户端每25秒续期60秒租约，最长到createdAt后一小时；接通前保持120秒TTL。
- 同一requestId创建重试保持原状态和原TTL，不再发送；只有已接通的progress可续期。每段关系同时最多一个未过期queued/observed/accepted/active请求，新请求至少间隔15秒。
- ended/failed/expired/declined/cancelled/revoked请求不再接受，也不会重播。永久的小型requestId claim避免旧ID被替换后重新入队；部分存储写入失败也只报失败，绝不伪报queued。遇到409 replay/conflict或429时应先poll确认现状，再按用户新动作生成新requestId，不能延长旧求助。

常见错误：401 unauthorized；403 wrong_role/not_family_member/invalid_capability/invalid_nonce；409 pair_pending/pair_expired/pair_revoked/pair_stale/request_pending/request_replayed/request_expired/request_cancelled/concurrent_change；429 request_rate_limited；503 storage_unavailable/service_unavailable。网络、503及非JSON响应均属于失败，客户端应保留可重试操作，不显示“已发出”或“已连接”。

## 后端存储与部署

实现文件为 `site/server/family-service.mjs` 与 `site/netlify/functions/family.mjs`。通过官方 `@netlify/blobs` 11.1.3 打开 site-wide store，明确 `region: ap-southeast-1`、`consistency: strong`。官方 getStore site-wide 数据跨发布保留；读写使用 ETag 与 onlyIfNew/onlyIfMatch条件写。设备auth、pair能力和nonce只保存绑定身份的 SHA-256 哈希。

只有 `context.deploy.context == production && context.deploy.published == true` 读取 `bangbang-family-v1-production`。未发布/历史/预览部署使用按deployId隔离的preview store；缺少部署上下文时失败。预览不能拿生产家人数据测试。Netlify运行时自动提供站点存储凭据，客户端无需且不能持有Netlify访问token。

状态转移以单个pair记录CAS为权威，有限重试冲突后返回409。owner关系索引最多32段，满时清理已失效索引；客户端poll建议附本地pairIds，以继续识别被清理索引的旧关系已撤销。requestId claims只作为防重放墓碑，没有任何原始秘密。forget是双方能力撤销，不删除允许旧ID复活的墓碑。

当前SDK的条件写错误处理存在已公开缺陷：非412失败可能被包装为modified=true。适配层拒绝非成功/304/404/412HTTP响应，还要求条件写成功提供非空ETag，并强读回核对ETag与内容；因此无法确认保存的操作返回503。异常可能包含签名URL，服务不打印或回显异常正文。

函数配置按域名+IP每60秒180请求的基础限流；真实平台是否应用需要发布后检查，单元测试不能证明限流已上线。函数路径与入口相同。需要以支持Functions的Netlify持续部署或CLI发布 `site/netlify/functions`，只上传静态首页ZIP不会创建后端。主页无需新增复杂说明，原有宣发/下载保持独立。

本地验证在 `site` 执行 `npm ci`、`npm test`。测试使用注入时钟和有条件写/强读语义的内存store，覆盖owner冒用、角色/设备/scope绑定、nonce/cap、TTL/防重放、观察/答复/撤回、forget、并发、条件写假成功、错误脱敏及预览隔离。这些是主机逻辑证据，不等于真实Netlify持久化、移动端后台提醒或两部真机远程会话验证。

2026-10-02 已通过官方 CLI 发布至原 Netlify 站点。专门随机 QA 安装身份在真实生产 TLS / Blobs 上完成 12 项初始化检查：双方注册、错误身份拒绝、配对 offer/confirm、角色拒绝、求助排队、对方观察、明确接受、双方读取与撤回。相同产物再次生产发布后，2 项读取检查确认原关系和取消状态保留；最后 3 项检查撤销专用 QA 关系，并确认不能再求助。没有修改已有用户的家人关系，也没有公开 QA auth/cap。

首次部署 `6abeeda9bbdbc83ad4c97032`，当前部署 `6abeee9cb4651b458ae0c918`。本地脱敏结果为 `artifacts/netlify-live-qa/{init,verify,cleanup}-result.json`。这些结果证明生产协议及持久化，不包含真实手机加密 Chat 的首次配对及再次求助；该完整移动流程仍待单独验收。没有验证后台推送或平台实际限流阈值。

官方依据（核验日期2026-10-01）：[Blobs API、强一致与条件写](https://docs.netlify.com/build/data-and-storage/netlify-blobs/)、[Functions Context与配置](https://docs.netlify.com/build/functions/api/)、[基础限流](https://docs.netlify.com/manage/security/secure-access-to-sites/rate-limiting/)、[条件写错误问题 #741](https://github.com/netlify/primitives/issues/741)。
