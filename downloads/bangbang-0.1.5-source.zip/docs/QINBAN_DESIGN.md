# 早期方案与产品设计（历史参考）

> 本文保留 2026-10-01 的早期调研与设计快照，不是当前产品需求。后续已调整为安卓双角色、iOS 控制端、暖橙色、大/小方形按钮及家人呼叫；网站也已精简。当前审核请从[审核清单](REVIEW-bangbang.md)进入，以[产品需求](PRD-bangbang.md)与[技术方案](TECHNICAL_DESIGN-bangbang.md)明确的基线为准。

## 早期需求快照（部分已被后续要求替代）

- 应用名称「帮帮」，参考苹果的简洁设计风格。
- 老人不会操作手机，由熟悉的家人异地远程协助。
- 在连接码旁、开始共享前、接入请求中醒目提示不要把连接码给陌生人。
- 被控端与控制端均为 Android APK；暂不做 iOS。
- 尽可能无需自行部署服务器。
- 独立 Git 仓库维护并推送 GitHub。

## 2026-10-01 开源调研

| 项目 | 已核实能力 | 本次选择 |
| --- | --- | --- |
| [RustDesk](https://github.com/rustdesk/rustdesk) | Android 主控/被控、公共连接服务、自建服务、AGPL-3.0 | 采用 1.4.9 固定版本；适老化 UI 在它的真实远控底层上实现 |
| [RemotePhone](https://github.com/dpk404/remote-phone) | MIT；Android 采屏/无障碍触控、Wi-Fi、桌面控制端 | 适合轻量局域网改造，但异地仍需补服务；没有复制其代码 |
| [droidVNC-NG](https://github.com/bk138/droidVNC-NG) | Android VNC 服务、无 root、GPL-2.0 | 需另配 Android 控制端，公网使用需额外网络与加密配置 |
| [RemoteLink](https://github.com/TamTahiti/RemoteLink) | README 描述 Android 双端与多种传输，项目仍有阶段性路线图 | 未将 README 列出的能力视为已验证实现，未采用 |

## 连接架构

```mermaid
flowchart LR
  Elder[长辈手机：帮帮] <-->|优先建立直连的加密会话| Helper[家人手机：帮帮]
  Elder <-->|设备发现与必要时中转| Public[RustDesk 公共基础设施]
  Helper <-->|设备发现与必要时中转| Public
```

设备号码是稳定的 RustDesk ID，不是假装成一次性口令。知道号码不能跳过本地批准。长辈开始共享、确认远程请求，且任何时候能结束会话。首次配置保存为 click 审批，不展示无人值守流程。高级设置仍可显式调整上游能力。

## 适老界面

- 参考 Apple HIG 的清晰层级与无障碍设计：浅灰背景、纯白卡片、深色文字，仅交互动作使用蓝色，取消大片绿色与绿色文字。
- 24 dp 页面边距、18–24 dp 圆角、32 sp 页面标题，主按钮至少 64 dp；深色模式采用黑色背景和分层灰色卡片。
- 独立绘制双手机图标与插画；使用设备系统字体，不捆绑 Apple 专有字体或品牌图标。
- 同一 APK 的两个角色可切换，协助中不显示切换入口。
- 长辈端只聚焦权限、号码、开始/结束；家人端聚焦输入、连接、最近使用的号码。
- 系统权限拒绝或共享取消不能显示成“协助已开始”。
- 保留系统字号，布局支持滚动。显示状态来自真实服务模型。

设计参考：[Apple Color](https://developer.apple.com/design/human-interface-guidelines/color)、[Apple Accessibility](https://developer.apple.com/design/human-interface-guidelines/accessibility)、[Apple Layout](https://developer.apple.com/design/human-interface-guidelines/layout)。实现平台仍是 Android，系统授权与返回行为遵循 Android。

## 明确边界

无自动绕过 Android 权限、无静默后台控制、无冒称账号绑定或可信家人身份验证。请求中的设备名称由对端提供，需要通过电话及设备 ID 核对。没有自建服务费用，但公共服务可能不可用，首版不提供 SLA。没有专用语音通话 UI；协助时可保持电话沟通。
