# 家庭恢复服务部署准备

本目录只准备单机持久化后端，未创建云资源、购买主机或部署。可以复用项目方已有的 Linux 主机；与 RustDesk hbbs/hbbr、Netlify 家人呼叫服务分开运行。客户端仅在明确配置批准的 HTTPS `/v1/household` 后启用家庭管理，基础协助仍可免建家庭使用。

## 运行条件

- Node 内置 `node:sqlite`。本轮本机实测 **Node 24.19.0**；Docker 模板锁定官方 `24.21.0-bookworm-slim`，该容器镜像尚未本机构建或验收。依赖仅为 Node 标准库，没有 npm 服务依赖。
- 一台服务、一个本地持久数据卷、一个写入服务进程。SQLite WAL 不放在 Netlify 临时目录或网络文件系统，不通过复制多实例的方式扩容。
- 对外 HTTPS。容器仅映射宿主机回环地址 8788，由现有 TLS 反向代理转发。不要公开 HTTP 管理端口。
- 可信 `BANGBANG_FAMILY_ENDPOINT` 必须已经支持 `identity.verify`；支持内部撤销时双方还需相同私密 `BANGBANG_FAMILY_INTERNAL_SECRET`。

镜像核验（2026-10-02）：[Docker 官方 Node 标签列表](https://hub.docker.com/_/node)包含 `24.21.0-bookworm-slim`；直接向 Docker Hub Registry 的 `library/node/manifests/24.21.0-bookworm-slim` 做认证 HEAD 请求得到 HTTP 200，OCI index digest 为 `sha256:0e0ff40c39bc087845bfb27465a0df4ea419520094bc35842ff83dd8cbe6f9b6`。这确认该官方标签真实存在；本机没有可用 Docker CLI，因此没有构建镜像、启动容器或验证容器数据卷，不能把 registry 成功当作容器运行通过。

## 配置与启动

从仓库根目录执行，先在私密编辑器填写 `.env`：

```sh
cp deploy/household/.env.example deploy/household/.env
chmod 600 deploy/household/.env
docker compose -f deploy/household/compose.yaml config --quiet
docker compose -f deploy/household/compose.yaml build
docker compose -f deploy/household/compose.yaml up -d
```

不要用无 `--quiet` 的 compose config 输出私密环境变量。`Caddyfile.example` 仅供接入已有反向代理时替换批准的域名；本轮未安装 Caddy、申请域名或改变端口。

`BANGBANG_FAMILY_ENDPOINT` 是固定 HTTPS family 路径，禁止用户名、密码、query、fragment 或跟随重定向。原安装 Bearer 只转发给这个固定服务，不写入 SQLite 或日志。内部共享密钥是 32–128 字节安全随机值的 canonical base64url 文本；HMAC 使用该文本的 UTF-8 字节作 key，双方必须一致。不给浏览器或手机分发此密钥。

未配置内部密钥时，家庭恢复仍会在本库撤销旧设备，并记录 `not_configured`。只有收到 family 的匹配 `200 {revoked:true,installationId}` 才显示 `confirmed`；网络或存储失败保持 pending，由常驻服务每 15 秒重试，重启后继续。

不使用 Docker 时，设置 `BANGBANG_HOUSEHOLD_DB` 为受限本地目录中的绝对文件路径，配置固定 family endpoint，运行：

```sh
node site/server/household-http.mjs
```

默认仅监听 `127.0.0.1:8788`；配置 `BANGBANG_HOUSEHOLD_HOST` 和 `BANGBANG_HOUSEHOLD_PORT` 仅供受控容器网络。进程设置 umask 077，数据库权限 0600，使用 WAL、FULL 同步、外键与 `BEGIN IMMEDIATE` 事务。

## 维护与验收

停止/更新保留 `household-data` 卷，不执行 `docker compose down -v`。备份使用 SQLite 一致性备份或停止服务后复制整个数据库及 WAL 状态；加密保存。恢复旧备份可能回退设备撤销、已消费的恢复卡和邀请历史，必须在受控停写期间核对撤销队列与最新安全状态后恢复服务；不要把普通文件复制当作完整安全恢复。

本轮 schema version 为 1；高于当前版本的库拒绝启动。回滚应用不得删除库或改写 version。没有自动数据清理、外部灾备、跨机 HA 或远程账户人工找回机制，部署方需据实际规模安排磁盘与备份。服务只输出规范化启动/重试错误，不输出 Bearer、邀请码、恢复卡或用户称呼。

上线前用批准的测试家庭依次验证：双向配对来源、显式加入、称呼保留、移除/退出、旧机确认换机、丢机恢复卡、旧卡重放、旧机拒绝访问、family 凭据最终撤销、无网络时 pending 及恢复后重试。家庭恢复不会继承原远控能力、密码或屏幕共享权限，也不能强制断开已离线的原生协助；两端下次在线同步须处理已撤销状态。

完整接口和证据边界见 [家庭与换机恢复](../../docs/HOUSEHOLD_RECOVERY.md)。参考：[Node 24 SQLite](https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html)、[官方 Node 镜像](https://hub.docker.com/_/node)、[Caddy reverse_proxy](https://caddyserver.com/docs/caddyfile/directives/reverse_proxy)。
