# Oracle 连接服务器部署准备

目前只准备部署文件，没有创建 Oracle 账号或云主机。此模板也适用于支持 Docker Compose 的国内 Linux 主机。

Netlify 保留宣发、下载和家人请求接口；此主机只运行 RustDesk 的发现服务器 hbbs 与中转 hbbr。它与统计后台是两个独立组件。Oracle 免费资源受地区容量、账号资格和闲置资源回收规则影响，不是可用性承诺。查看 [Always Free 官方说明](https://docs.oracle.com/en-us/iaas/Content/FreeTier/freetier_topic-Always_Free_Resources.htm)。

## 部署

1. 创建明确标有 Always Free eligible 的 Ubuntu VM，确认系统与镜像架构一致；启用 SSH 密钥登录。不要选择付费形态。
2. 在云安全列表和主机防火墙同时放行 TCP 21115–21117、UDP 21116；SSH 22 仅允许管理 IP。21118/21119 WebSocket 和管理端口保持关闭。原生客户端不需要它们。
3. 安装 Docker Engine 与 Compose 插件，将本目录放到 `/opt/bangbang`，执行：

   ```sh
   cp .env.example .env
   # 编辑 RELAY_HOST 为这台 VM 的公网地址
   mkdir -p data
   chmod 700 data
   docker compose config --quiet
   docker compose pull
   docker compose up -d
   docker compose ps
   ```

4. 保存 `data/id_ed25519.pub` 公钥，两台客户端在“更多 → 连接与高级设置 → ID/中继服务器”配置相同的 ID 服务器、公钥和中继地址。保留 `-k _`，要求客户端提供正确公钥。
5. 在不同网络上完成一次正常接通、远程操作、挂断和再次呼叫，再验证中继连接。用客户端诊断的 `path=relay` 确认走过中继；仅看到容器运行或 TCP 端口开放不算远控成功。

模板固定 `1.1.16`，上线时记录实际拉取的镜像 digest、VM 区域和防火墙规则。依照 [RustDesk 官方部署说明](https://rustdesk.com/docs/en/self-host/rustdesk-server-oss/docker/) 使用 Linux host network。

## 留存与维护

- `data/` 内有私钥和登记数据库，私钥永不放进客户端、Git、网站或统计接口。公钥可配置给客户端。
- Docker 日志每服务最多约 15 MB；原生服务日志可能有网络地址和设备标识，仅用于受限运维排障，不自动传到埋点平台。需要导出时先脱敏。
- 客户端只上传枚举化的连接诊断到 Cloudflare，云主机的原始日志不进入成功率统计。
- 对 `data/` 做加密离线备份。变更密钥意味着所有客户端需要重新配置；不要删除数据目录作为重启手段。
- 停止：`docker compose stop`。回滚镜像时保留数据和密钥，重新做跨网络接通检查。
- 先设置流量、磁盘和预算提醒；发现免费资格或可用额度不足时停止创建资源。
